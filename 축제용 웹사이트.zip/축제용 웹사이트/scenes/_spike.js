// scenes/_spike.js — 컴퓨트 파티클 성능/호환성 스파이크 (개발·점검용)
//   열기:  http://localhost:8123/?spike&autostart=1            (WebGPU)
//          http://localhost:8123/?spike&autostart=1&webgl=1     (WebGL2 폴백 강제)
//   옵션:  &n=500000  파티클 수 직접 지정 /  &q=mid  품질 단계 지정

import { SceneBase } from './_base.js';
import { ParticleField } from '../engine/particles.js';
import { Track } from '../engine/camera.js';

export default class Spike extends SceneBase {
  async warmup() {
    const q = new URLSearchParams(location.search);
    this.target = Number(q.get('n')) || this.quality.particleCap;
    // bright 는 겹침 밀도에 맞춰 낮게: 가산 블렌딩에서 100만 개가 겹치면 쉽게 하얗게 날아간다
    this.field = new ParticleField({ renderer: this.ctx.renderer, count: this.target, radius: 10, size: 0.05, bright: 0.05 });
    this.field.reset();
    this.field.update(0.016, 0, 0);          // 컴퓨트 파이프라인을 미리 컴파일
    this.track = new Track({
      pos: [[16, 4, 0], [0, 6, 16], [-16, 3, 0], [0, -5, -16], [16, 4, 0]],
      look: [[0, 0, 0]], fov: [55, 55], ease: (u) => u, scale: 10,
    });
    this.tw = 0;
  }

  start() {
    this.root.add(this.field.mesh);
    this.tw = 0;
    this.hud.add({
      id: 'spike-n', owner: this.id, anchor: [0, 0, 0], offset: [140, -110],
      text: () => `PARTICLES ${this.field.count.toLocaleString()}`, sub: `COMPUTE · ${this.ctx.backend.toUpperCase()}`,
    });
  }

  onQuality() { this.field.setCount(Math.min(this.target, this.quality.particleCap)); }

  update(t, dt) {
    this.tw += dt;
    this.field.update(dt, this.tw, this.audio.bass);
    this.cam(this.track.at(((t % 40) / 40)));
  }

  dispose() { this.field.mesh.removeFromParent(); }
}
