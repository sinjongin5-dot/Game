// scenes/_stub.js — "빈 씬" (2단계 검증용 자리표시자)
//
//  엔진이 제대로 동작하는지 눈과 귀로 확인하기 위한 최소한의 씬이다. 각 챕터를 구현할 때 이 파일을 상속하는 대신
//  scenes/chN.js 를 SceneBase 기반으로 새로 작성해서 교체한다.
//
//  확인되는 것: 씬 생명주기, 겹침 구간 카메라 블렌딩, 가중치 페이드, 불릿타임(timeScaleAt), 플래시/쉐이크,
//             HUD 투영, 오디오 드론/임팩트, 루프 반복·dispose 누수.

import * as THREE from 'three/webgpu';
import { SceneBase } from './_base.js';
import { Track } from '../engine/camera.js';
import { curve, smoothstep } from '../engine/ease.js';

// 씬별 자리표시자 모양/색/음 (id 기준)
const STYLES = {
  sun:    { color: 0xff8a1f, shape: 'sphere',   note: 55.0 },
  comet:  { color: 0x22e6ff, shape: 'cone',     note: 61.7 },
  entry:  { color: 0xff5a2a, shape: 'octa',     note: 65.4 },
  impact: { color: 0xffffff, shape: 'ico',      note: 73.4 },
  ch1:    { color: 0xbfe2ff, shape: 'sphere',   note: 82.4 },
  ch2:    { color: 0x1fd6c8, shape: 'ico',      note: 98.0 },
  ch3:    { color: 0xff3b30, shape: 'torus',    note: 110.0 },
  ch4:    { color: 0xffe08a, shape: 'octa',     note: 123.5 },
  ch5:    { color: 0xffd23a, shape: 'cylinder', note: 87.3 },
  ch6:    { color: 0x2f7bff, shape: 'torus',    note: 73.4 },
  ch7:    { color: 0x7dff6a, shape: 'cone',     note: 65.4 },
  finale: { color: 0x4dff9a, shape: 'sphere',   note: 55.0 },
  credits:{ color: 0x7dff6a, shape: 'ico',      note: 49.0 },
  bridge: { color: 0xffa040, shape: 'sphere',   note: 55.0 },
};

function geometryFor(shape) {
  switch (shape) {
    case 'cone': return new THREE.ConeGeometry(1.6, 3.4, 5);
    case 'octa': return new THREE.OctahedronGeometry(2.1, 0);
    case 'ico': return new THREE.IcosahedronGeometry(2.1, 1);
    case 'torus': return new THREE.TorusKnotGeometry(1.5, 0.45, 96, 12);
    case 'cylinder': return new THREE.CylinderGeometry(1.0, 1.0, 3.2, 24);
    default: return new THREE.SphereGeometry(2.1, 32, 20);
  }
}

export class StubScene extends SceneBase {
  constructor(ctx, def) {
    super(ctx, def);
    this.style = STYLES[def.id] || STYLES.sun;
    this.index = ctx.config.scenes.findIndex((s) => s.id === def.id);
  }

  async warmup() {
    const { color, shape } = this.style;
    const c = new THREE.Color(color).multiplyScalar(1.8);       // 1 초과 = HDR → 블룸에 걸림
    this.coreMat = new THREE.MeshBasicNodeMaterial({ color: c, transparent: true, opacity: 1, depthWrite: false });
    this.wireMat = new THREE.MeshBasicNodeMaterial({ color: new THREE.Color(0xffffff), wireframe: true, transparent: true, opacity: 1, depthWrite: false });
    this.satMat = new THREE.MeshBasicNodeMaterial({ color: new THREE.Color(0xffffff).multiplyScalar(2.2), transparent: true, opacity: 1, depthWrite: false });

    const geo = geometryFor(shape);
    this.core = new THREE.Mesh(geo, this.coreMat);
    this.wire = new THREE.Mesh(geo, this.wireMat); this.wire.scale.setScalar(1.06);
    this.spin = new THREE.Group();
    this.spin.add(this.core, this.wire);
    const satGeo = new THREE.SphereGeometry(0.12, 10, 8);
    for (let i = 0; i < 18; i++) {
      const m = new THREE.Mesh(satGeo, this.satMat);
      const a = (i / 18) * Math.PI * 2;
      m.position.set(Math.cos(a) * 4.2, Math.sin(a * 3) * 0.8, Math.sin(a) * 4.2);
      this.spin.add(m);
    }
    this.root.add(this.spin);

    // 카메라 돌리: 씬마다 시작 각도·방향·반경이 달라서 겹침 구간의 블렌딩이 눈에 보인다
    const dir = this.index % 2 ? -1 : 1, a0 = this.index * 0.9, R = 8 + (this.index % 3), pts = [];
    for (let i = 0; i <= 6; i++) { const a = a0 + dir * (i / 6) * 1.6; pts.push([Math.cos(a) * R, 1.2 + Math.sin(i) * 1.5, Math.sin(a) * R]); }
    this.track = new Track({ pos: pts, look: [[0, 0, 0]], fov: [48, 58], scale: R });
  }

  start() {
    const id = this.id, { audio, post, camRig } = this;
    this.spin.rotation.set(0, 0, 0);

    // HUD: 3D 오브젝트에 붙어 따라다니는 라벨 (다이제틱 HUD 검증)
    this.hud.add({
      id: `${id}-label`, owner: id, anchor: this.core, text: (t) => `${this.def.label}`, sub: `STUB · ${id}`,
      offset: [110, -90], from: this.def.start + 0.5, to: this.def.end - 0.5,
    });

    // 소리: 씬마다 다른 근음의 드론 + 시작 핑
    const n = this.style.note;
    this.own(audio.drone({ freqs: [n, n * 1.5, n * 2], level: 0.2, cutoff: 500 + this.index * 40, fadeIn: 1.5 }));
    audio.ping({ freq: n * 8, level: 0.12 });

    // 충돌 씬: 화이트 플래시 + 쉐이크 + 쾅 (연출 도구 검증)
    if (id === 'impact') { post.flashPulse(1, 2.4); camRig.shake(1.2); audio.hit({ freq: 46, level: 0.85 }); }
    if (id === 'ch4') this.own(audio.riser({ dur: 3, from: 300, to: 4000, level: 0.2 }));
  }

  /** 불릿타임 검증: ch2 는 8~12초 구간에서 0.02~0.05배, entry 는 마지막 0.5초 슬로모션 */
  timeScaleAt(t) {
    if (this.id === 'ch2') return curve([[0, 1], [7, 1], [8.5, 0.03], [12, 0.03], [13.5, 1]], t);
    if (this.id === 'entry') return curve([[0, 1], [7.3, 1], [7.6, 0.15], [8.5, 0.15]], t);
    return 1;
  }

  update(t, dt) {
    const w = this.weight, id = this.id;
    this.spin.rotation.y += dt * 0.5; this.spin.rotation.x += dt * 0.17;
    const sc = 0.92 + 0.08 * Math.sin(t * 2.0);
    this.core.scale.setScalar(sc * (0.6 + 0.4 * w));
    this.coreMat.opacity = 0.55 * w; this.wireMat.opacity = 0.9 * w; this.satMat.opacity = w;

    this.cam(this.track.at(this.progress(t)));

    // 루프 경계: bridge 는 마지막 1초 동안 화이트로, sun 은 처음 1.2초 동안 화이트에서 걷힌다 (경계 컷은 화이트 플래시로 처리)
    if (id === 'bridge') this.post.setFlash(smoothstep((t - (this.len - 1.0)) / 1.0));
    if (id === 'sun') this.post.setFlash(1 - smoothstep(t / 1.2));
  }

  dispose() {
    // 캐시 자원(geometry/material)은 유지. 이번 바퀴에서만 만든 것(HUD 항목, 소리)은 Director/SceneBase 가 이미 정리했다.
  }
}
