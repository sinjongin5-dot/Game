// scenes/finale.js — 피날레: 초록 오로라 (245~265초)
//
//  와우 모먼트: 냉각탑의 수증기를 타고 올라온 눈부신 하양이 걷히면, 한반도 위 밤하늘에 초록 오로라가 커튼처럼 걸리고
//  야경 불빛이 초록으로 물든다. 카메라는 지구 궤도를 따라 천천히 내려앉았다가 다시 멀어진다 ("과학으로 만드는 깨끗한 에너지").
//  이 궤도는 크레딧 씬(265~275)이 이어받는다 — shared/aurora.js 의 orbitPose(0~30초).
//  연출상의 상징이다: 실제 한반도 하늘에 이런 오로라가 걸리는 것은 아니다.
//  자막: config.js (finale)

import * as THREE from 'three/webgpu';
import { SceneBase } from './_base.js';
import { Shared } from './_shared.js';
import { makeStars } from './shared/space.js';
import { makeEarth, EARTH_R, EARTH_POS } from './shared/earth.js';
import { makeAurora, orbitPose } from './shared/aurora.js';
import { hackProfile } from '../ui/hack.js';
import { makePose } from '../engine/camera.js';
import { clamp, smoothstep } from '../engine/ease.js';

export default class Finale extends SceneBase {
  async warmup() {
    const ctx = this.ctx;
    this.stars = await Shared.create(ctx, 'stars', makeStars);
    this.earth = await Shared.create(ctx, 'earth', makeEarth);
    this.aurora = await Shared.create(ctx, 'aurora', makeAurora);
    this.pose = makePose(); this.pose.near = 0.2; this.pose.far = 9000;
  }

  start() {
    const ctx = this.ctx;
    Shared.acquire(ctx, 'stars'); Shared.acquire(ctx, 'earth'); Shared.acquire(ctx, 'aurora');
    this._acc = 0; this._tickT = 0;
    this.onQuality();
    const a = this.audio;
    // 밝아지는 화음: D 장조 9 (D4 F#4 A4 C#5 E5) + 낮은 지속음
    this.pad = this.own(a.drone({ freqs: [293.7, 370.0, 440.0, 554.4, 659.3], level: 0.0001, cutoff: 3800, type: 'sine', fadeIn: 0.2, bus: 'music', detune: 4 }));
    this.sub = this.own(a.drone({ freqs: [73.4, 110.0], level: 0.12, cutoff: 300, fadeIn: 2.5, detune: 5 }));
    this.air = this.own(a.wind({ level: 0.05, center: 1800, fadeIn: 3 }));
  }

  onQuality() { this.aurora.setCount(Math.min(36000, this.quality.particleCap * 0.18)); }

  update(t, dt, dtReal) {
    const w = this.weight, post = this.post, ctx = this.ctx, a = this.audio, p = this.pose;
    post.blendBloom(1.15, w);
    const tt = Math.max(0, t);
    orbitPose(tt, p);
    p.scale = 60; p.near = 0.2; p.far = 9000;
    this.cam(p);

    // 지구 디테일/구름 + 오로라 + 야경의 초록 물듦
    const alt = p.pos.distanceTo(EARTH_POS) - EARTH_R;
    this.earth.uDetail.value = clamp(1 - (alt - 0.5) / 30);
    this.earth.uCloudSpin.value = ctx.u.time.value * 0.0006;
    this.aurora.uAur.value = smoothstep((tt - 1.0) / 4.5) * w;
    this.earth.uGreen.value = smoothstep((tt - 3.0) / 6.0);
    this.aurora.uCor.value = ctx.config.hack?.enabled ? hackProfile(this.def.start + t, ctx.config.hack).cor : 0;       // 끝 무렵 해킹 연출이 시작되면 오로라가 오염되기 시작

    // 시작: 수증기 구름의 하양이 걷히며 지구가 드러난다
    post.setFlash(1 - smoothstep(tt / 1.8));
    post.u.anamorphic.value = ctx.config.post.anamorphic.strength * (0.6 + 0.5 * smoothstep((tt - 5) / 4));

    this._acc += dtReal;
    if (this._acc > 0.12) {
      this._acc = 0;
      this.pad.setLevel(0.1 * smoothstep((tt - 0.5) / 5) * w, 0.5);
      this.sub.setLevel(0.1 + 0.05 * smoothstep((tt - 6) / 6), 0.5);
    }
    this.once('open', t > 0.2, () => { a.whoosh({ dur: 2.2, from: 4000, to: 400, level: 0.22 }); a.hit({ freq: 49, level: 0.5, decay: 2.6, noise: 0.35 }); });
    this.once('aur', t > 3.4, () => { a.riser({ dur: 3.0, from: 400, to: 3600, level: 0.14 }); });
    // 반짝이는 높은 음 아르페지오(오로라가 커질수록 촘촘해짐)
    if (t > 4 && t > this._tickT) {
      const notes = [0, 4, 7, 11, 14, 16, 19];
      this._tickT = t + 0.55 - 0.3 * smoothstep((t - 4) / 8);
      a.ping({ freq: 587.3 * Math.pow(2, notes[Math.floor(Math.random() * notes.length)] / 12), level: 0.045, decay: 1.8 });
    }
  }

  dispose() {
    const ctx = this.ctx;
    Shared.release(ctx, 'stars'); Shared.release(ctx, 'earth'); Shared.release(ctx, 'aurora');
    this.aurora.uCor.value = 0;
    this.post.u.anamorphic.value = ctx.config.post.anamorphic.strength;
  }
}
