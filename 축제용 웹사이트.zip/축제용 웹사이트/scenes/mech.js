// scenes/mech.js — Ch.6a 핵심 기계 해부 (175~232초)
//
//  와우 모먼트: 가압경수로의 핵심 기계 6대를 "분해도 + 단면도"로 하나씩 해부한다. 분해된 부품이 조립되고, 단면이 열리고, 안에서 냉각재·증기·자기력선이 흐른다.
//   ① 원자로 용기(분해도 → 단면 → 냉각재 흐름 → 제어봉 SCRAM)  ② 원자로냉각재펌프  ③ 가압기  ④ 증기발생기  ⑤ 터빈  ⑥ 발전기
//  각 기계는 자기 무대(원점)에서 따로 만들어져 있고, 스캔 라인 전환으로 다음 기계로 넘어간다(shared/mech/*.js).
//  자막·키워드 카드: config.js (mech). 화면 속 수치는 "대표 가압경수로(APR1400급)"의 일반 자료이며 각 파일 주석에 출처를 적었다.

import * as THREE from 'three/webgpu';
import { SceneBase } from './_base.js';
import { stageFloor, stageBackdrop, dimLine } from './shared/mech/kit.js';
import { makeReactor } from './shared/mech/reactor.js';
import { makeRCP } from './shared/mech/rcp.js';
import { makePressurizer, PZR } from './shared/mech/pressurizer.js';
import { makeSteamGen } from './shared/mech/steamGen.js';
import { makeTurbine } from './shared/mech/turbine.js';
import { makeGenerator } from './shared/mech/generator.js';
import { makePose } from '../engine/camera.js';
import { clamp, lerp, spline, smoothstep, easeInOutCubic, easeOutCubic } from '../engine/ease.js';

const ST = new THREE.Vector3(0, -8000, 0);                                       // 무대 전체 위치(다른 장면과 멀리)
const GAP = 140;                                                                 // 기계 무대 간 간격(+x)
// 기계별 구간(로컬 초)과 카메라 웨이포인트 [u, 위치xyz, 시선xyz, FOV] (u = 구간 진행도, 기계 원점 기준)
const STAGES = [
  { id: 'reactor', i: 0, t0: 0, t1: 11, wp: [
    [0, 16, 10, 32, 0, 10, 0, 40], [0.2, 8, 8, 23, 0, 7.4, 0, 42], [0.34, 3.2, 3.2, 8.5, 0, 4.6, 0, 46], [0.5, 0.2, 1.8, 6.5, 0, 6.5, 0, 52],
    [0.62, 4.5, 12.0, 6.8, 0.5, 11.4, -0.5, 46], [0.76, 6, 7.5, 18, 0, 6.8, 0, 42], [0.9, 12, 8, 24, 0, 7.4, 0, 42], [1, 14, 8, 25, 0, 7.4, 0, 42]] },
  { id: 'rcp', i: 1, t0: 11, t1: 19.5, wp: [
    [0, 11, 5, 17, 0, 4, 0, 42], [0.25, 6, 1.0, 9, 0.5, 0.7, 0, 46], [0.5, 2.5, 3.2, 6.5, 0, 3.0, 0, 44], [0.75, 5.5, 6.5, 11, 0, 6.4, 0, 44], [1, 12, 5.5, 18, 0, 4.2, 0, 42]] },
  { id: 'prz', i: 2, t0: 19.5, t1: 28, wp: [
    [0, 14, 7.5, 26, 0, 7.5, 0, 42], [0.3, 4.5, 3.2, 9.5, 0, 2.6, 0, 46], [0.55, 5, 11.5, 12, 0.5, 11.8, 0, 46], [0.78, 3.4, 15.4, 8.5, 0, 14.8, 0, 46], [1, 12, 9, 26, 0, 8, 0, 42]] },
  { id: 'sg', i: 3, t0: 28, t1: 38, wp: [
    [0, 22, 12, 38, 0, 11.5, 0, 42], [0.2, 6, 2.6, 11, -0.5, 1.8, 0, 48], [0.4, 2.2, 5.5, 8.5, 0, 7.0, 0, 46], [0.6, 3.5, 13.2, 8.5, 0, 13.6, 0, 48], [0.8, 5, 18, 12, 0, 18.4, 0, 46], [1, 20, 14, 40, 0, 12, 0, 42]] },
  { id: 'turb', i: 4, t0: 38, t1: 48.5, wp: [
    [0, 0, 8, 40, -1, 4.5, 0, 42], [0.2, -9.5, 4.8, 12, -9.5, 3.6, 0, 46], [0.38, -6.5, 5.5, 8, -6.0, 3.6, 0, 50], [0.55, 2.5, 5.5, 14, 6.5, 3.8, 0, 46],
    [0.72, 14, 4, 9, 11, 3.6, 0, 52], [0.88, 6, 10, 30, 3, 5, 0, 44], [1, 0, 8, 38, 0, 4.5, 0, 42]] },
  { id: 'gen', i: 5, t0: 48.5, t1: 57, wp: [
    [0, 2, 8, 34, 0, 4, 0, 42], [0.25, -3, 3.8, 11, -2, 3.4, 0, 48], [0.5, 5.6, 4.6, 7.5, 5.4, 3.4, 0, 50], [0.7, 0.5, 1.2, 9, 0.5, 1.2, 0, 50], [1, 4, 8, 34, 2, 4, 0, 42]] },
];
const TRANS = [11, 19.5, 28, 38, 48.5];                                          // 스캔 라인 전환 시각
const camAt = (wp, u, k) => spline(wp.map((w) => [w[0], w[k]]), u);
const V = new THREE.Vector3();
const stageOf = (t) => { for (let i = STAGES.length - 1; i >= 0; i--) if (t >= STAGES[i].t0) return STAGES[i]; return STAGES[0]; };

export default class Mech extends SceneBase {
  async warmup() {
    const ctx = this.ctx;
    this.stage = new THREE.Group(); this.stage.position.copy(ST); this.root.add(this.stage);
    this.m = {
      reactor: makeReactor(ctx), rcp: makeRCP(ctx), prz: makePressurizer(ctx), sg: makeSteamGen(ctx), turb: makeTurbine(ctx), gen: makeGenerator(ctx),
    };
    Object.values(STAGES).forEach((s) => {
      const mm = this.m[s.id]; if (!mm) return;
      const g = new THREE.Group(); g.position.set(s.i * GAP, 0, 0); g.add(mm.root); g.add(stageFloor(70, -0.7, 1.0)); g.add(stageBackdrop(150, 80, -26, 11));
      if (s.id === 'reactor') g.add(dimLine([-5.2, 0, 0.5], [-5.2, 14.2, 0.5], 0.3));                       // 청사진풍 치수선(높이)
      if (s.id === 'sg') g.add(dimLine([-7.4, 0, 0.5], [-7.4, 21.6, 0.5], 0.35));
      if (s.id === 'prz') g.add(dimLine([-3.6, 0.9, 0.5], [-3.6, 14.5, 0.5], 0.3));
      this.stage.add(g); mm.holder = g;
    });
    this.pose = makePose(); this.pose.near = 0.1; this.pose.far = 3000;
    this._st = null; this._spin = 0; this._tspin = 0; this._gspin = 0;
  }

  start() {
    this._acc = 0; this._st = null; this._spin = 0; this._tspin = 0; this._gspin = 0;
    const s0 = this.def.start, id = this.id;
    const H = (o) => this.hud.add({ owner: id, ...o });
    const at = (i, x, y, z) => () => V.set(i * GAP + x, y, z).add(ST);
    // ① 원자로 용기
    H({ id: `${id}-head`, anchor: at(0, 0.9, 13.2, -0.4), text: '상부 덮개 + 제어봉 구동장치(CRDM) 61기', sub: 'CLOSURE HEAD · CONTROL ROD DRIVE MECHANISM', offset: [-110, -50], from: s0 + 0.8, to: s0 + 3.4, color: '#7be8ff' });
    H({ id: `${id}-studs`, anchor: at(0, 2.62, 11.7, -0.5), text: '스터드 볼트 54개', sub: '155기압의 힘을 버티는 체결부', offset: [90, -60], from: s0 + 1.2, to: s0 + 3.6, color: '#ffd27a' });
    H({ id: `${id}-guide`, anchor: at(0, 1.5, 14.0, -0.5), text: '상부 안내구조물 + 제어봉집합체(CEA)', sub: 'UPPER GUIDE STRUCTURE', offset: [120, -40], from: s0 + 1.6, to: s0 + 3.8, color: '#cfe3ff' });
    H({ id: `${id}-fuel`, anchor: at(0, 0.7, 5.2, -0.1), text: '연료집합체 241개 (APR1400)', sub: '노심 · 푸른 체렌코프 빛', offset: [110, 70], from: s0 + 3.6, to: s0 + 6.4, color: '#6ec8ff' });
    H({ id: `${id}-barrel`, anchor: at(0, -2.07, 7.6, 0), text: '노심 지지통(core barrel)', sub: '노심을 붙잡고 냉각수 길을 만듦', offset: [-110, -60], from: s0 + 3.9, to: s0 + 6.2, color: '#cfe3ff' });
    H({ id: `${id}-wall`, anchor: at(0, -2.45, 4.0, 0), text: '용기 벽: 저합금강 약 25 cm', sub: '내면 스테인리스 클래딩 · 내경 약 4.6 m', offset: [-140, 60], from: s0 + 4.2, to: s0 + 6.6, color: '#ffffff' });
    H({ id: `${id}-in`, anchor: at(0, 3.2, 9.6, -2.6), text: '저온관(입구) 4개 · 약 291 °C', sub: 'COLD LEG', offset: [70, -60], from: s0 + 5.0, to: s0 + 7.2, color: '#78b8ff' });
    H({ id: `${id}-out`, anchor: at(0, 4.1, 8.9, 0), text: '고온관(출구) 2개 · 약 324 °C', sub: 'HOT LEG', offset: [80, 40], from: s0 + 5.2, to: s0 + 7.4, color: '#ff8c5a' });
    H({ id: `${id}-scram`, anchor: at(0, 0, 9.4, 0), text: 'SCRAM — 원자로 비상정지', sub: '전자석 전류가 끊기면 제어봉이 중력으로 낙하', offset: [120, -70], from: s0 + 8.0, to: s0 + 10.8, color: '#ff5a5a' });
    H({ id: `${id}-dim`, anchor: at(0, -5.2, 7.1, 0.5), text: '전체 높이 약 13~14 m', sub: '내경 약 4.6 m · 무게 수백 톤', offset: [-130, 0], from: s0 + 0.6, to: s0 + 3.2, color: '#62d8ff' });
    // ② 원자로냉각재펌프
    const a2 = s0 + 11;
    H({ id: `${id}-rcp-motor`, anchor: at(1, 1.0, 6.0, 0), text: '대형 전동기', sub: '고정자 코일 · 회전자 · 수 MW급', offset: [90, -50], from: a2 + 0.8, to: a2 + 3.2, color: '#7be8ff' });
    H({ id: `${id}-rcp-fly`, anchor: at(1, 0.75, 7.6, 0), text: '플라이휠', sub: '전원이 끊겨도 관성으로 계속 회전', offset: [110, -40], from: a2 + 2.2, to: a2 + 4.6, color: '#ffd27a' });
    H({ id: `${id}-rcp-seal`, anchor: at(1, 0.55, 3.2, 0), text: '3단 축 밀봉(seal)', sub: '155기압을 막는 정밀 부품', offset: [-130, -30], from: a2 + 3.8, to: a2 + 6.0, color: '#ffb36b' });
    H({ id: `${id}-rcp-tb`, anchor: at(1, 0.7, 2.0, 0), text: '열차단기', sub: '냉각수 코일이 열을 막음', offset: [120, 40], from: a2 + 4.0, to: a2 + 6.0, color: '#78b8ff' });
    H({ id: `${id}-rcp-imp`, anchor: at(1, 0.5, 0.8, 0), text: '임펠러 (날개 9개) · 약 1,200 rpm', sub: '물을 가속시켜 원자로로 밀어 보냄', offset: [-150, 40], from: a2 + 1.4, to: a2 + 4.0, color: '#ffffff' });
    H({ id: `${id}-rcp-out`, anchor: at(1, 3.2, 0.9, 0), text: '토출 노즐 → 원자로', sub: 'COLD LEG', offset: [20, -70], from: a2 + 6.0, to: a2 + 8.2, color: '#78b8ff' });
    // ③ 가압기
    const a3 = s0 + 19.5;
    H({ id: `${id}-pz-heat`, anchor: at(2, 0.4, 2.5, -0.3), text: '전열기(히터) 약 78개', sub: '물을 데워 증기를 만듦 → 압력 ↑', offset: [120, 40], from: a3 + 1.2, to: a3 + 3.6, color: '#ff9a5a' });
    H({ id: `${id}-pz-lvl`, anchor: at(2, 1.3, 7.6, 0), text: () => `${(155 + 0.7 * Math.sin(ctxT() * 0.9)).toFixed(1)} bar`, sub: '아래는 물, 위는 증기 · 포화 약 345 °C', offset: [110, -30], from: a3 + 2.2, to: a3 + 8.0, color: '#7be8ff' });
    H({ id: `${id}-pz-spray`, anchor: at(2, 0.0, 13.0, 0), text: '스프레이 노즐', sub: '차가운 물을 뿌려 증기 응축 → 압력 ↓', offset: [140, -40], from: a3 + 4.6, to: a3 + 7.0, color: '#78b8ff' });
    H({ id: `${id}-pz-valve`, anchor: at(2, 0.0, 16.6, -0.25), text: '안전밸브 3기(스프링식)', sub: '압력이 너무 오르면 열려 증기를 방출', offset: [120, 20], from: a3 + 6.0, to: a3 + 8.4, color: '#ff7a7a' });
    H({ id: `${id}-pz-surge`, anchor: at(2, 3.4, -1.5, 0), text: '서지관 → 고온관', sub: '계통의 부피 변화를 흡수', offset: [60, 50], from: a3 + 0.8, to: a3 + 3.0, color: '#cfe3ff' });
    // ④ 증기발생기
    const a4 = s0 + 28;
    H({ id: `${id}-sg-in`, anchor: at(3, -3.4, 0.95, 0), text: '1차 입구(고온관) 약 324 °C', sub: 'HOT LEG IN', offset: [-30, -70], from: a4 + 1.4, to: a4 + 4.0, color: '#ff8c5a' });
    H({ id: `${id}-sg-out`, anchor: at(3, 3.4, 0.95, 0), text: '1차 출구(저온관) 약 291 °C', sub: 'COLD LEG OUT', offset: [30, -70], from: a4 + 1.6, to: a4 + 4.0, color: '#78b8ff' });
    H({ id: `${id}-sg-ts`, anchor: at(3, 1.4, 2.4, -0.1), text: '관판(tubesheet)', sub: '수천 개 구멍에 U자관을 확관·용접', offset: [110, 40], from: a4 + 2.4, to: a4 + 4.8, color: '#ffd27a' });
    H({ id: `${id}-sg-tube`, anchor: at(3, 1.0, 9.5, -0.1), text: 'U자관 다발', sub: '관 안 1차수 · 관 밖 2차수 — 섞이지 않고 열만 전달', offset: [120, -20], from: a4 + 4.0, to: a4 + 6.6, color: '#ff9a5a' });
    H({ id: `${id}-sg-sep`, anchor: at(3, 0.9, 14.2, 0), text: '습분분리기', sub: '소용돌이로 물방울을 원심 분리', offset: [-130, -30], from: a4 + 5.8, to: a4 + 8.0, color: '#cfe3ff' });
    H({ id: `${id}-sg-dry`, anchor: at(3, -1.0, 17.7, 0), text: '건조기(지그재그 판)', sub: '남은 물방울까지 걸러 건조 증기로', offset: [-130, -40], from: a4 + 6.6, to: a4 + 8.6, color: '#ffffff' });
    H({ id: `${id}-sg-fw`, anchor: at(3, 3.4, 16.7, 0), text: '급수 링 ← 급수관', sub: 'FEEDWATER RING', offset: [60, -50], from: a4 + 4.8, to: a4 + 6.6, color: '#78b8ff' });
    H({ id: `${id}-sg-steam`, anchor: at(3, 3.4, 24.9, 0), text: '주증기 → 터빈 (약 70 bar)', sub: 'MAIN STEAM', offset: [40, 30], from: a4 + 8.0, to: a4 + 9.8, color: '#ffe08a' });
    H({ id: `${id}-sg-dim`, anchor: at(3, -7.4, 10.8, 0.5), text: '높이 약 20 m 이상', sub: '대형 원전의 가장 큰 열교환기', offset: [-130, 0], from: a4 + 0.4, to: a4 + 2.6, color: '#62d8ff' });
    H({ id: `${id}-pz-dim`, anchor: at(2, -3.6, 7.7, 0.5), text: '높이 십여 m', sub: '압력 15.5 MPa · 포화 약 345 °C', offset: [-130, 0], from: a3 + 0.2, to: a3 + 2.0, color: '#62d8ff' });
    // ⑤ 터빈
    const a5 = s0 + 38;
    H({ id: `${id}-tb-in`, anchor: at(4, -9.5, 9.8, 0), text: '주증기 입구 · 제어밸브', sub: '약 70 bar 증기를 터빈 중앙으로', offset: [-60, -60], from: a5 + 0.8, to: a5 + 3.0, color: '#ffe08a' });
    H({ id: `${id}-tb-hp`, anchor: at(4, -9.5, 6.4, 0), text: '고압터빈(HP) — 복류 8단', sub: '증기가 중앙에서 좌우로 갈라져 흐름', offset: [70, -60], from: a5 + 1.6, to: a5 + 4.0, color: '#ff9a5a' });
    H({ id: `${id}-tb-st`, anchor: at(4, -6.1, 5.0, 0), text: '고정 노즐 → 회전 버킷', sub: '단마다 압력이 떨어지며 회전력을 얻음', offset: [90, -60], from: a5 + 3.6, to: a5 + 6.0, color: '#ffffff' });
    H({ id: `${id}-tb-msr`, anchor: at(4, 4.5, 12.4, 0), text: '습분분리재열기(MSR)', sub: '물방울을 거르고 다시 가열', offset: [-80, -50], from: a5 + 4.8, to: a5 + 7.0, color: '#7be8ff' });
    H({ id: `${id}-tb-lp`, anchor: at(4, 7.0, 7.4, 0), text: '저압터빈(LP) — 날개가 점점 길어짐', sub: '증기가 팽창할수록 부피가 커진다', offset: [90, -50], from: a5 + 5.4, to: a5 + 7.8, color: '#78b8ff' });
    H({ id: `${id}-tb-last`, anchor: at(4, 12.8, 6.0, 0), text: '마지막 단 날개 길이 1.5 m급', sub: 'LAST STAGE BLADE', offset: [20, -70], from: a5 + 6.8, to: a5 + 9.0, color: '#cfe3ff' });
    H({ id: `${id}-tb-rpm`, anchor: at(4, 0.0, 1.2, 0), text: '실제 회전수 1,800 rpm (화면은 슬로모션)', sub: '60 Hz 계통 · 4극 발전기와 직결', offset: [0, 60], from: a5 + 2.4, to: a5 + 9.8, color: '#ffd27a' });
    // ⑥ 발전기
    const a6 = s0 + 48.5;
    H({ id: `${id}-gn-rotor`, anchor: at(5, 0.0, 4.4, 0.0), text: '회전자 — 4극 전자석 (N·S·N·S)', sub: '직류 계자 전류 · 1,800 rpm', offset: [0, -90], from: a6 + 1.2, to: a6 + 3.6, color: '#ff8c8c' });
    H({ id: `${id}-gn-core`, anchor: at(5, -3.0, 5.2, 0), text: '고정자 철심', sub: '얇은 규소강판을 겹쳐 와전류 손실 감소', offset: [-120, -50], from: a6 + 2.2, to: a6 + 4.8, color: '#cfe3ff' });
    H({ id: `${id}-gn-coil`, anchor: at(5, 1.5, 4.8, 0), text: '3상 구리 코일 — 유도 전류', sub: '패러데이 법칙 · 60 Hz', offset: [100, -50], from: a6 + 3.0, to: a6 + 5.4, color: '#ffb36b' });
    H({ id: `${id}-gn-end`, anchor: at(5, 5.6, 4.6, 0), text: '엔드 와인딩', sub: '코일이 곡선으로 돌아 나오는 부분', offset: [80, -60], from: a6 + 4.8, to: a6 + 6.6, color: '#ffb36b' });
    H({ id: `${id}-gn-h2`, anchor: at(5, 0.0, 6.6, -0.6), text: '수소 냉각기', sub: '수소 가스로 회전자 냉각 · 코일은 순수 냉각수', offset: [-90, -40], from: a6 + 3.8, to: a6 + 6.2, color: '#7be8ff' });
    H({ id: `${id}-gn-out`, anchor: at(5, 0.0, 0.9, -0.4), text: '단자(부싱) 3상 → 변압기', sub: '약 20 kV대 → 345·765 kV 승압 송전', offset: [90, 40], from: a6 + 5.6, to: a6 + 8.2, color: '#ffe08a' });
    H({ id: `${id}-gn-mw`, anchor: at(5, 8.4, 4.2, 0), text: '약 1,400 MWe (APR1400급)', sub: '대형 원전 1기 = 대형 도시 하나를 밝힐 규모', offset: [-40, -60], from: a6 + 0.8, to: a6 + 3.4, color: '#ffffff' });

    const a = this.audio;
    this.pad = this.own(a.drone({ freqs: [110, 164.8, 220], level: 0.08, cutoff: 1100, type: 'sine', fadeIn: 1.5, bus: 'music', detune: 3 }));
    this.hum = this.own(a.drone({ freqs: [55, 82.4], level: 0.12, cutoff: 500, fadeIn: 1.0, detune: 6 }));
    this.air = this.own(a.wind({ level: 0.0, center: 900, fadeIn: 1.0 }));
  }

  update(t, dt, dtReal) {
    const w = this.weight, post = this.post, p = this.pose, a = this.audio, ctx = this.ctx;
    post.blendBloom(0.9, w);
    _ct = ctx.u.time.value;
    const st = stageOf(t);
    const u = clamp((t - st.t0) / (st.t1 - st.t0));
    const lt = t - st.t0;
    for (const s of STAGES) { const mm = this.m[s.id]; if (mm) mm.holder.visible = s === st; }

    // 단면 열림: 각 구간 시작 0.2~1.6 초에 +x 깊이에서 0 으로 훑으며 열린다
    const cutZ = (lt0 = 0.2, len = 1.4) => 100 * Math.pow(1 - easeInOutCubic(clamp((lt - lt0) / len)), 1.5);
    this._spin += dt * (st.id === 'rcp' ? 4 + 9 * smoothstep(lt / 3) : 0);

    if (st.id === 'reactor') {
      const R = this.m.reactor, U = R.U;
      const asm = easeInOutCubic(clamp((t - 0.5) / 2.6));
      R.set(1 - asm, ST.z + 0.0 + (t < 0.5 ? 0 : 0), 1);
      const scram = clamp((t - 8.1) / 1.6);
      U.rod.value = easeOutCubic(scram) * (scram > 0 ? 1 : 0);
      U.cher.value = (1.0 - 0.6 * smoothstep((t - 8.3) / 1.4)) * w;
      U.flow.value = asm * w;
      this.once('scram', t > 8.1, () => { post.flashPulse(0.5, 4); this.camRig.shake(0.9); a.hit({ freq: 52, level: 0.8, decay: 2.0, noise: 0.5 }); });
    } else if (st.id === 'rcp') {
      this.m.rcp.set(this._spin, ST.z + cutZ(), 1);
      this.m.rcp.U.flow.value = smoothstep((lt - 1.2) / 1.2) * w;
    } else if (st.id === 'prz') {
      this.m.prz.set(PZR.LEVEL + 0.18 * Math.sin(t * 0.8) + 0.08 * Math.sin(t * 2.1), ST.z + cutZ(), 1);
      this.m.prz.U.spray.value = 0.25 + 0.75 * smoothstep((lt - 3.8) / 1.2);
      this.m.prz.U.heat.value = 1.0 - 0.5 * smoothstep((lt - 4.0) / 1.5) + 0.0;
      this.m.prz.U.flow.value = w;
    } else if (st.id === 'sg') {
      this.m.sg.set(ST.z + cutZ(), 1);
      this.m.sg.U.flow.value = smoothstep((lt - 1.2) / 1.2) * w;
    } else if (st.id === 'turb') {
      this._tspin += dt * (1.2 + 7.5 * smoothstep(lt / 6));
      this.m.turb.set(this._tspin, ST.z + cutZ(), 1);
      this.m.turb.U.flow.value = smoothstep((lt - 1.0) / 1.2) * w;
    } else if (st.id === 'gen') {
      this._gspin += dt * (4 + 7 * smoothstep(lt / 3));
      this.m.gen.set(this._gspin, ST.z + cutZ(), 1);
      this.m.gen.U.flow.value = smoothstep((lt - 1.2) / 1.2) * w;
      this.m.gen.U.gen.value = smoothstep((lt - 2.4) / 1.5) * w;
    }

    // 사운드: 기계마다 다른 윙윙 소리(음높이·세기를 구간마다 갱신)
    this._acc += dtReal;
    if (this._acc > 0.1) {
      this._acc = 0;
      const sp = { reactor: [[55, 82.4], 0.1, 400, 0.0], rcp: [[90 + 40 * smoothstep(lt / 3), 180 + 80 * smoothstep(lt / 3)], 0.14, 900, 0.03], prz: [[70, 140], 0.1, 700, 0.1], sg: [[50, 100], 0.1, 500, 0.12], turb: [[110 + 90 * smoothstep(lt / 6), 220 + 180 * smoothstep(lt / 6)], 0.16, 1500, 0.06], gen: [[60, 120, 180], 0.18, 1200, 0.0] }[st.id];
      this.hum.setFreqs(sp[0], 0.3); this.hum.setLevel(sp[1] * w, 0.3); this.hum.setCutoff(sp[2], 0.3); this.air.setLevel(sp[3] * w, 0.4);
    }
    this.once('endflash', t > 56.0, () => { post.flashPulse(0.9, 3.0); a.hit({ freq: 48, level: 0.7, decay: 2.0, noise: 0.4 }); a.riser({ dur: 1.0, from: 300, to: 6000, level: 0.25 }); });

    // 카메라
    p.pos.set(camAt(st.wp, u, 1), camAt(st.wp, u, 2), camAt(st.wp, u, 3)).add(ST); p.pos.x += st.i * GAP;
    p.look.set(camAt(st.wp, u, 4), camAt(st.wp, u, 5), camAt(st.wp, u, 6)).add(ST); p.look.x += st.i * GAP;
    p.fov = camAt(st.wp, u, 7); p.roll = 0; p.scale = 12; p.near = 0.1; p.far = 3000;
    this.cam(p);

    // 스캔 라인 전환
    let scan = -1;
    for (const T of TRANS) { const q = (t - (T - 0.5)) / 1.0; if (q > 0 && q < 1) scan = lerp(1.06, -0.06, q); }
    post.u.scan.value = scan;
    this.once('cut', t > -0.1, () => post.flashPulse(0.8, 6));
    TRANS.forEach((T, i) => this.once(`tr${i}`, t > T - 0.05, () => { post.flashPulse(0.18, 7); a.whoosh({ dur: 0.9, from: 6000, to: 700, level: 0.2 }); a.ping({ freq: 1400 - i * 110, level: 0.08, decay: 1.2 }); }));
  }

  dispose() { this.post.u.scan.value = -1; }
}

let _ct = 0;
const ctxT = () => _ct;
