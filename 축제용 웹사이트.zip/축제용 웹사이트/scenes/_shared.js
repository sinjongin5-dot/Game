// scenes/_shared.js — 여러 씬이 함께 쓰는 3D 자원(별, 태양, 지구, 도시 …)의 생성·참조 관리
//
//  왜 필요한가:
//   · 매치컷은 앞뒤 씬이 겹쳐서 "같은 물체"를 이어받는 방식이다. 같은 지구를 두 씬이 따로 만들면 겹침 구간에 지구가 두 개 그려진다.
//   · 또 챕터가 루프마다 같은 자원을 다시 만들면 셰이더 재컴파일 끊김과 메모리 누수가 생긴다.
//
//  사용법 (씬 안에서):
//    async warmup() { this.sun = await Shared.create(this.ctx, 'sun', makeSun); }   // 로딩 때 1회 (이미 있으면 재사용)
//    start()   { Shared.acquire(this.ctx, 'sun'); }    // 이 씬이 쓰기 시작 → 참조 +1, 처음이면 장면(scene)에 붙임
//    dispose() { Shared.release(this.ctx, 'sun'); }    // 참조 -1, 0 이 되면 장면에서 뗌 (자원은 캐시로 남아 있음)
//
//  factory(ctx) 는 { root: THREE.Object3D, ...씬이 쓸 핸들 } 을 돌려준다. dispose?() 가 있으면 앱 종료 때 호출.

const store = new Map();   // key → { obj, refs }

export const Shared = {
  /** 없으면 만들고, 있으면 기존 것을 돌려준다 */
  async create(ctx, key, factory) {
    let e = store.get(key);
    if (!e) { e = { obj: await factory(ctx), refs: 0 }; e.obj.root.name = `shared:${key}`; store.set(key, e); }
    return e.obj;
  },

  get(key) { return store.get(key)?.obj; },

  /** 참조 +1. 처음 참조되면 장면에 붙인다 */
  acquire(ctx, key) {
    const e = store.get(key);
    if (!e) throw new Error(`Shared '${key}' 가 아직 만들어지지 않았습니다 (warmup 에서 Shared.create 필요)`);
    if (e.refs++ === 0) ctx.scene.add(e.obj.root);
    return e.obj;
  },

  /** 참조 -1. 아무도 안 쓰면 장면에서 뗀다 */
  release(ctx, key) {
    const e = store.get(key);
    if (!e || e.refs === 0) return;
    if (--e.refs === 0) ctx.scene.remove(e.obj.root);
  },

  refs(key) { return store.get(key)?.refs ?? 0; },

  /** 만들어 둔 공유 자원의 키 목록 (로딩 때 한꺼번에 컴파일(웜업)하려고 사용) */
  keys() { return [...store.keys()]; },
};
