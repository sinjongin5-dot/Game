// scenes/_base.js — 모든 씬의 기반 클래스
//
//  씬을 새로 만들 때: SceneBase 를 상속하고 필요한 메서드만 덮어쓰면 된다.
//
//    async warmup()      로딩 화면에서 1회. 지오메트리/머티리얼/컴퓨트 파이프라인을 만들어 둔다 (재사용 자원 = 캐시)
//    start()             씬 구간에 들어갈 때마다(루프 때마다) 호출. 상태를 초기화하고 root 에 오브젝트를 붙인다.
//    update(t, dt)       매 프레임. t=씬 로컬 시간(초, 겹침 구간에서는 음수/길이 초과 가능), dt=월드 dt(불릿타임 반영)
//    dispose()           구간을 벗어날 때. "이번 바퀴에서만 쓰는 동적 자원"(이벤트·타이머·임시 텍스처·소리)을 정리한다.
//                        warmup 에서 만든 캐시 자원은 지우지 않는다(다음 바퀴에 셰이더 재컴파일 끊김 방지).
//    timeScaleAt(t)      (선택) 이 씬의 시간 배율. 불릿타임 곡선을 돌려주면 월드 시간이 느려진다.
//    onQuality(tier)     (선택) 품질 단계가 바뀔 때 — 파티클 수·레이마칭 스텝 등을 줄인다.
//
//  도우미:
//    this.weight         겹침 구간에서 이 씬이 차지하는 비중(0~1). 페이드 아웃/인에 사용.
//    this.cam(pose)      카메라 포즈 제출 (Director 가 가중치 곱해서 섞어 줌)
//    this.once(key, cond, fn)  start() 이후 cond 가 처음 참이 되는 순간 fn 을 한 번만 실행 (효과음·플래시 타이밍용)
//    this.hud / this.audio / this.post / this.quality  공용 시스템 바로가기

import * as THREE from 'three/webgpu';

export class SceneBase {
  constructor(ctx, def) {
    this.ctx = ctx;
    this.def = def;
    this.id = def.id;
    this.len = def.end - def.start;
    this.root = new THREE.Group();
    this.root.name = `scene:${def.id}`;
    this.weight = 1;
    this.failed = false;
    this._fired = new Set();
    this._voices = [];
  }

  get audio() { return this.ctx.audio; }
  get post() { return this.ctx.post; }
  get hud() { return this.ctx.ui.hud; }
  get quality() { return this.ctx.quality; }
  get camRig() { return this.ctx.cam; }

  // ── 하위 클래스가 덮어쓰는 훅 ──
  async warmup() {}
  start() {}
  update(/* t, dt, dtReal */) {}
  dispose() {}

  // ── Director 가 호출하는 내부 래퍼 ──
  _begin() { this._fired.clear(); this._voices.length = 0; this.start(); }
  _end() {
    // 이 씬이 시작한 소리는 부드럽게 끈다 (겹침 구간에서 다음 씬 소리와 자연스럽게 교차)
    for (const v of this._voices) { try { v.stop(1.2); } catch (_) { /* 무시 */ } }
    this._voices.length = 0;
    this.dispose();
  }

  // ── 도우미 ──
  cam(pose) { this.ctx.cam.submit(pose, this.weight); }

  /** 이 씬이 시작한 소리를 등록해 두면 씬이 끝날 때 자동으로 페이드 아웃된다 */
  own(voice) { this._voices.push(voice); return voice; }

  once(key, cond, fn) {
    if (cond && !this._fired.has(key)) { this._fired.add(key); fn(); }
  }

  /** 로컬 시간 t 의 진행도 (0~1, 범위 밖은 클램프) */
  progress(t) { return Math.min(1, Math.max(0, t / this.len)); }
}
