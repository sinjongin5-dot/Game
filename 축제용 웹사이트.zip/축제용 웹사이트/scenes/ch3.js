// scenes/ch3.js — Ch.3 연쇄 반응 & 제어: 통제된 불꽃 (90~120초)
//
//  와우 모먼트: 컴퓨트 셰이더로 수십만 개 중성자가 격자형 연료 속에서 폭발적으로 번지는 장면(k>1) → 제어봉이 위에서 내려오자
//               중성자들이 빨려 들어가듯 사라지며 안정(k=1).
//   0~2      Ch.2 에서 나온 빠른 중성자 3개(빨강)가 격자 속으로 — (매치컷)
//   2~11.5   연료봉에서 새 중성자가 태어나며 중심에서 바깥으로 불꽃처럼 번짐. 계기판 k 가 오르며 붉게(초임계)
//   13.5~19  제어봉 9개가 위에서 내려오고 중성자가 끌려 들어가 사라짐 → k 가 내려가 1.00 에 연두색으로 안착
//   20~28    안정 상태: 물 분자(H₂O)와 충돌하며 중성자 색이 빨강 → 파랑으로 바뀜(느린 중성자가 U-235 를 더 잘 쪼갬)
//   26~30    안정된 노심의 빛(연두·청록 광구)이 화면을 채움 → (매치컷) Ch.4 저울의 빛
//  우측 계기판 = ui/gauge.js (증식계수 k). 자막/카드는 config.js (ch3).
//  ※ 개념도: 실제 원자로는 지발중성자·음의 온도계수 등으로 이렇게 폭주하지 않도록 설계된다 — 화면에 "모식도" 주석 표기.

import * as THREE from 'three/webgpu';
import { SceneBase } from './_base.js';
import { makeNeutronField } from './shared/neutronField.js';
import { makeLattice } from './shared/lattice.js';
import { makeBeams } from './shared/beams.js';
import { makePose } from '../engine/camera.js';
import { clamp, curve, smoothstep, spline } from '../engine/ease.js';

const FAST = new THREE.Color(0xff3b30);
const V = new THREE.Vector3(), HEAD = new THREE.Vector3(), DIR = new THREE.Vector3();
const START = [new THREE.Vector3(0.9, 0.35, 0.2).normalize(), new THREE.Vector3(-0.6, -0.25, 0.8).normalize(), new THREE.Vector3(-0.3, 0.5, -0.8).normalize()];

/** k(t): 1.0 → 초임계로 상승(≈1.38) → 제어봉이 들어오며 0.87 까지 내려갔다가 1.00 에 안착 */
const kAt = (t) => spline([[0, 1.0], [2, 1.0], [5, 1.11], [9, 1.31], [13.5, 1.38], [16, 1.06], [17.6, 0.87], [19.6, 0.985], [21.2, 1.0], [30, 1.0]], t);
/** 집단 크기(0~1): 지수적 증가 → 정점 → 제어봉으로 감소 → 안정 */
const fracAt = (t) => (t < 2 ? 0 : t < 11.5 ? Math.exp(0.6 * (t - 11.5)) * 1.0 : t < 14 ? 1.0 : 0.22 + 0.78 * Math.exp(-0.55 * (t - 14)));

export default class Ch3 extends SceneBase {
  async warmup() {
    const ctx = this.ctx;
    this.lat = makeLattice(ctx);
    this.root.add(this.lat.root);
    this.N = Math.max(20000, Math.min(800000, Math.floor(this.quality.particleCap * 0.8)));
    this.field = makeNeutronField(ctx.renderer, this.N);
    this.field.reset(); this.field.update(0.016);            // 컴퓨트 파이프라인 미리 컴파일
    this.root.add(this.field.mesh);
    this.beams = makeBeams(ctx, 3, 420);
    this.root.add(this.beams.root);
    this.pose = makePose(); this.pose.near = 0.2; this.pose.far = 4000;
  }

  start() {
    this._acc = 0; this._click = 0;
    this.field.reset();
    this.onQuality();
    const s0 = this.def.start, id = this.id, lim = this.lat.lim;
    const H = (o) => this.hud.add({ owner: id, ...o });
    H({ id: `${id}-fuel`, anchor: () => V.set(2.8, 6.2, 5.6), text: '연료봉 (UO₂ 펠릿)', sub: 'FUEL ROD', offset: [80, -70], from: s0 + 1.8, to: s0 + 8.5, color: '#ff8c2a' });
    H({ id: `${id}-chain`, anchor: () => V.set(0, 7.4, 0), text: '중성자가 중성자를 만든다 — 연쇄 반응', sub: 'k > 1  SUPERCRITICAL', offset: [110, -80], from: s0 + 7, to: s0 + 13.4, color: '#ff5a4a' });
    H({ id: `${id}-ctrl`, anchor: () => V.set(0, this.lat.ctrlGroup.position.y + 6.4, 0), text: '제어봉 (붕소·카드뮴)', sub: 'CONTROL ROD', offset: [-120, -50], from: s0 + 14.6, to: s0 + 22, color: '#7dff6a' });
    H({ id: `${id}-mod`, anchor: () => V.set(lim, 1, 0), text: '감속재: 물 (H₂O)', sub: 'MODERATOR', offset: [90, -80], from: s0 + 21, to: s0 + 28, color: '#22e6ff' });
    H({ id: `${id}-legend`, anchor: () => V.set(-lim, 3.5, 0), text: '빨강 = 빠른 중성자 → 파랑 = 느린 중성자', sub: 'NEUTRON SPEED', offset: [-60, -90], from: s0 + 22.5, to: s0 + 29, color: '#bfe2ff' });
    H({ id: `${id}-note`, anchor: () => V.set(0, -7.6, 0), text: '※ 이해를 돕기 위한 모식도 — 실제 원자로는 이렇게 폭주하지 않도록 설계됩니다', offset: [0, 70], from: s0 + 5, to: s0 + 14, color: '#9fb8d8' });

    const a = this.audio;
    this.drone = this.own(a.drone({ freqs: [55, 82.4, 110], level: 0.16, cutoff: 260, fadeIn: 1.2, detune: 8 }));
  }

  onQuality() {
    const n = Math.min(this.N, Math.floor(this.quality.particleCap * 0.8));
    this.field.setCount(n);
    this.field.u.bright.value = clamp(0.45 * Math.sqrt(800000 / Math.max(n, 20000)), 0.45, 1.7);
    this.lat.setMoleculeCount(Math.floor(2000 * Math.min(1, this.quality.particleCap / 300000)));
  }

  update(t, dt, dtReal) {
    const w = this.weight, post = this.post, a = this.audio, ui = this.ctx.ui;
    post.blendBloom(1.2, w);
    const frac = fracAt(t), k = kAt(t);
    const rod = smoothstep((t - 13.5) / 5.5);

    // ── 중성자 군집 / 격자 ──
    const u = this.field.u;
    u.frac.value = frac * w; u.spread.value = 1.5 + 14 * smoothstep((t - 2) / 8); u.rod.value = rod;
    this.field.update(dt);
    this.lat.setRod(rod);
    this.lat.uActivity.value = clamp(Math.pow(frac, 0.55)) * 0.95 * w;
    this.lat.uGlow.value = smoothstep((t - 25.5) / 4.0) * 1.1 * w;

    // ── 처음 2.5초: Ch.2 의 빠른 중성자 3개가 격자 속으로 퍼져 나간다 ──
    for (let i = 0; i < 3; i++) {
      if (t < 3.0) { HEAD.copy(START[i]).multiplyScalar(2 + 11 * t); this.beams.set(i, { pos: HEAD, dir: START[i], len: 5, color: FAST, alpha: w * (1 - smoothstep((t - 1.8) / 1.2)), size: 0.45 }); }
      else this.beams.hide(i);
    }

    // ── 계기판 ──
    ui.gauge.set({ show: t > 3.0 && t < 25.5 && w > 0.5, value: k });

    // ── 카메라: 바깥 → 중심 쪽으로 파고들었다가 → 제어봉 전체를 보는 높은 시점 → 물 분자 근처 → 노심 광구로 ──
    const th = 0.75 + 0.075 * t + 0.2 * Math.sin(t * 0.21);
    const rho = spline([[0, 42], [5, 34], [9, 19], [12.5, 23], [16, 40], [21, 25], [24, 17], [27, 14], [30, 9]], t);
    const h = spline([[0, 9], [5, 6], [9, 1.5], [12.5, 4], [16, 19], [21, 5], [24, 0.5], [27, 1.5], [30, 0]], t);
    const p = this.pose;
    p.pos.set(Math.cos(th) * rho, h, Math.sin(th) * rho);
    p.look.set(0, spline([[0, 0], [16, 2], [30, 0]], t), 0);
    p.fov = spline([[0, 52], [9, 58], [16, 50], [30, 56]], t);
    p.roll = 0.03 * Math.sin(t * 0.25); p.scale = 10; p.near = 0.2; p.far = 4000;
    this.cam(p);

    // ── 사운드: 개체 수에 비례하는 가이거 클릭, 긴장 상승, 제어봉 충돌, 안정 화음 ──
    this._acc += dtReal;
    if (this._acc > 0.12) {
      this._acc = 0;
      this.drone.setCutoff(260 + 1500 * frac, 0.3);
      this.drone.setLevel(0.14 + 0.16 * frac, 0.3);
    }
    this._click += dtReal * (4 + 60 * frac) * w;
    for (let i = 0; this._click >= 1 && i < 6; i++, this._click -= 1) a.ping({ freq: 1500 + Math.random() * 3200, level: 0.012 + 0.012 * frac, decay: 0.05 });
    this._click = Math.min(this._click, 1);
    this.once('rise', t > 2, () => this.own(a.riser({ dur: 9.5, from: 160, to: 3200, level: 0.2 })));
    this.once('rods', t > 13.6, () => { a.hit({ freq: 62, level: 0.6, decay: 1.4, noise: 0.4 }); a.whoosh({ dur: 2.2, from: 3000, to: 220, level: 0.25 }); });
    this.once('land', t > 19.0, () => { a.hit({ freq: 55, level: 0.5, decay: 1.8, noise: 0.2 }); });
    this.once('stable', t > 20.2, () => { this.own(a.drone({ freqs: [220, 277.2, 329.6], level: 0.17, cutoff: 2200, type: 'sine', fadeIn: 1.8, bus: 'music', detune: 3 })); a.ping({ freq: 880, level: 0.12, decay: 2.2 }); });
    this.once('glow', t > 25.5, () => this.own(a.riser({ dur: 4.4, from: 300, to: 5000, level: 0.22 })));
  }

  dispose() {
    this.ctx.ui.gauge.set({ show: false, value: 1 });
    this.field.u.frac.value = 0;
  }
}
