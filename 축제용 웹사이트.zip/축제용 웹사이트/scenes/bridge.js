// scenes/bridge.js — 루프 브릿지 (275~280초): 지구에서 태양으로 — 휩 팬 + 돌진 + 화이트아웃
//
//  크레딧의 지구 궤도에서 카메라가 멀어졌다가, 빠르게 태양 쪽으로 휙 돌고(휩 팬), 속도선과 함께 태양으로 돌진한다.
//  마지막 0.8초는 순백으로 채우고, 루프가 돌아 Scene 1(태양)이 "같은 위치·같은 FOV·같은 흰 화면"에서 시작한다 → 끊김 없는 순환.
//  좌표(오프닝 공통): 태양 = 원점, 지구 중심 = EARTH_POS(+X). 태양 씬 시작 포즈: 위치 (480,44,64) → 시선 (0,−2,0), FOV 46.

import * as THREE from 'three/webgpu';
import { SceneBase } from './_base.js';
import { Shared } from './_shared.js';
import { makeStars, makeSun } from './shared/space.js';
import { makeEarth, EARTH_R, EARTH_POS } from './shared/earth.js';
import { makeAurora, orbitPose } from './shared/aurora.js';
import { hackProfile } from '../ui/hack.js';
import { makePose } from '../engine/camera.js';
import { clamp, lerp, smoothstep, easeInCubic, easeInOutCubic } from '../engine/ease.js';

const SUN_START = new THREE.Vector3(480, 44, 64), SUN_LOOK = new THREE.Vector3(0, -2, 0);
const _a = new THREE.Vector3(), _c = new THREE.Vector3();

export default class Bridge extends SceneBase {
  async warmup() {
    const ctx = this.ctx;
    this.stars = await Shared.create(ctx, 'stars', makeStars);
    this.sun = await Shared.create(ctx, 'sun', makeSun);
    this.earth = await Shared.create(ctx, 'earth', makeEarth);
    this.aurora = await Shared.create(ctx, 'aurora', makeAurora);
    this.pose = makePose(); this.pose.near = 0.5; this.pose.far = 9000;
    this.p0 = orbitPose(ctx.config.hack?.enabled ? 14 : 30, makePose());   // 크레딧(해킹 되감기) 끝 포즈 = 브릿지 시작 포즈 (credits.js 의 REWIND_END_TT)
    this.far = new THREE.Vector3();
  }

  start() {
    const ctx = this.ctx;
    Shared.acquire(ctx, 'stars'); Shared.acquire(ctx, 'sun'); Shared.acquire(ctx, 'earth'); Shared.acquire(ctx, 'aurora');
    // 멀어질 지점: 시작 위치에서 지구 중심 반대쪽으로 + 위로, 태양이 보이는 쪽(−X)으로 비스듬히
    this.far.copy(this.p0.pos).sub(EARTH_POS).normalize().multiplyScalar(EARTH_R * 6.5).add(EARTH_POS);
    this._acc = 0;
    const a = this.audio;
    a.whoosh({ dur: 2.0, from: 800, to: 4500, level: 0.2 });
  }

  update(t, dt, dtReal) {
    const w = this.weight, post = this.post, ctx = this.ctx, a = this.audio, p = this.pose;
    post.blendBloom(1.6, w);

    // ── 위치: 지구 곁 → (뒤로 빠짐) → 태양 쪽으로 가속 돌진, 마지막은 태양 씬 시작 위치 ──
    const retreat = easeInOutCubic(clamp(t / 1.6));
    const dash = easeInCubic(clamp((t - 1.9) / 2.9));
    _a.lerpVectors(this.p0.pos, this.far, retreat);
    _a.y += 30 * retreat;
    p.pos.lerpVectors(_a, SUN_START, dash);

    // ── 시선: 지구를 보다가 → 휩 팬으로 태양 쪽 → 태양 ──
    const whip = easeInOutCubic(clamp((t - 1.35) / 1.0));
    _c.copy(this.p0.look).lerp(EARTH_POS, 0.5);                                // 지구 쪽(크레딧 마지막 시선 근처)
    p.look.lerpVectors(_c, SUN_LOOK, whip);
    p.fov = lerp(this.p0.fov, 50, retreat) + (lerp(0, -4, dash)) + 6 * Math.sin(Math.PI * whip);
    p.roll = 0.25 * Math.sin(Math.PI * whip) * (1 - dash);
    p.scale = lerp(60, 260, retreat); p.near = 0.5; p.far = 9000;
    this.cam(p);

    // ── 오로라/지구는 멀어지며 사라지고, 태양은 점점 커진다 ──
    this.aurora.uAur.value = 0.65 * (1 - smoothstep(t / 2.0)) * w;
    this.aurora.uCor.value = ctx.config.hack?.enabled ? hackProfile(this.def.start + t, ctx.config.hack).cor : 0;
    this.earth.uGreen.value = 1;
    const alt = p.pos.distanceTo(EARTH_POS) - EARTH_R;
    this.earth.uDetail.value = clamp(1 - (alt - 0.5) / 30);
    this.sun.uBig.value = 0.12 * w;
    _a.set(0, 0, 0).project(ctx.camera);
    post.u.godCenter.value.set(_a.x * 0.5 + 0.5, _a.y * 0.5 + 0.5);
    post.u.godray.value = 0.3 * smoothstep((t - 2.2) / 2.0) * w;
    post.u.speed.value = 0.9 * smoothstep((t - 2.3) / 0.8) * w;
    post.u.anamorphic.value = ctx.config.post.anamorphic.strength * (0.5 + 0.7 * smoothstep((t - 2.5) / 2));

    // ── 화이트아웃: 4.1초부터 서서히, 마지막 0.2초는 순백(다음 바퀴 Scene 1 이 흰색에서 시작) ──
    post.setFlash(smoothstep((t - 3.9) / 0.9));

    this._acc += dtReal;
    this.once('riser', t > 1.5, () => { a.riser({ dur: 3.3, from: 200, to: 6000, level: 0.26 }); });
    this.once('whip', t > 1.4, () => a.whoosh({ dur: 1.2, from: 300, to: 5000, level: 0.3 }));
    this.once('thump', t > 4.5, () => a.hit({ freq: 46, level: 0.5, decay: 1.2, noise: 0.4 }));
  }

  dispose() {
    const ctx = this.ctx, u = this.post.u;
    for (const k of ['stars', 'sun', 'earth', 'aurora']) Shared.release(ctx, k);
    u.speed.value = 0; u.godray.value = 0; u.anamorphic.value = ctx.config.post.anamorphic.strength;
    this.earth.uGreen.value = 0; this.aurora.uAur.value = 0; this.aurora.uCor.value = 0; this.sun.uBig.value = 0;
  }
}
