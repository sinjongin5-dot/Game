// scenes/ch6.js — Ch.6 원자로에서 전기까지: 디지털 트윈 (175~210초)
//
//  와우 모먼트 1: 체렌코프 방사 — 물속에서 입자가 "그 물속의 빛 속도(c/n)보다 빠르게" 움직일 때 생기는 푸른 빛을 블룸으로 은은하게.
//  와우 모먼트 2: 투명 단면 디지털 트윈 — 카메라가 스플라인을 따라 원자로 → 증기발생기 → 터빈 → 발전기를 비행.
//   가압경수로(PWR): 1차 계통(고압 냉각수, 빨강-주황)과 2차 계통(깨끗한 물/증기, 청록)은 열만 주고받고 섞이지 않는다.
//   터빈은 고속 회전(모션 블러 원반), 발전기에서는 자기력선 입자가 회전하며 전류가 유도된다(패러데이 법칙).
//  이어서 전기가 송전탑을 따라 빛 펄스로 달려가 서울 야경에 불이 하나둘 켜진다(오프닝의 서울과 연결).
//   0~5      체렌코프 마크로  →  5~10 원자로 전체  →  10~17 증기발생기  →  17~24 터빈·발전기  →  24~29 송전(펄스 비행)  →  29~35 서울 점등
//  자막/키워드 카드: config.js (ch6)
//  출처(개념): 체렌코프 방사 = 매질 속 광속(c/n)보다 빠른 하전입자가 내는 푸른 빛 (물 n≈1.33 → 문턱 에너지 약 0.26 MeV 전자). 패러데이 전자기 유도 법칙.

import * as THREE from 'three/webgpu';
import { SceneBase } from './_base.js';
import { Shared } from './_shared.js';
import { makePlant, LINE_X0 } from './shared/plant.js';
import { makeCoolingTower } from './shared/coolingTower.js';
import { makeCity } from './shared/city.js';
import { makeStars } from './shared/space.js';
import { makePose } from '../engine/camera.js';
import { clamp, lerp, curve, spline, smoothstep, easeInCubic, easeInOutCubic } from '../engine/ease.js';

const SWAP = 29.3;                                    // 로컬 시간: 송전 펄스가 서울에 닿는 순간(전기 섬광으로 장면 교체)
// 카메라 웨이포인트 [시간, 위치xyz, 시선xyz, FOV] — 플랜트 좌표. 각 성분을 spline 으로 이어 속도가 끊기지 않게 한다.
const WP = [
  [0,    -54.6, -2.5, 7.5,   -60.5, -3.0, 0,   38],
  [3.6,  -50.5, 0.5, 10.5,   -60.0, 0.5, 0,    42],
  [6.5,  -42.0, 9.0, 26.0,   -57.0, 3.0, 0,    48],
  [9.5,  -36.0, 8.0, 15.0,   -44.0, 5.0, 0,    46],
  [12.3, -32.0, 13.0, 16.0,  -28.0, 7.0, 0,    46],
  [15.5, -20.0, 19.0, 11.0,  -26.0, 13.0, 0,   50],
  [18.2, -7.0, 9.0, 17.0,    6.0, 5.5, 0,      50],
  [21.0, 13.0, 7.5, 13.0,    24.0, 4.5, 0,     52],
  [24.0, 41.0, 7.0, 13.0,    48.0, 5.0, 0,     50],
  [26.3, 64.0, 9.0, 17.0,    74.0, 8.0, 0,     54],
];
const cam = (t, k) => spline(WP.map((w) => [w[0], w[k]]), t);
const V = new THREE.Vector3();

export default class Ch6 extends SceneBase {
  async warmup() {
    const ctx = this.ctx;
    this.stars = await Shared.create(ctx, 'stars', makeStars);
    this.city = await Shared.create(ctx, 'city', makeCity);
    this.plant = await makePlant(ctx);
    this.root.add(this.plant.root);
    this.tower1 = makeCoolingTower(ctx); this.tower1.root.position.set(-30, -9.5, -95);
    this.tower2 = makeCoolingTower(ctx); this.tower2.root.position.set(24, -9.5, -105);
    this.root.add(this.tower1.root, this.tower2.root);
    this.pose = makePose(); this.pose.near = 0.2; this.pose.far = 30000;
  }

  start() {
    this._phase = 'plant';
    this.plant.root.visible = true; this.tower1.root.visible = this.tower2.root.visible = true;
    this.spin = 0; this._acc = 0; this._pyl = -1; this._arp = 0;
    this.plant.setQuality(this.quality.particleCap);
    Shared.acquire(this.ctx, 'stars');
    const s0 = this.def.start, id = this.id, P = this.plant;
    const H = (o) => this.hud.add({ owner: id, ...o });
    H({ id: `${id}-cher`, anchor: () => V.set(-60, -3.4, 0), text: '체렌코프 방사', sub: 'CHERENKOV RADIATION', offset: [110, -70], from: s0 + 0.8, to: s0 + 5.2, color: '#5aa8ff' });
    H({ id: `${id}-reactor`, anchor: () => V.set(-60, 10.4, 0), text: '원자로 — 핵분열열 발생', sub: 'REACTOR VESSEL', offset: [90, -60], from: s0 + 6, to: s0 + 10.5, color: '#22e6ff' });
    H({ id: `${id}-prim`, anchor: () => V.set(-44, 6.4, 0), text: '1차 계통 — 고압 냉각수', sub: 'PRIMARY LOOP  ·  약 155 bar', offset: [-30, -90], from: s0 + 8.6, to: s0 + 13.4, color: '#ff7a3a' });
    H({ id: `${id}-sg`, anchor: () => V.set(-28, 17.8, 0), text: '증기발생기', sub: 'STEAM GENERATOR', offset: [90, -40], from: s0 + 11, to: s0 + 17, color: '#1fd6c8' });
    H({ id: `${id}-nomix`, anchor: () => V.set(-28, 8, 3.8), text: '1차와 2차는 섞이지 않는다 — 열만 전달', sub: 'HEAT ONLY', offset: [-130, 70], from: s0 + 13.6, to: s0 + 18.2, color: '#ffffff' });
    H({ id: `${id}-sec`, anchor: () => V.set(-8, 12.8, 0), text: '2차 계통 — 깨끗한 물과 증기', sub: 'SECONDARY LOOP', offset: [20, -80], from: s0 + 15.4, to: s0 + 19.6, color: '#1fd6c8' });
    H({ id: `${id}-turb`, anchor: () => V.set(22, 9.6, 0), text: '터빈 — 증기의 힘으로 회전', sub: 'TURBINE', offset: [70, -70], from: s0 + 19.6, to: s0 + 24, color: '#9fd8ff' });
    H({ id: `${id}-gen`, anchor: () => V.set(50, 9.2, 0), text: '발전기 — 패러데이 전자기 유도', sub: 'FARADAY\'S LAW', offset: [-60, -80], from: s0 + 23, to: s0 + 27, color: '#ffd27a' });
    H({ id: `${id}-tx`, anchor: () => V.set(66, 1, 0), text: '변압기 → 송전', sub: 'TRANSMISSION', offset: [70, -80], from: s0 + 26, to: s0 + 29.2, color: '#ffd27a' });
    H({ id: `${id}-seoul`, anchor: () => V.set(0, 45, 0), text: '서울', sub: 'SEOUL', offset: [90, -70], from: s0 + 32.2, to: s0 + 35, color: '#ffd27a' });

    const a = this.audio;
    this.hum = this.own(a.drone({ freqs: [55, 82.4, 110], level: 0.16, cutoff: 320, fadeIn: 1.5, detune: 8 }));
    this.water = this.own(a.wind({ level: 0.05, center: 260, fadeIn: 1.5 }));
    this.turbSnd = this.own(a.drone({ freqs: [80, 160], level: 0.0001, cutoff: 900, type: 'sawtooth', fadeIn: 0.2, bus: 'sfx', detune: 5 }));
    this.mains = this.own(a.drone({ freqs: [60, 120, 180], level: 0.0001, cutoff: 1400, type: 'sine', fadeIn: 0.2, bus: 'music', detune: 2 }));
  }

  _toCity() {
    this.plant.root.visible = false; this.tower1.root.visible = this.tower2.root.visible = false;
    Shared.acquire(this.ctx, 'city');
    this.city.uSlab.value = 0; this.city.uGround.value = 0.6; this.city.uWipe.value = 0; this.city.setImpact(-1);
    this.city.setCount(this.quality.particleCap * 0.4);
    this._phase = 'city';
  }
  _toPlant() { Shared.release(this.ctx, 'city'); this.plant.root.visible = true; this.tower1.root.visible = this.tower2.root.visible = true; this._phase = 'plant'; }

  onQuality() { this.plant.setQuality(this.quality.particleCap); this.tower1.setCount(7000 * Math.min(1, this.quality.particleCap / 300000)); this.tower2.setCount(7000 * Math.min(1, this.quality.particleCap / 300000)); if (this._phase === 'city') this.city.setCount(this.quality.particleCap * 0.4); }

  update(t, dt, dtReal) {
    const w = this.weight, post = this.post, a = this.audio, ctx = this.ctx, P = this.plant, U = P.U, pose = this.pose;
    post.blendBloom(this._phase === 'city' ? 0.8 : 1.4, w);
    if (this._phase === 'plant' && t >= SWAP) this._toCity();
    else if (this._phase === 'city' && t < SWAP - 0.001) { this.city.uOn.value = 1e9; this._toPlant(); }

    // ── 회전·세기 타임라인 ──
    const omega = curve([[0, 0], [16.5, 0], [19, 9], [21.5, 58], [24, 70], [27, 70], [30, 40]], t);
    this.spin += omega * dt;
    P.setSpin(this.spin);
    U.blur.value = clamp((omega - 14) / 34);
    U.gen.value = smoothstep((omega - 6) / 50) * w;
    U.cher.value = (0.9 + 0.35 * smoothstep((t - 0.5) / 2)) * w;
    U.glow.value = w;
    P.flowSecondary.uAlpha.value = (0.25 + 0.75 * smoothstep((t - 9) / 3)) * w;
    P.flowPrimary.uAlpha.value = w;
    P.flowSecondary.uSpeed.value = lerp(0.03, 0.11, smoothstep((t - 15) / 6));
    this.tower1.uPlume.value = this.tower2.uPlume.value = w;

    // ── 카메라 ──
    if (this._phase === 'plant') {
      if (t < 26.3) {
        pose.pos.set(cam(t, 1), cam(t, 2), cam(t, 3)); pose.look.set(cam(t, 4), cam(t, 5), cam(t, 6)); pose.fov = cam(t, 7);
      } else {                                                                      // 송전선을 따라 가속 비행: 펄스가 앞에서 달린다
        const u = clamp((t - 26.3) / 3.0), x = lerp(64, 3900, easeInCubic(u));
        pose.pos.set(x, lerp(9, 20.5, smoothstep(u * 2)), lerp(17, 5.5, smoothstep(u * 2)));
        pose.look.set(x + 110 + 400 * u, 19.5, 0);
        pose.fov = lerp(54, 70, u);
        U.packet.value = clamp((x + 170 + 600 * u - 66) / (P.lineEnd - 66));      // 펄스는 카메라 앞에서 달리며 서울로
        const pyl = Math.floor((x - LINE_X0) / 150);
        if (pyl > this._pyl && x > LINE_X0) { this._pyl = pyl; a.ping({ freq: 1800 + (pyl % 5) * 260, level: 0.05, decay: 0.12 }); }
      }
      pose.roll = 0.015 * Math.sin(t * 0.6);
      pose.scale = 10; pose.near = 0.15; pose.far = 30000;
      if (t < 26.2) U.packet.value = -1;
    } else {
      const u = clamp((t - SWAP) / (this.len - SWAP));
      pose.pos.set(lerp(-1900, -1050, easeInOutCubic(u)), lerp(520, 1450, easeInOutCubic(u)), lerp(2500, 2350, u));
      pose.look.set(0, 0, 0); pose.fov = lerp(52, 56, u); pose.roll = 0; pose.scale = 300; pose.near = 1; pose.far = 30000;
      // 서울 점등: 중심에서 바깥으로 불이 켜지는 파면
      const on = smoothstep((t - (SWAP + 0.3)) / 4.6);
      this.city.uOn.value = on * 5400 + (t < SWAP + 0.3 ? -2000 : 0);
      this.city.uGlow.value = 0.4 * w;
      const arpIdx = Math.floor(on * 14);
      if (arpIdx > this._arp) { this._arp = arpIdx; a.ping({ freq: 392 * Math.pow(2, [0, 2, 4, 7, 9, 12, 14, 16, 19][arpIdx % 9] / 12), level: 0.08, decay: 1.2 }); }
    }
    this.cam(pose);
    post.u.anamorphic.value = ctx.config.post.anamorphic.strength * (1 + 0.9 * (this._phase === 'plant' && t > 26.3 ? 1 : 0));
    post.u.speed.value = this._phase === 'plant' && t > 26.8 ? 0.35 * w : 0;

    // ── 사운드 ──
    this._acc += dtReal;
    if (this._acc > 0.1) {
      this._acc = 0;
      this.hum.setLevel((0.14 + 0.03 * smoothstep(t / 8)) * (this._phase === 'city' ? 0.2 : 1), 0.3);
      this.water.setLevel(0.04 + 0.2 * smoothstep((t - 4) / 10) * (t < 28 ? 1 : 0.2), 0.3);
      this.turbSnd.setFreqs([70 + omega * 2.2, 140 + omega * 4.4], 0.2);
      this.turbSnd.setLevel(0.2 * smoothstep((omega - 4) / 40) * (this._phase === 'plant' ? 1 : 0), 0.2);
      this.turbSnd.setCutoff(500 + omega * 22, 0.2);
      this.mains.setLevel(0.14 * smoothstep((omega - 20) / 40) * (this._phase === 'plant' ? 1 : 0.15), 0.3);
    }
    if (t < 8 && Math.random() < 0.18) a.ping({ freq: 2400 + Math.random() * 3000, level: 0.012, decay: 0.12 });            // 체렌코프 반짝임
    this.once('turbine', t > 17.2, () => a.whoosh({ dur: 3.4, from: 300, to: 3200, level: 0.22 }));
    this.once('gen', t > 23.2, () => a.ping({ freq: 440, level: 0.1, decay: 2.4 }));
    this.once('zap', t > 26.2, () => { this.own(a.riser({ dur: 3.1, from: 400, to: 6000, level: 0.24 })); a.hit({ freq: 70, level: 0.5, decay: 1.2, noise: 0.6 }); });
    this.once('flash', t > SWAP - 0.05, () => { post.flashPulse(0.95, 2.6); a.hit({ freq: 50, level: 0.6, decay: 1.6, noise: 0.5 }); this.camRig.shake(0.5); });
  }

  dispose() {
    const ctx = this.ctx;
    Shared.release(ctx, 'stars');
    if (this._phase === 'city') Shared.release(ctx, 'city');
    this.city.uOn.value = 1e9; this.city.uSlab.value = 1; this.city.uGround.value = 1; this.city.uWipe.value = 1;
    this.plant.U.packet.value = -1;
    const u = this.post.u; u.speed.value = 0; u.anamorphic.value = ctx.config.post.anamorphic.strength;
  }
}
