// scenes/shared/fuelcycle.js — Ch.5 연료의 화학: 단계별 무대 모음
//
//  모든 길이는 cm (1 유닛 = 1 cm) — 펠릿·연료봉은 실제 크기 그대로, 원심분리기(개념도)와 점 격자(개념도)는 임의 스케일.
//   · makeYellowcake : 옐로케이크(우라늄 정광) 더미 — 알갱이 2만 개의 마크로 샷
//   · makeDotGrid    : 1000개 점 격자 — 천연 우라늄(U-235 7개) → 농축 후(약 40개)
//   · makePellets    : 소결 펠릿 더미(백열→식음) + 500원 동전(지름 26.5 mm) 크기 비교
//   · makeRodAssembly: 연료봉(지르코늄 합금 피복관 + 펠릿 쌓기) → 연료집합체(17×17 격자)
//   · makeMotes      : 빛줄기 속에 떠다니는 먼지(보케 연출)
//  출처(치수, 가압경수로 일반 자료): 펠릿 지름 약 8.2 mm·길이 약 10~13 mm, 연료봉 바깥지름 약 9.5 mm·유효 길이 약 3.66 m(12 ft),
//   17×17 집합체: 연료봉 264 + 안내관 24 + 계측관 1 = 289 칸, 피치 12.6 mm.  500원 동전 지름 26.5 mm (한국은행).
//   ※ 한국형 표준(OPR1000·APR1400)은 16×16 배열이므로 화면에는 "예)"로 표기한다.

import * as THREE from 'three/webgpu';
import {
  Fn, float, vec2, vec3, vec4, uniform, uv, instanceIndex, instanceColor, instancedBufferAttribute, hash, normalWorld, positionWorld, positionLocal, positionGeometry,
  cameraPosition, normalize, length, dot, mix, smoothstep, clamp, pow, exp, sin, cos, abs, fract, atan, step, varying, max, min, mx_noise_float, reflect,
} from 'three/tsl';
import { shade, envColor, rng } from './studio.js';

const TAU = Math.PI * 2;
const V_ = (nW) => normalize(cameraPosition.sub(positionWorld));

/** 어두운 광택 바닥(원형): 위의 물체가 은은히 비치고 가장자리는 어둠으로 사라진다. warm = 바닥에 깔리는 따뜻한 반사광 */
export function makeFloor(radius = 60, warm = 0.3) {
  const mat = new THREE.MeshBasicNodeMaterial();
  mat.colorNode = Fn(() => {
    const n = vec3(0.0, 1.0, 0.0), V = normalize(cameraPosition.sub(positionWorld));
    const r = length(positionGeometry.xy);
    const R = reflect(V.negate(), n);
    const fres = pow(float(1.0).sub(clamp(dot(n, V), 0.0, 1.0)), 4.0);
    const fade = smoothstep(radius, radius * 0.25, r);
    const pool = exp(pow(r.div(9.0), 2.0).negate());
    const col = vec3(0.012, 0.012, 0.016).add(envColor(R).mul(fres).mul(0.05)).add(vec3(0.5, 0.3, 0.1).mul(pool).mul(warm * 0.3));
    return vec4(col.mul(fade), 1.0);
  })();
  const m = new THREE.Mesh(new THREE.CircleGeometry(radius, 64), mat);
  m.rotation.x = -Math.PI / 2;
  return m;
}

/** 빛줄기 속 먼지: 상태 없음(해시 + 시간) */
export function makeMotes(ctx, count, half = new THREE.Vector3(8, 4, 8), color = new THREE.Color(1.0, 0.8, 0.5), size = 0.05, bright = 1.0) {
  const t = ctx.u.time, i = instanceIndex, h = (k) => hash(i.add(k * 977));
  const mat = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
  const p = vec3(h(1).sub(0.5).mul(2.0 * half.x), h(2).mul(half.y), h(3).sub(0.5).mul(2.0 * half.z));
  const drift = vec3(sin(t.mul(h(4).mul(0.5).add(0.1)).add(h(5).mul(6.28))).mul(0.5), sin(t.mul(0.2).add(h(8).mul(9.0))).mul(0.4), cos(t.mul(h(9).mul(0.4).add(0.1)).add(h(10).mul(6.28))).mul(0.5));
  mat.positionNode = p.add(drift);
  mat.scaleNode = h(11).mul(size).add(size * 0.5);
  mat.colorNode = vec3(color.r, color.g, color.b).mul(h(12).mul(0.7).add(0.3)).mul(bright).mul(sin(t.mul(h(13).mul(1.2).add(0.3)).add(h(14).mul(6.28))).mul(0.4).add(0.6));
  mat.opacityNode = smoothstep(0.5, 0.0, length(uv().sub(0.5))).pow(1.4);
  const s = new THREE.Sprite(mat); s.count = count; s.frustumCulled = false; s.renderOrder = 4;
  return s;
}

// ───────────────────────────── A) 옐로케이크 ─────────────────────────────
export function makeYellowcake(ctx) {
  const group = new THREE.Group();
  const R = 5.4, H = 2.8, N = 40000;
  const rnd = rng(11);
  const geo = new THREE.IcosahedronGeometry(1, 0);
  const mat = new THREE.MeshBasicNodeMaterial();
  mat.colorNode = Fn(() => {
    const n = normalize(normalWorld), V = normalize(cameraPosition.sub(positionWorld));
    return vec4(shade(n, V, instanceColor, { metal: 0.0, rough: 0.6 }), 1.0);
  })();
  const mesh = new THREE.InstancedMesh(geo, mat, N);
  const m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), e = new THREE.Euler(), pos = new THREE.Vector3(), sc = new THREE.Vector3(), col = new THREE.Color();
  const cA = new THREE.Color(0.9, 0.62, 0.07), cB = new THREE.Color(0.78, 0.36, 0.04), cC = new THREE.Color(0.58, 0.46, 0.13);
  const heap = (x, z) => { const r = Math.hypot(x, z) / R; return H * Math.pow(Math.max(0, 1 - r * r), 1.15) + 0.2 * Math.sin(x * 1.7 + z * 1.1) * Math.sin(z * 1.9 - x * 0.7); };
  for (let i = 0; i < N; i++) {
    const scatter = rnd() < 0.07;
    const r = scatter ? R * (0.9 + rnd() * 0.9) : R * Math.sqrt(rnd()), a = rnd() * TAU;
    const x = r * Math.cos(a), z = r * Math.sin(a);
    let depth = rnd() < 0.35 ? rnd() * 0.4 : rnd() * 0.1;
    const s = 0.045 + Math.pow(rnd(), 2.2) * 0.1;
    const y = scatter ? s * 0.6 : Math.max(s * 0.5, heap(x, z) - depth);
    pos.set(x, y, z); sc.set(s * (0.8 + rnd() * 0.5), s * (0.6 + rnd() * 0.5), s * (0.8 + rnd() * 0.5));
    e.set(rnd() * TAU, rnd() * TAU, rnd() * TAU); q.setFromEuler(e);
    m4.compose(pos, q, sc); mesh.setMatrixAt(i, m4);
    const k = rnd(); col.copy(cA).lerp(cB, k * k).lerp(cC, rnd() < 0.2 ? rnd() * 0.7 : 0).multiplyScalar(0.5 + 0.5 * Math.min(1, depth < 0.15 ? 1 : 0.6 + 0.4 * rnd()));
    mesh.setColorAt(i, col);
  }
  mesh.frustumCulled = false;
  group.add(mesh);
  const floor = makeFloor(70, 1.0); group.add(floor);
  const motes = makeMotes(ctx, 500, new THREE.Vector3(9, 6, 9), new THREE.Color(1.0, 0.78, 0.45), 0.045, 1.2); motes.position.y = 0.2; group.add(motes);
  return { group, mesh, motes, N, R, H, setCount(n) { mesh.count = Math.max(2000, Math.min(N, n | 0)); } };
}

// ───────────────────────────── G) 1000개 점 격자 ─────────────────────────────
export function makeDotGrid(ctx) {
  const group = new THREE.Group();
  const COLS = 40, ROWS = 25, N = COLS * ROWS, PITCH = 1.25, t = ctx.u.time;
  const rnd = rng(1000);
  const rank = new Float32Array(N); { const idx = Array.from({ length: N }, (_, i) => i); for (let i = N - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [idx[i], idx[j]] = [idx[j], idx[i]]; } idx.forEach((v, k) => { rank[v] = k; }); }
  const uK = uniform(0.0), uAppear = uniform(0.0), uA = uniform(1.0);
  const geo = new THREE.SphereGeometry(0.42, 18, 12);
  const rk = varying(instancedBufferAttribute(new THREE.InstancedBufferAttribute(rank, 1)), 'vRank');
  const ora = clamp(uK.sub(rk), 0.0, 1.0);
  const mat = new THREE.MeshBasicNodeMaterial({ transparent: true, depthWrite: true });
  // 등장: 중심에서 바깥으로 번지는 파문 + 약한 부유, 주황 점은 커지고 맥동
  const ph = hash(instanceIndex.mul(7).add(3));
  const appear = smoothstep(0.0, 1.0, uAppear.mul(1.7).sub(ph.mul(0.7)));
  const ii = float(instanceIndex), ctr = vec3(ii.mod(COLS).sub((COLS - 1) / 2).mul(PITCH), ii.div(COLS).floor().sub((ROWS - 1) / 2).mul(PITCH), 0.0);   // 이 점의 격자 중심
  const sz = appear.mul(float(1.0).add(ora.mul(0.9)).add(ora.mul(float(1.0).sub(ora)).mul(2.4)));
  const ex = smoothstep(0.0, 1.0, uAppear.mul(1.25));                                     // 한 점에서 격자가 퍼져 나옴
  mat.positionNode = ctr.mul(ex).add(positionLocal.sub(ctr).mul(sz)).add(vec3(0.0, sin(t.mul(0.8).add(ph.mul(6.28))).mul(0.06), 0.0));
  mat.colorNode = Fn(() => {
    const n = normalize(normalWorld), V = normalize(cameraPosition.sub(positionWorld));
    const rim = pow(float(1.0).sub(clamp(dot(n, V), 0.0, 1.0)), 2.2);
    const glass = shade(n, V, vec3(0.3, 0.42, 0.58), { metal: 0.25, rough: 0.35 }).mul(0.7).add(vec3(0.2, 0.55, 0.95).mul(rim).mul(0.45));
    const pulse = sin(t.mul(4.0).add(rk.mul(1.7))).mul(0.25).add(1.0);
    const fire = vec3(1.0, 0.36, 0.04).mul(pulse).mul(1.25).add(vec3(1.0, 0.6, 0.3).mul(rim).mul(0.7));
    return vec4(mix(glass, fire, ora), uA);
  })();
  const mesh = new THREE.InstancedMesh(geo, mat, N), m4 = new THREE.Matrix4();
  for (let i = 0; i < N; i++) { const c = i % COLS, r = (i / COLS) | 0; m4.makeTranslation((c - (COLS - 1) / 2) * PITCH, (r - (ROWS - 1) / 2) * PITCH, 0); mesh.setMatrixAt(i, m4); }
  mesh.frustumCulled = false; group.add(mesh);
  // 홀로그램 테두리
  const w = COLS * PITCH * 0.5 + 0.3, hgt = ROWS * PITCH * 0.5 + 0.3;
  const frame = new THREE.LineSegments(new THREE.BufferGeometry().setFromPoints([[-w, -hgt], [w, -hgt], [w, -hgt], [w, hgt], [w, hgt], [-w, hgt], [-w, hgt], [-w, -hgt]].map(([x, y]) => new THREE.Vector3(x, y, 0))),
    new THREE.LineBasicNodeMaterial({ color: 0x5ad7ff, transparent: true, opacity: 0.55, blending: THREE.AdditiveBlending, depthWrite: false }));
  group.add(frame);
  return { group, mesh, uK, uAppear, uA, N, w, h: hgt };
}

// ───────────────────────────── C) 펠릿 + 동전 ─────────────────────────────
export function pelletGeometry(radius = 0.41, halfLen = 0.55) {
  const c = 0.07, dish = 0.035, P = [[0, -halfLen + dish], [0.18, -halfLen + dish * 0.85], [0.31, -halfLen], [radius - c, -halfLen], [radius, -halfLen + c],
    [radius, halfLen - c], [radius - c, halfLen], [0.31, halfLen], [0.18, halfLen - dish * 0.85], [0, halfLen - dish]];
  return new THREE.LatheGeometry(P.map(([x, y]) => new THREE.Vector2(x, y)), 28);
}

/** 흑체 복사 근사: 0=차가움, 1=백열 (어두운 적색 → 주황 → 노랑-백) */
const blackbody = (h) => vec3(1.0, smoothstep(0.2, 0.9, h).mul(0.45), smoothstep(0.7, 1.1, h).mul(0.08)).mul(smoothstep(0.0, 0.5, h)).mul(h.mul(0.75).add(0.15));

export function makePellets(ctx) {
  const group = new THREE.Group();
  const uHeat = uniform(1.0), t = ctx.u.time;
  const geo = pelletGeometry();
  const mat = new THREE.MeshBasicNodeMaterial();
  const off = varying(hash(instanceIndex.mul(13).add(5)), 'vPOff');
  mat.colorNode = Fn(() => {
    const n = normalize(normalWorld), V = normalize(cameraPosition.sub(positionWorld));
    const speck = mx_noise_float(positionWorld.mul(46.0)).mul(0.5).add(0.5);
    const alb = vec3(0.075, 0.07, 0.065).mul(speck.mul(0.8).add(0.6));
    const hot = clamp(uHeat.sub(off.mul(0.18)).add(speck.sub(0.5).mul(0.3).mul(uHeat)), 0.0, 1.3);
    return vec4(shade(n, V, alb, { metal: 0.0, rough: 0.3 }).mul(float(1.0).sub(clamp(hot, 0.0, 1.0).mul(0.55))).add(blackbody(hot)), 1.0);
  })();
  const mesh = new THREE.InstancedMesh(geo, mat, 22), m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), e = new THREE.Euler(), rnd = rng(77);
  let k = 0;
  for (let row = 0; row < 6; row++) { const n = 6 - row; for (let i = 0; i < n; i++) {
    e.set(Math.PI / 2, (rnd() - 0.5) * 0.18, (rnd() - 0.5) * 0.12, 'XYZ'); q.setFromEuler(e);
    m4.compose(new THREE.Vector3((i - (n - 1) / 2) * 0.86 + (rnd() - 0.5) * 0.04, 0.41 + row * 0.74, (rnd() - 0.5) * 0.5), q, new THREE.Vector3(1, 1, 1)); mesh.setMatrixAt(k++, m4);
  } }
  mesh.setMatrixAt(21, m4.compose(new THREE.Vector3(-1.9, 0.55, 2.0), new THREE.Quaternion(), new THREE.Vector3(1, 1, 1)));        // 똑바로 선 대표 펠릿 (오목한 끝면이 위)
  mesh.frustumCulled = false; group.add(mesh);
  // 500원 동전 (지름 26.5 mm, 두께 약 1.9 mm): 은색 + 동심원 무늬 + 가장자리 톱니
  const coinMat = new THREE.MeshBasicNodeMaterial();
  coinMat.colorNode = Fn(() => {
    const n = normalize(normalWorld), V = normalize(cameraPosition.sub(positionWorld));
    const r = length(positionGeometry.xz), a = atan(positionGeometry.z, positionGeometry.x);
    const ring = smoothstep(0.35, 0.5, abs(fract(r.mul(7.5)).sub(0.5))), rim = smoothstep(1.2, 1.26, r);
    const reeded = smoothstep(0.4, 0.6, abs(fract(a.mul(36.0 / TAU)).sub(0.5)));
    const alb = vec3(0.78, 0.8, 0.84).mul(float(0.8).add(ring.mul(0.2)).add(rim.mul(0.15)));
    return vec4(shade(n, V, alb, { metal: 0.95, rough: 0.28 }).mul(float(1.0).sub(reeded.mul(0.0))), 1.0);
  })();
  const coin = new THREE.Mesh(new THREE.CylinderGeometry(1.325, 1.325, 0.19, 72), coinMat); coin.position.set(4.3, 0.095, 0.4);
  group.add(coin);
  const floor = makeFloor(70, 0.5); group.add(floor);
  const motes = makeMotes(ctx, 350, new THREE.Vector3(8, 5, 8), new THREE.Color(1.0, 0.7, 0.4), 0.04, 1.0); group.add(motes);
  return { group, mesh, coin, uHeat, motes };
}

// ───────────────────────────── D) 연료봉 → 연료집합체 ─────────────────────────────
export const ROD_L = 366, ROD_R = 0.475, PITCH_CM = 1.26;
const GUIDE = [[2, 5], [2, 8], [2, 11], [3, 3], [3, 13], [5, 2], [5, 5], [5, 8], [5, 11], [5, 14], [8, 2], [8, 5], [8, 11], [8, 14], [11, 2], [11, 5], [11, 8], [11, 11], [11, 14], [13, 3], [13, 13], [14, 5], [14, 8], [14, 11], [8, 8]];

export function makeRodAssembly(ctx) {
  const group = new THREE.Group();
  const uLoad = uniform(-1.0), uAsm = uniform(0.0), uOpaque = uniform(0.0), uBlue = uniform(0.0), uA = uniform(1.0);
  const HERO = [8, 7];                                             // 대표 연료봉(연료봉 자리 중 하나)
  const cell = (r, c) => [(c - 8) * PITCH_CM, (r - 8) * PITCH_CM];
  // 연료봉 외관 재질 (집합체용). 바깥쪽 연료봉일수록 늦게 뻗는다(uAsm 0→1): 집합체가 "조립되는" 연출
  const rodShade = (n, V, tint) => shade(n, V, tint.mul(vec3(0.62, 0.64, 0.68)), { metal: 0.85, rough: 0.35 });
  const growOf = (d) => smoothstep(0.0, 1.0, uAsm.mul(1.8).sub(d.mul(0.8)));          // d = 집합체 중심에서의 거리/11
  const attr = (arr, name) => varying(instancedBufferAttribute(new THREE.InstancedBufferAttribute(arr, 1)), name);
  const fogMul = (depth) => exp(depth.mul(0.0075).negate()).mul(0.7).add(0.3);
  const blueGlow = (depth, k) => vec3(0.1, 0.45, 1.0).mul(exp(depth.mul(0.012).negate())).mul(uBlue).mul(k);   // 체렌코프풍 푸른 빛(깊이에 따라 사라짐)
  const cells = [];
  for (let r = 0; r < 17; r++) for (let c = 0; c < 17; c++) { if (r === HERO[0] && c === HERO[1]) continue; cells.push([r, c]); }
  const guideSet = new Set(GUIDE.map(([r, c]) => r * 17 + c));
  const NG = 8, nC = cells.length;
  const dRod = new Float32Array(nC), dCol = new Float32Array(nC * NG), zCol = new Float32Array(nC * NG);
  const rodGeo = new THREE.CylinderGeometry(ROD_R, ROD_R, ROD_L, 14, 1, false); rodGeo.rotateX(Math.PI / 2); rodGeo.translate(0, 0, -ROD_L / 2);
  const rodMat = new THREE.MeshBasicNodeMaterial({ transparent: true, depthWrite: true });
  const aRodD = attr(dRod, 'vRodD');
  rodMat.positionNode = Fn(() => { const p = positionLocal; return vec3(p.x, p.y, p.z.mul(growOf(aRodD))); })();
  rodMat.colorNode = Fn(() => {
    const n = normalize(normalWorld), V = normalize(cameraPosition.sub(positionWorld)), depth = positionWorld.sub(cameraPosition).length();
    const base = rodShade(n, V, instanceColor);
    return vec4(base.mul(mix(vec3(1.0, 1.0, 1.0), vec3(0.35, 0.6, 1.0), uBlue.mul(0.8))).mul(fogMul(depth)).add(blueGlow(depth, 0.9)).add(vec3(0.2, 0.6, 1.0).mul(pow(float(1.0).sub(clamp(dot(n, V), 0.0, 1.0)), 3.0)).mul(uBlue).mul(1.2)), uA);
  })();
  const rods = new THREE.InstancedMesh(rodGeo, rodMat, nC), m4 = new THREE.Matrix4(), col = new THREE.Color();
  cells.forEach(([r, c], i) => {
    const [x, y] = cell(r, c); m4.makeTranslation(x, y, 0); rods.setMatrixAt(i, m4); dRod[i] = Math.hypot(x, y) / 11;
    const g = guideSet.has(r * 17 + c); col.setRGB(g ? 1.25 : 1.0, g ? 1.2 : 1.0, g ? 1.1 : 1.0); rods.setColorAt(i, col);
  });
  rods.frustumCulled = false; group.add(rods);
  // 지지격자(스페이서 그리드): 일정 간격의 마디
  const collarGeo = new THREE.CylinderGeometry(0.64, 0.64, 3.2, 14, 1, false); collarGeo.rotateX(Math.PI / 2);
  const collarMat = new THREE.MeshBasicNodeMaterial({ transparent: true });
  const aColD = attr(dCol, 'vColD'), aColZ = attr(zCol, 'vColZ');
  collarMat.positionNode = Fn(() => { const p = positionLocal; return vec3(p.x, p.y, p.z.add(aColZ.mul(growOf(aColD)))); })();
  collarMat.colorNode = Fn(() => {
    const n = normalize(normalWorld), V = normalize(cameraPosition.sub(positionWorld)), depth = positionWorld.sub(cameraPosition).length();
    return vec4(shade(n, V, vec3(0.45, 0.42, 0.38), { metal: 0.9, rough: 0.4 }).mul(fogMul(depth)).add(blueGlow(depth, 1.2)), uA);
  })();
  const collars = new THREE.InstancedMesh(collarGeo, collarMat, nC * NG);
  cells.forEach(([r, c], i) => { const [x, y] = cell(r, c); for (let g = 0; g < NG; g++) { const k = i * NG + g; m4.makeTranslation(x, y, 0); collars.setMatrixAt(k, m4); dCol[k] = dRod[i]; zCol[k] = -(34 + g * 44); } });
  collars.frustumCulled = false; group.add(collars);

  // 대표 연료봉: 반투명 피복관 + 안에 쌓인 펠릿(333개 = 전체 길이)
  const heroX = cell(HERO[0], HERO[1])[0], heroY = cell(HERO[0], HERO[1])[1];
  const hero = new THREE.Group(); hero.position.set(heroX, heroY, 0); group.add(hero);
  const tubeGeo = new THREE.CylinderGeometry(ROD_R, ROD_R, ROD_L, 28, 1, true); tubeGeo.rotateX(Math.PI / 2); tubeGeo.translate(0, 0, -ROD_L / 2);
  const tubeMat = new THREE.MeshBasicNodeMaterial({ transparent: true, depthWrite: false, side: THREE.DoubleSide });
  tubeMat.colorNode = Fn(() => {
    const n = normalize(normalWorld), V = normalize(cameraPosition.sub(positionWorld)), depth = positionWorld.sub(cameraPosition).length();
    const fres = pow(float(1.0).sub(abs(dot(n, V))), 2.0);
    const c = shade(n, V, vec3(0.62, 0.64, 0.68), { metal: 0.9, rough: 0.3 }).mul(0.9);
    const a = clamp(fres.mul(0.55).add(0.16).add(uOpaque.mul(0.85)), 0.0, 1.0);
    return vec4(c.mul(exp(depth.mul(0.0075).negate()).mul(0.7).add(0.3)).add(vec3(0.1, 0.45, 1.0).mul(uBlue).mul(exp(depth.mul(0.012).negate())).mul(2.2)), a);
  })();
  const tube = new THREE.Mesh(tubeGeo, tubeMat); tube.renderOrder = 3; hero.add(tube);
  // 끝마개
  const cap = new THREE.Mesh(new THREE.CylinderGeometry(ROD_R * 0.98, ROD_R * 0.98, 0.5, 28), tubeMat); cap.rotation.x = Math.PI / 2; cap.position.z = 0.25; hero.add(cap);
  const pGeo = pelletGeometry(0.41, 0.54); pGeo.rotateX(Math.PI / 2);
  const NPEL = 330;
  const pMat = new THREE.MeshBasicNodeMaterial();
  pMat.positionNode = Fn(() => {
    const kk = float(instanceIndex), early = step(kk, 17.5);                // 앞쪽(관 입구 근처) 18개만 "밀려 들어가는" 연출
    const d = clamp(uLoad.sub(float(17.0).sub(kk).mul(0.05)).div(0.45), 0.0, 1.0);
    const off = float(1.0).sub(d.mul(d).mul(float(3.0).sub(d.mul(2.0)))).mul(early).mul(26.0);
    return positionLocal.add(vec3(0.0, 0.0, off));
  })();
  pMat.colorNode = Fn(() => {
    const n = normalize(normalWorld), V = normalize(cameraPosition.sub(positionWorld)), depth = positionWorld.sub(cameraPosition).length();
    const speck = mx_noise_float(positionWorld.mul(46.0)).mul(0.5).add(0.5);
    return vec4(shade(n, V, vec3(0.085, 0.078, 0.07).mul(speck.mul(0.8).add(0.6)), { metal: 0.0, rough: 0.32 }).mul(exp(depth.mul(0.0075).negate())), 1.0);
  })();
  const pellets = new THREE.InstancedMesh(pGeo, pMat, NPEL);
  for (let i = 0; i < NPEL; i++) { m4.makeTranslation(0, 0, -(0.8 + i * 1.12)); pellets.setMatrixAt(i, m4); }
  pellets.frustumCulled = false; hero.add(pellets);
  const motes = makeMotes(ctx, 300, new THREE.Vector3(5, 3, 14), new THREE.Color(0.7, 0.85, 1.0), 0.035, 0.9); motes.position.set(0, 0, -8); group.add(motes);
  return { group, hero, rods, collars, tube, pellets, uLoad, uAsm, uOpaque, uBlue, uA, motes, heroPos: new THREE.Vector3(heroX, heroY, 0) };
}
