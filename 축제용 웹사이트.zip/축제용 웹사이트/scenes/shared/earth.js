// scenes/shared/earth.js — 프로시저럴 지구: 해안선 마스크 + 낮/밤 + 야간 도시 불빛 + 구름 + 대기 산란(근사)
//
//  좌표(오프닝 공통): 태양=원점, 지구 중심 = EARTH_POS(+X 쪽), 지구 반지름 EARTH_R(연출용 비율). 태양빛은 항상 −X 방향에서 온다.
//  지구는 한반도(서울)가 KOR_UP 방향을 향하도록 회전해 있다 → 혜성은 이 방향으로 접근하며, 서울이 해 질 녘(터미네이터)에 걸린다.
//  셰이더 구성:
//    · 표면   : 마스크(R=육지, G=불빛) → 바다/육지/극지 색, 일조 램버트, 터미네이터 노을, 바다 반사광, 야간 불빛, 가장자리 대기 산란
//    · 구름   : 별도 껍질(1.008R). 4옥타브 fBm + 카메라가 가까워질수록 고주파 디테일이 켜짐(uDetail)
//    · 대기   : 큰 껍질(1.09R, BackSide). "광선이 지구 중심에서 얼마나 가깝게 지나가는가(충돌 파라미터)"로 글로우 세기를 계산 → 안/밖 어디서 봐도 연속

import * as THREE from 'three/webgpu';
import {
  Fn, float, vec2, vec3, vec4, uniform, texture, positionLocal, normalWorld, positionWorld, cameraPosition,
  normalize, length, dot, mix, smoothstep, clamp, pow, exp, sqrt, asin, atan, step, abs, max, reflect, negate,
} from 'three/tsl';
import { fbm3 } from '../../engine/tsl.js';
import { buildEarthMasks } from './earthMasks.js';

export const EARTH_R = 40;
export const EARTH_POS = new THREE.Vector3(2640, 0, 0);
export const KOR_UP = new THREE.Vector3(0.15, 0.25, 0.96).normalize();     // 한반도가 향하는 월드 방향(지구 중심 기준)
export const SEOUL_LL = { lat: 37.5665, lon: 126.978 };
const D2R = Math.PI / 180;

/** 위경도 → 모델 공간 단위 법선: n = (cos φ cos λ, sin φ, −cos φ sin λ)  (셰이더의 lon/lat 해석과 동일) */
export function llToNormal(lat, lon, out = new THREE.Vector3()) {
  const la = lat * D2R, lo = lon * D2R;
  return out.set(Math.cos(la) * Math.cos(lo), Math.sin(la), -Math.cos(la) * Math.sin(lo));
}

/** (lat,lon) 지점이 월드의 upW 방향을 향하고 북쪽이 northHint 쪽이 되게 하는 쿼터니언 */
export function orientEarth(lat, lon, upW, northHint = new THREE.Vector3(0, 1, 0)) {
  const la = lat * D2R, lo = lon * D2R;
  const u = llToNormal(lat, lon);
  const e = new THREE.Vector3(-Math.sin(lo), 0, -Math.cos(lo));                                                   // 동쪽 = ∂n/∂λ (정규화)
  const n = new THREE.Vector3().crossVectors(u, e).normalize();                                                    // 북쪽 = up × east
  const Bm = new THREE.Matrix4().makeBasis(e, n, u);
  const uw = upW.clone().normalize();
  const nw = northHint.clone().addScaledVector(uw, -northHint.dot(uw)).normalize();
  const ew = new THREE.Vector3().crossVectors(nw, uw).normalize();
  const Bw = new THREE.Matrix4().makeBasis(ew, nw, uw);
  const M = new THREE.Matrix4().multiplyMatrices(Bw, Bm.clone().transpose());
  return new THREE.Quaternion().setFromRotationMatrix(M);
}

export async function makeEarth(ctx) {
  const R = EARTH_R;
  const root = new THREE.Group();
  root.position.copy(EARTH_POS);
  const t = ctx.u.time;

  const masks = buildEarthMasks();
  const gTex = new THREE.CanvasTexture(masks.global), kTex = new THREE.CanvasTexture(masks.korea);
  for (const tx of [gTex, kTex]) { tx.colorSpace = THREE.NoColorSpace; tx.generateMipmaps = true; tx.minFilter = THREE.LinearMipmapLinearFilter; tx.magFilter = THREE.LinearFilter; tx.anisotropy = 8; tx.wrapS = THREE.ClampToEdgeWrapping; tx.wrapT = THREE.ClampToEdgeWrapping; tx.needsUpdate = true; }
  const K = masks.koreaBox;

  const quat = orientEarth(SEOUL_LL.lat, SEOUL_LL.lon, KOR_UP);
  const sunW = vec3(-1, 0, 0);                              // 태양 쪽 방향(월드)
  const uDetail = uniform(0);                               // 0~1: 카메라가 가까울수록 구름/불빛 고주파 디테일 on
  const uCloudSpin = uniform(0);
  const uGreen = uniform(0);                                // 0~1: 한반도 야경 불빛을 초록으로 물들이는 정도 (피날레)

  // 위경도 + 마스크 샘플 (표면/구름 공통)
  const geo = (p) => {
    const lon = atan(p.z.negate(), p.x), lat = asin(clamp(p.y, -1.0, 1.0));
    const uvG = vec2(lon.div(Math.PI * 2).add(0.5), lat.div(Math.PI).add(0.5));
    const lonD = lon.mul(180 / Math.PI), latD = lat.mul(180 / Math.PI);
    const uvK = vec2(lonD.sub(K.lon0).div(K.lon1 - K.lon0), latD.sub(K.lat0).div(K.lat1 - K.lat0));
    const inK = step(0.0, uvK.x).mul(step(uvK.x, 1.0)).mul(step(0.0, uvK.y)).mul(step(uvK.y, 1.0));
    const sg = texture(gTex, uvG), sk = texture(kTex, clamp(uvK, 0.0, 1.0));
    return { land: mix(sg.r, sk.r, inK), city: mix(sg.g, sk.g, inK), latAbs: abs(p.y), inK };
  };

  // ── 표면 ──
  const surfMat = new THREE.MeshBasicNodeMaterial();
  surfMat.colorNode = Fn(() => {
    const p = normalize(positionLocal);
    const nW = normalize(normalWorld);
    const viewW = normalize(cameraPosition.sub(positionWorld));
    const { land, city, latAbs, inK } = geo(p);
    const ndl = dot(nW, sunW);
    const day = smoothstep(-0.06, 0.2, ndl);
    const lam = clamp(ndl, 0.0, 1.0);

    // 색: 바다는 짙은 파랑(연안은 밝게), 육지는 위도/노이즈에 따른 초록~황토, 극지는 눈
    const biome = fbm3(p.mul(5.0)).mul(0.5).add(0.5);
    const landL = smoothstep(0.35, 0.65, land);
    const oceanCol = mix(vec3(0.012, 0.07, 0.22), vec3(0.03, 0.2, 0.42), smoothstep(0.0, 0.35, land));
    const dry = smoothstep(0.55, 0.8, biome).mul(smoothstep(0.55, 0.15, latAbs));
    const landCol = mix(mix(vec3(0.06, 0.14, 0.05), vec3(0.17, 0.22, 0.09), biome), vec3(0.42, 0.34, 0.2), dry);
    const ice = smoothstep(0.8, 0.92, latAbs.add(fbm3(p.mul(7.0)).mul(0.05)));
    let albedo = mix(oceanCol, landCol, landL);
    albedo = mix(albedo, vec3(0.9, 0.93, 1.0), ice);

    // 바다 태양 반사광 (물결 노이즈로 흩어진 하이라이트)
    const rv = reflect(sunW.negate(), nW);
    const glint = pow(max(dot(rv, viewW), 0.0), 90.0).mul(float(1.0).sub(landL)).mul(day).mul(fbm3(p.mul(60.0).add(vec3(0, 0, t.mul(0.05)))).mul(0.4).add(0.8));

    // 터미네이터 노을: 낮/밤 경계에 주황빛
    const twilight = exp(pow(ndl.div(0.16), 2.0).negate());
    let col = albedo.mul(lam.mul(1.55)).add(vec3(1.0, 0.8, 0.55).mul(glint).mul(2.2));
    col = col.add(vec3(1.0, 0.42, 0.12).mul(twilight).mul(0.11).mul(landL.mul(0.5).add(0.5)));
    // 어두운 쪽 지표는 아주 약한 푸른 달빛 정도
    col = col.add(albedo.mul(vec3(0.02, 0.03, 0.06)).mul(float(1.0).sub(day)));

    // 야간 불빛: 육지 위에서만, 낮에는 사라짐. 가까워지면 점 알갱이처럼 쪼개진다
    const grain = smoothstep(0.45, 0.62, fbm3(p.mul(900.0)).mul(0.5).add(0.5));
    const cityL = pow(city, 1.5).mul(landL).mul(mix(float(1.0), grain.mul(2.0), uDetail));
    const sn = llToNormal(SEOUL_LL.lat, SEOUL_LL.lon);
    const koreaMask = smoothstep(0.985, 0.995, dot(p, vec3(sn.x, sn.y, sn.z)));              // 서울 중심 약 6~10° 안쪽만(한반도) — 가장자리는 부드럽게
    col = col.add(mix(vec3(1.0, 0.72, 0.38), vec3(0.08, 1.0, 0.32), koreaMask.mul(uGreen)).mul(cityL).mul(mix(float(1.15), float(0.85), koreaMask.mul(uGreen))).mul(float(1.0).sub(day)));

    // 가장자리 대기 산란(근사): 가장자리일수록 푸르게, 낮 쪽만
    const fres = pow(float(1.0).sub(clamp(dot(nW, viewW), 0.0, 1.0)), 3.2);
    col = col.add(mix(vec3(0.1, 0.22, 0.55), vec3(0.9, 0.45, 0.2), twilight.mul(0.5)).mul(fres).mul(day.mul(0.9).add(0.12)).mul(1.5));
    return vec4(col, 1.0);
  })();
  const sphere = new THREE.Mesh(new THREE.SphereGeometry(R, 256, 160), surfMat);
  sphere.quaternion.copy(quat);
  sphere.name = 'earth-surface';
  root.add(sphere);

  // ── 구름 ──
  const cloudMat = new THREE.MeshBasicNodeMaterial({ transparent: true, depthWrite: false });
  cloudMat.colorNode = Fn(() => {
    const p = normalize(positionLocal);
    const nW = normalize(normalWorld);
    const ndl = dot(nW, sunW);
    const day = smoothstep(-0.12, 0.25, ndl);
    const drift = vec3(uCloudSpin, 0.0, 0.0);
    let d = fbm3(p.mul(2.4).add(drift)).mul(1.15).add(fbm3(p.mul(7.0).add(drift.mul(1.3)).add(11.0)).mul(0.35)).add(0.08);
    // 가까워지면 고주파 디테일이 추가된다(적란운 덩어리 느낌)
    d = d.add(fbm3(p.mul(70.0).add(drift)).mul(0.45).mul(uDetail));
    const a = smoothstep(0.3, 0.66, d);
    const twilight = exp(pow(ndl.div(0.2), 2.0).negate());
    const lit = vec3(1.0, 1.0, 1.0).mul(clamp(ndl, 0.0, 1.0).mul(1.4).add(0.04));
    const col = mix(lit, vec3(1.0, 0.55, 0.28).mul(0.8), twilight.mul(0.6).mul(day.mul(0.7).add(0.3))).mul(day.mul(0.92).add(0.08));
    const night = vec3(0.012, 0.016, 0.03);                              // 밤의 구름은 어두운 회청색 실루엣
    return vec4(mix(night, col, day), a.mul(0.92));
  })();
  const clouds = new THREE.Mesh(new THREE.SphereGeometry(R * 1.008, 192, 128), cloudMat);
  clouds.quaternion.copy(quat);
  clouds.renderOrder = 3;
  root.add(clouds);

  // ── 대기(껍질) ──
  const atmoMat = new THREE.MeshBasicNodeMaterial({ transparent: true, depthWrite: false, side: THREE.BackSide, blending: THREE.AdditiveBlending });
  const AT = 1.09;
  atmoMat.colorNode = Fn(() => {
    const C = vec3(EARTH_POS.x, EARTH_POS.y, EARTH_POS.z);
    const ray = normalize(positionWorld.sub(cameraPosition));
    const oc = cameraPosition.sub(C);
    const b = dot(oc, ray);
    const closest = oc.sub(ray.mul(b));                           // 광선이 지구 중심에 가장 가까운 점(중심 기준 벡터)
    const h = length(closest);                                    // 충돌 파라미터
    const hn = h.div(R);
    const out = max(hn.sub(1.0), 0.0);
    const glow = exp(out.mul(-34.0)).mul(smoothstep(AT, 1.0, hn)).mul(step(1.0, hn));
    const dirC = closest.div(max(h, 0.001));
    const sunSide = dot(dirC, sunW);                              // 림이 태양 쪽인지
    const dayF = smoothstep(-0.25, 0.45, sunSide);
    const tw = exp(pow(sunSide.div(0.22), 2.0).negate());
    const col = mix(vec3(0.16, 0.38, 1.0), vec3(1.0, 0.5, 0.2), tw.mul(0.55)).mul(glow).mul(dayF.mul(1.5).add(0.06));
    return vec4(col.mul(1.4), 1.0);
  })();
  const atmo = new THREE.Mesh(new THREE.SphereGeometry(R * AT, 128, 96), atmoMat);
  atmo.renderOrder = 4;
  root.add(atmo);

  return { root, sphere, clouds, atmo, uDetail, uCloudSpin, uGreen, quat, R, masks };
}
