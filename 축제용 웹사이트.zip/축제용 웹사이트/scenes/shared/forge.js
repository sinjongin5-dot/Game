// scenes/shared/forge.js — "빛 입자 단조(forge)": 한 점에서 쏟아져 나온 빛 입자가 글자 모양으로 모여 3D 글자를 빚는다 (Ch.4 E=mc²)
//
//  titleText.js 의 sampleText 로 글자 픽셀을 샘플링해 목표 위치를 얻고, 입자는 "씬 로컬 시간 uT 의 함수"로 셰이더 안에서 이동한다(상태 없음).
//   · 왼쪽 글자 픽셀부터(key) 차례로 출발해 소용돌이치며 도착 → 글자 윤곽이 빛으로 그려진다.
//   · uBurst(0→): 모든 입자가 글자에서 사방(카메라 쪽 포함)으로 폭발적으로 퍼진다 → 화이트아웃.

import * as THREE from 'three/webgpu';
import {
  float, vec3, uniform, uv, instanceIndex, instancedBufferAttribute, hash, normalize, length, mix, smoothstep, pow, sin, cos, exp, clamp, varying, max, min,
} from 'three/tsl';
import { sphereDir } from '../../engine/tsl.js';
import { sampleText, TITLE_W } from './titleText.js';

export function makeForge(ctx, N, text, worldW = 12, center = new THREE.Vector3()) {
  const uT = uniform(0.0), uBurst = uniform(0.0), uVis = uniform(1.0);
  const uSource = uniform(new THREE.Vector3()), uStart = uniform(0.0), uSpan = uniform(4.0);
  const uCenter = uniform(center.clone());
  const k = worldW / TITLE_W;
  const { A, B } = sampleText(text, N, 777);
  const a = instancedBufferAttribute(new THREE.InstancedBufferAttribute(A, 4)), b = instancedBufferAttribute(new THREE.InstancedBufferAttribute(B, 4));
  const i = instanceIndex, h = (n) => hash(i.add(n));
  const key = a.z, isEdge = a.w;
  const target = uCenter.add(vec3(a.x.mul(k), a.y.mul(k), b.z.sub(0.5).mul(0.25)));
  const dir = sphereDir(b.x, b.y);
  const p0 = uSource.add(dir.mul(b.w.mul(0.5).add(0.1)));
  const tc = uStart.add(key.mul(uSpan)).add(b.w.mul(0.3));
  const dur = b.z.mul(0.9).add(1.6);
  const x = clamp(uT.sub(tc).div(dur), 0.0, 1.0);
  const s = x.mul(x).mul(x).mul(x.mul(x.mul(6.0).sub(15.0)).add(10.0));                         // smootherstep
  const swirl = normalize(dir.cross(vec3(0.0, 1.0, 0.0)).add(vec3(0.001, 0.0, 0.0))).mul(sin(s.mul(3.14159)).mul(b.y.mul(3.0).add(1.2)));
  const arrived = vec3(sin(uT.mul(5.0).add(b.x.mul(40.0))), cos(uT.mul(4.0).add(b.y.mul(40.0))), 0.0).mul(0.02);
  let pos = mix(p0, target, s).add(swirl).add(arrived.mul(s));
  // 폭발: 글자 위치에서 바깥(+카메라 쪽)으로
  const out = normalize(target.sub(uCenter).add(vec3(0.0, 0.0, 0.9)).add(dir.mul(0.6)));
  pos = pos.add(out.mul(uBurst.mul(uBurst).mul(b.z.mul(30.0).add(14.0))));

  const born = smoothstep(0.0, 0.15, uT.sub(tc));
  const col = mix(vec3(1.0, 0.8, 0.4), vec3(0.45, 0.95, 1.0), s).mul(mix(0.22, 1.0, isEdge)).mul(born).mul(uVis).mul(float(1.0).add(uBurst.mul(2.5)));
  const mat = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
  mat.positionNode = pos;
  mat.scaleNode = float(0.045).add(h(3).mul(0.05)).mul(float(1.0).add(uBurst.mul(1.5)));
  mat.colorNode = varying(col.mul(0.9), 'vForge');
  mat.opacityNode = smoothstep(0.5, 0.0, length(uv().sub(0.5))).pow(1.4);
  const points = new THREE.Sprite(mat);
  points.count = N; points.frustumCulled = false; points.renderOrder = 8;
  return { points, uT, uBurst, uVis, uSource, uStart, uSpan, uCenter, N, setCount(n) { points.count = Math.max(1000, Math.min(N, n | 0)); } };
}
