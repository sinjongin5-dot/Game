// scenes/shared/worm.js — 피날레 해킹 연출: 지구를 뒤덮는 "웜 네트워크" (순수 시각 효과 — 실제 네트워크 통신은 전혀 없다)
//
//  전 세계 48개 도시를 노드로, 가까운 도시끼리 아치형 회선으로 잇는다. 서울에서 시작한 붉은 감염이 회선을 타고 번지고(다익스트라 순서),
//  감염된 회선에는 데이터 패킷이 달린다. 시간을 거꾸로 돌리면(uT 감소) 감염이 되감긴다 — 되감기 연출에 그대로 쓴다.
//  좌표: 지구(EARTH_POS, 반지름 EARTH_R). 위경도 → 모델 법선 → 지구 회전(earth.quat)을 거쳐 월드 방향.

import * as THREE from 'three/webgpu';
import {
  Fn, float, vec3, vec4, uniform, uv, instanceIndex, instancedBufferAttribute, hash, attribute, normalize, length, mix, smoothstep, clamp, pow, exp, sin, fract, step,
  varying, positionLocal,
} from 'three/tsl';
import { EARTH_POS, EARTH_R, llToNormal } from './earth.js';

const CITIES = [
  ['서울', 37.57, 126.98], ['도쿄', 35.68, 139.69], ['베이징', 39.9, 116.4], ['상하이', 31.23, 121.47], ['싱가포르', 1.35, 103.82], ['뭄바이', 19.08, 72.88],
  ['두바이', 25.2, 55.27], ['모스크바', 55.76, 37.62], ['런던', 51.51, -0.13], ['파리', 48.86, 2.35], ['프랑크푸르트', 50.11, 8.68], ['카이로', 30.04, 31.24],
  ['라고스', 6.52, 3.38], ['나이로비', -1.29, 36.82], ['요하네스버그', -26.2, 28.05], ['시드니', -33.87, 151.21], ['오클랜드', -36.85, 174.76], ['자카르타', -6.2, 106.85],
  ['방콕', 13.76, 100.5], ['홍콩', 22.32, 114.17], ['타이베이', 25.03, 121.57], ['마닐라', 14.6, 120.98], ['델리', 28.61, 77.21], ['이스탄불', 41.01, 28.98],
  ['마드리드', 40.42, -3.7], ['로마', 41.9, 12.5], ['스톡홀름', 59.33, 18.07], ['뉴욕', 40.71, -74.0], ['토론토', 43.65, -79.38], ['시카고', 41.88, -87.63],
  ['로스앤젤레스', 34.05, -118.24], ['샌프란시스코', 37.77, -122.42], ['시애틀', 47.61, -122.33], ['멕시코시티', 19.43, -99.13], ['보고타', 4.71, -74.07], ['리마', -12.05, -77.04],
  ['상파울루', -23.55, -46.63], ['부에노스아이레스', -34.6, -58.38], ['산티아고', -33.45, -70.67], ['호놀룰루', 21.31, -157.86], ['앵커리지', 61.22, -149.9], ['레이캬비크', 64.15, -21.94],
  ['퍼스', -31.95, 115.86], ['울란바토르', 47.89, 106.91], ['테헤란', 35.69, 51.39], ['카라치', 24.86, 67.0], ['다카', 23.81, 90.41], ['하노이', 21.03, 105.85],
];
export const WORM_NODES = CITIES.length;

// ── 그래프: 각 노드를 가장 가까운 3개와 연결 + 서울에서 먼 허브로 몇 개의 장거리 회선 ──
const dirs = CITIES.map(([, la, lo]) => llToNormal(la, lo, new THREE.Vector3()));
const ang = (a, b) => Math.acos(Math.min(1, Math.max(-1, dirs[a].dot(dirs[b]))));
const edgeSet = new Map();
const addEdge = (a, b) => { if (a === b) return; const k = a < b ? `${a}-${b}` : `${b}-${a}`; if (!edgeSet.has(k)) edgeSet.set(k, [a, b]); };
for (let i = 0; i < CITIES.length; i++) {
  const order = CITIES.map((_, j) => j).filter((j) => j !== i).sort((x, y) => ang(i, x) - ang(i, y));
  for (let k = 0; k < 3; k++) addEdge(i, order[k]);
}
for (const j of [27, 8, 15, 36, 12, 31]) addEdge(0, j);                                  // 서울 → 뉴욕·런던·시드니·상파울루·라고스·샌프란시스코(장거리)
const EDGES = [...edgeSet.values()];

// 서울(0)에서 퍼지는 감염 시각(다익스트라): 회선 하나를 건너는 데 약 0.4~0.6초
const rngS = (s) => { let a = s >>> 0; return () => { a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; };
const rr = rngS(5505);
const EDGE_DUR = EDGES.map(([a, b]) => 0.3 + ang(a, b) * 0.55 + rr() * 0.1);
export const T_INF = (() => {
  const t = new Array(CITIES.length).fill(Infinity); t[0] = 0.3;
  const done = new Array(CITIES.length).fill(false);
  for (let it = 0; it < CITIES.length; it++) {
    let u = -1; for (let i = 0; i < t.length; i++) if (!done[i] && (u < 0 || t[i] < t[u])) u = i;
    if (u < 0 || t[u] === Infinity) break; done[u] = true;
    EDGES.forEach(([a, b], e) => { if (a === u && t[b] > t[u] + EDGE_DUR[e]) t[b] = t[u] + EDGE_DUR[e]; if (b === u && t[a] > t[u] + EDGE_DUR[e]) t[a] = t[u] + EDGE_DUR[e]; });
  }
  return t;
})();
export const WORM_END = Math.max(...T_INF) + 0.6;                                       // 모든 노드가 감염되는 시각(웜 시작 기준 초)
/** uT(웜 시작 후 초) 시점에 감염된 노드 수 */
export const wormInfectedAt = (uT) => T_INF.reduce((n, t) => n + (uT >= t ? 1 : 0), 0);

export function makeWorm(ctx, earthQuat) {
  const root = new THREE.Group(); root.position.copy(EARTH_POS);
  const t = ctx.u.time;
  const uT = uniform(0.0), uA = uniform(1.0);
  const R0 = EARTH_R * 1.012;
  const wdir = dirs.map((d) => d.clone().applyQuaternion(earthQuat));

  // ── 회선(아치) ──
  const SEG = 36, pos = [], aS = [], aT0 = [], aDur = [];
  EDGES.forEach(([a, b], e) => {
    const A = wdir[a], B = wdir[b], w = Math.acos(Math.min(1, A.dot(B))), sinw = Math.sin(w) || 1;
    // 감염은 먼저 감염된 쪽에서 나중 쪽으로 진행한다
    const fromA = T_INF[a] <= T_INF[b], te = Math.min(T_INF[a], T_INF[b]);
    const pt = (s) => { const k = fromA ? s : 1 - s; const p = A.clone().multiplyScalar(Math.sin((1 - k) * w) / sinw).addScaledVector(B, Math.sin(k * w) / sinw); const h = EARTH_R * (0.012 + 0.2 * (w / Math.PI) * Math.sin(Math.PI * k)); return p.multiplyScalar(EARTH_R + h); };
    for (let i = 0; i < SEG; i++) { const s0 = i / SEG, s1 = (i + 1) / SEG; for (const s of [s0, s1]) { const p = pt(s); pos.push(p.x, p.y, p.z); aS.push(s); aT0.push(te); aDur.push(EDGE_DUR[e]); } }
  });
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute('aS', new THREE.Float32BufferAttribute(aS, 1));
  g.setAttribute('aT0', new THREE.Float32BufferAttribute(aT0, 1)); g.setAttribute('aDur', new THREE.Float32BufferAttribute(aDur, 1));
  const lm = new THREE.LineBasicNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
  lm.colorNode = Fn(() => {
    const s = attribute('aS', 'float'), te = attribute('aT0', 'float'), dur = attribute('aDur', 'float');
    const prog = clamp(uT.sub(te).div(dur), 0.0, 1.0);
    const infected = float(1.0).sub(smoothstep(prog.sub(0.02), prog.add(0.001), s)).mul(step(0.0001, prog));      // s < prog 인 부분
    const head = exp(pow(s.sub(prog).div(0.035), 2.0).negate()).mul(step(0.0001, prog)).mul(float(1.0).sub(step(0.9999, prog)));
    const idle = vec3(0.15, 0.7, 1.0).mul(0.35);
    const hot = vec3(1.0, 0.12, 0.42).mul(1.6).add(vec3(1.0, 0.8, 0.9).mul(head).mul(2.5));
    return vec4(mix(idle, hot, infected).add(vec3(1.0, 0.9, 1.0).mul(head).mul(2.0)).mul(uA), 1.0);
  })();
  const lines = new THREE.LineSegments(g, lm); lines.frustumCulled = false; lines.renderOrder = 7; root.add(lines);

  // ── 노드(도시): 대기 중 청록 → 감염 시 붉은 파문 ──
  const nodeAttr = new Float32Array(CITIES.length * 4);
  CITIES.forEach((_, i) => { nodeAttr.set([wdir[i].x * R0, wdir[i].y * R0, wdir[i].z * R0, T_INF[i]], i * 4); });
  const nm = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
  {
    const a = instancedBufferAttribute(new THREE.InstancedBufferAttribute(nodeAttr, 4));
    const dt = uT.sub(a.w);
    const pulse = exp(dt.max(0.0).mul(-2.6)).mul(step(0.0, dt));
    nm.positionNode = a.xyz;
    nm.scaleNode = float(1.1).add(pulse.mul(3.2)).add(step(0.0, dt).mul(0.5));
    const col = mix(vec3(0.2, 0.9, 1.0), vec3(1.0, 0.15, 0.4), step(0.0, dt)).mul(float(1.0).add(pulse.mul(3.0))).mul(uA);
    nm.colorNode = varying(col, 'vWormNode');
    nm.opacityNode = smoothstep(0.5, 0.0, length(uv().sub(0.5))).pow(1.5);
  }
  const nodes = new THREE.Sprite(nm); nodes.count = CITIES.length; nodes.frustumCulled = false; nodes.renderOrder = 8; root.add(nodes);

  // ── 패킷: 감염된 회선을 따라 달리는 빛 알갱이 ──
  const NP = 520, rp = rngS(77);
  const pa = new Float32Array(NP * 4), pb = new Float32Array(NP * 4), pc = new Float32Array(NP * 4);
  for (let i = 0; i < NP; i++) {
    const e = Math.floor(rp() * EDGES.length), [a, b] = EDGES[e], fromA = T_INF[a] <= T_INF[b];
    const A = wdir[fromA ? a : b], B = wdir[fromA ? b : a], w = Math.acos(Math.min(1, A.dot(B)));
    const mid = A.clone().add(B).normalize().multiplyScalar(EARTH_R * (1.012 + 0.2 * (w / Math.PI) * 2.0));       // 2차 베지어 제어점(아치 정점을 지나도록 2배)
    pa.set([A.x * R0, A.y * R0, A.z * R0, Math.min(T_INF[a], T_INF[b]) + EDGE_DUR[e]], i * 4); pb.set([B.x * R0, B.y * R0, B.z * R0, rp()], i * 4); pc.set([mid.x, mid.y, mid.z, 0.4 + rp() * 0.9], i * 4);
  }
  const pm = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
  {
    const A = instancedBufferAttribute(new THREE.InstancedBufferAttribute(pa, 4)), B = instancedBufferAttribute(new THREE.InstancedBufferAttribute(pb, 4)), C = instancedBufferAttribute(new THREE.InstancedBufferAttribute(pc, 4));
    const s = fract(B.w.add(t.mul(C.w))), om = float(1.0).sub(s);
    pm.positionNode = A.xyz.mul(om.mul(om)).add(C.xyz.mul(om.mul(s).mul(2.0))).add(B.xyz.mul(s.mul(s)));
    pm.scaleNode = float(0.5);
    const on = step(0.0, uT.sub(A.w));
    pm.colorNode = varying(vec3(1.0, 0.55, 0.85).mul(on).mul(uA).mul(1.6), 'vWormPkt');
    pm.opacityNode = smoothstep(0.5, 0.0, length(uv().sub(0.5))).pow(1.4);
  }
  const packets = new THREE.Sprite(pm); packets.count = NP; packets.frustumCulled = false; packets.renderOrder = 8; root.add(packets);

  return { root, uT, uA, packets };
}
