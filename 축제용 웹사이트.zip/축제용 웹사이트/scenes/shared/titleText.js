// scenes/shared/titleText.js — "친환경 에너지" 글자 데이터
//
//  ① sampleText(text, N) : 오프스크린 캔버스에 글자를 그린 뒤 픽셀을 샘플링 → 파티클 목표 위치
//        · 외곽선 픽셀(≈58%)  = 네온 선으로 "그려지는" 파티클   · 안쪽 픽셀(≈42%) = 글자 면을 채우는 파티클
//        · key = 왼쪽→오른쪽 순서값(0~1): 이 순서대로 파티클이 모여 글자가 그려지고, 같은 순서로 풍화된다
//  ② buildTitleTexture(text) : 실제 폰트 글자(금속 그라데이션 + 청록 네온 외곽 + 부드러운 발광)를 캔버스 텍스처로
//  좌표: 평면 좌표(유닛). 가로 폭 TITLE_W, 세로는 캔버스 비율대로. 월드 배치는 호출하는 쪽에서(TITLE_Y 높이).

import * as THREE from 'three/webgpu';

export const TITLE_W = 96;          // 글자 판 가로 폭(유닛)
export const TITLE_Y = 58;          // 글자 중심 높이(서울 로컬 월드, 유닛 = 10 m)
const CW = 2048, CH = 512;
const FONT = '"Black Han Sans", "Pretendard", sans-serif';

function rng(seed) { let a = seed >>> 0; return () => { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

/** 글자가 캔버스 폭의 약 92% 를 채우도록 폰트 크기를 맞춘다 */
function fitFont(g, text) {
  let size = 340;
  g.font = `400 ${size}px ${FONT}`;
  const w = g.measureText(text).width;
  size = Math.floor(size * Math.min(1, (CW * 0.92) / w));
  g.font = `400 ${size}px ${FONT}`;
  return size;
}

function textCanvas(text, paint) {
  const c = document.createElement('canvas'); c.width = CW; c.height = CH;
  const g = c.getContext('2d');
  const size = fitFont(g, text);
  g.textAlign = 'center'; g.textBaseline = 'middle';
  paint(g, size);
  return c;
}

export function sampleText(text, N, seed = 4242) {
  const r = rng(seed);
  const c = textCanvas(text, (g) => { g.fillStyle = '#fff'; g.fillText(text, CW / 2, CH / 2 + 12); });
  const img = c.getContext('2d').getImageData(0, 0, CW, CH).data;
  const solid = (x, y) => x >= 0 && y >= 0 && x < CW && y < CH && img[(y * CW + x) * 4 + 3] > 128;
  const edge = [], fill = [];
  let minX = CW, maxX = 0, minY = CH, maxY = 0;
  for (let y = 1; y < CH - 1; y += 1) for (let x = 1; x < CW - 1; x += 1) {
    if (!solid(x, y)) continue;
    if (x < minX) minX = x; if (x > maxX) maxX = x; if (y < minY) minY = y; if (y > maxY) maxY = y;
    if (!solid(x - 1, y) || !solid(x + 1, y) || !solid(x, y - 1) || !solid(x, y + 1)) edge.push(x, y); else fill.push(x, y);
  }
  const scale = TITLE_W / CW;                                   // 캔버스 픽셀 → 유닛
  const nEdge = Math.floor(N * 0.58);
  const A = new Float32Array(N * 4), B = new Float32Array(N * 4);
  for (let i = 0; i < N; i++) {
    const isEdge = i < nEdge;
    const src = isEdge ? edge : fill, k = Math.floor(r() * (src.length / 2)) * 2;
    const px = src[k] + (r() - 0.5), py = src[k + 1] + (r() - 0.5);
    const nx = (px - minX) / Math.max(1, maxX - minX);          // 0~1 (왼 → 오)
    A[i * 4] = (px - CW / 2) * scale;                          // 캔버스 중심 기준 → 글자 판(텍스처)과 정확히 겹친다
    A[i * 4 + 1] = -(py - CH / 2) * scale;
    A[i * 4 + 2] = Math.min(1, Math.max(0, nx * 0.95 + ((py - minY) / Math.max(1, maxY - minY)) * 0.03 + r() * 0.02));   // key
    A[i * 4 + 3] = isEdge ? 1 : 0;
    B[i * 4] = r(); B[i * 4 + 1] = r(); B[i * 4 + 2] = r(); B[i * 4 + 3] = r();
  }
  // 실제 글자 판(캔버스 전체)의 크기와, 글자 영역이 판에서 차지하는 범위 (텍스처 판 배치용)
  return { A, B, planeW: TITLE_W, planeH: TITLE_W * (CH / CW), bounds: { w: (maxX - minX) * scale, h: (maxY - minY) * scale } };
}

/** 금속(크롬) + 네온 외곽 질감의 글자 텍스처 (알파 포함) */
export function buildTitleTexture(text) {
  const c = textCanvas(text, (g, size) => {
    const y = CH / 2 + 12;
    // ① 바깥 발광(네온 글로우): 청록색 그림자를 여러 겹
    g.save();
    g.shadowColor = 'rgba(40,220,255,0.95)'; g.shadowBlur = 38;
    g.lineWidth = 10; g.strokeStyle = 'rgba(70,235,255,0.85)'; g.lineJoin = 'round';
    g.strokeText(text, CW / 2, y);
    g.shadowBlur = 16; g.strokeText(text, CW / 2, y);
    g.restore();
    // ② 금속 면: 위는 거의 흰색 → 중간 하늘색 → 아래는 어두운 강철 → 맨 아래 한 줄 반사
    const grad = g.createLinearGradient(0, y - size * 0.55, 0, y + size * 0.55);
    grad.addColorStop(0.0, '#ffffff'); grad.addColorStop(0.38, '#cfeaff'); grad.addColorStop(0.5, '#6aa6d6');
    grad.addColorStop(0.52, '#20405f'); grad.addColorStop(0.78, '#8fd0ff'); grad.addColorStop(1.0, '#e8f7ff');
    g.fillStyle = grad; g.fillText(text, CW / 2, y);
    // ③ 안쪽 얇은 하이라이트 선
    g.lineWidth = 3; g.strokeStyle = 'rgba(255,255,255,0.9)'; g.strokeText(text, CW / 2, y);
  });
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace; tex.anisotropy = 8; tex.generateMipmaps = true; tex.minFilter = THREE.LinearMipmapLinearFilter; tex.needsUpdate = true;
  return tex;
}
