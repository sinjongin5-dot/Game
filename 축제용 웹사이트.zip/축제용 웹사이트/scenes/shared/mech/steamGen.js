// scenes/shared/mech/steamGen.js — 증기발생기(Steam Generator) 단면도: 1차 냉각수의 열로 2차 계통의 물을 끓이는 거대한 열교환기
//
//  흐름(왼쪽 고온관 → U자관 → 오른쪽 저온관)
//   · 채널 헤드(아래 반구): 칸막이판(divider plate)이 입구실(고온)과 출구실(저온)을 나눈다.
//   · 관판(tubesheet): 두께 수십 cm 의 강철판. 수천 개의 구멍에 U자관 끝을 확관·용접한다 — 1차(관 안)와 2차(관 밖)를 가르는 핵심 경계.
//   · U자관 다발(Inconel 계열 합금): 1차수(약 324 °C → 291 °C)가 관 안에서 열을 내주고, 관 밖 2차수는 약 285 °C 포화온도에서 끓는다. 두 물은 섞이지 않는다.
//   · 지지판: U자관이 진동으로 서로 부딪히거나 휘지 않게 일정 간격으로 잡아 준다.
//   · 감싸개(wrapper)와 환형 하강부(downcomer): 끓는 이중상 혼합물은 다발 안으로 올라가고, 급수(차가운 물)와 분리된 물은 바깥 환형부로 내려온다(자연 순환).
//   · 습분분리기(원심 소용돌이 날개) → 건조기(지그재그 판): 증기 속 물방울을 걸러 건조 증기(수분 0.25% 이하 수준)만 상부 주증기 노즐로 보낸다.
//   · 급수 링(feedwater ring): 터빈을 돈 뒤 응축·재가열된 급수를 드럼 안에 고르게 뿌린다.
//  수치(대표값): 1차 입구/출구 약 324/291 °C, 2차 증기압 약 6.9 MPa(≈70 bar, 포화온도 약 285 °C), 높이 약 20 m 이상, U자관 수천~1만여 개(APR1400 급).
//  ※ 튜브 개수·배치·치수는 이해를 위한 모식이다(실제는 훨씬 촘촘). 1 유닛 = 1 m.

import * as THREE from 'three/webgpu';
import {
  Fn, float, vec3, vec4, uniform, uv, instanceIndex, hash, positionGeometry, normalize, length, mix, smoothstep, pow, sin, cos, fract, step, varying, abs, clamp,
  positionWorld, floor,
} from 'three/tsl';
import { mechMat, latheSolid, makeCut, PALETTE, TAU, pipe, rng } from './kit.js';

export const SG = { LEVEL: 14.4, TOP: 21.5, TS_Y: 2.7, BUNDLE_TOP: 12.2 };

export function makeSteamGen(ctx) {
  const t = ctx.u.time;
  const root = new THREE.Group();
  const cut = makeCut(0);
  const U = { flow: uniform(1.0), heat: uniform(1.0) };

  const steel = mechMat({ cut, color: PALETTE.steel, metal: 0.9, rough: 0.34 });
  const steelLt = mechMat({ color: PALETTE.steelLt, metal: 0.9, rough: 0.3 });
  const solid = mechMat({ color: PALETTE.steel, metal: 0.9, rough: 0.34 });

  // ── 외피: 채널 헤드 + 하부 원통 + 원추 + 증기 드럼 + 상부 돔 ──
  const outer = [[0.0001, 0], [0.9, 0.1], [1.6, 0.45], [2.05, 1.05], [2.3, 1.9], [2.3, 13.6], [3.4, 15.4], [3.4, 19.6], [3.0, 20.5], [2.2, 21.1], [1.0, 21.5], [0.0001, 21.6]];
  const inner = [[0.0001, 0.18], [0.9, 0.27], [1.55, 0.6], [1.95, 1.15], [2.14, 1.95], [2.14, 13.6], [3.24, 15.45], [3.24, 19.6], [2.86, 20.4], [2.1, 20.95], [0.95, 21.35], [0.0001, 21.44]];
  const shell = latheSolid(outer, inner, { cut, mat: steel, seg: 96 }); root.add(shell);

  // ── 관판(구멍 뚫린 두꺼운 판) + 칸막이판 + 1차 노즐 ──
  const tsMat = mechMat({ color: PALETTE.steelLt, metal: 0.9, rough: 0.3, cut });
  const tubesheet = new THREE.Mesh(new THREE.CylinderGeometry(2.14, 2.14, 0.7, 72), tsMat); tubesheet.position.y = 2.35; root.add(tubesheet);
  const holeMat = new THREE.MeshBasicNodeMaterial({ transparent: true, depthWrite: false });
  holeMat.colorNode = Fn(() => {                                                                                       // 관판 윗면의 육각 배열 구멍(관 끝) 무늬
    const p = positionGeometry, q = vec3(p.x.div(0.1), p.y.div(0.0866).mul(0.0).add(p.y.div(0.1)), 0.0);
    const gx = fract(p.x.div(0.1)).sub(0.5), gy = fract(p.y.div(0.1).add(floor(p.x.div(0.1)).mul(0.5))).sub(0.5);
    const d = length(vec3(gx, gy, 0.0)), hole = smoothstep(0.34, 0.26, d), r = length(p.xy);
    return vec4(vec3(0.02, 0.03, 0.05).mul(hole).add(vec3(0.5, 0.52, 0.56).mul(float(1.0).sub(hole)).mul(0.5)), smoothstep(2.14, 2.0, r));
  })();
  const tsTop = new THREE.Mesh(new THREE.CircleGeometry(2.14, 72), holeMat); tsTop.rotation.x = -Math.PI / 2; tsTop.position.y = 2.71; root.add(tsTop);
  const divider = new THREE.Mesh(new THREE.BoxGeometry(0.1, 1.85, 4.2), steel); divider.position.set(0, 1.12, 0); root.add(divider);
  const noz = (sgn, col) => { const p = pipe([[sgn * 2.1, 0.95, 0], [sgn * 3.3, 0.95, 0], [sgn * 5.2, 0.95, 0]], 0.52, mechMat({ cut, color: col, metal: 0.9, rough: 0.34 }), { radial: 32 }); root.add(p); };
  noz(-1, PALETTE.steel); noz(1, PALETTE.steel);

  // ── 감싸개(wrapper) + 지지판 ──
  const wrapMat = new THREE.MeshBasicNodeMaterial({ transparent: true, depthWrite: false, side: THREE.DoubleSide });
  wrapMat.colorNode = Fn(() => vec4(vec3(0.3, 0.6, 1.0).mul(0.5), 0.08))();
  wrapMat.maskNode = positionWorld.z.lessThan(cut.uZ).or(cut.uOn.lessThan(0.5));
  const wrapper = new THREE.Mesh(new THREE.CylinderGeometry(1.8, 1.8, SG.BUNDLE_TOP - SG.TS_Y, 64, 1, true), wrapMat); wrapper.position.y = (SG.BUNDLE_TOP + SG.TS_Y) / 2; wrapper.renderOrder = 3; root.add(wrapper);
  const sup = new THREE.InstancedMesh(new THREE.CylinderGeometry(1.76, 1.76, 0.05, 48), mechMat({ color: PALETTE.steelDk, metal: 0.85, rough: 0.45, alpha: 0.5, transparent: true }), 7);
  const m4 = new THREE.Matrix4(); for (let i = 0; i < 7; i++) { m4.makeTranslation(0, 3.9 + i * 1.32, 0); sup.setMatrixAt(i, m4); } sup.frustumCulled = false; sup.renderOrder = 2; root.add(sup);

  // ── U자관 다발: 평행한 평면(z)마다 반지름이 다른 U자 14개를 겹겹이 (고온 다리 = −x, 저온 다리 = +x) ──
  const tubeMat = mechMat({
    color: [0.62, 0.64, 0.7], metal: 0.9, rough: 0.35,
    emissiveNode: Fn(() => {
      const u = uv().x;                                                                                                // 관 길이 방향(0 = 고온 다리 아래 → 1 = 저온 다리 아래)
      const pulse = smoothstep(0.55, 1.0, sin(u.mul(60.0).sub(t.mul(5.0))).mul(0.5).add(0.5));
      const col = mix(vec3(1.0, 0.25, 0.06), vec3(0.95, 0.6, 0.25), smoothstep(0.35, 1.0, u));
      return col.mul(pulse.mul(0.9).add(0.12)).mul(U.heat).mul(1.4);
    })(),
  });
  const ROWS = 14, tubeInstances = [];
  const y0 = SG.TS_Y + 0.05, Hleg = 7.4;
  for (let r = 0; r < ROWS; r++) {
    const R = 0.18 + r * 0.1;                                                                                          // 이 줄의 U자 반지름(절반 폭)
    const pts = [];
    pts.push(new THREE.Vector3(-R, y0, 0), new THREE.Vector3(-R, y0 + Hleg, 0));
    for (let k = 1; k < 12; k++) { const a = Math.PI - k / 12 * Math.PI; pts.push(new THREE.Vector3(Math.cos(a) * R, y0 + Hleg + Math.sin(a) * R, 0)); }
    pts.push(new THREE.Vector3(R, y0 + Hleg, 0), new THREE.Vector3(R, y0, 0));
    const curve = new THREE.CatmullRomCurve3(pts, false, 'centripetal');
    const geo = new THREE.TubeGeometry(curve, 90, 0.022, 7, false);
    const zs = []; for (let z = 0; z >= -1.7; z -= 0.085) if (Math.hypot(R, z) <= 1.74) zs.push(z);
    const im = new THREE.InstancedMesh(geo, tubeMat, zs.length);
    zs.forEach((z, i) => { m4.makeTranslation(0, 0, z); im.setMatrixAt(i, m4); });
    im.frustumCulled = false; root.add(im);
  }

  // ── 물/증기 부피 + 수면 ──
  const volMat = (rgb, a) => { const m = new THREE.MeshBasicNodeMaterial({ transparent: true, depthWrite: false, side: THREE.DoubleSide }); m.colorNode = vec4(vec3(...rgb), a); m.maskNode = positionWorld.z.lessThan(cut.uZ).or(cut.uOn.lessThan(0.5)); return m; };
  const wGeo = new THREE.CylinderGeometry(2.13, 2.13, SG.LEVEL - SG.TS_Y, 64, 1, true), watr = new THREE.Mesh(wGeo, volMat([0.05, 0.25, 0.6], 0.09)); watr.position.y = (SG.LEVEL + SG.TS_Y) / 2; watr.renderOrder = 2; root.add(watr);
  const dGeo = new THREE.CylinderGeometry(3.23, 3.23, 5.0, 64, 1, true), drumW = new THREE.Mesh(dGeo, volMat([0.05, 0.25, 0.6], 0.09)); drumW.position.y = 15.5 + 1.2; drumW.scale.y = 1.0; drumW.visible = false; root.add(drumW);
  const lvlMat = new THREE.MeshBasicNodeMaterial({ transparent: true, depthWrite: false, side: THREE.DoubleSide, blending: THREE.AdditiveBlending });
  lvlMat.colorNode = Fn(() => { const p = positionGeometry, rr = length(p.xy), rip = pow(sin(rr.mul(9.0).sub(t.mul(2.5))).mul(0.5).add(0.5), 5.0); return vec4(vec3(0.2, 0.55, 1.0).mul(rip.mul(0.5).add(0.12)).mul(smoothstep(3.3, 2.0, rr)), 1.0); })();
  const level = new THREE.Mesh(new THREE.CircleGeometry(3.2, 64), lvlMat); level.rotation.x = -Math.PI / 2; level.position.y = 15.9; level.renderOrder = 4; root.add(level);

  // ── 습분분리기(소용돌이 캔 7개) ──
  const sepMat = mechMat({ cut, color: PALETTE.steelLt, metal: 0.9, rough: 0.3 });
  const vaneShape = new THREE.Shape(); vaneShape.moveTo(0, 0); vaneShape.lineTo(0.3, 0); vaneShape.lineTo(0.3, 0.03); vaneShape.lineTo(0, 0.03); vaneShape.closePath();
  const sepPos = [[0, 0], ...[0, 1, 2, 3, 4, 5].map((k) => [Math.cos(k / 6 * TAU) * 0.95, Math.sin(k / 6 * TAU) * 0.95]), ...[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11].map((k) => [Math.cos(k / 12 * TAU + 0.26) * 1.9, Math.sin(k / 12 * TAU + 0.26) * 1.9])];
  const sepVis = sepPos.filter(([, z]) => z <= 0.4);
  const cans = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.34, 0.34, 1.7, 24, 1, true), mechMat({ color: PALETTE.steelLt, metal: 0.9, rough: 0.3, double: true }), sepVis.length);
  sepVis.forEach(([x, z], i) => { m4.makeTranslation(x, 13.45 + 0.85 + 0.25, z); cans.setMatrixAt(i, m4); }); cans.frustumCulled = false; root.add(cans);
  // 소용돌이 날개: 비틀린 판
  const swirlGeo = new THREE.BufferGeometry(); {
    const pos = [], idx = [], N = 10; for (let i = 0; i <= N; i++) { const s = i / N, a = s * 2.4, y = s * 0.7; for (const rr of [0.06, 0.3]) pos.push(Math.cos(a) * rr, y, Math.sin(a) * rr); if (i < N) { const k = i * 2; idx.push(k, k + 1, k + 2, k + 1, k + 3, k + 2); } }
    swirlGeo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); swirlGeo.setIndex(idx); swirlGeo.computeVertexNormals();
  }
  const swirl = new THREE.InstancedMesh(swirlGeo, mechMat({ color: PALETTE.brass, metal: 1.0, rough: 0.3, double: true }), sepVis.length * 2);
  sepVis.forEach(([x, z], i) => { for (let k = 0; k < 2; k++) { m4.makeRotationY(k * Math.PI).setPosition(x, 13.45 + 0.35 + k * 0.0, z); swirl.setMatrixAt(i * 2 + k, m4); } }); swirl.frustumCulled = false; root.add(swirl);

  // ── 건조기(지그재그 판 모듈) + 급수 링 ──
  const dryerShape = new THREE.Shape(); {                                                                      // 지그재그 판: 수평면(x–z)에서 본 단면을 위로 1 m 압출
    const w = 0.035, zig = []; for (let i = 0; i <= 18; i++) zig.push([(i % 2) * 0.16, i * 0.32]);
    dryerShape.moveTo(zig[0][0], zig[0][1]); zig.slice(1).forEach(([x, y]) => dryerShape.lineTo(x, y)); zig.slice().reverse().forEach(([x, y]) => dryerShape.lineTo(x + w, y)); dryerShape.closePath();
  }
  const dGeom = new THREE.ExtrudeGeometry(dryerShape, { depth: 1.0, bevelEnabled: false }); dGeom.rotateX(-Math.PI / 2); dGeom.translate(0, 0, 2.9);
  const dryer = new THREE.InstancedMesh(dGeom, mechMat({ cut, color: [0.5, 0.55, 0.62], metal: 0.9, rough: 0.4, double: true }), 26);
  for (let i = 0; i < 26; i++) { m4.makeTranslation(-2.5 + i * 0.2, 17.4, 0); dryer.setMatrixAt(i, m4); } dryer.frustumCulled = false; root.add(dryer);
  const fwRing = new THREE.Mesh(new THREE.TorusGeometry(2.7, 0.14, 14, 72), mechMat({ cut, color: [0.25, 0.5, 0.85], metal: 0.7, rough: 0.35, emissive: [0.0, 0.08, 0.25] })); fwRing.rotation.x = Math.PI / 2; fwRing.position.y = 16.7; root.add(fwRing);
  const fwIn = pipe([[3.2, 16.7, 0], [4.6, 16.7, 0], [7.0, 16.7, 0]], 0.36, solid, { radial: 26 }); root.add(fwIn);
  const mainSteam = pipe([[0, 21.4, 0], [0, 23.4, 0], [1.2, 24.6, 0], [3.6, 24.9, 0], [8.0, 24.9, 0]], 0.62, solid, { radial: 30 }); root.add(mainSteam);
  const restrictor = new THREE.Mesh(new THREE.TorusGeometry(0.6, 0.09, 12, 36), steelLt); restrictor.rotation.x = Math.PI / 2; restrictor.position.y = 22.3; root.add(restrictor);
  for (let k = 0; k < 4; k++) { const a = k / 4 * TAU + 0.8, leg = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.28, 2.4, 14), steelLt); leg.position.set(Math.cos(a) * 2.6, -0.7, Math.sin(a) * 2.6); root.add(leg); }  // 지지 다리

  // ── 입자: 하강부(차가운 물) → 관판 위에서 안쪽으로 → 다발에서 끓어 오름(기포) → 분리기 → 건조기 → 주증기 노즐 ──
  const NP = 9000, i = instanceIndex, h = (k) => hash(i.add(k * 7127));
  const pm = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
  {
    const s = fract(h(1).add(t.mul(0.07).mul(h(2).mul(0.4).add(0.8))));
    const th = h(3).mul(TAU).add(t.mul(0.1).mul(smoothstep(0.7, 0.85, s)).mul(h(10).mul(2.0).sub(1.0)));
    const a1 = smoothstep(0.0, 0.2, s), a2 = smoothstep(0.2, 0.28, s), a3 = smoothstep(0.28, 0.6, s), a4 = smoothstep(0.6, 0.78, s), a5 = smoothstep(0.78, 1.0, s);
    const rin = pow(h(4), 0.5).mul(1.6);
    const r = mix(mix(mix(float(1.97), rin, a2), rin.mul(0.6).add(0.5), a4), float(0.0), a5);
    const y = float(14.2).add(float(3.0).sub(float(14.2)).mul(a1)).add(float(3.4).sub(float(3.0)).mul(a2)).add(float(12.2).sub(float(3.4)).mul(a3)).add(float(15.0).sub(float(12.2)).mul(a4)).add(float(21.0).sub(float(15.0)).mul(a5));
    const pos = vec3(cos(th).mul(r), y, sin(th).mul(r));
    pm.positionNode = pos;
    pm.scaleNode = h(5).mul(0.07).add(0.04).mul(mix(float(0.7), float(1.5), a3).mul(float(1.0).sub(a5.mul(0.4))));
    const water = vec3(0.25, 0.55, 1.0), bubble = vec3(0.85, 0.95, 1.0), steam = vec3(0.95, 0.95, 1.0);
    const c = mix(mix(water, bubble, a3), steam, a5);
    pm.colorNode = varying(c.mul(step(pos.z, 0.05)).mul(U.flow).mul(1.3), 'vSgFlow');
    pm.opacityNode = smoothstep(0.5, 0.0, length(uv().sub(0.5))).pow(1.4);
  }
  const flow = new THREE.Sprite(pm); flow.count = NP; flow.frustumCulled = false; flow.renderOrder = 6; root.add(flow);

  return {
    root, U, cut,
    set(cutDepth, cutOn = 1) {
      cut.uOn.value = cutOn; cut.uZ.value = cutDepth;
      const showSec = cutDepth < 0.06 && cutOn > 0.5; root.traverse((o) => { if (o.userData.section) o.visible = showSec; });
    },
  };
}
