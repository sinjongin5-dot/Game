// scenes/shared/mech/reactor.js — 가압경수로(PWR) 원자로 용기와 내부 구조물 (분해도 + 단면도)
//
//  구성 (실제 구조를 단순화한 모형, 1 유닛 = 1 m)
//   · 원자로 용기: 저합금강 단조 + 내면 스테인리스 클래딩. 아래 반구형 하부 헤드, 원통 몸통, 노즐 벨트(냉각재 입구 4·출구 2), 상부 플랜지.
//   · 상부 덮개(폐쇄 헤드) + 제어봉 구동장치(CRDM) 61기 + 스터드 볼트 54개(플랜지를 죄는 대형 볼트).
//   · 노심 지지통(core barrel), 하부 노심지지판, 연료집합체 241개(APR1400 노심), 상부 안내구조물, 제어봉집합체(CEA)와 연장축.
//   · 냉각재 흐름: 차가운 물이 입구 노즐 → 노심통 바깥 환형부(downcomer)를 따라 내려가 → 하부 플리넘에서 방향을 틀어 → 노심을 위로 통과하며 가열 → 출구 노즐.
//   · SCRAM(원자로 비상정지): 제어봉 구동장치의 전자석이 전류를 잃으면 제어봉이 중력으로 떨어져 노심에 삽입된다(fail-safe).
//  수치 출처(대표값, APR1400·가압경수로 일반 자료): 열출력 3,983 MWt/전기출력 1,400 MWe, 노심 연료집합체 241개, 제어봉집합체 93개,
//   운전압력 15.5 MPa(155 bar), 입구/출구 온도 약 291 °C / 324 °C, 용기 내경 약 4.6 m·벽 두께 약 0.25 m(내면 스테인리스 클래딩 포함).
//  ※ 형상은 이해를 위한 모식 모형이다(노즐 구멍·내부 세부는 단순화).

import * as THREE from 'three/webgpu';
import {
  Fn, float, vec3, vec4, uniform, uv, instanceIndex, hash, positionGeometry, normalize, length, mix, smoothstep, clamp, pow, exp, sin, cos, abs, fract, step,
  varying, positionLocal, cameraPosition, positionWorld,
} from 'three/tsl';
import { mechMat, latheSolid, boltRing, makeCut, PALETTE, TAU, rng } from './kit.js';

export const RV = { Ro: 2.55, Ri: 2.3, H: 11.1, CORE_Y0: 2.85, CORE_H: 4.0, FLANGE_R: 2.95 };
const OUTER = [[0, 0], [0.8, 0.06], [1.5, 0.3], [2.1, 0.75], [2.45, 1.35], [2.55, 2.1], [2.55, 10.3], [2.95, 10.3], [2.95, 11.1]];
const INNER = [[0, 0.25], [0.8, 0.3], [1.5, 0.52], [2.05, 0.95], [2.3, 1.5], [2.3, 2.2], [2.3, 10.3], [2.3, 11.1]];
const DOME_OUT = [[2.95, 0], [2.95, 0.65], [2.6, 0.82], [2.4, 1.4], [1.9, 2.2], [1.2, 2.8], [0.5, 3.05], [0, 3.1]];     // 덮개 바깥 곡선 (기준 y=0 → 장착 시 y=11.1)
const DOME_IN = [[2.3, 0], [2.3, 0.6], [2.2, 0.9], [2.05, 1.45], [1.65, 2.15], [1.05, 2.65], [0.45, 2.85], [0, 2.9]];
export const domeY = (r) => { const pts = DOME_OUT.slice().reverse(); for (let i = 0; i < pts.length - 1; i++) { const [r0, y0] = pts[i], [r1, y1] = pts[i + 1]; if (r >= r0 && r <= r1) return y0 + (y1 - y0) * (r - r0) / (r1 - r0 || 1); } return 0; };

export function makeReactor(ctx) {
  const t = ctx.u.time;
  const root = new THREE.Group();
  const cut = makeCut(0);
  const U = { cher: uniform(1.0), rod: uniform(0.0), flow: uniform(1.0), explode: uniform(0.0) };
  const rnd = rng(11);

  const steel = mechMat({ cut, color: PALETTE.steel, metal: 0.9, rough: 0.34 });
  const steelLt = mechMat({ cut, color: PALETTE.steelLt, metal: 0.9, rough: 0.3 });
  const solid = mechMat({ color: PALETTE.steel, metal: 0.9, rough: 0.34 });
  const dark = mechMat({ color: PALETTE.steelDk, metal: 0.85, rough: 0.45 });

  // ── 용기 본체 ──
  const vessel = new THREE.Group(); root.add(vessel);
  const shell = latheSolid(OUTER, INNER, { cut, mat: steel, seg: 96 }); vessel.add(shell);
  // 노즐 벨트: 출구(고온관) 2 + 입구(저온관) 4
  const nozzles = new THREE.Group(); vessel.add(nozzles);
  const mkNoz = (ang, y, r, len) => {
    const g = new THREE.Group();
    const body = new THREE.Mesh(new THREE.CylinderGeometry(r, r * 1.12, len, 32, 1, true), steel); body.rotation.z = Math.PI / 2; body.position.x = 2.5 + len / 2 - 0.2; g.add(body);
    const fl = new THREE.Mesh(new THREE.CylinderGeometry(r * 1.4, r * 1.4, 0.18, 32), steelLt); fl.rotation.z = Math.PI / 2; fl.position.x = 2.5 + len - 0.2; g.add(fl);
    const boss = new THREE.Mesh(new THREE.CylinderGeometry(r * 1.55, r * 1.7, 0.5, 32), steel); boss.rotation.z = Math.PI / 2; boss.position.x = 2.5; g.add(boss);
    g.rotation.y = -ang; g.position.y = y; nozzles.add(g); return g;
  };
  [0, Math.PI].forEach((a) => mkNoz(a, 8.9, 0.6, 1.8));                                              // 고온관(출구) 2개
  [Math.PI / 4, -Math.PI / 4, 3 * Math.PI / 4, -3 * Math.PI / 4].forEach((a) => mkNoz(a, 9.6, 0.42, 1.6));      // 저온관(입구) 4개
  // 스터드 볼트 + 너트 (플랜지)
  const studs = boltRing(54, 2.62, 10.9, 0.14, 1.15, solid); vessel.add(studs);
  const cutStuds = (g) => g.children.forEach((im) => { const m4 = new THREE.Matrix4(); for (let i = 0; i < im.count; i++) { im.getMatrixAt(i, m4); const z = new THREE.Vector3().setFromMatrixPosition(m4).z; if (z > 0.12) { m4.makeScale(0, 0, 0); im.setMatrixAt(i, m4); } } });
  cutStuds(studs);

  // ── 상부 덮개 + CRDM 61기 ──
  const head = new THREE.Group(); head.position.y = RV.H; root.add(head);
  head.add(latheSolid(DOME_OUT, DOME_IN, { cut, mat: steel, seg: 96 }));
  const crdmPos = [];                                                                                  // 육각 배열(피치 0.34 m) 중 반지름 1.75 이내 61개
  for (let q = -6; q <= 6; q++) for (let r = -6; r <= 6; r++) { const x = (q + r / 2) * 0.34, z = r * 0.34 * 0.866; if (Math.hypot(x, z) <= 1.5 && crdmPos.length < 61) crdmPos.push([x, z]); }
  const vis = crdmPos.filter(([, z]) => z <= 0.12);                                                   // 단면의 보이는 쪽만
  const tube = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.12, 0.12, 1, 14), solid, vis.length);
  const coil = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.2, 0.2, 0.17, 18), mechMat({ color: [0.12, 0.3, 0.5], metal: 0.4, rough: 0.5 }), vis.length * 7);
  const cap = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.16, 0.16, 0.3, 14), dark, vis.length);
  const m4 = new THREE.Matrix4(), q4 = new THREE.Quaternion(), s3 = new THREE.Vector3();
  vis.forEach(([x, z], i) => {
    const r = Math.hypot(x, z), y0 = domeY(r) - 0.25, hh = 3.6;
    m4.compose(new THREE.Vector3(x, y0 + hh / 2, z), q4.identity(), s3.set(1, hh, 1)); tube.setMatrixAt(i, m4);
    for (let k = 0; k < 7; k++) { m4.makeTranslation(x, y0 + 0.5 + k * 0.23, z); coil.setMatrixAt(i * 7 + k, m4); }
    m4.makeTranslation(x, y0 + hh + 0.12, z); cap.setMatrixAt(i, m4);
  });
  [tube, coil, cap].forEach((im) => { im.frustumCulled = false; head.add(im); });
  root.userData.crdmCount = crdmPos.length;

  // ── 노심 지지통 + 하부 지지판 + 연료집합체 241 ──
  const internals = new THREE.Group(); root.add(internals);
  internals.add(latheSolid([[2.1, 2.55], [2.1, 9.7], [2.28, 9.7], [2.28, 10.05]], [[2.04, 2.55], [2.04, 9.7], [2.2, 9.7], [2.2, 10.05]], { cut, mat: steelLt, hatch: [0.8, 0.85, 0.95] }));
  const plateMat = mechMat({ color: PALETTE.steelLt, metal: 0.9, rough: 0.35 });
  const lowPlate = new THREE.Mesh(new THREE.CylinderGeometry(2.04, 2.04, 0.2, 64), plateMat); lowPlate.position.y = 2.7; internals.add(lowPlate);
  const fuelPos = [];
  const PITCH = 0.2056, cells = [];
  for (let i = -10; i <= 10; i++) for (let j = -10; j <= 10; j++) cells.push([i * PITCH, j * PITCH, Math.hypot(i, j)]);
  cells.sort((a, b) => a[2] - b[2]); cells.slice(0, 241).forEach(([x, z]) => fuelPos.push([x, z]));
  const fuelMat = mechMat({
    color: [0.3, 0.32, 0.36], metal: 0.8, rough: 0.45, instanced: true,
    emissiveNode: Fn(() => {                                                                          // 체렌코프 푸른 빛: 아래쪽이 더 밝고, 연료봉 격자 사이로 새어 나옴
      const p = positionGeometry, yy = p.y.add(2.0).div(4.0), lat = abs(fract(p.x.mul(77.8)).sub(0.5)).max(abs(fract(p.z.mul(77.8)).sub(0.5)));
      const gap = smoothstep(0.34, 0.48, lat);
      return vec3(0.08, 0.38, 1.0).mul(U.cher).mul(gap.mul(0.9).add(0.12)).mul(float(1.15).sub(yy.mul(0.6))).mul(0.8);
    })(),
  });
  const fuelVis = fuelPos.filter(([, z]) => z <= 0.1);                                                  // 단면에서 보이는 쪽(절단면 앞쪽 절반은 제거)
  const fuel = new THREE.InstancedMesh(new THREE.BoxGeometry(0.195, RV.CORE_H, 0.195), fuelMat, fuelVis.length);
  const col = new THREE.Color();
  fuelVis.forEach(([x, z], i) => { m4.makeTranslation(x, RV.CORE_Y0 + RV.CORE_H / 2, z); fuel.setMatrixAt(i, m4); col.setScalar(0.85 + rnd() * 0.3); fuel.setColorAt(i, col); });
  fuel.frustumCulled = false; internals.add(fuel);
  // 중성자 반사체/배플(노심 외곽 계단 모양 판): 얇은 링
  const baffle = new THREE.Mesh(new THREE.CylinderGeometry(1.98, 1.98, RV.CORE_H + 0.2, 64, 1, true), mechMat({ color: PALETTE.steelDk, metal: 0.8, rough: 0.5, double: true, transparent: true, alpha: 0.35 })); baffle.position.y = RV.CORE_Y0 + RV.CORE_H / 2; internals.add(baffle);
  // 체렌코프 광 볼륨 (노심 위 물 속)
  const glowMat = new THREE.MeshBasicNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide });
  glowMat.colorNode = Fn(() => {
    const p = positionGeometry, y = p.y.add(RV.CORE_H / 2).div(RV.CORE_H);
    return vec4(vec3(0.05, 0.3, 1.0).mul(U.cher).mul(smoothstep(0.0, 0.2, y).mul(smoothstep(1.3, 0.8, y))).mul(0.07), 1.0);
  })();
  const glow = new THREE.Mesh(new THREE.CylinderGeometry(1.9, 1.9, RV.CORE_H + 1.4, 48, 1, true), glowMat); glow.position.y = RV.CORE_Y0 + RV.CORE_H / 2 + 0.3; glow.renderOrder = 5; internals.add(glow);

  // ── 상부 안내구조물 + 제어봉집합체(CEA) + 연장축 ──
  const upper = new THREE.Group(); root.add(upper);
  const upMat = mechMat({ cut, color: PALETTE.steelLt, metal: 0.9, rough: 0.32 });
  upper.add(latheSolid([[2.0, 7.35], [2.0, 10.0]], [[1.94, 7.35], [1.94, 10.0]], { cut, mat: upMat, noSection: true }));
  const topPlate = new THREE.Mesh(new THREE.CylinderGeometry(2.0, 2.0, 0.16, 64), plateMat); topPlate.position.y = 10.0; upper.add(topPlate);
  const midPlate = new THREE.Mesh(new THREE.CylinderGeometry(2.0, 2.0, 0.14, 64), plateMat); midPlate.position.y = 7.3; upper.add(midPlate);
  const ceaPos = fuelPos.filter((_, i) => i % 5 === 2).slice(0, 93).filter(([, z]) => z <= 0.12);   // 제어봉집합체 위치(노심 집합체 중 일부)
  const guideTubes = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.075, 0.075, 2.7, 10), mechMat({ color: PALETTE.steelLt, metal: 0.9, rough: 0.35 }), ceaPos.length);
  ceaPos.forEach(([x, z], i) => { m4.makeTranslation(x, 8.65, z); guideTubes.setMatrixAt(i, m4); }); guideTubes.frustumCulled = false; upper.add(guideTubes);
  // CEA 손가락(제어봉) 4개씩 + 스파이더(허브) + 연장축 : 삽입량 U.rod 로 아래로 이동
  const rodGroup = new THREE.Group(); upper.add(rodGroup);
  const fingerMat = mechMat({ color: [0.3, 0.32, 0.36], metal: 0.9, rough: 0.35 });
  const hubMat = mechMat({ color: PALETTE.brass, metal: 0.9, rough: 0.3 });
  const shaftMat = mechMat({ color: PALETTE.steelLt, metal: 0.9, rough: 0.3 });
  const mkMoving = (geo, mat, n, drop = 4.4) => {
    const im = new THREE.InstancedMesh(geo, mat, n);
    // 삽입량(0~1)만큼 y 를 내린다 — positionNode 의 positionLocal 은 이미 인스턴스 변환이 적용된 메시 공간 좌표다
    mat.positionNode = positionLocal.sub(vec3(0.0, U.rod.mul(drop), 0.0));
    im.frustumCulled = false; rodGroup.add(im); return im;
  };
  const fingers = mkMoving(new THREE.CylinderGeometry(0.028, 0.028, 3.9, 8), fingerMat, ceaPos.length * 4);
  const hubs = mkMoving(new THREE.CylinderGeometry(0.1, 0.1, 0.14, 12), hubMat, ceaPos.length);
  const shafts = mkMoving(new THREE.CylinderGeometry(0.045, 0.045, 1, 8), shaftMat, ceaPos.length);
  ceaPos.forEach(([x, z], i) => {
    for (let k = 0; k < 4; k++) { const a = k / 4 * TAU + Math.PI / 4; m4.makeTranslation(x + Math.cos(a) * 0.055, 7.5 + 3.9 / 2, z + Math.sin(a) * 0.055); fingers.setMatrixAt(i * 4 + k, m4); }
    m4.makeTranslation(x, 7.5 + 3.9, z); hubs.setMatrixAt(i, m4);
    const top = RV.H + domeY(Math.hypot(x, z)) + 1.2, base = 7.5 + 3.9, hh = top - base;
    m4.compose(new THREE.Vector3(x, base + hh / 2, z), q4.identity(), s3.set(1, hh, 1)); shafts.setMatrixAt(i, m4);
  });

  // ── 냉각재 흐름 입자: 입구 → 환형부(내려감) → 하부 플리넘 → 노심(올라감, 가열) → 상부 플리넘 → 출구 ──
  const NP = 7000, i = instanceIndex, h = (k) => hash(i.add(k * 5237));
  const pm = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
  {
    const s = fract(h(1).add(t.mul(0.12).mul(h(2).mul(0.4).add(0.8))));
    const th = h(3).mul(TAU), rc = pow(h(4), 0.55).mul(1.75), Ra = float(2.18);
    const yTop = float(9.6), yBot = float(2.75), yIn = float(3.05), yOut = float(6.95), yHot = float(9.0);
    const a1 = smoothstep(0.0, 0.3, s), a2 = smoothstep(0.3, 0.42, s), a3 = smoothstep(0.42, 0.8, s), a4 = smoothstep(0.8, 1.0, s);
    const r = mix(mix(Ra, rc, a2), rc.mul(0.8), a4);
    const y = yTop.add(yBot.sub(yTop).mul(a1)).add(yIn.sub(yBot).mul(a2)).add(yOut.sub(yIn).mul(a3)).add(yHot.sub(yOut).mul(a4));
    const pos = vec3(cos(th).mul(r), y, sin(th).mul(r));
    pm.positionNode = pos;
    pm.scaleNode = h(5).mul(0.06).add(0.045);
    const heat = smoothstep(0.42, 0.8, s);
    const c = mix(vec3(0.25, 0.55, 1.0), vec3(1.0, 0.42, 0.12), heat);
    const vis = step(pos.z, 0.05).mul(U.flow);                                                         // 보이는(단면) 쪽만
    pm.colorNode = varying(c.mul(vis).mul(1.4), 'vReacFlow');
    pm.opacityNode = smoothstep(0.5, 0.0, length(uv().sub(0.5))).pow(1.4);
  }
  const flow = new THREE.Sprite(pm); flow.count = NP; flow.frustumCulled = false; flow.renderOrder = 6; root.add(flow);

  // ── 외부 지지: 원자로 지지 구조물 + 바닥 ──
  const pedestal = new THREE.Mesh(new THREE.CylinderGeometry(3.3, 3.8, 0.7, 48), mechMat({ color: PALETTE.concrete, metal: 0.05, rough: 0.8, cut })); pedestal.position.y = -0.35; root.add(pedestal);

  const parts = { head, upper, internals, vessel };
  return {
    root, U, cut, parts, sections: [shell], fuelCount: fuelPos.length, ceaCount: Math.max(ceaPos.length, 1),
    /** 분해도 t(0=조립, 1=완전 분해) 와 단면 깊이(월드 z 평면)를 적용 */
    set(explode, cutDepth, cutOn = 1) {
      head.position.y = RV.H + explode * 7.0; upper.position.y = explode * 3.4; internals.position.y = explode * 0.9;
      studs.visible = true;
      cut.uOn.value = cutOn; cut.uZ.value = cutDepth;
      const showSec = cutDepth < 0.06 && cutOn > 0.5;
      root.traverse((o) => { if (o.userData.section) o.visible = showSec; });
    },
  };
}
