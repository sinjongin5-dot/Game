// scenes/shared/mech/rcp.js — 원자로냉각재펌프(RCP, Reactor Coolant Pump) 단면도
//
//  1차 계통의 물을 원자로와 증기발생기 사이로 "강제 순환"시키는 수직형 원심 펌프. 위에서부터:
//   · 대형 전동기(고정자 코일·회전자) + 플라이휠: 전원이 끊겨도 한동안 관성으로 계속 돌며 냉각수 유량을 천천히 줄여 준다(코스트다운).
//   · 축 밀봉(shaft seal) 3단: 155기압의 1차 냉각수가 전동기 쪽으로 새지 않게 막는 정밀 부품(단계마다 압력을 나눠 받는다).
//   · 열차단기(thermal barrier): 300 °C 가 넘는 물의 열이 밀봉으로 올라오지 않게 냉각수를 흘려 식힌다.
//   · 임펠러(회전 날개) + 디퓨저(고정 날개) + 볼류트 케이싱: 아래 흡입구로 들어온 물이 임펠러에서 가속되고 디퓨저에서 압력으로 바뀌어 옆 토출 노즐로 나간다.
//  수치(대표값): 회전수 약 1,200 rpm, 가압경수로 1기에 2~4대(APR1400 은 4대), 1대당 유량은 시간당 수만 m³ 수준, 압력 상승은 수 bar 급(관로 저항 극복).
//  ※ 부품 형상·개수는 이해를 위한 모식 모형이다. 1 유닛 = 1 m.

import * as THREE from 'three/webgpu';
import {
  Fn, float, vec3, uniform, uv, instanceIndex, hash, normalize, length, mix, smoothstep, pow, sin, cos, fract, step, varying, clamp,
} from 'three/tsl';
import { mechMat, latheSolid, makeCut, PALETTE, TAU, pipe } from './kit.js';

export function makeRCP(ctx) {
  const t = ctx.u.time;
  const root = new THREE.Group();
  const cut = makeCut(0);
  const U = { flow: uniform(1.0), spin: 0 };

  const steel = mechMat({ cut, color: PALETTE.steel, metal: 0.9, rough: 0.34 });
  const steelLt = mechMat({ cut, color: PALETTE.steelLt, metal: 0.9, rough: 0.3 });
  const paint = mechMat({ cut, color: PALETTE.paintBlue, metal: 0.4, rough: 0.5 });
  const solid = mechMat({ color: PALETTE.steelLt, metal: 0.9, rough: 0.3 });
  const copper = mechMat({ color: PALETTE.copper, metal: 1.0, rough: 0.28 });
  const brass = mechMat({ color: PALETTE.brass, metal: 1.0, rough: 0.3 });
  const copperCut = mechMat({ cut, color: PALETTE.copper, metal: 1.0, rough: 0.28 });

  // ── 펌프 케이싱(볼류트): 흡입 노즐(아래) + 몸통 + 토출 노즐(옆) ──
  root.add(latheSolid([[0.5, -1.4], [0.5, -0.2], [0.95, 0.0], [1.3, 0.35], [1.42, 0.9], [1.3, 1.45], [0.8, 1.7], [0.55, 1.75]], [[0.38, -1.4], [0.38, -0.2], [0.85, 0.08], [1.18, 0.4], [1.28, 0.9], [1.18, 1.4], [0.74, 1.62], [0.4, 1.66]], { cut, mat: steel, seg: 64 }));
  const dis = pipe([[1.3, 0.9, 0], [2.4, 0.9, 0], [3.4, 0.9, 0]], 0.5, steel, { radial: 28 }); root.add(dis);
  const suc = new THREE.Mesh(new THREE.CylinderGeometry(0.62, 0.62, 0.2, 36), steelLt); suc.position.y = -1.4; root.add(suc);

  // ── 임펠러(회전): 하부 쉬라우드 + 9개 휜 날개 + 허브 ──
  const imp = new THREE.Group(); imp.position.y = 0.55; root.add(imp);
  const shroud = new THREE.Mesh(new THREE.CylinderGeometry(0.66, 0.62, 0.06, 56), solid); imp.add(shroud);
  const hub = new THREE.Mesh(new THREE.ConeGeometry(0.32, 0.5, 32), brass); hub.position.y = 0.25; imp.add(hub);
  const vShape = new THREE.Shape(); {
    const N = 14, outer = [], inner = [];
    for (let i = 0; i <= N; i++) { const s = i / N, r = 0.14 + 0.5 * s, a = 1.15 * Math.pow(s, 0.9); outer.push([Math.cos(a) * r, Math.sin(a) * r]); inner.push([Math.cos(a + 0.07) * r, Math.sin(a + 0.07) * r]); }
    vShape.moveTo(outer[0][0], outer[0][1]); outer.forEach(([x, y]) => vShape.lineTo(x, y)); inner.reverse().forEach(([x, y]) => vShape.lineTo(x, y)); vShape.closePath();
  }
  const vaneGeo = new THREE.ExtrudeGeometry(vShape, { depth: 0.34, bevelEnabled: false }); vaneGeo.rotateX(-Math.PI / 2);
  for (let i = 0; i < 9; i++) { const v = new THREE.Mesh(vaneGeo, brass); v.rotation.y = i / 9 * TAU; v.position.y = 0.03; imp.add(v); }
  
  // 디퓨저(고정 날개) 12개
  const dif = new THREE.Group(); dif.position.y = 0.55; root.add(dif);
  const dvShape = new THREE.Shape(); dvShape.moveTo(0.7, 0); dvShape.lineTo(1.12, 0.18); dvShape.lineTo(1.12, 0.23); dvShape.lineTo(0.7, 0.05); dvShape.closePath();
  const dvGeo = new THREE.ExtrudeGeometry(dvShape, { depth: 0.36, bevelEnabled: false }); dvGeo.rotateX(-Math.PI / 2);
  for (let i = 0; i < 12; i++) { const v = new THREE.Mesh(dvGeo, steelLt); v.rotation.y = i / 12 * TAU; v.position.y = 0.03; dif.add(v); }

  // ── 축 + 열차단기 + 3단 밀봉 + 커플링 ──
  const shaftMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.17, 0.17, 7.2, 24), solid); shaftMesh.position.y = 3.6; imp.add(shaftMesh); shaftMesh.position.y = 3.6 - 0.55;
  root.add(latheSolid([[0.72, 1.7], [0.72, 2.6], [0.62, 2.62]], [[0.64, 1.7], [0.64, 2.6], [0.55, 2.62]], { cut, mat: steelLt, seg: 48, noSection: false }));
  const coolCoil = new THREE.Mesh(new THREE.TorusGeometry(0.5, 0.045, 12, 48), mechMat({ cut, color: [0.2, 0.6, 1.0], metal: 0.3, rough: 0.3, emissive: [0.0, 0.12, 0.35] }));
  for (let k = 0; k < 4; k++) { const c = coolCoil.clone(); c.rotation.x = Math.PI / 2; c.position.y = 1.95 + k * 0.17; root.add(c); }                       // 열차단기 냉각수 코일
  root.add(latheSolid([[0.62, 2.62], [0.62, 3.9], [0.5, 3.92]], [[0.54, 2.62], [0.54, 3.9], [0.42, 3.92]], { cut, mat: steel, seg: 48 }));      // 밀봉 하우징
  const sealRings = new THREE.Group(); root.add(sealRings);
  [[2.85, copper], [3.2, brass], [3.55, copper]].forEach(([y, m]) => {                                                                        // 3단 기계식 밀봉(회전 링 + 고정 링)
    const a = new THREE.Mesh(new THREE.CylinderGeometry(0.34, 0.34, 0.12, 36), m); a.position.y = y; sealRings.add(a);
    const b = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.3, 0.07, 36), steelLt); b.position.y = y + 0.1; sealRings.add(b);
  });

  // ── 전동기: 하부 프레임 + 고정자 + 회전자 + 코일 단부 + 플라이휠 + 상부 베어링 + 냉각기 ──
  const motorProfileOut = [[1.0, 3.95], [1.0, 7.3], [0.9, 7.35], [0.9, 7.9], [0.7, 7.95], [0.7, 8.7], [0.0001, 8.75]];
  const motorProfileIn = [[0.88, 3.95], [0.88, 7.3], [0.78, 7.35], [0.78, 7.9], [0.58, 7.95], [0.58, 8.62], [0.0001, 8.66]];
  root.add(latheSolid(motorProfileOut, motorProfileIn, { cut, mat: paint, seg: 64, hatch: [0.55, 0.7, 0.9] }));
  const fin = new THREE.InstancedMesh(new THREE.CylinderGeometry(1.06, 1.06, 0.045, 48, 1, true), paint, 24);
  const m4 = new THREE.Matrix4(); for (let i = 0; i < 24; i++) { m4.makeTranslation(0, 4.3 + i * 0.125, 0); fin.setMatrixAt(i, m4); } fin.frustumCulled = false; root.add(fin);
  const stator = new THREE.Mesh(new THREE.CylinderGeometry(0.86, 0.86, 2.4, 48, 1, true), mechMat({ cut, color: [0.3, 0.3, 0.34], metal: 0.85, rough: 0.5 })); stator.position.y = 5.6; root.add(stator);
  const rotor = new THREE.Mesh(new THREE.CylinderGeometry(0.58, 0.58, 2.4, 40), mechMat({ color: [0.45, 0.47, 0.52], metal: 0.9, rough: 0.35 })); rotor.position.y = 5.6; imp.add(rotor); rotor.position.y = 5.6 - 0.55;
  for (const y of [4.3, 6.9]) { const end = new THREE.Mesh(new THREE.TorusGeometry(0.74, 0.09, 12, 56), copperCut); end.rotation.x = Math.PI / 2; end.position.y = y; root.add(end); }       // 코일 단부
  const fly = new THREE.Mesh(new THREE.CylinderGeometry(0.76, 0.76, 0.34, 56), mechMat({ color: PALETTE.steelDk, metal: 0.9, rough: 0.3 })); fly.position.y = 7.6 - 0.55; imp.add(fly);
  for (let k = 0; k < 2; k++) { const c = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 1.7, 24), mechMat({ color: PALETTE.paintGreen, metal: 0.4, rough: 0.5 })); c.position.set(k ? 1.15 : -1.15, 5.3, -0.25); root.add(c); }      // 공기/물 냉각기
  // 지지다리 3개
  for (let k = 0; k < 3; k++) { const a = k / 3 * TAU + 0.5, leg = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.17, 1.9, 14), steelLt); leg.position.set(Math.cos(a) * 1.45, -0.3, Math.sin(a) * 1.45); root.add(leg); }

  // ── 유동 입자: 흡입(아래) → 임펠러에서 소용돌이 가속 → 토출 노즐 ──
  const NP = 5200, i = instanceIndex, h = (k) => hash(i.add(k * 4421));
  const pm = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
  {
    const s = fract(h(1).add(t.mul(0.28).mul(h(2).mul(0.4).add(0.8))));
    const a1 = smoothstep(0.0, 0.25, s), a2 = smoothstep(0.25, 0.78, s), a3 = smoothstep(0.78, 1.0, s);
    const th0 = h(3).mul(TAU), spin = float(1.0);
    const r = mix(mix(h(4).mul(0.2), float(0.22).add(a2.mul(0.9)), a2), float(1.2), a3);
    const th = th0.add(a2.mul(7.0)).add(t.mul(2.2));
    const y = mix(mix(float(-1.3), float(0.7), a1), float(0.95), a2);
    const radial = vec3(cos(th).mul(r), y, sin(th).mul(r));
    const out = vec3(float(1.25).add(a3.mul(2.5)), float(0.9).add(h(7).sub(0.5).mul(0.7)), h(5).sub(0.5).mul(0.9));
    const pos = mix(radial, out, a3);
    pm.positionNode = pos;
    pm.scaleNode = h(6).mul(0.05).add(0.04);
    const vis = step(pos.z, 0.05).mul(U.flow);
    pm.colorNode = varying(mix(vec3(0.3, 0.6, 1.0), vec3(0.8, 0.95, 1.0), a2).mul(vis).mul(0.85), 'vRcpFlow');
    pm.opacityNode = smoothstep(0.5, 0.0, length(uv().sub(0.5))).pow(1.4);
  }
  const flow = new THREE.Sprite(pm); flow.count = NP; flow.frustumCulled = false; flow.renderOrder = 6; root.add(flow);

  return {
    root, U, cut, imp,
    set(spin, cutDepth, cutOn = 1) {
      imp.rotation.y = spin; cut.uOn.value = cutOn; cut.uZ.value = cutDepth;
      const showSec = cutDepth < 0.06 && cutOn > 0.5; root.traverse((o) => { if (o.userData.section) o.visible = showSec; });
    },
  };
}
