// scenes/shared/mech/pressurizer.js — 가압기(Pressurizer) 단면도
//
//  1차 계통은 약 155 bar(15.5 MPa), 300 °C 이상의 물이다. 이 압력이 약해지면 물이 끓어 버리므로, 가압기가 계통 압력을 "일정하게 누르고 있는" 역할을 한다.
//   · 아래: 전열기(히터) 수십 개가 물을 데워 증기를 만든다 → 증기 부피가 늘어 압력이 오른다.
//   · 위: 스프레이 노즐이 차가운 물(저온관에서 끌어온)을 증기 속에 뿌린다 → 증기가 응축되어 압력이 내려간다.
//   · 압력이 너무 높아지면 안전밸브(스프링식)가 열려 증기를 빼낸다. 아래 서지관(surge line)은 고온관과 이어져 계통의 부피 변화를 흡수한다.
//   · 가압기 안은 물과 증기가 "포화 상태로 공존"한다: 155 bar 에서 물의 끓는점(포화온도)은 약 345 °C.
//  수치(대표값): 압력 15.5 MPa, 포화온도 약 345 °C(증기표), 높이 십여 m. 1 유닛 = 1 m. 형상은 모식 모형.

import * as THREE from 'three/webgpu';
import {
  Fn, float, vec3, vec4, uniform, uv, instanceIndex, hash, positionGeometry, normalize, length, mix, smoothstep, pow, sin, cos, fract, step, varying, abs, clamp,
  positionWorld, cameraPosition, dot, normalWorld,
} from 'three/tsl';
import { mechMat, latheSolid, makeCut, PALETTE, TAU, pipe } from './kit.js';

export const PZR = { WATER_Y0: 1.25, TOP: 13.9, LEVEL: 7.6 };

export function makePressurizer(ctx) {
  const t = ctx.u.time;
  const root = new THREE.Group();
  const cut = makeCut(0);
  const U = { heat: uniform(1.0), spray: uniform(1.0), level: uniform(PZR.LEVEL), flow: uniform(1.0) };

  const steel = mechMat({ cut, color: PALETTE.steel, metal: 0.9, rough: 0.34 });
  const steelLt = mechMat({ color: PALETTE.steelLt, metal: 0.9, rough: 0.3 });
  const solid = mechMat({ color: PALETTE.steel, metal: 0.9, rough: 0.34 });

  // ── 압력용기 + 스커트(지지 원통) ──
  const outer = [[0.0001, 0.9], [0.5, 0.95], [1.0, 1.15], [1.4, 1.6], [1.58, 2.4], [1.58, 12.4], [1.5, 13.1], [1.15, 13.9], [0.6, 14.35], [0.0001, 14.5]];
  const inner = [[0.0001, 1.1], [0.5, 1.15], [0.95, 1.35], [1.28, 1.75], [1.38, 2.5], [1.38, 12.4], [1.3, 13.0], [1.0, 13.7], [0.55, 14.1], [0.0001, 14.28]];
  const vessel = latheSolid(outer, inner, { cut, mat: steel, seg: 80 }); root.add(vessel);
  root.add(latheSolid([[1.62, 0], [1.62, 1.55], [1.55, 1.7]], [[1.52, 0], [1.52, 1.55], [1.45, 1.7]], { cut, mat: steel, seg: 64 }));
  // 맨웨이/플랜지 링
  for (const y of [2.5, 12.3]) { const r = new THREE.Mesh(new THREE.TorusGeometry(1.6, 0.07, 12, 72), mechMat({ cut, color: PALETTE.steelLt, metal: 0.9, rough: 0.3 })); r.rotation.x = Math.PI / 2; r.position.y = y; root.add(r); }

  // ── 물(아래) + 증기(위): 반투명 부피 + 수면 ──
  const waterMat = new THREE.MeshBasicNodeMaterial({ transparent: true, depthWrite: false, side: THREE.DoubleSide });
  waterMat.colorNode = Fn(() => {
    const y = positionGeometry.y;
    return vec4(vec3(0.05, 0.3, 0.7).add(vec3(0.1, 0.4, 0.8).mul(y.mul(0.3))), 0.2);
  })();
  waterMat.maskNode = positionWorld.z.lessThan(cut.uZ).or(cut.uOn.lessThan(0.5));
  const waterGeo = new THREE.CylinderGeometry(1.36, 1.36, 1, 48, 1, true); waterGeo.translate(0, 0.5, 0);
  const water = new THREE.Mesh(waterGeo, waterMat); water.position.y = PZR.WATER_Y0; water.renderOrder = 3; root.add(water);
  const steamMat = new THREE.MeshBasicNodeMaterial({ transparent: true, depthWrite: false, side: THREE.DoubleSide });
  steamMat.colorNode = Fn(() => {
    const p = positionWorld, n = mx_noiseLike(p);
    return vec4(vec3(0.75, 0.82, 0.95).mul(0.5), n.mul(0.1).add(0.05));
  })();
  steamMat.maskNode = positionWorld.z.lessThan(cut.uZ).or(cut.uOn.lessThan(0.5));
  const steamGeo = new THREE.CylinderGeometry(1.36, 1.36, 1, 48, 1, true); steamGeo.translate(0, 0.5, 0);
  const steam = new THREE.Mesh(steamGeo, steamMat); steam.renderOrder = 3; root.add(steam);
  // 수면: 잔물결 원판
  const surfMat = new THREE.MeshBasicNodeMaterial({ transparent: true, depthWrite: false, side: THREE.DoubleSide, blending: THREE.AdditiveBlending });
  surfMat.colorNode = Fn(() => {
    const p = positionGeometry, rr = length(p.xy), ripple = sin(rr.mul(14.0).sub(t.mul(3.0))).mul(0.5).add(0.5), c = pow(ripple, 5.0);
    return vec4(vec3(0.2, 0.55, 1.0).mul(c.mul(0.5).add(0.15)).mul(smoothstep(1.4, 1.0, rr)), 1.0);
  })();
  const surf = new THREE.Mesh(new THREE.CircleGeometry(1.36, 48), surfMat); surf.rotation.x = -Math.PI / 2; surf.renderOrder = 4; root.add(surf);

  // ── 전열기(히터) 봉 78개 중 단면 쪽 ──
  const heaterPos = [];
  for (let q = -8; q <= 8; q++) for (let r = -8; r <= 8; r++) { const x = (q + r / 2) * 0.17, z = r * 0.17 * 0.866; if (Math.hypot(x, z) <= 0.98 && heaterPos.length < 78) heaterPos.push([x, z]); }
  const vis = heaterPos.filter(([, z]) => z <= 0.06);
  const heatMat = mechMat({
    color: [0.3, 0.2, 0.18], metal: 0.6, rough: 0.5,
    emissiveNode: Fn(() => vec3(1.0, 0.32, 0.06).mul(U.heat).mul(positionGeometry.y.add(1.2).div(2.4).mul(0.5).add(0.7)).mul(sin(t.mul(3.0)).mul(0.15).add(1.1)).mul(1.8))(),
  });
  const heaters = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.038, 0.038, 2.4, 10), heatMat, vis.length);
  const m4 = new THREE.Matrix4();
  vis.forEach(([x, z], i) => { m4.makeTranslation(x, 2.55, z); heaters.setMatrixAt(i, m4); }); heaters.frustumCulled = false; root.add(heaters);
  const plate = new THREE.Mesh(new THREE.CylinderGeometry(1.1, 1.1, 0.1, 40), mechMat({ color: PALETTE.steelDk, metal: 0.85, rough: 0.45 })); plate.position.y = 1.4; root.add(plate);

  // ── 서지관(아래, 고온관으로) + 스프레이관(위, 저온관에서) + 안전밸브 3기 ──
  const surge = pipe([[0, 0.95, 0], [0, -0.7, 0], [1.4, -1.5, 0], [4.5, -1.5, 0], [8, -1.5, 0]], 0.36, solid, { radial: 28 }); root.add(surge);
  const sprayLine = pipe([[4.2, 6.5, 0], [4.2, 15.6, 0], [1.6, 16.1, 0], [0, 15.8, 0], [0, 14.4, 0]], 0.17, solid, { radial: 20 }); root.add(sprayLine);
  const valve = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.55, 0.55), mechMat({ color: PALETTE.paintRed, metal: 0.4, rough: 0.5 })); valve.position.set(4.2, 12.0, 0); root.add(valve);        // 스프레이 제어밸브
  const spring = new THREE.Group(); root.add(spring);
  [-0.65, 0.0, 0.65].forEach((x, k) => {                                                                                                                                                  // 안전밸브(스프링식) 3기
    const body = new THREE.Mesh(new THREE.CylinderGeometry(0.26, 0.3, 0.9, 24), steelLt); body.position.set(x, 14.9, -0.25 + k * 0.0); spring.add(body);
    const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 1.8, 10), solid); stem.position.set(x, 15.9, -0.25); spring.add(stem);
    for (let c = 0; c < 6; c++) { const coil = new THREE.Mesh(new THREE.TorusGeometry(0.19, 0.03, 8, 24), mechMat({ color: PALETTE.brass, metal: 1.0, rough: 0.3 })); coil.rotation.x = Math.PI / 2; coil.position.set(x, 15.45 + c * 0.14, -0.25); spring.add(coil); }
    const cap = new THREE.Mesh(new THREE.SphereGeometry(0.2, 16, 12), mechMat({ color: PALETTE.paintRed, metal: 0.4, rough: 0.5 })); cap.position.set(x, 16.8, -0.25); spring.add(cap);
  });
  const stub = pipe([[-0.65, 14.6, -0.25], [-0.65, 14.4, 0.4], [0, 14.4, 0.8]], 0.12, solid, { flanges: false }); root.add(stub);
  // 서포트 브래킷 + 격자 난간(청사진 느낌의 가는 선)
  for (let k = 0; k < 3; k++) { const a = k / 3 * TAU + 0.7, br = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.2, 1.2), steelLt); br.position.set(Math.cos(a) * 1.9, 9.5 + k * 0.001, Math.sin(a) * 1.9); br.rotation.y = -a; root.add(br); }

  // ── 입자: 히터에서 올라오는 기포 + 스프레이 물방울 + 증기 속 응축 방울 ──
  const mk = (n, build) => { const m = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending }); const o = build(m); const sp = new THREE.Sprite(m); sp.count = n; sp.frustumCulled = false; sp.renderOrder = 6; root.add(sp); return sp; };
  const i = instanceIndex, h = (k) => hash(i.add(k * 3331));
  mk(900, (m) => {                                                                                  // 기포
    const s = fract(h(1).add(t.mul(h(2).mul(0.25).add(0.18))));
    const ang = h(3).mul(TAU), rr = pow(h(4), 0.5).mul(0.95);
    const y = mix(float(1.8), U.level, s);
    const pos = vec3(cos(ang).mul(rr).add(sin(t.mul(2.0).add(h(5).mul(9.0))).mul(0.05)), y, sin(ang).mul(rr));
    m.positionNode = pos; m.scaleNode = h(6).mul(0.05).add(0.03).mul(float(0.6).add(s));
    m.colorNode = varying(vec3(0.8, 0.95, 1.0).mul(step(pos.z, 0.05)).mul(U.heat).mul(1.2), 'vPzrBub');
    m.opacityNode = smoothstep(0.5, 0.0, length(uv().sub(0.5))).pow(1.2);
  });
  mk(700, (m) => {                                                                                  // 스프레이 물방울(위에서 원뿔 모양으로 낙하)
    const s = fract(h(1).add(t.mul(h(2).mul(0.5).add(0.5))));
    const ang = h(3).mul(TAU), spread = s.mul(0.95).mul(h(4).mul(0.6).add(0.4));
    const y = float(13.85).sub(s.mul(float(13.85).sub(U.level.add(0.1))));
    const pos = vec3(cos(ang).mul(spread), y, sin(ang).mul(spread));
    m.positionNode = pos; m.scaleNode = h(5).mul(0.035).add(0.03);
    m.colorNode = varying(vec3(0.45, 0.75, 1.0).mul(U.spray).mul(step(pos.z, 0.05)).mul(1.5), 'vPzrSpray');
    m.opacityNode = smoothstep(0.5, 0.0, length(uv().sub(0.5))).pow(1.3);
  });
  mk(500, (m) => {                                                                                  // 증기 안의 응축 방울(천천히)
    const s = fract(h(1).add(t.mul(0.05).mul(h(2).add(0.5))));
    const ang = h(3).mul(TAU), rr = pow(h(4), 0.5).mul(1.2);
    const pos = vec3(cos(ang).mul(rr), mix(float(13.2), U.level.add(0.2), s), sin(ang).mul(rr));
    m.positionNode = pos; m.scaleNode = h(5).mul(0.03).add(0.02);
    m.colorNode = varying(vec3(0.7, 0.85, 1.0).mul(step(pos.z, 0.05)).mul(0.9), 'vPzrDrop');
    m.opacityNode = smoothstep(0.5, 0.0, length(uv().sub(0.5))).pow(1.3);
  });

  return {
    root, U, cut,
    set(level, cutDepth, cutOn = 1) {
      U.level.value = level;
      water.scale.y = level - PZR.WATER_Y0; steam.position.y = level; steam.scale.y = PZR.TOP - level; surf.position.y = level;
      cut.uOn.value = cutOn; cut.uZ.value = cutDepth;
      const showSec = cutDepth < 0.06 && cutOn > 0.5; root.traverse((o) => { if (o.userData.section) o.visible = showSec; });
    },
  };
}

// 위치 기반 잔잔한 값(0~1) — 증기 질감용 가벼운 사인 합
function mx_noiseLike(p) { return sin(p.x.mul(3.1).add(p.y.mul(2.3))).mul(sin(p.z.mul(2.7).sub(p.y.mul(1.7)))).mul(0.5).add(0.5); }
