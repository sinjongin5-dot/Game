// scenes/shared/mech/turbine.js — 증기터빈(고압터빈 + 저압터빈) 단면도
//
//  증기발생기가 만든 약 70 bar 의 증기가 터빈을 지나며 팽창하고, 그 열에너지가 회전 운동에너지로 바뀐다.
//   · 한 "단(stage)" = 고정 노즐(고정익, 증기의 방향을 바꾸고 가속) + 회전 버킷(동익, 증기에 밀려 회전자를 돌림). 단을 지날 때마다 압력이 떨어진다.
//   · 고압터빈(HP): 중앙으로 증기가 들어가 좌우로 갈라져 흐르는 복류형. 배기는 습분분리재열기(MSR)에서 물방울을 거르고 재가열된 뒤 저압터빈으로 간다.
//   · 저압터빈(LP): 증기가 진공에 가까운 압력까지 팽창하므로 부피가 엄청나게 커진다 → 뒤 단으로 갈수록 날개가 길고 케이싱이 넓어진다(마지막 단 날개 길이 1.5 m 이상).
//   · 케이싱은 두꺼운 주강이고, 회전자는 한 몸의 단조 강철이다. 저널 베어링이 축을 받치고, 날개 끝 속도는 음속 가까이 된다.
//  수치(대표값, 60 Hz 한국 계통): 회전수 1,800 rpm(4극 발전기와 직결), 주증기 약 6.9 MPa·약 285 °C(포화), 복수기 진공 약 5 kPa 수준.
//  ※ 날개 수·단 수·치수는 이해를 위한 모식이다. 축은 +x 방향, 1 유닛 = 1 m. 회전은 positionNode 에서 x축 회전(스핀)으로 처리한다.

import * as THREE from 'three/webgpu';
import {
  Fn, float, vec3, vec4, uniform, uv, instanceIndex, hash, normalize, length, mix, smoothstep, pow, sin, cos, fract, step, varying, abs, clamp, positionLocal,
} from 'three/tsl';
import { mechMat, latheSolid, makeCut, PALETTE, TAU, pipe } from './kit.js';

/** 날개 한 장(뿌리 → 끝으로 비틀리는 렌즈 단면). 스팬은 +y 방향, 길이 1 → 인스턴스에서 스케일. */
function bladeGeometry(chord = 0.16, thick = 0.035, twist = 0.7, segs = 7) {
  const pos = [], idx = [], ring = 8;
  for (let s = 0; s <= segs; s++) {
    const k = s / segs, ang = twist * k, c = chord * (1.0 - 0.35 * k);
    for (let j = 0; j < ring; j++) {
      const a = j / ring * TAU, px = Math.cos(a) * c * 0.5, pz = Math.sin(a) * thick * (0.5 - 0.15 * k) * (1 + 0.6 * Math.cos(a));
      pos.push(px * Math.cos(ang) - pz * Math.sin(ang), k, px * Math.sin(ang) + pz * Math.cos(ang));
    }
  }
  for (let s = 0; s < segs; s++) for (let j = 0; j < ring; j++) { const a = s * ring + j, b = s * ring + (j + 1) % ring, c = (s + 1) * ring + j, d = (s + 1) * ring + (j + 1) % ring; idx.push(a, c, b, b, c, d); }
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setIndex(idx); g.computeVertexNormals(); return g;
}

/** 케이싱 단면(축 위치 a, 반지름 r) 곡선으로부터 두꺼운 회전체 만들기 (축이 +x 가 되도록 z 회전) */
function casing(innerPts, wall, cut, mat) {
  const outer = innerPts.map(([r, a]) => [r + wall, a]), inner = innerPts;
  const g = latheSolid(outer, inner, { cut, mat, seg: 72 });
  g.rotation.z = -Math.PI / 2; return g;
}

export function makeTurbine(ctx) {
  const t = ctx.u.time;
  const root = new THREE.Group();
  const cut = makeCut(0);
  const U = { flow: uniform(1.0), spin: uniform(0.0), blur: uniform(0.0) };

  const steel = mechMat({ cut, color: PALETTE.steel, metal: 0.9, rough: 0.36 });
  const steelDk = mechMat({ cut, color: PALETTE.steelDk, metal: 0.85, rough: 0.45 });
  const solid = mechMat({ color: PALETTE.steelLt, metal: 0.92, rough: 0.28 });
  const AX = 3.6;                                                                             // 축 높이

  // 회전: 동익은 "축 높이에 놓인 그룹" 안에 있으므로 메시 공간의 (y,z) 가 곧 축 기준 좌표다 → x축 둘레로 U.spin 만큼 돌린다
  const movingMat = mechMat({ color: [0.82, 0.84, 0.88], metal: 0.92, rough: 0.3, rim: 0.35 });
  movingMat.positionNode = Fn(() => { const p = positionLocal, c = cos(U.spin), s = sin(U.spin); return vec3(p.x, p.y.mul(c).sub(p.z.mul(s)), p.y.mul(s).add(p.z.mul(c))); })();
  const statMat = mechMat({ cut, color: [0.62, 0.64, 0.7], metal: 0.9, rough: 0.35 });
  const rotMat = (color, o = {}) => mechMat({ color, metal: 0.92, rough: 0.3, ...o });                  // 축 대칭 부품(회전해도 같아 보임)

  // ── 단 배치: [중심으로부터의 거리 a, 허브 반지름, 날개 길이] — HP(복류) 8단 / LP(복류) 6단 ──
  const stagesHP = Array.from({ length: 8 }, (_, i) => [0.75 + i * 0.5, 0.62 + i * 0.012, 0.22 + i * 0.045]);
  const stagesLP = Array.from({ length: 6 }, (_, i) => [1.2 + i * 1.05, 0.9 + i * 0.03, 0.55 + Math.pow(i, 1.6) * 0.16]);
  const HP_X = -9.5, LP_X = 7.0;
  const innerOf = (stages, half) => { const pts = [[1.3, -half], ...stages.slice().reverse().map(([a, rh, L]) => [rh + L + 0.1, -a]), [1.1, 0.0], ...stages.map(([a, rh, L]) => [rh + L + 0.1, a]), [1.3, half]]; return pts.map(([r, a]) => [r, a]); };
  // 위의 곡선을 (반지름, 축) 쌍으로 쓰되 latheSolid 는 아래→위 정렬이어야 하므로 축이 증가하는 순서로 정렬
  const sorted = (arr) => arr.slice().sort((p, q) => p[1] - q[1]);

  const buildTurbine = (cx, stages, half, label) => {
    const g = new THREE.Group(); g.position.set(cx, AX, 0); root.add(g);
    // 케이싱(두꺼운 주강 반쪽 단면)
    const ip = sorted(innerOf(stages, half));
    const cs = casing(ip.map(([r, a]) => [r, a]), 0.38, cut, steel); g.add(cs);
    // 케이싱 외부 리브/플랜지(수평 분할면 볼트열)
    const rAt = (x) => { for (let i = 0; i < ip.length - 1; i++) { const [r0, a0] = ip[i], [r1, a1] = ip[i + 1]; if (x >= a0 && x <= a1) return r0 + (r1 - r0) * (x - a0) / (a1 - a0 || 1); } return ip[ip.length - 1][0]; };
    const ribMat = mechMat({ cut, color: PALETTE.steelLt, metal: 0.9, rough: 0.3 });
    for (let i = -4; i <= 4; i++) { const x = i * (half / 4.4), rib = new THREE.Mesh(new THREE.TorusGeometry(rAt(x) + 0.42, 0.07, 10, 56), ribMat); rib.rotation.y = Math.PI / 2; rib.position.x = x; g.add(rib); }
    // 회전자: 중심 몸통 + 단별 디스크 + 동익 링
    const rotorCore = new THREE.Mesh(new THREE.CylinderGeometry(0.58, 0.58, half * 2 + 3.0, 40), rotMat([0.5, 0.52, 0.58])); rotorCore.rotation.z = Math.PI / 2; g.add(rotorCore); rotorCore.position.set(0, 0, 0);
    const nMove = 56, nStat = 64, bm = bladeGeometry(0.16, 0.04, 0.75), bs = bladeGeometry(0.16, 0.04, -0.75);
    stages.forEach(([a, rh, L]) => {
      for (const side of [-1, 1]) {
        const disc = new THREE.Mesh(new THREE.CylinderGeometry(rh, rh, 0.14, 40), rotMat([0.55, 0.57, 0.62])); disc.rotation.z = Math.PI / 2; disc.position.x = side * a; g.add(disc);
        // 동익(회전)
        const mv = new THREE.InstancedMesh(bm, movingMat, nMove);
        const m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), e = new THREE.Euler();
        // 날개의 스팬은 +y 방향이다 → x축 회전으로 방사 방향을 돌리고 허브 반지름만큼 띄운다
        for (let k = 0; k < nMove; k++) { const ang = k / nMove * TAU; e.set(ang, 0, 0); q.setFromEuler(e); m4.compose(new THREE.Vector3(side * a, Math.cos(ang) * rh, Math.sin(ang) * rh), q, new THREE.Vector3(1, L, 1)); mv.setMatrixAt(k, m4); }
        mv.frustumCulled = false; g.add(mv);
        // 정익(고정): 케이싱 안쪽에서 안으로 뻗는 날개 — 동익보다 약간 중심 쪽(a ± 0.22)
        const st = new THREE.InstancedMesh(bs, statMat, nStat);
        for (let k = 0; k < nStat; k++) { const ang = k / nStat * TAU, rout = rh + L + 0.1, dirY = Math.cos(ang), dirZ = Math.sin(ang); e.set(ang + Math.PI, 0, 0); q.setFromEuler(e); m4.compose(new THREE.Vector3(side * (a - 0.24), dirY * rout, dirZ * rout), q, new THREE.Vector3(1, L * 0.95, 1)); st.setMatrixAt(k, m4); }
        st.frustumCulled = false; g.add(st);
      }
    });
    root.userData[label] = g;
    return g;
  };
  const hp = buildTurbine(HP_X, stagesHP, 4.6, 'hp');
  const lp = buildTurbine(LP_X, stagesLP, 7.3, 'lp');

  // ── 축(저널) + 베어링 받침 + 커플링 + 바닥 받침(콘크리트 테이블) ──
  const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.42, 36, 36), rotMat([0.55, 0.57, 0.62])); shaft.rotation.z = Math.PI / 2; shaft.position.set(-1.5, AX, 0); root.add(shaft);
  for (const x of [-15.5, -3.6, 1.0, 14.8, 21.5]) {
    const br = new THREE.Mesh(new THREE.BoxGeometry(1.4, 1.5, 2.4), mechMat({ color: PALETTE.steelDk, metal: 0.85, rough: 0.45 })); br.position.set(x, AX - 1.9, 0); root.add(br);
    const ring = new THREE.Mesh(new THREE.CylinderGeometry(0.62, 0.62, 0.9, 32), mechMat({ color: PALETTE.brass, metal: 1.0, rough: 0.3 })); ring.rotation.z = Math.PI / 2; ring.position.set(x, AX, 0); root.add(ring);
  }
  const table = new THREE.Mesh(new THREE.BoxGeometry(46, 1.6, 7.5), mechMat({ color: PALETTE.concrete, metal: 0.05, rough: 0.8 })); table.position.set(3, 0.2, -2.0); root.add(table);
  for (const [cx, w] of [[HP_X, 10.5], [LP_X, 17.5]]) { const pad = new THREE.Mesh(new THREE.BoxGeometry(w, 0.9, 5.5), steelDk); pad.position.set(cx, 1.45, -0.6); root.add(pad); }
  // 주증기관 + 제어밸브(HP 중앙 위) + 크로스오버관(HP 배기 → MSR → LP 중앙)
  const mainIn = pipe([[HP_X, AX + 2.2, 0], [HP_X, AX + 5.0, 0], [HP_X - 3.5, AX + 6.2, 0], [HP_X - 9, AX + 6.2, 0]], 0.42, solid, { radial: 24 }); root.add(mainIn);
  const valve = new THREE.Mesh(new THREE.BoxGeometry(1.3, 1.6, 1.3), mechMat({ color: PALETTE.paintRed, metal: 0.4, rough: 0.5 })); valve.position.set(HP_X, AX + 3.2, 0); root.add(valve);
  const cross = pipe([[HP_X + 4.6, AX + 1.6, 0], [HP_X + 5.6, AX + 3.8, 0], [LP_X - 5, AX + 6.4, 0], [LP_X, AX + 6.4, 0], [LP_X, AX + 4.0, 0]], 0.5, solid, { radial: 26 }); root.add(cross);
  const msr = new THREE.Mesh(new THREE.CylinderGeometry(1.5, 1.5, 11, 40, 1, true), mechMat({ cut, color: PALETTE.paintGreen, metal: 0.45, rough: 0.5 })); msr.rotation.z = Math.PI / 2; msr.position.set(LP_X - 2.5, AX + 8.6, 0); root.add(msr);   // 습분분리재열기(MSR)
  // LP 배기 후드 + 복수기(아래 박스)
  const hood = new THREE.Mesh(new THREE.BoxGeometry(14.0, 3.2, 6.4), mechMat({ cut, color: PALETTE.steelDk, metal: 0.85, rough: 0.5, double: true })); hood.position.set(LP_X, 0.7, -0.8); root.add(hood);

  // ── 증기 입자: HP 중앙에서 양쪽으로, LP 중앙에서 양쪽으로 팽창(색은 주황-노랑 → 연한 푸른 백색) ──
  const mkFlow = (cx, stages, half, N, label) => {
    const i = instanceIndex, h = (k) => hash(i.add(k * 6007));
    const m = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
    const s = fract(h(1).add(t.mul(0.12).mul(h(2).mul(0.4).add(0.8))));
    const side = step(0.5, h(3)).mul(2.0).sub(1.0);
    const xr = float(0.25).add(s.mul(half - 0.3));
    const rh0 = stages[0][1] + 0.05, rh1 = stages[stages.length - 1][1] + 0.05, L0 = stages[0][2], L1 = stages[stages.length - 1][2];
    const rhub = mix(float(rh0), float(rh1), s), L = mix(float(L0), float(L1), s);
    const rr = rhub.add(L.mul(pow(h(4), 0.7)));
    const th = h(5).mul(TAU).add(t.mul(mix(float(2.2), float(1.0), s))).add(U.spin);
    const x = side.mul(xr).add(cx);
    const pos = vec3(x, float(AX).add(cos(th).mul(rr)), sin(th).mul(rr));
    m.positionNode = pos;
    m.scaleNode = h(6).mul(0.06).add(0.04).mul(mix(float(0.8), float(2.0), s));
    const col = mix(vec3(1.0, 0.55, 0.2), vec3(0.75, 0.9, 1.0), smoothstep(0.0, 1.0, s));
    m.colorNode = varying(col.mul(step(pos.z, 0.05)).mul(U.flow).mul(mix(float(1.2), float(0.6), s)), `vTurb${label}`);
    m.opacityNode = smoothstep(0.5, 0.0, length(uv().sub(0.5))).pow(1.4);
    const sp = new THREE.Sprite(m); sp.count = N; sp.frustumCulled = false; sp.renderOrder = 6; root.add(sp);
  };
  mkFlow(HP_X, stagesHP, 4.4, 4200, "hp"); mkFlow(LP_X, stagesLP, 7.0, 5200, "lp");

  return {
    root, U, cut, hp, lp,
    set(spin, cutDepth, cutOn = 1) {
      U.spin.value = spin; cut.uOn.value = cutOn; cut.uZ.value = cutDepth;
      const showSec = cutDepth < 0.06 && cutOn > 0.5; root.traverse((o) => { if (o.userData.section) o.visible = showSec; });
    },
    AX, HP_X, LP_X,
  };
}
