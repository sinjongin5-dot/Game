// scenes/shared/mech/generator.js — 터빈 발전기(동기발전기) 단면도: 회전하는 자석이 코일에 전류를 만든다 (패러데이 전자기 유도)
//
//  · 회전자(rotor): 한 몸의 단조 강철 원통. 표면의 홈에 여자 코일(계자 권선)을 넣고 직류를 흘려 거대한 4극 전자석(N·S·N·S)으로 만든다.
//    터빈과 한 축으로 직결되어 1,800 rpm(= 30 회전/초)으로 돈다 → 4극이 한 바퀴에 2번 지나가므로 전기가 60 Hz(초당 60번 진동).
//  · 고정자(stator): 얇은 규소강판을 겹쳐 쌓은 철심(와전류 손실을 줄이려고 얇게 적층) + 홈에 넣은 3상 구리 코일. 자기장이 코일을 쓸고 지나가면 전압이 유도된다.
//    양 끝의 곡선 구리 다발은 "엔드 와인딩"이고, 3상은 120°씩 어긋난 전류로 합쳐져 단자(부싱)로 나간다.
//  · 냉각: 코일과 철심의 열이 크므로 회전자는 수소 가스, 고정자 코일은 순수 냉각수로 식힌다(수소는 밀도가 낮아 마찰 손실이 작고 열전달이 좋다) — 위쪽 수소 냉각기.
//  · 여자기(exciter): 회전자 끝에 붙은 작은 발전기+정류기가 계자 코일에 직류를 공급한다.
//  수치(대표값): 출력 약 1,400 MWe(APR1400 급), 단자 전압 수십 kV(약 20~24 kV) → 변압기로 345/765 kV 로 승압 송전.
//  ※ 슬롯 수·권선 모양은 이해를 위한 모식이다. 축 +x, 1 유닛 = 1 m.

import * as THREE from 'three/webgpu';
import {
  Fn, float, vec3, vec4, uniform, uv, instanceIndex, hash, positionGeometry, normalize, length, mix, smoothstep, pow, sin, cos, atan, fract, step, varying, abs, clamp, positionLocal,
} from 'three/tsl';
import { mechMat, latheSolid, makeCut, PALETTE, TAU, pipe } from './kit.js';

export function makeGenerator(ctx) {
  const t = ctx.u.time;
  const root = new THREE.Group();
  const cut = makeCut(0);
  const U = { flow: uniform(1.0), phase: uniform(0.0), gen: uniform(1.0) };
  const AX = 3.4, HALF = 6.2;

  const frame = mechMat({ cut, color: PALETTE.paintBlue, metal: 0.45, rough: 0.5 });
  const steelLt = mechMat({ color: PALETTE.steelLt, metal: 0.9, rough: 0.3 });
  const copper = mechMat({ color: PALETTE.copper, metal: 1.0, rough: 0.28 });
  const copperCut = mechMat({ cut, color: PALETTE.copper, metal: 1.0, rough: 0.28 });

  // ── 고정자 프레임(두꺼운 외피) ──
  const outer = [[2.4, -HALF - 0.6], [2.4, HALF + 0.6]], inner = [[2.25, -HALF - 0.6], [2.25, HALF + 0.6]];
  const fr = latheSolid(outer, inner, { cut, mat: frame, seg: 80, hatch: [0.55, 0.7, 0.9] }); fr.rotation.z = -Math.PI / 2; fr.position.y = AX; root.add(fr);
  for (const sgn of [-1, 1]) { const end = latheSolid([[2.4, 0], [1.1, 0.5], [0.7, 0.9]], [[2.25, 0.0], [1.0, 0.42], [0.6, 0.8]], { cut, mat: frame, seg: 64, hatch: [0.55, 0.7, 0.9] }); end.rotation.z = -Math.PI / 2 * sgn; end.position.set(sgn * (HALF + 0.6), AX, 0); root.add(end); }
  for (let i = -6; i <= 6; i++) { const rib = new THREE.Mesh(new THREE.TorusGeometry(2.45, 0.07, 10, 64), mechMat({ cut, color: PALETTE.steelLt, metal: 0.9, rough: 0.3 })); rib.rotation.y = Math.PI / 2; rib.position.set(i * 0.95, AX, 0); root.add(rib); }

  // ── 고정자 철심: 얇은 규소강판 적층(링 70개) ──
  const coreMat = mechMat({ cut, color: [0.42, 0.45, 0.52], metal: 0.9, rough: 0.35 });
  const laminations = new THREE.InstancedMesh(new THREE.CylinderGeometry(1.7, 1.7, 0.07, 64, 1, true), coreMat, 76);
  const inRing = new THREE.InstancedMesh(new THREE.CylinderGeometry(1.28, 1.28, 0.07, 64, 1, true), coreMat, 76);
  const m4 = new THREE.Matrix4(), q = new THREE.Quaternion().setFromEuler(new THREE.Euler(0, 0, Math.PI / 2));
  for (let i = 0; i < 76; i++) { m4.compose(new THREE.Vector3(-5.0 + i * 0.1333, AX, 0), q, new THREE.Vector3(1, 1, 1)); laminations.setMatrixAt(i, m4); inRing.setMatrixAt(i, m4); }
  laminations.frustumCulled = inRing.frustumCulled = false; root.add(laminations, inRing);
  const yoke = new THREE.Mesh(new THREE.CylinderGeometry(1.7, 1.7, 10.1, 64, 1, true), mechMat({ cut, color: [0.3, 0.33, 0.4], metal: 0.9, rough: 0.5, alpha: 0.5, transparent: true })); yoke.rotation.z = Math.PI / 2; yoke.position.set(0, AX, 0); root.add(yoke);

  // ── 고정자 코일(3상 구리 바) + 엔드 와인딩 ──
  const bars = 36, barMat = mechMat({
    cut, color: PALETTE.copper, metal: 1.0, rough: 0.28,
    emissiveNode: Fn(() => {                                                                            // 유도 전류 펄스: 축 방향으로 흐르는 밝은 띠(상마다 120° 위상차)
      const x = positionGeometry.y, ph = x.mul(0.9).sub(t.mul(5.0));
      return vec3(1.0, 0.55, 0.15).mul(smoothstep(0.6, 1.0, sin(ph).mul(0.5).add(0.5))).mul(U.gen).mul(0.7);
    })(),
  });
  const barGeo = new THREE.CylinderGeometry(0.045, 0.045, 10.4, 8);
  const barMesh = new THREE.InstancedMesh(barGeo, barMat, bars);
  const rot = new THREE.Quaternion().setFromEuler(new THREE.Euler(0, 0, Math.PI / 2));
  for (let k = 0; k < bars; k++) { const a = k / bars * TAU; m4.compose(new THREE.Vector3(0, AX + Math.cos(a) * 1.4, Math.sin(a) * 1.4), rot, new THREE.Vector3(1, 1, 1)); barMesh.setMatrixAt(k, m4); }
  barMesh.frustumCulled = false; root.add(barMesh);
  for (const sgn of [-1, 1]) {
    const cone = new THREE.Group(); cone.position.set(sgn * 5.2, AX, 0); root.add(cone);
    for (let k = 0; k < bars; k++) {                                                                      // 엔드 와인딩: 곡선으로 휘어 돌아가는 바
      const a = k / bars * TAU, a2 = a + 0.55;
      const pts = [[0, Math.cos(a) * 1.4, Math.sin(a) * 1.4], [sgn * 0.5, Math.cos(a + 0.2) * 1.55, Math.sin(a + 0.2) * 1.55], [sgn * 0.9, Math.cos(a2) * 1.7, Math.sin(a2) * 1.7]];
      const tube = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts.map((p) => new THREE.Vector3(...p))), 12, 0.045, 6, false), copperCut); cone.add(tube);
    }
    const basket = new THREE.Mesh(new THREE.TorusGeometry(1.62, 0.07, 10, 60), copperCut); basket.rotation.y = Math.PI / 2; basket.position.x = sgn * 0.85; cone.add(basket);
  }

  // ── 회전자: 4극 전자석 (표면 셰이더에 N/S 극 패턴) + 슬롯 줄무늬 + 리테이닝 링 ──
  const rotor = new THREE.Group(); rotor.position.y = AX; root.add(rotor);
  const rotMat = new THREE.MeshBasicNodeMaterial();
  rotMat.colorNode = Fn(() => {
    const p = positionGeometry, ang = atan(p.z, p.x).add(0.0), pole = sin(ang.mul(2.0)), slot = smoothstep(0.35, 0.5, abs(fract(ang.mul(24.0 / TAU)).sub(0.5)));
    const N = vec3(1.0, 0.18, 0.12), S = vec3(0.15, 0.4, 1.0);
    const base = mix(vec3(0.5, 0.52, 0.58), mix(S, N, step(0.0, pole)), smoothstep(0.1, 0.5, abs(pole)).mul(0.65));
    return vec4(base.mul(slot.mul(0.5).add(0.5)).mul(0.9).add(mix(S, N, step(0.0, pole)).mul(abs(pole)).mul(0.25)), 1.0);
  })();
  const rBody = new THREE.Mesh(new THREE.CylinderGeometry(1.0, 1.0, 10.6, 64), rotMat); rBody.rotation.z = Math.PI / 2; rotor.add(rBody);   // 위 셰이더의 (x,z) = 원통 로컬 단면 좌표(회전해도 극이 몸에 붙어 돈다)
  const shaftL = new THREE.Mesh(new THREE.CylinderGeometry(0.46, 0.46, 3.4, 32), steelLt); shaftL.rotation.z = Math.PI / 2; shaftL.position.x = -8.0; rotor.add(shaftL);
  const shaftR = shaftL.clone(); shaftR.position.x = 8.4; rotor.add(shaftR);
  for (const x of [-5.4, 5.4]) { const rr = new THREE.Mesh(new THREE.CylinderGeometry(1.08, 1.08, 0.9, 48), mechMat({ color: PALETTE.steelDk, metal: 0.9, rough: 0.35 })); rr.rotation.z = Math.PI / 2; rr.position.x = x; rotor.add(rr); }
  // 베어링 받침
  for (const x of [-8.6, 8.9]) { const br = new THREE.Mesh(new THREE.BoxGeometry(1.2, 1.5, 2.2), mechMat({ color: PALETTE.steelDk, metal: 0.85, rough: 0.45 })); br.position.set(x, AX - 1.9, 0); root.add(br); const j = new THREE.Mesh(new THREE.CylinderGeometry(0.6, 0.6, 0.8, 28), mechMat({ color: PALETTE.brass, metal: 1.0, rough: 0.3 })); j.rotation.z = Math.PI / 2; j.position.set(x, AX, 0); root.add(j); }

  // ── 여자기(오른쪽 끝) + 수소 냉각기(위) + 단자 부싱(아래) + 기초 ──
  const exc = new THREE.Mesh(new THREE.CylinderGeometry(1.15, 1.15, 2.2, 40), mechMat({ cut, color: PALETTE.paintGreen, metal: 0.45, rough: 0.5 })); exc.rotation.z = Math.PI / 2; exc.position.set(HALF + 3.3, AX, 0); root.add(exc);
  for (const x of [-3.2, 0, 3.2]) { const c = new THREE.Mesh(new THREE.BoxGeometry(2.2, 1.0, 1.6), mechMat({ color: [0.2, 0.55, 0.45], metal: 0.4, rough: 0.5 })); c.position.set(x, AX + 2.9, -0.6); root.add(c); }
  for (let k = 0; k < 3; k++) {
    const x = -1.6 + k * 1.6;
    const ins = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.3, 1.5, 20), mechMat({ color: [0.75, 0.7, 0.62], metal: 0.1, rough: 0.5 })); ins.position.set(x, AX - 3.1, -0.4); root.add(ins);
    const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.26, 0.26, 0.2, 20), copper); cap.position.set(x, AX - 2.3, -0.4); root.add(cap);
    root.add(pipe([[x, AX - 3.85, -0.4], [x, 0.9, -0.4], [x + 3 + k * 0.5, 0.9, -0.4], [x + 9, 0.9, -0.4]], 0.14, copper, { flanges: false }));
  }
  const base = new THREE.Mesh(new THREE.BoxGeometry(24, 1.4, 7), mechMat({ color: PALETTE.concrete, metal: 0.05, rough: 0.8 })); base.position.set(0, -0.0, -1.5); root.add(base);

  // ── 자기력선 입자: 회전자 극에서 나와 공극→고정자 철심→이웃 극으로 돌아오는 폐곡선 (회전자와 함께 돈다) ──
  const NP = 5600, i = instanceIndex, h = (k) => hash(i.add(k * 6571));
  const pm = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
  {
    const s = fract(h(1).add(t.mul(0.35)));
    const pair = h(2).mul(4.0).floor();                                                                   // 어느 극쌍 사이를 도는가(4)
    const base = pair.mul(TAU / 4.0).add(U.phase).add(0.25);
    const ang = base.add(s.mul(TAU / 4.0 - 0.5));
    const arc = sin(s.mul(Math.PI));
    const rr = float(1.02).add(arc.mul(h(3).mul(0.5).add(0.15)));
    const x = h(4).mul(9.6).sub(4.8);
    const pos = vec3(x, float(AX).add(cos(ang).mul(rr)), sin(ang).mul(rr));
    pm.positionNode = pos;
    pm.scaleNode = h(5).mul(0.05).add(0.035);
    pm.colorNode = varying(mix(vec3(0.3, 0.7, 1.0), vec3(1.0, 0.45, 0.25), step(0.5, s)).mul(step(pos.z, 0.06)).mul(U.flow).mul(0.9), 'vGenField');
    pm.opacityNode = smoothstep(0.5, 0.0, length(uv().sub(0.5))).pow(1.3);
  }
  const field = new THREE.Sprite(pm); field.count = NP; field.frustumCulled = false; field.renderOrder = 6; root.add(field);

  return {
    root, U, cut, rotor, AX,
    set(spin, cutDepth, cutOn = 1) {
      rotor.rotation.x = spin; U.phase.value = spin; cut.uOn.value = cutOn; cut.uZ.value = cutDepth;
      const showSec = cutDepth < 0.06 && cutOn > 0.5; root.traverse((o) => { if (o.userData.section) o.visible = showSec; });
    },
  };
}
