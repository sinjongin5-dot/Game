// scenes/shared/mech/kit.js — Ch.6a "핵심 기계 해부" 공용 부품: 재질·단면(컷어웨이)·회전체·볼트·배관·치수선
//
//  모든 기계는 "세로 평면 z = 기계 원점 z − 컷 깊이" 로 반쪽을 잘라 낸 단면(컷어웨이) 모형이다. 카메라는 +z 쪽에서 단면을 본다.
//   · 껍데기(압력용기·케이싱 등)는 maskNode 로 z 가 평면보다 큰 부분을 버리고, 속면(뒷면)은 어둡게 칠해 안쪽 벽이 보이게 한다.
//   · 두께가 있는 껍데기는 바깥 곡선 + 안쪽 곡선을 따로 돌리고(lathe) 그 사이를 사선 해칭(hatching)으로 채운 "절단면 다각형"을 평면 위에 올린다 — 제도의 단면도 표현.
//   · 회전자·튜브·연료집합체처럼 속이 찬 부품은 자르지 않는다(실제 단면도도 속이 찬 부품은 자르지 않고 보여 준다).
//  재질은 shared/studio.js 의 shade()(키라이트+필라이트+프레넬+스튜디오 환경 반사) 위에 청색 림라이트를 얹어 "청사진 + PBR" 느낌으로 통일한다.
//  단위: 1 유닛 = 1 m (실제 가압경수로의 대략적인 비율. 수치 출처는 각 기계 파일 주석).

import * as THREE from 'three/webgpu';
import {
  Fn, float, vec2, vec3, vec4, uniform, uv, instanceColor, normalWorld, positionWorld, positionGeometry, cameraPosition, frontFacing,
  normalize, length, dot, mix, smoothstep, clamp, pow, exp, sin, cos, abs, fract, floor, step, max, min, mx_noise_float,
} from 'three/tsl';
import { shade } from '../studio.js';

export const TAU = Math.PI * 2;
export const PALETTE = {
  steel:   [0.52, 0.55, 0.6],
  steelDk: [0.30, 0.32, 0.36],
  steelLt: [0.78, 0.8, 0.84],
  paintBlue: [0.10, 0.30, 0.52],
  paintGreen: [0.10, 0.38, 0.30],
  paintRed: [0.55, 0.12, 0.10],
  copper:  [0.90, 0.46, 0.24],
  brass:   [0.85, 0.66, 0.25],
  concrete: [0.16, 0.17, 0.2],
  rubber:  [0.05, 0.05, 0.06],
};

/** 기계 한 대의 컷어웨이 상태 (uniform 은 그 기계의 모든 재질이 공유). uZ = 절단 평면의 월드 z (이보다 큰 쪽을 버린다) */
export function makeCut(z0 = 0) {
  return { uOn: uniform(1.0), uZ: uniform(z0 + 100.0), z0 };
}

/**
 * 기계 재질.
 *  o.color  : 알베도 [r,g,b] (instanced=true 면 인스턴스 색을 곱한다)
 *  o.metal/rough : 금속성/거칠기     o.cut : makeCut() 결과(없으면 자르지 않음)
 *  o.emissive : [r,g,b] 자체발광(HDR)  o.emissiveNode : 위치/시간에 따라 변하는 발광 노드(vec3)  o.rim : 청색 림 세기
 *  o.double : 양면(껍데기)           o.interior : 뒷면(안쪽 벽) 밝기 배수
 */
export function mechMat(o = {}) {
  const { color = PALETTE.steel, metal = 0.85, rough = 0.38, cut = null, emissive = null, emissiveNode = null, rim = 0.3, instanced = false, interior = 0.75, alpha = 1.0, transparent = false } = o;
  const tr = transparent || alpha < 1.0;
  const m = new THREE.MeshBasicNodeMaterial({ side: (o.double ?? !!cut) ? THREE.DoubleSide : THREE.FrontSide, transparent: tr, depthWrite: !tr });
  m.colorNode = Fn(() => {
    const nRaw = normalize(normalWorld), V = normalize(cameraPosition.sub(positionWorld));
    const n = nRaw;                                                                      // 양면 재질의 법선은 three 가 이미 면 방향에 맞춰 뒤집어 준다(프레임버퍼 쪽 확인 필요 시 frontFacing 사용)
    const alb = instanced ? instanceColor.mul(vec3(color[0], color[1], color[2])) : vec3(color[0], color[1], color[2]);
    let col = shade(n, V, alb, { metal, rough, ambient: o.ambient ?? 0.32 });
    col = col.add(alb.mul(0.07));
    col = col.add(vec3(0.15, 0.55, 1.0).mul(pow(float(1.0).sub(clamp(dot(n, V), 0.0, 1.0)), 3.0)).mul(rim));
    col = mix(col.mul(interior), col, frontFacing.select(1.0, 0.0));
    if (emissive) col = col.add(vec3(emissive[0], emissive[1], emissive[2]));
    if (emissiveNode) col = col.add(emissiveNode);
    return vec4(col, alpha);
  })();
  if (cut) m.maskNode = positionWorld.z.lessThan(cut.uZ).or(cut.uOn.lessThan(0.5));
  return m;
}

/** 단면 해칭 재질: 사선 줄무늬 + 은은한 푸른 빛. 절단면 다각형(평면)에 쓴다. */
export function hatchMat(tint = [0.72, 0.8, 0.9], spacing = 0.12) {
  const m = new THREE.MeshBasicNodeMaterial({ side: THREE.DoubleSide });
  m.colorNode = Fn(() => {
    const p = positionGeometry, d = p.x.add(p.y).div(spacing), line = smoothstep(0.42, 0.5, abs(fract(d).sub(0.5)));
    const base = vec3(tint[0], tint[1], tint[2]);
    return vec4(base.mul(line.mul(0.55).add(0.28)).add(vec3(0.05, 0.12, 0.2)), 1.0);
  })();
  return m;
}

/**
 * 회전체(압력용기·케이싱·원통) — 바깥 곡선 + 안쪽 곡선(같은 순서, 아래→위) + 절단면 해칭.
 *  outer/inner : [[반지름, y], …]
 *  절단면 해칭 메시는 userData.section = true 로 표시해 두어, 기계 코드가 컷이 "축을 지나는 평면(깊이 0)"일 때만 보이게 한다.
 */
export function latheSolid(outer, inner, o = {}) {
  const g = new THREE.Group(), seg = o.seg ?? 72;
  const mat = o.mat ?? mechMat({ cut: o.cut });
  const to2 = (pts) => pts.map(([r, y]) => new THREE.Vector2(Math.max(r, 0.0001), y));
  g.add(new THREE.Mesh(new THREE.LatheGeometry(to2(outer), seg), mat));
  if (inner) g.add(new THREE.Mesh(new THREE.LatheGeometry(to2(inner), seg), mat));
  if (inner && !o.noSection) {
    const hm = hatchMat(o.hatch ?? [0.72, 0.8, 0.9]);
    const poly = [...outer, ...inner.slice().reverse()];
    for (const sgn of [1, -1]) {
      const shape = new THREE.Shape(poly.map(([r, y]) => new THREE.Vector2(sgn * r, y)));
      const mesh = new THREE.Mesh(new THREE.ShapeGeometry(shape), hm); mesh.userData.section = true; g.add(mesh);
    }
  }
  return g;
}

/** 원주 방향 스터드 볼트 + 너트 (n 개, 반지름 R, 바닥 높이 y0, 볼트 지름 d, 높이 h) */
export function boltRing(n, R, y0, d, h, mat, nutScale = 1.7) {
  const g = new THREE.Group();
  const stud = new THREE.InstancedMesh(new THREE.CylinderGeometry(d / 2, d / 2, h, 10), mat, n);
  const nut = new THREE.InstancedMesh(new THREE.CylinderGeometry(d * nutScale / 2, d * nutScale / 2, d * 0.9, 6), mat, n);
  const m4 = new THREE.Matrix4();
  for (let i = 0; i < n; i++) {
    const a = i / n * TAU;
    m4.makeTranslation(Math.cos(a) * R, y0 + h / 2, Math.sin(a) * R); stud.setMatrixAt(i, m4);
    m4.makeTranslation(Math.cos(a) * R, y0 + h - d * 0.2, Math.sin(a) * R); nut.setMatrixAt(i, m4);
  }
  stud.frustumCulled = nut.frustumCulled = false; g.add(stud, nut); return g;
}

/** 관(파이프): 경로 점들을 지나는 매끈한 튜브 + 양 끝 플랜지. userData.curve 로 경로를 돌려준다. */
export function pipe(points, radius, mat, o = {}) {
  const curve = new THREE.CatmullRomCurve3(points.map((p) => new THREE.Vector3(...p)), false, 'centripetal');
  const g = new THREE.Group();
  g.add(new THREE.Mesh(new THREE.TubeGeometry(curve, o.seg ?? 48, radius, o.radial ?? 20, false), mat));
  if (o.flanges !== false) for (const u of [0, 1]) {
    const p = curve.getPointAt(u), t = curve.getTangentAt(u);
    const fl = new THREE.Mesh(new THREE.CylinderGeometry(radius * 1.35, radius * 1.35, radius * 0.28, 24), mat);
    fl.position.copy(p); fl.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), t); g.add(fl);
  }
  g.userData.curve = curve;
  return g;
}

/** 청사진풍 치수선: 두 점 + 양 끝 눈금 (가산 청록선) */
export function dimLine(a, b, tick = 0.25, color = 0x62d8ff) {
  const A = new THREE.Vector3(...a), B = new THREE.Vector3(...b), d = B.clone().sub(A).normalize();
  const side = new THREE.Vector3(0, 0, 1).cross(d).normalize().multiplyScalar(tick);
  const pts = [A, B, A.clone().add(side), A.clone().sub(side), B.clone().add(side), B.clone().sub(side)];
  const geo = new THREE.BufferGeometry().setFromPoints(pts); geo.setIndex([0, 1, 2, 3, 4, 5]);
  const l = new THREE.LineSegments(geo, new THREE.LineBasicNodeMaterial({ color, transparent: true, opacity: 0.85, blending: THREE.AdditiveBlending, depthWrite: false }));
  l.renderOrder = 6; return l;
}

/** 어두운 바닥 + 청사진 격자 (기계 무대용) */
export function stageFloor(radius = 60, y = 0, spacing = 1.0) {
  const m = new THREE.MeshBasicNodeMaterial({ transparent: true, depthWrite: false });
  m.colorNode = Fn(() => {
    const p = positionGeometry, r = length(p.xy), fade = smoothstep(radius, radius * 0.15, r);
    const gx = abs(fract(p.x.div(spacing)).sub(0.5)), gy = abs(fract(p.y.div(spacing)).sub(0.5));
    const line = smoothstep(0.47, 0.5, max(gx, gy)), major = smoothstep(0.495, 0.5, max(abs(fract(p.x.div(spacing * 5.0)).sub(0.5)), abs(fract(p.y.div(spacing * 5.0)).sub(0.5))));
    const col = vec3(0.01, 0.018, 0.03).add(vec3(0.1, 0.4, 0.7).mul(line.mul(0.12).add(major.mul(0.22))));
    return vec4(col.mul(fade), fade.mul(0.95));
  })();
  const mesh = new THREE.Mesh(new THREE.CircleGeometry(radius, 72), m); mesh.rotation.x = -Math.PI / 2; mesh.position.y = y; mesh.renderOrder = -1;
  return mesh;
}

export const rng = (seed) => { let a = seed >>> 0; return () => { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; };

/** 기계 뒤쪽의 큰 배경막: 어두운 청록 방사 그라디언트(금속 실루엣이 배경과 분리되어 보이게). 카메라는 +z 쪽에서 본다. */
export function stageBackdrop(w = 120, h = 70, z = -22, y = 8) {
  const m = new THREE.MeshBasicNodeMaterial({ depthWrite: false });
  m.colorNode = Fn(() => {
    const p = uv().sub(0.5), r = length(p.mul(vec2(1.0, 1.6))), g = exp(r.mul(r).mul(-7.0));
    const grid = smoothstep(0.47, 0.5, max(abs(fract(uv().x.mul(w / 4.0)).sub(0.5)), abs(fract(uv().y.mul(h / 4.0)).sub(0.5))));
    return vec4(vec3(0.015, 0.05, 0.1).mul(g.mul(1.6).add(0.15)).add(vec3(0.05, 0.25, 0.45).mul(grid).mul(0.07).mul(g)), 1.0);
  })();
  const mesh = new THREE.Mesh(new THREE.PlaneGeometry(w, h), m); mesh.position.set(0, y, z); mesh.renderOrder = -5;
  return mesh;
}
