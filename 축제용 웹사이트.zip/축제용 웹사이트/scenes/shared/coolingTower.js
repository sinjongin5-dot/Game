// scenes/shared/coolingTower.js — 냉각탑(쌍곡면 쉘) + 수증기 기둥
//
//  Ch.6 배경, Ch.7(수증기 ≠ 연기 비교)·피날레(수증기가 위로 올라가며 우주로)에서 재사용한다.
//  수증기는 "물이 증발했다 응결한 것"이다 — 원전 냉각탑에서 나오는 흰 구름은 연기가 아니라 수증기(물).
//  구성: 홀로그램 유리 쉘(LatheGeometry, 쌍곡면 단면) + 위로 올라가며 퍼지고 옅어지는 흰 입자 기둥(상태 없는 셰이더 입자)

import * as THREE from 'three/webgpu';
import {
  Fn, float, vec3, vec4, uniform, uv, instanceIndex, hash, normalWorld, positionWorld, cameraPosition, normalize, dot, pow, abs, mix,
  smoothstep, length, fract, sin, varying, mx_noise_float, clamp,
} from 'three/tsl';

export function makeCoolingTower(ctx, { radiusBase = 14, radiusThroat = 9, radiusTop = 10.5, height = 46, plume = 7000, plumeHeight = 120 } = {}) {
  const root = new THREE.Group();
  const t = ctx.u.time;
  const uPlume = uniform(1.0), uShell = uniform(1.0);

  // 쌍곡면 단면(아래가 넓고 3/4 높이가 가장 좁음)
  const pts = [];
  for (let i = 0; i <= 40; i++) {
    const y = (i / 40) * height, k = (y - height * 0.72) / (height * 0.5);
    const r = Math.sqrt(radiusThroat * radiusThroat + (radiusBase * radiusBase - radiusThroat * radiusThroat) * Math.min(1, k * k * 1.3) + (y > height * 0.72 ? (radiusTop * radiusTop - radiusThroat * radiusThroat) * (k * k) : 0));
    pts.push(new THREE.Vector2(r, y));
  }
  const shellMat = new THREE.MeshBasicNodeMaterial({ transparent: true, depthWrite: false, side: THREE.DoubleSide });
  shellMat.colorNode = Fn(() => {
    const nW = normalize(normalWorld), V = normalize(cameraPosition.sub(positionWorld));
    const f = pow(float(1.0).sub(abs(dot(nW, V))), 2.0);
    const bands = sin(positionWorld.y.mul(0.9)).mul(0.5).add(0.5);                          // 가로 이음선
    return vec4(vec3(0.5, 0.75, 1.0).mul(f.mul(0.5).add(bands.mul(0.05)).add(0.06)), f.mul(0.5).add(0.09).mul(uShell));
  })();
  const shell = new THREE.Mesh(new THREE.LatheGeometry(pts, 64), shellMat);
  shell.renderOrder = 4;
  root.add(shell);

  // 수증기 기둥: 위로 올라가며 퍼지고 옅어진다(노이즈로 일렁임)
  const pm = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false });
  {
    const i = instanceIndex;
    const h = (k) => hash(i.add(k));
    const s = fract(h(0).add(t.mul(0.045).mul(h(1).mul(0.5).add(0.75))));                // 0(탑 상단) → 1(높은 하늘)
    const a = h(2).mul(6.2831853), rr = pow(h(3), 0.5).mul(radiusTop * 0.85).mul(float(1.0).add(s.mul(1.6)));
    const drift = vec3(mx_noise_float(vec3(s.mul(3.0), t.mul(0.1), h(4).mul(5.0))), 0.0, mx_noise_float(vec3(s.mul(3.0).add(4.0), t.mul(0.1), h(5).mul(5.0)))).mul(s.mul(26.0));
    pm.positionNode = vec3(rr.mul(sin(a.add(1.5708))), s.mul(plumeHeight).add(height), rr.mul(sin(a))).add(drift);
    pm.scaleNode = float(5.0).add(s.mul(22.0)).mul(h(6).mul(0.6).add(0.7));
    pm.colorNode = varying(vec3(0.92, 0.95, 1.0).mul(float(1.0).sub(s).pow(1.2)).mul(uPlume), `vPlume${plume}`);
    pm.opacityNode = smoothstep(0.5, 0.0, length(uv().sub(0.5))).pow(1.1).mul(0.16);
  }
  const plumeSprite = new THREE.Sprite(pm);
  plumeSprite.count = plume; plumeSprite.frustumCulled = false; plumeSprite.renderOrder = 8;
  root.add(plumeSprite);

  return { root, shell, plume: plumeSprite, uPlume, uShell, height, setCount(n) { plumeSprite.count = Math.max(500, Math.min(plume, n | 0)); } };
}
