// scenes/shared/powerplants.js — Ch.7 황혼의 발전소 2곳: 석탄 화력(검은 연기 + CO₂ 분자) vs 원전(냉각탑의 흰 수증기)
//
//  1 유닛 = 1 m. 왼쪽(−x)이 석탄 화력, 오른쪽(+x)이 원전. 수평선 뒤에서 저무는 노을이 설비 윤곽을 비춘다(실루엣 + 불 켜진 창).
//  · 석탄 화력: 보일러동·터빈동·굴뚝 2개·석탄 더미. 굴뚝에서 짙은 연기 기둥(상태 없는 셰이더 입자)과 CO₂ 분자(탄소 1 + 산소 2, 붉은 빛)가 올라간다.
//  · 원전: 격납건물(원통 + 돔)·터빈동·쌍곡면 냉각탑 2기. 냉각탑에서 나오는 흰 구름은 연기가 아니라 "물이 증발했다 응결한 수증기".
//  ※ 연출용 모형이다 — 실제 설비의 배치·크기와 다르다.

import * as THREE from 'three/webgpu';
import {
  Fn, float, vec3, vec4, uniform, uv, instanceIndex, hash, normalWorld, normalGeometry, positionWorld, positionGeometry, positionLocal, cameraPosition,
  normalize, length, dot, mix, smoothstep, clamp, pow, exp, sin, cos, abs, fract, floor, step, varying, max, mx_noise_float, attribute,
} from 'three/tsl';
import { makeCoolingTower } from './coolingTower.js';
import { rng } from './studio.js';

export const COAL_X = -125, NUKE_X = 105;
const CHIM = [new THREE.Vector3(-98, 0, -26), new THREE.Vector3(-146, 0, -30)];       // 굴뚝 바닥
const CHIM_H = 130;
const TAU = Math.PI * 2;

/** 건물 재질: 노을 림라이트 + 어두운 정면 + 창문(켜진 창) */
function buildingMat({ base, win = 0.4, winColor = new THREE.Color(1.0, 0.78, 0.45), cell = [3.2, 4.2], rimGain = 1.0 }) {
  const m = new THREE.MeshBasicNodeMaterial();
  m.colorNode = Fn(() => {
    const n = normalize(normalWorld);
    const rim = pow(clamp(dot(n, normalize(vec3(-0.25, 0.25, -0.93))), 0.0, 1.0), 1.6);
    const top = clamp(n.y, 0.0, 1.0);
    const amb = vec3(0.035, 0.05, 0.085).add(vec3(0.07, 0.08, 0.12).mul(top));
    let col = vec3(base.r, base.g, base.b).mul(amb.mul(1.5).add(vec3(1.0, 0.5, 0.22).mul(rim).mul(1.25 * rimGain)));
    // 창문: 면의 가로축(x 또는 z)·높이(y)로 격자, 칸마다 켜짐 여부는 해시
    const ng = normalGeometry, p = positionGeometry;
    const horiz = mix(p.x, p.z, step(0.5, abs(ng.x)));
    const gx = horiz.div(cell[0]), gy = p.y.div(cell[1]);
    const cid = floor(gx).add(floor(gy).mul(57.0));
    const inCell = smoothstep(0.18, 0.28, fract(gx)).mul(smoothstep(0.82, 0.72, fract(gx))).mul(smoothstep(0.22, 0.32, fract(gy))).mul(smoothstep(0.78, 0.68, fract(gy)));
    const on = step(float(1.0).sub(win), hash(cid.add(11.0)));
    const sideFace = float(1.0).sub(abs(ng.y));
    col = col.add(vec3(winColor.r, winColor.g, winColor.b).mul(inCell).mul(on).mul(sideFace).mul(1.5));
    return vec4(col, 1.0);
  })();
  return m;
}

/** 쌍곡면 냉각탑 불투명 쉘 (coolingTower.js 와 같은 단면) */
function solidTowerShell({ radiusBase = 14, radiusThroat = 9, radiusTop = 10.5, height = 46 }, scale) {
  const pts = [];
  for (let i = 0; i <= 40; i++) {
    const y = (i / 40) * height, k = (y - height * 0.72) / (height * 0.5);
    const r = Math.sqrt(radiusThroat * radiusThroat + (radiusBase * radiusBase - radiusThroat * radiusThroat) * Math.min(1, k * k * 1.3) + (y > height * 0.72 ? (radiusTop * radiusTop - radiusThroat * radiusThroat) * (k * k) : 0));
    pts.push(new THREE.Vector2(r * scale, y * scale));
  }
  const mesh = new THREE.Mesh(new THREE.LatheGeometry(pts, 56), buildingMat({ base: new THREE.Color(0.55, 0.56, 0.6), win: 0.0, rimGain: 1.3 }));
  return mesh;
}

export function makePowerplants(ctx) {
  const group = new THREE.Group();
  const t = ctx.u.time;
  const uSmoke = uniform(1.0), uVapor = uniform(1.0), uCO2 = uniform(1.0);

  // ── 하늘 돔: 수평선 노을 + 위로 갈수록 남색 ──
  const skyMat = new THREE.MeshBasicNodeMaterial({ side: THREE.BackSide, depthWrite: false });
  skyMat.colorNode = Fn(() => {
    const d = normalize(positionLocal);
    const h = d.y;
    const glowDir = pow(max(dot(d, normalize(vec3(-0.12, 0.0, -1.0))), 0.0), 3.0);
    const band = exp(pow(h.sub(0.02).div(0.16), 2.0).negate());
    const zen = mix(vec3(0.07, 0.05, 0.16), vec3(0.008, 0.016, 0.05), smoothstep(0.0, 0.7, h));
    const horizon = mix(vec3(0.35, 0.14, 0.2), vec3(1.0, 0.45, 0.16), glowDir).mul(band).mul(mix(0.4, 1.0, glowDir));
    const below = smoothstep(0.0, -0.05, h);
    return vec4(zen.add(horizon).mul(float(1.0).sub(below.mul(0.9))), 1.0);
  })();
  const sky = new THREE.Mesh(new THREE.SphereGeometry(2900, 48, 24), skyMat); sky.renderOrder = -20; sky.frustumCulled = false;
  group.add(sky);
  // 지면: 어두운 평면 + 멀수록 안개(노을색)
  const gMat = new THREE.MeshBasicNodeMaterial();
  gMat.colorNode = Fn(() => {
    const q = positionWorld.sub(cameraPosition), d = length(q.xz), v = normalize(q);
    const fog = smoothstep(150.0, 2600.0, d);
    const hv = exp(pow(v.y.div(0.1), 2.0).negate());
    return vec4(mix(vec3(0.008, 0.011, 0.018), vec3(0.2, 0.09, 0.09), fog.mul(0.9)).add(vec3(0.5, 0.22, 0.1).mul(hv).mul(0.15)), 1.0);
  })();
  const ground = new THREE.Mesh(new THREE.CircleGeometry(2800, 64), gMat); ground.rotation.x = -Math.PI / 2; ground.position.y = -0.2;
  group.add(ground);

  // ── 석탄 화력 ──
  const dark = new THREE.Color(0.5, 0.5, 0.52);
  const boiler = new THREE.Mesh(new THREE.BoxGeometry(52, 48, 38), buildingMat({ base: dark, win: 0.25, cell: [4.5, 5.5] })); boiler.position.set(COAL_X, 24, -2);
  const turbine = new THREE.Mesh(new THREE.BoxGeometry(70, 22, 28), buildingMat({ base: dark, win: 0.5 })); turbine.position.set(COAL_X, 11, 36);
  const annex = new THREE.Mesh(new THREE.BoxGeometry(22, 30, 22), buildingMat({ base: dark, win: 0.3 })); annex.position.set(COAL_X + 38, 15, -2);
  group.add(boiler, turbine, annex);
  const chimMat = buildingMat({ base: new THREE.Color(0.55, 0.52, 0.5), win: 0.0, rimGain: 1.2 });
  for (const c of CHIM) {
    const ch = new THREE.Mesh(new THREE.CylinderGeometry(3.6, 6.2, CHIM_H, 20, 1, false), chimMat); ch.position.set(c.x, CHIM_H / 2, c.z); group.add(ch);
    const beacon = new THREE.Mesh(new THREE.SphereGeometry(0.9, 8, 6), new THREE.MeshBasicNodeMaterial({ color: 0xff3a2a })); beacon.position.set(c.x, CHIM_H + 0.6, c.z); group.add(beacon);
  }
  const pile = new THREE.Mesh(new THREE.ConeGeometry(22, 14, 28), buildingMat({ base: new THREE.Color(0.12, 0.12, 0.13), win: 0.0 })); pile.position.set(COAL_X - 52, 7, 42); group.add(pile);
  const conv = new THREE.Mesh(new THREE.BoxGeometry(46, 1.6, 2.4), buildingMat({ base: dark, win: 0.0 })); conv.position.set(COAL_X - 30, 12, 24); conv.rotation.z = 0.35; group.add(conv);

  // 연기: 두 굴뚝에서 바람(+x)에 실려 위로 퍼지는 짙은 기둥
  const NS = 8000;
  const sm = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false });
  const plumePath = (i, k0) => {
    const h = (k) => hash(i.add(k0 + k));
    const which = step(0.5, h(0));
    const bx = mix(float(CHIM[0].x), float(CHIM[1].x), which), bz = mix(float(CHIM[0].z), float(CHIM[1].z), which);
    const s = fract(h(1).add(t.mul(0.035).mul(h(2).mul(0.5).add(0.75))));                   // 0(굴뚝 입구) → 1(하늘 높이)
    const a = h(3).mul(TAU), rr = pow(h(4), 0.5).mul(float(3.0).add(pow(s, 0.8).mul(62.0)));
    const turb = vec3(mx_noise_float(vec3(s.mul(3.0), t.mul(0.12), h(5).mul(5.0))), mx_noise_float(vec3(s.mul(3.0).add(4.0), t.mul(0.1), h(6).mul(5.0))).mul(0.5), mx_noise_float(vec3(s.mul(3.0).add(9.0), t.mul(0.1), h(7).mul(5.0)))).mul(s.mul(34.0));
    const pos = vec3(bx.add(rr.mul(cos(a))).add(pow(s, 1.3).mul(150.0)), float(CHIM_H).add(s.mul(125.0)).add(rr.mul(sin(a)).mul(0.55)), bz.add(rr.mul(sin(a)))).add(turb);
    return { pos, s, h };
  };
  {
    const { pos, s, h } = plumePath(instanceIndex, 100);
    sm.positionNode = pos;
    sm.scaleNode = float(9.0).add(s.mul(46.0)).mul(h(8).mul(0.6).add(0.7));
    const lit = pow(float(1.0).sub(s), 0.5).mul(0.5).add(0.5);
    sm.colorNode = varying(vec3(0.03, 0.027, 0.03).mul(h(9).mul(2.4).add(0.5)).mul(lit).add(vec3(0.5, 0.22, 0.1).mul(0.07).mul(float(1.0).sub(s)).mul(h(10))).mul(uSmoke), 'vSmoke');
    sm.opacityNode = smoothstep(0.5, 0.0, length(uv().sub(0.5))).pow(1.0).mul(smoothstep(0.0, 0.06, s)).mul(float(1.0).sub(smoothstep(0.75, 1.0, s)).mul(0.5).add(0.5)).mul(h(11).mul(0.5).add(0.6)).mul(uSmoke);
  }
  const smoke = new THREE.Sprite(sm); smoke.count = NS; smoke.frustumCulled = false; smoke.renderOrder = 7; group.add(smoke);

  // CO₂ 분자 (O=C=O): 탄소(회색) + 산소 2개(붉은 빛). 연기 속에서 천천히 돌며 올라간다.
  const molGeo = (() => {
    const g = []; const s = new THREE.SphereGeometry(1, 10, 8);
    const a = s.clone().scale(0.9, 0.9, 0.9), o1 = s.clone().scale(1.0, 1.0, 1.0).translate(2.2, 0, 0), o2 = s.clone().scale(1.0, 1.0, 1.0).translate(-2.2, 0, 0);
    const col = (geo, r, gC, b) => { const n = geo.attributes.position.count, arr = new Float32Array(n * 3); for (let i = 0; i < n; i++) { arr[i * 3] = r; arr[i * 3 + 1] = gC; arr[i * 3 + 2] = b; } geo.setAttribute('color', new THREE.BufferAttribute(arr, 3)); return geo; };
    g.push(col(a, 0.35, 0.36, 0.4), col(o1, 1.0, 0.18, 0.1), col(o2, 1.0, 0.18, 0.1));
    return g;
  })();
  const NM = 110;
  const molMat = new THREE.MeshBasicNodeMaterial({ transparent: true });
  {
    const i = instanceIndex, h = (k) => hash(i.add(500 + k));
    const which = step(0.5, h(0));
    const bx = mix(float(CHIM[0].x), float(CHIM[1].x), which), bz = mix(float(CHIM[0].z), float(CHIM[1].z), which);
    const s = fract(h(1).add(t.mul(0.03)));
    const a = h(3).mul(TAU), rr = pow(h(4), 0.5).mul(float(2.0).add(pow(s, 0.8).mul(45.0)));
    const center = vec3(bx.add(rr.mul(cos(a))).add(pow(s, 1.3).mul(145.0)), float(CHIM_H + 6.0).add(s.mul(115.0)), bz.add(rr.mul(sin(a))));
    // 분자 자체 회전: 임의 축(z) 기준 + 약간 기울임
    const ang = t.mul(h(5).mul(1.2).add(0.4)).add(h(6).mul(TAU)), ca = cos(ang), sa = sin(ang);
    const lp = positionLocal.mul(float(0.8).add(s.mul(0.9)));
    molMat.positionNode = center.add(vec3(lp.x.mul(ca).sub(lp.y.mul(sa)), lp.x.mul(sa).add(lp.y.mul(ca)), lp.z));
    molMat.colorNode = Fn(() => {
      const c = vertexColorOf();
      const nW = normalize(normalWorld), V = normalize(cameraPosition.sub(positionWorld));
      const lam = clamp(dot(nW, normalize(vec3(-0.3, 0.6, 0.7))), 0.0, 1.0);
      return vec4(c.mul(lam.mul(0.8).add(0.6)).mul(float(1.0).add(0.8)).mul(uCO2), uCO2.mul(smoothstep(0.0, 0.05, s)).mul(float(1.0).sub(smoothstep(0.85, 1.0, s))));
    })();
  }
  const molecules = [];
  for (const g of molGeo) { const im = new THREE.InstancedMesh(g, molMat, NM); const m4 = new THREE.Matrix4(); for (let i = 0; i < NM; i++) im.setMatrixAt(i, m4.identity()); im.frustumCulled = false; im.renderOrder = 8; group.add(im); molecules.push(im); }

  // ── 원전 ──
  const conc = new THREE.Color(0.62, 0.64, 0.68);
  const contain = new THREE.Mesh(new THREE.CylinderGeometry(18, 18, 42, 40, 1, false), buildingMat({ base: conc, win: 0.0, rimGain: 1.3 })); contain.position.set(NUKE_X, 21, 0);
  const dome = new THREE.Mesh(new THREE.SphereGeometry(18, 40, 20, 0, TAU, 0, Math.PI / 2), buildingMat({ base: conc, win: 0.0, rimGain: 1.4 })); dome.position.set(NUKE_X, 42, 0);
  const turbH = new THREE.Mesh(new THREE.BoxGeometry(62, 24, 30), buildingMat({ base: conc, win: 0.55, cell: [3.2, 4.0] })); turbH.position.set(NUKE_X + 46, 12, 4);
  const aux = new THREE.Mesh(new THREE.BoxGeometry(24, 30, 22), buildingMat({ base: conc, win: 0.35 })); aux.position.set(NUKE_X - 4, 15, 30);
  group.add(contain, dome, turbH, aux);
  const towers = [];
  for (const [x, z] of [[NUKE_X + 12, -76], [NUKE_X + 78, -84]]) {
    const tw = makeCoolingTower(ctx, { radiusBase: 14, radiusThroat: 9, radiusTop: 10.5, height: 46, plume: 5000, plumeHeight: 150 });
    tw.root.scale.setScalar(1.5); tw.root.position.set(x, 0, z); tw.uShell.value = 0.0;
    const shell = solidTowerShell({}, 1.5); shell.position.set(x, 0, z);
    group.add(tw.root, shell); towers.push(tw);
  }
  // 약한 아래 조명: 원전 부지의 따뜻한 가로등 불빛 웅덩이
  const poolMat = new THREE.MeshBasicNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
  poolMat.colorNode = Fn(() => { const r = length(uv().sub(0.5)).mul(2.0); return vec4(vec3(1.0, 0.7, 0.4).mul(exp(r.mul(-4.0))).mul(smoothstep(1.0, 0.6, r)).mul(0.35), 1.0); })();
  for (const [x, z, s] of [[COAL_X, 30, 150], [NUKE_X + 20, 20, 150]]) { const p = new THREE.Mesh(new THREE.PlaneGeometry(s, s), poolMat); p.rotation.x = -Math.PI / 2; p.position.set(x, 0.3, z); group.add(p); }

  return {
    group, towers, smoke, molecules, uSmoke, uVapor, uCO2, sky,
    setCount(frac) { smoke.count = Math.max(1500, Math.floor(NS * frac)); for (const tw of towers) tw.setCount(5000 * frac); },
  };
}

// 인스턴스 메시의 정점 색 속성 'color' 읽기
const vertexColorOf = () => attribute('color', 'vec3');
