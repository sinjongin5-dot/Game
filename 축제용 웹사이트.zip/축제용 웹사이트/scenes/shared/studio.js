// scenes/shared/studio.js — 스튜디오 조명 셰이딩 (Ch.5 매크로 촬영용)
//
//  PBR 풍의 가벼운 근사: 키라이트(따뜻한 상단 좌측) + 필라이트(차가운 우측) + 프레넬 반사 + 절차적 스튜디오 환경(소프트박스·스트립 라이트·수평선 띠).
//  외부 HDR 이미지 없이(오프라인) 금속·세라믹 표면에 "촬영장 조명이 비치는" 느낌을 낸다.
//  사용: shade(normalWorld 정규화, 시선방향V, 알베도 vec3, {metal, rough}) → 색 vec3 (HDR)

import { vec3, float, normalize, dot, clamp, pow, mix, exp, smoothstep, reflect } from 'three/tsl';

/** 반사 방향 R 이 바라보는 스튜디오 환경의 색 */
export const envColor = (R) => {
  const up = R.y.mul(0.5).add(0.5);
  const sky = mix(vec3(0.02, 0.025, 0.045), vec3(0.28, 0.45, 0.8), pow(up, 2.0));
  const hor = vec3(1.0, 0.72, 0.45).mul(exp(pow(R.y.sub(0.08).div(0.13), 2.0).negate())).mul(0.9);
  const box = vec3(1.0, 1.0, 1.0).mul(smoothstep(0.86, 0.95, dot(R, normalize(vec3(-0.35, 0.75, 0.55))))).mul(3.2);
  const strip = vec3(0.65, 0.88, 1.0).mul(smoothstep(0.93, 0.985, dot(R, normalize(vec3(0.9, 0.2, 0.35))))).mul(2.2);
  return sky.add(hor).add(box).add(strip);
};

export const shade = (n, V, albedo, { metal = 0.0, rough = 0.4, ambient = 0.07 } = {}) => {
  const L1 = normalize(vec3(-0.45, 0.8, 0.55)), L2 = normalize(vec3(0.8, 0.25, 0.35));
  const lam1 = clamp(dot(n, L1), 0.0, 1.0), lam2 = clamp(dot(n, L2), 0.0, 1.0);
  const diff = albedo.mul(vec3(1.0, 0.93, 0.82).mul(lam1).mul(1.2).add(vec3(0.4, 0.6, 1.0).mul(lam2).mul(0.35)).add(ambient));
  const R = reflect(V.negate(), n);
  const fres = pow(float(1.0).sub(clamp(dot(n, V), 0.0, 1.0)), 5.0);
  const F0 = mix(vec3(0.04, 0.04, 0.04), albedo, metal);
  const F = F0.add(vec3(1.0, 1.0, 1.0).sub(F0).mul(fres));
  const spec = envColor(R).mul(F).mul(mix(1.0, 0.45, rough));
  const H = normalize(L1.add(V));
  const hl = pow(clamp(dot(n, H), 0.0, 1.0), mix(220.0, 30.0, rough)).mul(mix(1.6, 0.5, rough));
  return diff.mul(float(1.0).sub(metal)).add(spec).add(vec3(1.0, 0.95, 0.85).mul(hl));
};

/** 결정적 난수 */
export function rng(seed) { let a = seed >>> 0; return () => { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
