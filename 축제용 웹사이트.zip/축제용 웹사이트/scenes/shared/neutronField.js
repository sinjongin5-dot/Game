// scenes/shared/neutronField.js — Ch.3 중성자 군집: GPU 컴퓨트(WebGPU) / transform feedback(WebGL2 폴백) 겸용
//
//  각 중성자는 "자기 상태(위치·속도·생존도) + 해석적 격자 함수"만 참조한다 (이웃 참조·atomics 없음 → 폴백에서도 동일 코드로 동작).
//   · 집단 크기: 슬롯 우선순위 h(고정 난수) ≤ uFrac 인 슬롯만 활성. uFrac 이 지수적으로 커지면 연쇄 반응(k>1), 줄어들면 반응 억제.
//     새로 활성화되는 슬롯은 "핵분열이 일어나는 연료봉 위치"(퍼지는 반경 uSpread 안)에서 빠른 중성자로 태어난다 → 불꽃이 번지는 모양.
//   · 감속재: 연료봉 밖(물)에 있으면 확률적으로 산란 — 방향이 바뀌고 속도가 줄어든다(빨강 → 파랑).
//   · 제어봉: 삽입된 제어봉(uRod)에 가까우면 끌려 들어가며 흡수되어 사라진다.
//  중성자 색 = 속도: 빠름(≈3.6)=빨강, 느림(≈0.9)=파랑  (config.js colors.neutronFast / neutronSlow)
//  ※ 개념도: 실제 원자로는 지발중성자 등으로 이렇게 폭주하지 않도록 설계된다(자막에 모식도 표기).

import * as THREE from 'three/webgpu';
import {
  Fn, instancedArray, instanceIndex, vec3, vec4, float, uniform, hash, uint, normalize, length, mix, smoothstep, step, max, min, abs, round,
  sqrt, cos, sin, If, select, clamp, uv,
} from 'three/tsl';
import { sphereDir } from '../../engine/tsl.js';

export const PITCH = 2.8;          // 연료봉 간격
export const HALF = 3;             // 격자 -3..3 (7×7)
export const ROD_H = 12;           // 막대 길이

export function makeNeutronField(renderer, N) {
  const pos = instancedArray(N, 'vec4');       // xyz 위치, w 생존도(0~1)
  const vel = instancedArray(N, 'vec3');
  const u = {
    dt: uniform(0.016), frame: uniform(0.0), frac: uniform(0.0), spread: uniform(2.0), rod: uniform(0.0),
    fast: uniform(3.6), slow: uniform(0.9), bright: uniform(1.0), size: uniform(0.075),
  };
  const id = instanceIndex;
  const rnd = (k) => hash(id.add(uint(u.frame).mul(1103).add(k)));

  // ── 초기화: 모두 비활성 ──
  const initNode = Fn(() => {
    const P = pos.element(id), Vv = vel.element(id);
    P.assign(vec4(0.0, 0.0, 0.0, 0.0)); Vv.assign(vec3(0.0, 0.0, 0.0));
  })().compute(N);

  // ── 갱신 ──
  const updateNode = Fn(() => {
    const P = pos.element(id), Vv = vel.element(id);
    const p = P.xyz.toVar(), alive = P.w.toVar(), v = Vv.toVar();
    const want = step(hash(id), u.frac);                                       // 이 슬롯이 활성이어야 하는가

    // 탄생: 비활성이었다가 활성이 되는 순간 → 퍼지는 반경 안의 연료봉 위치에서 빠른 중성자로
    If(alive.lessThan(0.04).and(want.greaterThan(0.5)), () => {
      const rs = sqrt(rnd(1)).mul(u.spread), th = rnd(2).mul(6.2831853);
      const gx = round(rs.mul(cos(th)).div(PITCH)).clamp(-HALF, HALF).toVar();
      const gz = round(rs.mul(sin(th)).div(PITCH)).clamp(-HALF, HALF).toVar();
      const ctrl = abs(gx.sub(round(gx.mul(0.5)).mul(2.0))).lessThan(0.1).and(abs(gz.sub(round(gz.mul(0.5)).mul(2.0))).lessThan(0.1));
      If(ctrl, () => { gx.addAssign(1.0); });                                    // 제어봉 자리는 건너뛰어 옆 연료봉에서 시작
      p.assign(vec3(gx.mul(PITCH).add(rnd(3).sub(0.5).mul(0.5)), rnd(4).sub(0.5).mul(ROD_H - 1.0), gz.mul(PITCH).add(rnd(5).sub(0.5).mul(0.5))));
      v.assign(sphereDir(rnd(6), rnd(7)).mul(u.fast.mul(rnd(8).mul(0.3).add(0.85))));
      alive.assign(0.06);
    });
    // 생존도: 활성 슬롯은 빠르게 켜지고, 비활성 슬롯은 천천히 꺼진다 (※ 탄생 판정 "뒤에" 갱신해야 방금 죽은 슬롯만 새로 태어난다)
    const rate = want.greaterThan(0.5).select(float(12.0), float(4.0));
    alive.addAssign(want.sub(alive).mul(u.dt.mul(rate).min(1.0)));

    If(alive.greaterThan(0.03), () => {
      p.addAssign(v.mul(u.dt));
      // 경계(원자로 노심 용기) 반사
      const lim = float(HALF * PITCH + 1.4), limY = float(ROD_H * 0.5 + 0.4);
      If(abs(p.x).greaterThan(lim), () => { v.assign(vec3(v.x.negate(), v.y, v.z)); p.assign(vec3(p.x.clamp(lim.negate(), lim), p.y, p.z)); });
      If(abs(p.z).greaterThan(lim), () => { v.assign(vec3(v.x, v.y, v.z.negate())); p.assign(vec3(p.x, p.y, p.z.clamp(lim.negate(), lim))); });
      If(abs(p.y).greaterThan(limY), () => { v.assign(vec3(v.x, v.y.negate(), v.z)); p.assign(vec3(p.x, p.y.clamp(limY.negate(), limY), p.z)); });

      // 격자 좌표: 가장 가까운 막대까지 거리 d
      const gx = round(p.x.div(PITCH)), gz = round(p.z.div(PITCH));
      const dx = p.x.sub(gx.mul(PITCH)), dz = p.z.sub(gz.mul(PITCH));
      const d = sqrt(dx.mul(dx).add(dz.mul(dz)));
      const ctrl = abs(gx.sub(round(gx.mul(0.5)).mul(2.0))).lessThan(0.1).and(abs(gz.sub(round(gz.mul(0.5)).mul(2.0))).lessThan(0.1));
      const speed = length(v);

      // 감속재(물): 연료봉/제어봉 바깥에서 확률적 산란 → 방향 무작위, 속도 20% 감소(최소 slow)
      const inWater = d.greaterThan(0.62);
      If(inWater.and(rnd(11).lessThan(u.dt.mul(14.0))), () => {
        v.assign(sphereDir(rnd(12), rnd(13)).mul(max(speed.mul(0.8), u.slow)));
      });

      // 제어봉: 삽입 정도 uRod(0~1)에 따라 y 범위가 내려온다. 가까우면 끌려 들어가고, 안에 들어가면 흡수
      const yc = mix(float(ROD_H * 1.5), float(0.0), u.rod);
      const inY = abs(p.y.sub(yc)).lessThan(ROD_H * 0.5);
      const near = ctrl.and(inY).and(u.rod.greaterThan(0.02));
      If(near.and(d.lessThan(2.6)), () => {
        const dirIn = vec3(dx.negate(), 0.0, dz.negate()).div(max(d, 0.05));
        v.addAssign(dirIn.mul(u.dt.mul(14.0)));
      });
      If(near.and(d.lessThan(0.85)), () => { alive.subAssign(u.dt.mul(9.0)); v.mulAssign(0.9); });
    });

    P.assign(vec4(p, max(alive, 0.0)));
    Vv.assign(v);
  })().compute(N);

  // ── 렌더링 ──
  const pa = pos.toAttribute(), va = vel.toAttribute();
  const mat = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
  mat.positionNode = pa.xyz;
  mat.scaleNode = u.size;
  const cls = smoothstep(1.2, 3.3, length(va));                                   // 0 = 느림(파랑) … 1 = 빠름(빨강)
  mat.colorNode = mix(vec3(0.12, 0.42, 1.0), vec3(1.0, 0.18, 0.1), cls).mul(pa.w).mul(u.bright);
  mat.opacityNode = smoothstep(0.5, 0.0, length(uv().sub(0.5))).pow(1.3);
  const mesh = new THREE.Sprite(mat);
  mesh.count = N; mesh.frustumCulled = false; mesh.renderOrder = 6;

  let inited = false;
  return {
    mesh, u, N, count: N, pos, vel,
    reset() { renderer.compute(initNode); inited = true; },
    setCount(n) { n = Math.max(1000, Math.min(N, n | 0)); this.count = n; mesh.count = n; updateNode.count = n; },
    update(dt) {
      if (!inited) this.reset();
      u.dt.value = Math.min(dt, 0.05); u.frame.value += 1;
      renderer.compute(updateNode);
    },
    dispose() { mat.dispose(); mesh.removeFromParent(); },
  };
}
