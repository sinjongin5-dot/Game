// scenes/shared/lattice.js — Ch.3 노심 격자: 연료봉 40개 + 제어봉 9개 + 물(감속재) + 물 분자 H₂O(인스턴싱) + 노심 바닥판 + 노심 광구
//
//  격자: 7×7, 간격 PITCH. 짝수-짝수 좌표 9곳(−2,0,2 × −2,0,2)은 제어봉 자리, 나머지 40곳은 연료봉.
//  제어봉은 위(y=+18)에서 내려와 연료봉과 같은 높이(y=0)에 자리 잡는다 (setRod(e), e: 0=위 1=완전 삽입).
//  H₂O: 산소(빨강) 1 + 수소(흰색) 2, 결합각 104.5° — 이 각도는 물 분자의 실제 값이다 (출처: 일반화학).
//  연료봉 발광(uActivity)은 중성자 밀도에 비례하게 씬이 넣어 준다.

import * as THREE from 'three/webgpu';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import {
  Fn, float, vec2, vec3, vec4, uniform, uv, normalWorld, positionWorld, positionLocal, cameraPosition, vertexColor, instanceIndex, hash,
  normalize, length, dot, mix, smoothstep, clamp, pow, exp, sin, abs, fract, mx_noise_float,
} from 'three/tsl';
import { PITCH, HALF, ROD_H } from './neutronField.js';

const isCtrl = (i, j) => i % 2 === 0 && j % 2 === 0;

function rng(seed) { let a = seed >>> 0; return () => { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

/** 물 분자 1개의 지오메트리(정점 색 포함): 산소 빨강 + 수소 2개 흰색 */
function waterMoleculeGeometry() {
  const O = new THREE.SphereGeometry(0.15, 10, 8), H1 = new THREE.SphereGeometry(0.095, 8, 6), H2 = new THREE.SphereGeometry(0.095, 8, 6);
  const ang = (104.5 / 2) * (Math.PI / 180), bond = 0.2;
  H1.translate(Math.sin(ang) * bond, Math.cos(ang) * bond, 0); H2.translate(-Math.sin(ang) * bond, Math.cos(ang) * bond, 0);
  const paint = (g, r, gg, b) => { const n = g.attributes.position.count, c = new Float32Array(n * 3); for (let i = 0; i < n; i++) { c[i * 3] = r; c[i * 3 + 1] = gg; c[i * 3 + 2] = b; } g.setAttribute('color', new THREE.BufferAttribute(c, 3)); return g; };
  return mergeGeometries([paint(O, 1.0, 0.18, 0.16), paint(H1, 0.95, 0.97, 1.0), paint(H2, 0.95, 0.97, 1.0)]);
}

export function makeLattice(ctx) {
  const root = new THREE.Group();
  const t = ctx.u.time;
  const uActivity = uniform(0.0);       // 연료봉 발광(0~1)
  const uGlow = uniform(0.0);           // 노심 광구(Ch.4 로 이어지는 마지막 빛)
  const lim = HALF * PITCH + 1.4;

  // ── 연료봉 ──
  const fuelMat = new THREE.MeshBasicNodeMaterial();
  fuelMat.colorNode = Fn(() => {
    const nW = normalize(normalWorld), V = normalize(cameraPosition.sub(positionWorld));
    const lam = clamp(dot(nW, normalize(vec3(-0.3, 0.6, 0.7))), 0.0, 1.0).mul(0.8).add(0.2);
    const rim = pow(float(1.0).sub(clamp(dot(nW, V), 0.0, 1.0)), 2.4);
    const band = sin(positionLocal.y.mul(4.2)).mul(0.04).add(1.0);                         // 피복관 이음선
    const heat = mx_noise_float(vec3(positionWorld.x.mul(0.8), positionWorld.y.mul(0.35).add(t.mul(0.6)), positionWorld.z.mul(0.8))).mul(0.5).add(0.6);
    const base = vec3(0.17, 0.15, 0.14).mul(lam).mul(band);
    const glow = vec3(1.0, 0.42, 0.1).mul(uActivity).mul(heat).mul(rim.mul(1.7).add(0.1));
    return vec4(base.add(glow).add(vec3(0.2, 0.45, 1.0).mul(rim).mul(0.3)), 1.0);
  })();
  const fuelGeo = new THREE.CylinderGeometry(0.52, 0.52, ROD_H, 18, 1);
  const fuelPos = [];
  for (let i = -HALF; i <= HALF; i++) for (let j = -HALF; j <= HALF; j++) if (!isCtrl(i, j)) fuelPos.push([i * PITCH, j * PITCH]);
  const fuel = new THREE.InstancedMesh(fuelGeo, fuelMat, fuelPos.length);
  const m4 = new THREE.Matrix4();
  fuelPos.forEach(([x, z], k) => { m4.makeTranslation(x, 0, z); fuel.setMatrixAt(k, m4); });
  fuel.frustumCulled = false;
  root.add(fuel);

  // ── 제어봉 (붕소·카드뮴 개념: 짙은 강색 + 금색 띠) ──
  const ctrlMat = new THREE.MeshBasicNodeMaterial();
  ctrlMat.colorNode = Fn(() => {
    const nW = normalize(normalWorld), V = normalize(cameraPosition.sub(positionWorld));
    const lam = clamp(dot(nW, normalize(vec3(-0.3, 0.6, 0.7))), 0.0, 1.0).mul(0.75).add(0.25);
    const rim = pow(float(1.0).sub(clamp(dot(nW, V), 0.0, 1.0)), 2.2);
    const stripe = smoothstep(0.82, 0.9, fract(positionLocal.y.mul(0.5)));                  // 금색 띠
    const base = vec3(0.05, 0.065, 0.085).mul(lam);
    return vec4(base.add(vec3(0.9, 0.7, 0.2).mul(stripe).mul(lam).mul(0.5)).add(vec3(0.15, 0.85, 0.65).mul(rim).mul(0.55)), 1.0);
  })();
  const ctrlGroup = new THREE.Group();
  const ctrlGeo = new THREE.CylinderGeometry(0.8, 0.8, ROD_H, 20, 1);
  const ctrlRods = [];
  for (let i = -HALF; i <= HALF; i++) for (let j = -HALF; j <= HALF; j++) if (isCtrl(i, j)) {
    const m = new THREE.Mesh(ctrlGeo, ctrlMat); m.position.set(i * PITCH, 0, j * PITCH); ctrlGroup.add(m); ctrlRods.push(m);
  }
  ctrlGroup.position.y = ROD_H * 1.5;
  root.add(ctrlGroup);

  // ── 물(감속재) 볼륨 + 바닥판 ──
  const waterMat = new THREE.MeshBasicNodeMaterial({ transparent: true, depthWrite: false, side: THREE.DoubleSide });
  waterMat.colorNode = Fn(() => {
    const nW = normalize(normalWorld), V = normalize(cameraPosition.sub(positionWorld));
    const fres = pow(float(1.0).sub(abs(dot(nW, V))), 2.0);
    const caust = mx_noise_float(vec3(positionWorld.x.mul(0.55), positionWorld.z.mul(0.55), t.mul(0.35))).mul(0.5).add(0.5);
    return vec4(vec3(0.1, 0.38, 0.8).mul(caust.mul(0.5).add(0.6)), fres.mul(0.38).add(0.045));
  })();
  const water = new THREE.Mesh(new THREE.BoxGeometry(lim * 2, ROD_H + 0.8, lim * 2), waterMat);
  water.renderOrder = 3;
  root.add(water);

  const plateMat = new THREE.MeshBasicNodeMaterial();
  plateMat.colorNode = Fn(() => {
    const q = positionWorld.xz, r = length(q);
    const ring = smoothstep(0.06, 0.0, abs(fract(r.mul(0.28)).sub(0.5)).sub(0.46).abs());
    const grid = smoothstep(0.03, 0.0, abs(fract(q.x.div(PITCH).add(0.5)).sub(0.5)).sub(0.47).abs()).add(smoothstep(0.03, 0.0, abs(fract(q.y.div(PITCH).add(0.5)).sub(0.5)).sub(0.47).abs()));
    return vec4(vec3(0.015, 0.025, 0.04).add(vec3(0.1, 0.4, 0.7).mul(grid.mul(0.1).add(ring.mul(0.06)))).add(vec3(1.0, 0.45, 0.15).mul(uActivity).mul(0.04)).mul(smoothstep(lim * 1.8, 0.0, r)), 1.0);
  })();
  const plate = new THREE.Mesh(new THREE.CylinderGeometry(lim * 1.4, lim * 1.4, 0.3, 64), plateMat);
  plate.position.y = -ROD_H * 0.5 - 0.5;
  root.add(plate);

  // ── 물 분자 H₂O (인스턴싱) ──
  const MOL = 2000, rnd = rng(77);
  const molMat = new THREE.MeshBasicNodeMaterial();
  molMat.positionNode = positionLocal.add(vec3(mx_noise_float(vec3(float(instanceIndex).mul(0.37), t.mul(0.9), 1.0)), mx_noise_float(vec3(float(instanceIndex).mul(0.41), t.mul(0.8), 5.0)), mx_noise_float(vec3(float(instanceIndex).mul(0.29), t.mul(1.0), 9.0))).mul(0.06));
  molMat.colorNode = vec4(vertexColor().rgb.mul(0.55), 1.0);
  const molecules = new THREE.InstancedMesh(waterMoleculeGeometry(), molMat, MOL);
  const q = new THREE.Quaternion(), e = new THREE.Euler(), sc = new THREE.Vector3(), p = new THREE.Vector3();
  let n = 0;
  while (n < MOL) {
    const x = (rnd() * 2 - 1) * (lim - 0.5), z = (rnd() * 2 - 1) * (lim - 0.5), y = (rnd() * 2 - 1) * (ROD_H * 0.5);
    const gx = Math.round(x / PITCH), gz = Math.round(z / PITCH), d = Math.hypot(x - gx * PITCH, z - gz * PITCH);
    if (d < (isCtrl(gx, gz) ? 1.15 : 0.85)) continue;                                         // 막대 안쪽은 비움
    e.set(rnd() * 6.28, rnd() * 6.28, rnd() * 6.28); q.setFromEuler(e); const s = 0.5 + rnd() * 0.25; sc.set(s, s, s);
    m4.compose(p.set(x, y, z), q, sc); molecules.setMatrixAt(n++, m4);
  }
  molecules.frustumCulled = false; molecules.renderOrder = 2;
  root.add(molecules);

  // ── 노심 광구(마지막 장면: 안정된 노심의 빛) ──
  const orbMat = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false, depthTest: false, blending: THREE.AdditiveBlending });   // depthTest 끔: 막대 뒤에 있어도 화면을 덮는 빛
  orbMat.colorNode = Fn(() => { const r = length(uv().sub(0.5)).mul(2.0); return vec4(mix(vec3(0.3, 1.0, 0.6), vec3(1.0, 1.0, 1.0), exp(r.mul(-8.0))).mul(exp(r.mul(-3.0))).mul(smoothstep(1.0, 0.6, r)).mul(uGlow).mul(2.4), 1.0); })();
  const orb = new THREE.Sprite(orbMat); orb.scale.set(34, 34, 1); orb.renderOrder = 12;
  root.add(orb);

  return {
    root, uActivity, uGlow, fuel, ctrlGroup, ctrlRods, water, molecules, lim,
    /** 제어봉 삽입 정도 e(0~1) */
    setRod(e) { ctrlGroup.position.y = ROD_H * 1.5 * (1 - e); },
    setMoleculeCount(k) { molecules.count = Math.min(MOL, k | 0); },
  };
}
