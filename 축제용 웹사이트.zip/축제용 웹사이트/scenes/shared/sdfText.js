// scenes/shared/sdfText.js — 3D 수식 글자(SDF): "E = mc²" 를 레이마칭하는 금속 글자
//
//  ① 캔버스에 글자를 그리고, 2D 부호 거리장(SDF)을 JS 에서 계산한다 (Felzenszwalb 의 정확한 유클리드 거리 변환, 안쪽·바깥쪽 각각).
//  ② 그 거리장을 텍스처로 올려, 셰이더가 "2D SDF 를 z 방향으로 두께를 준 압출(extrusion)" 거리장으로 레이마칭한다.
//     → 둥근 모서리의 입체 글자. 크롬 재질(절차적 환경 반사) + 청록 네온 가장자리 + 빛 스윕.
//  로컬 좌표: 글자 판 중심이 uCenter(월드), 가로 폭 W, 세로 H(월드 단위), 두께 depth. 글자판 뒤(−z)에서 보면 거울상이니 +z 쪽 카메라용.

import * as THREE from 'three/webgpu';
import {
  Fn, float, int, vec2, vec3, vec4, uniform, cameraPosition, positionWorld, normalize, length, dot, max, min, abs, mix, smoothstep, clamp, pow,
  exp, sqrt, step, select, reflect, If, Loop, Break, texture,
} from 'three/tsl';

const INF = 1e20;

/** 1차원 제곱 거리 변환 (Felzenszwalb & Huttenlocher) */
function dt1d(f, n, d, v, z) {
  let k = 0; v[0] = 0; z[0] = -INF; z[1] = INF;
  for (let q = 1; q < n; q++) {
    let s;
    while (true) { s = ((f[q] + q * q) - (f[v[k]] + v[k] * v[k])) / (2 * q - 2 * v[k]); if (s <= z[k] && k > 0) k--; else break; }
    if (s > z[k]) { k++; v[k] = q; z[k] = s; z[k + 1] = INF; } else { v[k] = q; z[k] = Math.max(s, -INF); }
  }
  k = 0;
  for (let q = 0; q < n; q++) { while (z[k + 1] < q) k++; d[q] = (q - v[k]) * (q - v[k]) + f[v[k]]; }
}
function edt2d(grid, w, h) {
  const n = Math.max(w, h), f = new Float64Array(n), d = new Float64Array(n), v = new Int32Array(n), z = new Float64Array(n + 1);
  for (let x = 0; x < w; x++) { for (let y = 0; y < h; y++) f[y] = grid[y * w + x]; dt1d(f, h, d, v, z); for (let y = 0; y < h; y++) grid[y * w + x] = d[y]; }
  for (let y = 0; y < h; y++) { for (let x = 0; x < w; x++) f[x] = grid[y * w + x]; dt1d(f, w, d, v, z); for (let x = 0; x < w; x++) grid[y * w + x] = d[x]; }
}

/** 글자 → 부호 거리장 텍스처 (바깥 +, 안쪽 −, 픽셀 단위 R 로 정규화) */
export function buildSDFTexture(text, { W = 1024, H = 256, R = 26, font = '"Black Han Sans", "Pretendard", sans-serif' } = {}) {
  const c = document.createElement('canvas'); c.width = W; c.height = H;
  const g = c.getContext('2d');
  g.fillStyle = '#000'; g.fillRect(0, 0, W, H);
  // 글자 폭을 판 폭의 92% 로 맞춘다 → shared/titleText.js 의 파티클 목표(sampleText)와 같은 비율이라 빛 입자가 정확히 글자 위로 모인다
  let size = 200; g.font = `400 ${size}px ${font}`;
  const mw = g.measureText(text).width; size = Math.floor(Math.min(size * (0.92 * W) / mw, H * 0.82)); g.font = `400 ${size}px ${font}`;
  g.fillStyle = '#fff'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(text, W / 2, H / 2 + size * 0.04);
  const img = g.getImageData(0, 0, W, H).data;
  const inside = new Uint8Array(W * H); for (let i = 0; i < W * H; i++) inside[i] = img[i * 4] > 127 ? 1 : 0;
  const toOut = new Float64Array(W * H), toIn = new Float64Array(W * H);
  for (let i = 0; i < W * H; i++) { toOut[i] = inside[i] ? 0 : INF; toIn[i] = inside[i] ? INF : 0; }
  edt2d(toOut, W, H); edt2d(toIn, W, H);
  const data = new Uint8Array(W * H * 4);
  for (let i = 0; i < W * H; i++) {
    const sd = Math.sqrt(toOut[i]) - Math.sqrt(toIn[i]);                   // 바깥 +, 안쪽 −
    const v = Math.max(0, Math.min(255, Math.round((sd / R * 0.5 + 0.5) * 255)));
    data[i * 4] = data[i * 4 + 1] = data[i * 4 + 2] = v; data[i * 4 + 3] = 255;
  }
  const tex = new THREE.DataTexture(data, W, H, THREE.RGBAFormat, THREE.UnsignedByteType);
  tex.colorSpace = THREE.NoColorSpace; tex.minFilter = tex.magFilter = THREE.LinearFilter; tex.generateMipmaps = false;
  tex.wrapS = tex.wrapT = THREE.ClampToEdgeWrapping; tex.needsUpdate = true;
  return { tex, W, H, R };
}

/**
 * 3D 압출 SDF 글자 메시.
 * @param o.worldW  글자 판 가로 폭(월드 단위)    @param o.depth 두께(반)
 */
export function makeSDFText(ctx, { text = 'E = mc²', worldW = 12, depth = 0.5, center = new THREE.Vector3() } = {}) {
  const t = ctx.u.time;
  const sdf = buildSDFTexture(text);
  const worldH = worldW * (sdf.H / sdf.W), pxWorld = worldW / sdf.W;
  const uA = uniform(0.0), uSweep = uniform(-1.0), uCenter = uniform(center.clone()), uGain = uniform(1.0);

  const mat = new THREE.MeshBasicNodeMaterial({ transparent: true, depthWrite: false, side: THREE.BackSide });
  mat.colorNode = Fn(() => {
    const ro = cameraPosition.sub(uCenter), rd = normalize(positionWorld.sub(cameraPosition));
    const map = (p) => {
      const uvv = vec2(p.x.div(worldW).add(0.5), float(0.5).sub(p.y.div(worldH)));
      const inB = step(0.0, uvv.x).mul(step(uvv.x, 1.0)).mul(step(0.0, uvv.y)).mul(step(uvv.y, 1.0));
      const d2tex = texture(sdf.tex, clamp(uvv, 0.001, 0.999)).level(0).r.mul(2.0).sub(1.0).mul(sdf.R * pxWorld);
      const outside = length(max(abs(p.xy).sub(vec2(worldW * 0.5, worldH * 0.5)), vec2(0.0, 0.0)));
      const d2 = select(inB.greaterThan(0.5), d2tex, float(sdf.R * pxWorld).add(outside));
      // 두께가 가장자리에서 얇아지는 "둥근 쿠션" 단면 → 평평한 앞면에도 하이라이트 그라디언트가 생긴다
      const hh = float(depth).mul(smoothstep(0.0, 1.0, d2.negate().div(sdf.R * pxWorld)).mul(0.5).add(0.5));
      const w = vec2(d2, abs(p.z).sub(hh));
      return min(max(w.x, w.y), 0.0).add(length(max(w, vec2(0.0, 0.0)))).sub(0.05);                 // 모서리를 살짝 둥글게(베벨)
    };
    // 경계 상자와의 교차에서 시작
    const bmin = vec3(worldW * -0.5 - 0.3, worldH * -0.5 - 0.3, -depth - 0.3), bmax = vec3(worldW * 0.5 + 0.3, worldH * 0.5 + 0.3, depth + 0.3);
    const inv = vec3(1.0).div(rd.add(vec3(1e-5)));
    const t0v = bmin.sub(ro).mul(inv), t1v = bmax.sub(ro).mul(inv);
    const tn = max(max(min(t0v.x, t1v.x), min(t0v.y, t1v.y)), min(t0v.z, t1v.z)), tf = min(min(max(t0v.x, t1v.x), max(t0v.y, t1v.y)), max(t0v.z, t1v.z));
    const tt = max(tn, 0.0).toVar(); const hit = float(0.0).toVar();
    Loop({ start: int(0), end: int(90), type: 'int', condition: '<' }, () => {
      const d = map(ro.add(rd.mul(tt)));
      If(d.lessThan(0.004), () => { hit.assign(1.0); Break(); });
      tt.addAssign(max(d.mul(0.62), 0.004));
      If(tt.greaterThan(tf), () => { Break(); });
    });
    const P = ro.add(rd.mul(tt));
    const e = float(0.012);
    const k0 = vec3(1, -1, -1), k1 = vec3(-1, -1, 1), k2 = vec3(-1, 1, -1), k3 = vec3(1, 1, 1);
    const n = normalize(k0.mul(map(P.add(k0.mul(e)))).add(k1.mul(map(P.add(k1.mul(e))))).add(k2.mul(map(P.add(k2.mul(e))))).add(k3.mul(map(P.add(k3.mul(e))))));
    const V = rd.negate();
    // 크롬: 절차적 환경(푸른 하늘 + 수평선 띠 + 소프트박스 + 태양빛 주황 한 줄)을 반사
    const R_ = reflect(rd, n);
    const up = R_.y.mul(0.5).add(0.5);
    const sky = mix(vec3(0.01, 0.025, 0.07), vec3(0.25, 0.6, 1.0), pow(up, 1.6));
    const band = vec3(1.0, 0.85, 0.65).mul(exp(pow(R_.y.sub(0.14).div(0.05), 2.0).negate())).mul(1.6);
    const box = vec3(1.0, 1.0, 1.0).mul(smoothstep(0.9, 0.97, dot(R_, normalize(vec3(-0.3, 0.55, 0.75))))).mul(3.0);
    const warm = vec3(1.0, 0.5, 0.15).mul(smoothstep(0.93, 0.99, dot(R_, normalize(vec3(-0.9, 0.1, 0.3))))).mul(2.2);
    const fres = pow(float(1.0).sub(clamp(dot(n, V), 0.0, 1.0)), 3.0);
    let col = sky.add(band).add(box).add(warm).mul(mix(0.35, 1.0, fres)).add(vec3(0.2, 0.9, 1.0).mul(fres).mul(0.6));
    // 빛 스윕: 글자 위를 가로질러 지나가는 하이라이트
    const sw = exp(pow(P.x.div(worldW).add(0.5).sub(uSweep).mul(9.0), 2.0).negate()).mul(step(0.0, uSweep));
    col = col.add(vec3(1.0, 0.95, 0.85).mul(sw).mul(2.2));
    return vec4(col.mul(uGain), hit.mul(uA));
  })();
  const bound = new THREE.Mesh(new THREE.BoxGeometry(worldW + 0.6, worldH + 0.6, depth * 2 + 0.6), mat);
  bound.position.copy(center); bound.renderOrder = 9; bound.frustumCulled = false;
  return { mesh: bound, uA, uSweep, uGain, worldW, worldH, depth, uCenter, setCenter(v) { uCenter.value.copy(v); bound.position.copy(v); } };
}
