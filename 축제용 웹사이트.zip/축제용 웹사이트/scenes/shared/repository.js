// scenes/shared/repository.js — Ch.7 사용후핵연료의 길: 수조 → 건식 저장 → 지하 심층 처분 (단면 도해)
//
//  암반을 가른 "기술 도해" 스타일의 단면(평면 z=0) 위에 설비를 그려 넣고, 사용후핵연료 다발(빛 캡슐)이 길을 따라 이동한다.
//   ① 사용후핵연료 저장수조(수조 물이 열을 식히고 방사선을 막는다 — 수년간)
//   ② 건식 저장(콘크리트·강철 용기, 공기로 냉각)
//   ③ 지하 수백 m 암반 속 처분장: 터널 바닥의 수직 구멍에 구리 용기 + 벤토나이트 점토 + 암반 (다중 방벽)
//  1 유닛 = 5 m. 지표면이 y=0, 처분 깊이 y=−86 → 약 430 m (핀란드 온칼로 ≈ 400~430 m, 개념 도해).
//  ※ 실제 부지·설비의 모양이 아니라 개념을 보여 주는 모식도다.

import * as THREE from 'three/webgpu';
import {
  Fn, float, vec2, vec3, vec4, uniform, uv, positionGeometry, normalize, length, dot, mix, smoothstep, clamp, pow, exp, sin, cos, abs, fract, step, floor, varying, max, min,
} from 'three/tsl';
import { fbm3 } from '../../engine/tsl.js';

export const DEPTH_Y = -86;                                   // 처분 터널 높이(약 430 m)
export const HOLE_X0 = 140, HOLE_DX = 11, HOLES = 8;
export const PATH = [[-142, 6], [-100, 5], [-60, 5], [-20, 2], [10, 1.5], [30, -12], [60, -37], [95, -70], [118, DEPTH_Y], [HOLE_X0, DEPTH_Y], [HOLE_X0, DEPTH_Y - 10]];
const pathCurve = new THREE.CatmullRomCurve3(PATH.map(([x, y]) => new THREE.Vector3(x, y, 0.5)), false, 'centripetal');
export const pathAt = (u, out = new THREE.Vector3()) => pathCurve.getPointAt(Math.min(1, Math.max(0, u)), out);

function flat(w, h, x, y, z, colorFn, opts = {}) {
  const m = new THREE.MeshBasicNodeMaterial({ transparent: !!opts.transparent, depthWrite: !opts.transparent, blending: opts.additive ? THREE.AdditiveBlending : THREE.NormalBlending });
  m.colorNode = Fn(colorFn)();
  const mesh = new THREE.Mesh(new THREE.PlaneGeometry(w, h), m); mesh.position.set(x, y, z); mesh.renderOrder = opts.order ?? 1;
  return mesh;
}
const outline = (u, w = 0.02) => smoothstep(w, 0.0, min(min(u.x, float(1.0).sub(u.x)), min(u.y, float(1.0).sub(u.y))));      // 사각형 테두리 마스크

export function makeRepository(ctx) {
  const group = new THREE.Group();
  const t = ctx.u.time;
  const uPulse = uniform(0.0), uFill = uniform(0.0), uCap = uniform(0.0), uA = uniform(1.0);

  // ── 암반 단면 ──
  const rock = flat(560, 190, 0, -90, 0, () => {
    const g = positionGeometry, depth = float(95).sub(g.y);                                       // 지표(y=0)로부터의 깊이(유닛). 판 중심이 y=−90 이므로 지표는 판 로컬 y=+90
    const d = depth.sub(5.0);
    const warp = fbm3(vec3(g.x.mul(0.01), g.y.mul(0.05), 3.0)).mul(7.0);
    const band = fract(g.y.add(warp).mul(0.085)), n2 = fbm3(vec3(g.x.mul(0.05), g.y.mul(0.16), 1.0)).mul(0.5).add(0.5);
    const A = vec3(0.012, 0.011, 0.011), B = vec3(0.045, 0.04, 0.036), C = vec3(0.026, 0.03, 0.04);
    let col = mix(mix(A, B, smoothstep(0.2, 0.7, band)), C, smoothstep(0.55, 0.9, n2).mul(0.6));
    col = col.mul(float(1.0).sub(smoothstep(0.0, 140.0, d).mul(0.5)));
    const fr = fract(d.div(20.0)), line = smoothstep(0.012, 0.0, min(fr, float(1.0).sub(fr)));      // 깊이 눈금선: 100 m(=20 유닛)마다
    col = col.add(vec3(0.12, 0.4, 0.7).mul(line).mul(0.35));
    return vec4(col.mul(smoothstep(280.0, 200.0, abs(g.x))).mul(step(0.0, d)), 1.0);
  });
  rock.position.z = -0.5; group.add(rock);                    // 판 중심 y=−90, 높이 190 → y −185 ~ +5 (지표 위 5는 d<0 이라 투명 처리 대신 검게)
  // 지표(풀밭 띠) + 하늘의 노을빛 띠
  group.add(flat(560, 3, 0, 1.5, 0, () => vec4(vec3(0.012, 0.025, 0.016).add(vec3(0.012, 0.01, 0.005).mul(sin(positionGeometry.x.mul(0.7)).mul(0.5).add(0.5))), 1.0)));
  group.add(flat(560, 60, 0, 31, -0.8, () => { const u = uv(); return vec4(vec3(0.06, 0.04, 0.08).mul(smoothstep(1.0, 0.0, u.y)).add(vec3(0.5, 0.22, 0.12).mul(pow(smoothstep(0.6, 0.0, u.y), 2.5)).mul(0.5)), 1.0); }));

  // ── ① 저장수조(단면): 건물 + 물 + 연료다발 랙 ──
  const poolX = -118;
  group.add(flat(52, 22, poolX, 14, -0.1, () => { const u = uv(); return vec4(vec3(0.05, 0.07, 0.1).add(vec3(0.2, 0.55, 0.9).mul(outline(u, 0.012)).mul(0.9)), 1.0); }, { order: 2 }));
  const water = flat(40, 11, poolX, 7.5, 0.1, () => {
    const u = uv(), p = positionGeometry;
    const caustic = pow(sin(p.x.mul(1.3).add(sin(p.y.mul(0.9).add(t.mul(0.8))).mul(2.0)).add(t.mul(0.6))).mul(0.5).add(0.5), 6.0);
    const col = mix(vec3(0.02, 0.15, 0.32), vec3(0.04, 0.38, 0.62), u.y).add(vec3(0.3, 0.7, 1.0).mul(caustic).mul(0.18));
    return vec4(col.add(vec3(0.15, 0.5, 0.9).mul(outline(u, 0.015))), 1.0);
  }, { order: 3 });
  group.add(water);
  const rackMat = new THREE.MeshBasicNodeMaterial({ transparent: true, blending: THREE.AdditiveBlending, depthWrite: false });
  rackMat.colorNode = Fn(() => { const u = uv(); const core = smoothstep(0.5, 0.1, abs(u.x.sub(0.5))); return vec4(mix(vec3(0.2, 0.55, 1.0), vec3(1.0, 0.6, 0.2), u.y.mul(0.5)).mul(core).mul(sin(t.mul(2.0).add(u.y.mul(8.0))).mul(0.15).add(0.85)).mul(1.4), 1.0); })();
  for (let i = 0; i < 9; i++) { const r = new THREE.Mesh(new THREE.PlaneGeometry(1.8, 6.4), rackMat); r.position.set(poolX - 16 + i * 4, 6.0, 0.3); r.renderOrder = 4; group.add(r); }

  // ── ② 건식 저장 용기 ──
  const caskX = -50;
  group.add(flat(44, 1.2, caskX, 0.6, 0.1, () => vec4(vec3(0.13, 0.13, 0.14), 1.0)));                        // 콘크리트 패드
  const caskMat = new THREE.MeshBasicNodeMaterial({ transparent: true });
  caskMat.colorNode = Fn(() => {
    const u = uv();
    const shade = smoothstep(0.0, 0.5, u.x).mul(smoothstep(1.0, 0.5, u.x)).mul(0.6).add(0.4);
    const vent = step(0.9, u.y).mul(step(0.45, fract(u.x.mul(6.0)))).mul(0.5);
    const warm = smoothstep(0.7, 1.0, u.y).mul(sin(t.mul(3.0).add(u.x.mul(10.0))).mul(0.2).add(0.5));
    return vec4(vec3(0.33, 0.34, 0.37).mul(shade).mul(float(1.0).sub(vent)).add(vec3(1.0, 0.5, 0.2).mul(warm).mul(0.25)).add(vec3(0.3, 0.7, 1.0).mul(outline(u, 0.02)).mul(0.5)), 1.0);
  })();
  for (let i = 0; i < 4; i++) { const m = new THREE.Mesh(new THREE.PlaneGeometry(7.2, 12.5), caskMat); m.position.set(caskX - 14 + i * 9.5, 7.2, 0.2); m.renderOrder = 3; group.add(m); }

  // ── 처분장 시설(수직 입구 건물) + 철로 ──
  group.add(flat(30, 20, 10, 11, -0.1, () => { const u = uv(); return vec4(vec3(0.05, 0.07, 0.1).add(vec3(0.2, 0.55, 0.9).mul(outline(u, 0.014)).mul(0.9)), 1.0); }, { order: 2 }));
  group.add(flat(300, 0.35, -75, 0.4, 0.2, () => { const u = uv(); return vec4(vec3(0.5, 0.55, 0.62).mul(step(0.5, fract(u.x.mul(150.0)).mul(0.5).add(0.25))), 1.0); }));

  // ── 접근 터널(경사로) + 심층 처분 터널 ──
  const tunnelCurve = new THREE.CatmullRomCurve3([[10, 0.2], [30, -12], [60, -37], [95, -70], [118, DEPTH_Y], [165, DEPTH_Y], [250, DEPTH_Y]].map(([x, y]) => new THREE.Vector3(x, y, 0)), false, 'centripetal');
  const ribbon = (curve, width, seg = 160) => {
    const pts = curve.getSpacedPoints(seg), pos = [], uvs = [], idx = []; let L = 0;
    for (let i = 0; i < pts.length; i++) {
      const a = pts[Math.max(0, i - 1)], b = pts[Math.min(pts.length - 1, i + 1)]; const tx = b.x - a.x, ty = b.y - a.y, l = Math.hypot(tx, ty) || 1;
      const nx = -ty / l, ny = tx / l; if (i > 0) L += pts[i].distanceTo(pts[i - 1]);
      pos.push(pts[i].x + nx * width / 2, pts[i].y + ny * width / 2, 0, pts[i].x - nx * width / 2, pts[i].y - ny * width / 2, 0); uvs.push(0, L, 1, L);
      if (i < pts.length - 1) { const k = i * 2; idx.push(k, k + 1, k + 2, k + 1, k + 3, k + 2); }
    }
    const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2)); g.setIndex(idx);
    return { geo: g, length: L };
  };
  const tunnel = ribbon(tunnelCurve, 5.2);
  const tMat = new THREE.MeshBasicNodeMaterial({ transparent: true, depthWrite: false });
  tMat.colorNode = Fn(() => {
    const u = uv(), edge = smoothstep(0.38, 0.5, abs(u.x.sub(0.5)));
    const pulse = smoothstep(0.7, 1.0, sin(u.y.mul(0.35).sub(t.mul(2.4)).sub(uPulse.mul(0.0))).mul(0.5).add(0.5));
    return vec4(vec3(0.012, 0.014, 0.02).add(vec3(0.2, 0.7, 1.0).mul(edge).mul(0.9)).add(vec3(0.15, 0.5, 0.9).mul(pulse).mul(0.12)), 1.0);
  })();
  const tunnelMesh = new THREE.Mesh(tunnel.geo, tMat); tunnelMesh.position.z = 0.15; tunnelMesh.renderOrder = 2; group.add(tunnelMesh);

  // ── 처분 구멍: 벤토나이트 + 구리 용기(+ 안의 연료봉) ──
  const holeMat = new THREE.MeshBasicNodeMaterial({ transparent: true });
  holeMat.colorNode = Fn(() => {
    const u = uv();
    const bent = vec3(0.4, 0.3, 0.18).mul(smoothstep(0.0, 0.2, u.x).mul(smoothstep(1.0, 0.8, u.x)).mul(0.5).add(0.5)).mul(0.45);
    return vec4(bent.add(vec3(0.3, 0.7, 1.0).mul(outline(u, 0.03)).mul(0.5)), 1.0);
  })();
  const canMat = new THREE.MeshBasicNodeMaterial({ transparent: true });
  canMat.colorNode = Fn(() => {
    const u = uv();
    const sh = smoothstep(0.0, 0.5, u.x).mul(smoothstep(1.0, 0.5, u.x)).mul(0.6).add(0.4);
    const ironPart = smoothstep(0.34, 0.3, abs(u.x.sub(0.5))).mul(smoothstep(0.03, 0.06, u.y)).mul(smoothstep(0.97, 0.94, u.y));      // 안쪽 주철 인서트
    const rods = step(0.5, fract(u.x.mul(5.0).add(0.1))).mul(ironPart).mul(smoothstep(0.1, 0.14, u.y)).mul(smoothstep(0.9, 0.86, u.y));
    const cu = vec3(0.85, 0.46, 0.26).mul(sh).add(vec3(1.0, 0.8, 0.6).mul(pow(smoothstep(0.62, 0.7, u.x).mul(smoothstep(0.78, 0.7, u.x)), 2.0)).mul(0.35));
    const fin = mix(cu, vec3(0.1, 0.1, 0.11), ironPart.mul(0.9));
    return vec4(mix(fin, vec3(0.9, 0.75, 0.3), rods.mul(0.7)), uCap);
  })();
  const holes = [];
  for (let i = 0; i < HOLES; i++) {
    const x = HOLE_X0 + i * HOLE_DX;
    const hole = new THREE.Mesh(new THREE.PlaneGeometry(4.4, 17), holeMat); hole.position.set(x, DEPTH_Y - 11, 0.1); hole.renderOrder = 2; group.add(hole);
    const can = new THREE.Mesh(new THREE.PlaneGeometry(2.6, 13), canMat.clone()); can.position.set(x, DEPTH_Y - 11, 0.3); can.renderOrder = 3; can.visible = false; group.add(can);
    holes.push(can);
  }
  // 이동 캡슐(다발) + 꼬리
  const capMat = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
  capMat.colorNode = Fn(() => { const r = length(uv().sub(0.5)).mul(2.0); return vec4(mix(vec3(1.0, 0.7, 0.3), vec3(1.0, 1.0, 1.0), exp(r.mul(-8.0))).mul(exp(r.mul(-2.6))).mul(smoothstep(1.0, 0.5, r)).mul(2.0), 1.0); })();
  const capsule = new THREE.Sprite(capMat); capsule.scale.set(9, 9, 1); capsule.renderOrder = 9; group.add(capsule);
  const trail = []; for (let i = 0; i < 14; i++) { const s = new THREE.Sprite(capMat); s.renderOrder = 8; group.add(s); trail.push(s); }
  return { group, holes, capsule, trail, uPulse, uFill, uCap, uA, tunnelLength: tunnel.length };
}
