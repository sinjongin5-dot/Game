// scenes/shared/plant.js — Ch.6 디지털 트윈: 가압경수로(PWR) 발전소 투명 단면 모델
//
//  구성(월드 단위 ≈ 4 m, 모두 "홀로그램 유리" 재질로 속이 비치고 내부 흐름이 보인다)
//   · 원자로 용기 + 노심(연료집합체 + 체렌코프 푸른 빛 + 광자 입자) + 제어봉 구동부
//   · 1차 계통(고압 냉각수, 빨강-주황): 원자로 → 고온관 → 증기발생기 U자관 → 냉각재 펌프 → 원자로 (닫힌 고리)
//   · 증기발생기: 1차(U자관, 빨강)와 2차(물/증기, 청록)가 관벽으로만 열을 주고받고 "서로 섞이지 않는다"
//   · 2차 계통(깨끗한 물/증기, 청록): 증기발생기 → 주증기관 → 고압/저압 터빈 → 복수기 → 급수관 → 증기발생기
//   · 터빈(회전 블레이드 → 고속에서 모션 블러 원반) + 발전기(회전 자석 N/S + 고정자 코일 + 자기력선 입자 + 유도 전류)
//   · 변압기 → 송전선 → 송전탑 행렬 → (송전 펄스) → 서울
//  출처(개념): 가압경수로 구조는 한국 원전의 주력(APR1400·OPR1000) 방식. 1차 계통 약 155 bar·300 °C 이상, 2차 증기 약 70 bar (KHNP·IAEA 일반 자료).
//  좌표: 원자로 중심 (−60,0,0), 증기발생기 (−28,·,0), 터빈축 y=5 (x 4~40), 발전기 x 44~56, 변압기 x≈64, 송전선 +X 방향.

import * as THREE from 'three/webgpu';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import {
  Fn, float, vec2, vec3, vec4, uniform, uv, instanceIndex, hash, normalWorld, positionWorld, positionLocal, cameraPosition, normalize, length, dot,
  mix, smoothstep, clamp, pow, exp, sin, cos, abs, fract, atan, varying, mx_noise_float, max,
} from 'three/tsl';
import { makePath, makeFlow } from './flow.js';

export const REACTOR = new THREE.Vector3(-60, 0, 0);
export const SG = new THREE.Vector3(-28, 0, 0);
export const AXIS_Y = 5;                       // 터빈·발전기 축 높이
export const LINE_X0 = 90, LINE_SPAN = 150, LINE_N = 44;   // 송전탑: x = 90 + 150·i
export const LINE_Y = 21;

function rng(seed) { let a = seed >>> 0; return () => { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

/** 홀로그램 유리: 가장자리(프레넬)만 밝고 속은 비친다 */
function holo(color, { alpha = 0.05, edge = 0.6, power = 2.2, base = 0.1 } = {}) {
  const m = new THREE.MeshBasicNodeMaterial({ transparent: true, depthWrite: false, side: THREE.DoubleSide });
  m.colorNode = Fn(() => {
    const nW = normalize(normalWorld), V = normalize(cameraPosition.sub(positionWorld));
    const f = pow(float(1.0).sub(abs(dot(nW, V))), power);
    return vec4(vec3(color.r, color.g, color.b).mul(f.mul(edge).add(base)), f.mul(edge).add(alpha));
  })();
  return m;
}

export async function makePlant(ctx) {
  const root = new THREE.Group();
  const t = ctx.u.time;
  const rnd = rng(2026);
  const U = {
    cher: uniform(1.0),          // 체렌코프 광 세기
    spin: uniform(0.0),          // 터빈·발전기 회전각(라디안)
    blur: uniform(0.0),          // 고속 회전 시 블레이드 → 블러 원반 전환(0~1)
    packet: uniform(-1.0),       // 송전 펄스 위치(0~1, <0 이면 꺼짐)
    gen: uniform(0.0),           // 발전기 자기력선·유도전류 세기
    glow: uniform(1.0),
  };
  const red = new THREE.Color(1.0, 0.36, 0.12), teal = new THREE.Color(0.12, 0.85, 0.8), cyan = new THREE.Color(0.3, 0.8, 1.0), amber = new THREE.Color(1.0, 0.7, 0.2);

  // ───────── 지형(어두운 바닥 + 은은한 격자) ─────────
  const gMat = new THREE.MeshBasicNodeMaterial();
  gMat.colorNode = Fn(() => {
    const q = positionWorld.xz;
    const gx = abs(fract(q.x.div(20.0)).sub(0.5)), gz = abs(fract(q.y.div(20.0)).sub(0.5));
    const line = smoothstep(0.495, 0.5, max(gx, gz));
    const d = length(q.sub(vec2(-5.0, 0.0)));
    return vec4(vec3(0.004, 0.008, 0.016).add(vec3(0.05, 0.28, 0.45).mul(line).mul(0.35).mul(exp(d.div(-260.0)))).add(vec3(0.08, 0.2, 0.3).mul(exp(d.div(-90.0))).mul(0.12)), 1.0);
  })();
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(60000, 60000), gMat);
  ground.rotation.x = -Math.PI / 2; ground.position.y = -9.5;
  root.add(ground);

  // ───────── 원자로 ─────────
  const vessel = new THREE.Group(); vessel.position.copy(REACTOR); root.add(vessel);
  const vProfile = [[0.001, -8.6], [1.6, -8.35], [2.9, -7.6], [3.9, -6.0], [4.2, -4.0], [4.2, 6.6], [3.9, 7.9], [2.9, 9.0], [1.6, 9.7], [0.001, 9.95]].map(([r, y]) => new THREE.Vector2(r, y));
  vessel.add(new THREE.Mesh(new THREE.LatheGeometry(vProfile, 48), holo(cyan, { alpha: 0.035, edge: 0.55 })));
  // 체렌코프 푸른 빛: 노심 물 기둥(가산) + 연료집합체 + 광자 입자
  const cherMat = new THREE.MeshBasicNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide });
  cherMat.colorNode = Fn(() => {
    const nW = normalize(normalWorld), V = normalize(cameraPosition.sub(positionWorld));
    const f = pow(float(1.0).sub(abs(dot(nW, V))), 1.4);
    const n = mx_noise_float(vec3(positionWorld.x.mul(0.5), positionWorld.y.mul(0.35).sub(t.mul(1.1)), positionWorld.z.mul(0.5))).mul(0.5).add(0.6);
    const flick = sin(t.mul(23.0).add(positionWorld.y.mul(2.0))).mul(0.08).add(0.92);
    return vec4(vec3(0.03, 0.22, 1.0).mul(f.mul(0.9).add(0.05)).mul(n).mul(flick).mul(U.cher).mul(0.32), 1.0);
  })();
  const core = new THREE.Mesh(new THREE.CylinderGeometry(3.4, 3.4, 9, 40, 1, true), cherMat);
  core.position.y = -1.2; core.renderOrder = 5; vessel.add(core);
  const asmMat = new THREE.MeshBasicNodeMaterial();
  asmMat.colorNode = Fn(() => {
    const y = positionLocal.y;
    const edge = pow(float(1.0).sub(abs(positionLocal.x.mul(2.4))), 1.0);
    return vec4(vec3(0.015, 0.02, 0.035).add(vec3(0.05, 0.3, 1.0).mul(U.cher).mul(smoothstep(-4.5, 4.0, y).mul(0.6).add(0.15)).mul(0.5)), 1.0);
  })();
  const asmGeo = new THREE.BoxGeometry(0.46, 8, 0.46);
  const asmPos = [];
  for (let i = -3; i <= 3; i++) for (let j = -3; j <= 3; j++) if (Math.hypot(i, j) <= 3.1) asmPos.push([i * 0.82, j * 0.82]);
  const asm = new THREE.InstancedMesh(asmGeo, asmMat, asmPos.length);
  const m4 = new THREE.Matrix4();
  asmPos.forEach(([x, z], k) => { m4.makeTranslation(x, -1.2, z); asm.setMatrixAt(k, m4); });
  vessel.add(asm);
  const photons = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
  {
    const i = instanceIndex, h = (k) => hash(i.add(k));
    const a = h(0).mul(6.2831853), r = pow(h(1), 0.5).mul(3.3);
    const p = vec3(cos(a).mul(r), h(2).mul(9.0).sub(5.7).add(sin(t.mul(2.0).add(h(3).mul(20.0))).mul(0.15)), sin(a).mul(r));
    photons.positionNode = p.add(vec3(REACTOR.x, REACTOR.y, REACTOR.z));
    photons.scaleNode = float(0.05).add(h(4).mul(0.07));
    const tw = sin(t.mul(h(5).mul(30.0).add(14.0)).add(h(6).mul(40.0))).mul(0.5).add(0.5);
    photons.colorNode = varying(mix(vec3(0.1, 0.4, 1.0), vec3(0.5, 0.35, 1.0), h(7)).mul(tw.mul(tw)).mul(U.cher).mul(0.9), 'vPhoton');
    photons.opacityNode = smoothstep(0.5, 0.0, length(uv().sub(0.5))).pow(1.4);
  }
  const photonSprite = new THREE.Sprite(photons); photonSprite.count = 7000; photonSprite.frustumCulled = false; photonSprite.renderOrder = 9;
  root.add(photonSprite);
  // 제어봉 구동부(위쪽 가는 막대들)
  const drive = new THREE.Mesh(mergeGeometries(Array.from({ length: 9 }, (_, k) => new THREE.CylinderGeometry(0.16, 0.16, 5.2, 8).translate(((k % 3) - 1) * 1.3, 12.4, (Math.floor(k / 3) - 1) * 1.3))), holo(cyan, { alpha: 0.1, edge: 0.8 }));
  drive.position.copy(REACTOR); root.add(drive);

  // ───────── 증기발생기 ─────────
  const sg = new THREE.Group(); sg.position.copy(SG); root.add(sg);
  const sgProfile = [[0.001, -6.6], [1.4, -6.4], [2.4, -5.6], [2.6, -4.5], [2.6, 5.0], [3.0, 6.2], [3.8, 7.8], [3.8, 13.0], [3.3, 15.2], [2.2, 16.6], [0.001, 17.2]].map(([r, y]) => new THREE.Vector2(r, y));
  sg.add(new THREE.Mesh(new THREE.LatheGeometry(sgProfile, 48), holo(teal, { alpha: 0.045, edge: 0.6 })));
  // 2차 측 물(청록 볼륨)
  const wMat = new THREE.MeshBasicNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
  wMat.colorNode = Fn(() => { const n = mx_noise_float(vec3(positionWorld.x.mul(0.5), positionWorld.y.mul(0.4).sub(t.mul(0.8)), positionWorld.z.mul(0.5))).mul(0.5).add(0.5); return vec4(vec3(0.06, 0.5, 0.5).mul(n).mul(0.22), 1.0); })();
  const sgWater = new THREE.Mesh(new THREE.CylinderGeometry(2.45, 2.45, 10.5, 32, 1, true), wMat); sgWater.position.y = 0.3; sg.add(sgWater);
  // U자관 다발: 1차 냉각수가 지나는 가는 관 (빨강-주황 발광)
  const uTubes = [];
  for (let k = 0; k < 30; k++) {
    const ang = rnd() * 6.283, rr = Math.sqrt(rnd()) * 1.9, x = Math.cos(ang) * rr, z = Math.sin(ang) * rr, h = 6 + rnd() * 3.5, w = 0.25 + rnd() * 0.6;
    const c = new THREE.CatmullRomCurve3([new THREE.Vector3(x - w * 0.5, -5.0, z), new THREE.Vector3(x - w * 0.5, 0, z), new THREE.Vector3(x - w * 0.5, h - 1, z), new THREE.Vector3(x, h + 0.6, z), new THREE.Vector3(x + w * 0.5, h - 1, z), new THREE.Vector3(x + w * 0.5, 0, z), new THREE.Vector3(x + w * 0.5, -5.0, z)]);
    uTubes.push(new THREE.TubeGeometry(c, 28, 0.085, 6, false));
  }
  const tubeMat = new THREE.MeshBasicNodeMaterial();
  tubeMat.colorNode = Fn(() => vec4(vec3(0.5, 0.12, 0.04).add(vec3(1.0, 0.4, 0.1).mul(sin(positionWorld.y.mul(1.5).sub(t.mul(3.0))).mul(0.25).add(0.5)).mul(U.glow)), 1.0))();
  sg.add(new THREE.Mesh(mergeGeometries(uTubes), tubeMat));

  // ───────── 가압기·냉각재 펌프 ─────────
  const prz = new THREE.Mesh(new THREE.CapsuleGeometry(1.5, 6, 6, 20), holo(amber, { alpha: 0.05, edge: 0.55 }));
  prz.position.set(-44, 2.5, 9); root.add(prz);
  const pump = new THREE.Mesh(new THREE.CylinderGeometry(1.6, 1.6, 3.4, 20), holo(red, { alpha: 0.06, edge: 0.6 }));
  pump.position.set(-42, -4.0, -5); root.add(pump);

  // ───────── 1·2차 계통 경로와 배관 ─────────
  const V3 = (x, y, z) => new THREE.Vector3(x, y, z);
  // 1차: 원자로 하부 → 노심 위로 → 고온관 → 증기발생기 U자관 → 냉각재 펌프 → 원자로
  const primaryPts = [
    V3(-60, -7, 0), V3(-60, -2, 0), V3(-60, 4, 0), V3(-56, 5.2, 0), V3(-48, 6.0, 0), V3(-38, 5.0, 0), V3(-31, 1.0, 0.0),
    V3(-28.6, -4.2, 1.2), V3(-28.6, 3, 1.2), V3(-28.2, 9, 0.8), V3(-27.8, 10.2, 0), V3(-27.4, 9, -0.8), V3(-27.4, 3, -1.2), V3(-27.4, -4.2, -1.2),
    V3(-32, -4.5, -3), V3(-42, -4.2, -5), V3(-52, -3.5, -3.4), V3(-56.5, -2.4, -1.5),
  ];
  const primary = makePath(primaryPts, true);
  // 2차: 증기발생기 상부 → 주증기관 → 터빈 → 복수기 → 급수관 → 증기발생기
  const secondaryPts = [
    V3(-28, 13, 0), V3(-26, 16.8, 0), V3(-18, 17.2, 0), V3(-8, 12, 0), V3(1, 7, 0), V3(5, AXIS_Y, 0), V3(20, AXIS_Y, 0), V3(36, AXIS_Y, 0), V3(41, 3, 0), V3(41, -4, 0),
    V3(36, -6.5, 0), V3(12, -7, 0), V3(-14, -6.8, 2), V3(-27, -5.5, 3.2), V3(-30.5, 0, 3.4), V3(-30.5, 8, 2.4), V3(-29, 12, 1),
  ];
  const secondary = makePath(secondaryPts, true);
  const pipeMat = (c) => holo(c, { alpha: 0.05, edge: 0.7, power: 1.8, base: 0.12 });
  const tube = (path, r, c) => { const m = new THREE.Mesh(new THREE.TubeGeometry(path.curve, 420, r, 10, true), pipeMat(c)); m.renderOrder = 4; return m; };
  root.add(tube(primary, 0.78, red), tube(secondary, 0.62, teal));
  const flowPrimary = makeFlow(ctx, { path: primary, count: 9000, color: red, speed: 0.045, radius: 0.5, size: 0.2, bright: 0.5, seed: 1 });
  const flowSecondary = makeFlow(ctx, { path: secondary, count: 9000, color: teal, speed: 0.06, radius: 0.4, size: 0.18, bright: 0.55, seed: 2 });
  root.add(flowPrimary.sprite, flowSecondary.sprite);

  // ───────── 터빈 ─────────
  const rotorGroup = new THREE.Group(); rotorGroup.position.y = AXIS_Y; root.add(rotorGroup);   // x 축 회전
  const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.62, 0.62, 52, 16), new THREE.MeshBasicNodeMaterial({ color: new THREE.Color(0.07, 0.1, 0.16) }));
  shaft.rotation.z = Math.PI / 2; shaft.position.x = 30; rotorGroup.add(shaft);
  const turbines = [{ x0: 6, x1: 13, r: 2.3, stages: 4 }, { x0: 17, x1: 27, r: 3.5, stages: 5 }, { x0: 30, x1: 40, r: 3.5, stages: 5 }];
  const bladeMat = new THREE.MeshBasicNodeMaterial();
  bladeMat.colorNode = Fn(() => vec4(vec3(0.2, 0.3, 0.45), 1.0).mul(float(1.0).sub(U.blur.mul(0.93))))();
  bladeMat.transparent = true; bladeMat.opacityNode = float(1.0).sub(U.blur.mul(0.95));
  const blurMat = new THREE.MeshBasicNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide });
  blurMat.colorNode = Fn(() => {
    const r = length(uv().sub(0.5)).mul(2.0);
    const ring = smoothstep(0.18, 0.4, r).mul(smoothstep(1.0, 0.86, r));
    const sweep = mx_noise_float(vec3(atan(uv().y.sub(0.5), uv().x.sub(0.5)).mul(2.0), r.mul(7.0), t.mul(3.0))).mul(0.3).add(0.75);
    return vec4(vec3(0.55, 0.8, 1.0).mul(ring).mul(sweep).mul(U.blur).mul(0.55), 1.0);
  })();
  const bladeGeo = new THREE.BoxGeometry(0.1, 1, 0.45);
  turbines.forEach(({ x0, x1, r, stages }) => {
    const cas = new THREE.Mesh(new THREE.CylinderGeometry(r, r, x1 - x0, 36, 1, true), holo(teal, { alpha: 0.035, edge: 0.5 }));
    cas.rotation.z = Math.PI / 2; cas.position.set((x0 + x1) / 2, AXIS_Y, 0); root.add(cas);
    const per = 30, inst = new THREE.InstancedMesh(bladeGeo, bladeMat, stages * per), disc = [];
    for (let s = 0; s < stages; s++) {
      const x = x0 + 0.8 + (s / (stages - 1)) * (x1 - x0 - 1.6), br = r * (0.5 + 0.38 * (s / (stages - 1)));
      for (let b = 0; b < per; b++) {
        const a = (b / per) * Math.PI * 2, q = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(1, 0, 0), a + Math.PI / 2 + 0.4);
        const sc = new THREE.Vector3(1, br * 0.7, 1), pos = new THREE.Vector3(x, Math.cos(a) * br * 0.62, Math.sin(a) * br * 0.62);
        m4.compose(pos, q, sc); inst.setMatrixAt(s * per + b, m4);
      }
      const d = new THREE.Mesh(new THREE.PlaneGeometry(br * 2.1, br * 2.1), blurMat);
      d.rotation.y = Math.PI / 2; d.position.set(x, 0, 0); d.renderOrder = 6; rotorGroup.add(d);
    }
    inst.position.y = 0; inst.frustumCulled = false; rotorGroup.add(inst);
  });
  // 회전자(발전기 자석): 반은 빨강(N) 반은 파랑(S)
  const magMat = new THREE.MeshBasicNodeMaterial();
  magMat.colorNode = Fn(() => { const a = atan(positionLocal.z, positionLocal.y); const north = smoothstep(-0.05, 0.05, sin(a.add(0.0))); return vec4(mix(vec3(0.15, 0.3, 1.0), vec3(1.0, 0.2, 0.18), north).mul(0.75), 1.0); })();
  const magnet = new THREE.Mesh(new THREE.CylinderGeometry(1.5, 1.5, 8, 28), magMat);
  magnet.rotation.z = Math.PI / 2; magnet.position.x = 50; rotorGroup.add(magnet);

  // ───────── 발전기 ─────────
  const gen = new THREE.Mesh(new THREE.CylinderGeometry(3.4, 3.4, 12, 40, 1, true), holo(amber, { alpha: 0.04, edge: 0.55 }));
  gen.rotation.z = Math.PI / 2; gen.position.set(50, AXIS_Y, 0); root.add(gen);
  const coilMat = new THREE.MeshBasicNodeMaterial();
  coilMat.colorNode = Fn(() => vec4(vec3(0.32, 0.15, 0.04).add(vec3(1.0, 0.8, 0.3).mul(U.gen).mul(sin(positionWorld.x.mul(2.0).sub(t.mul(6.0))).mul(0.3).add(0.5))), 1.0))();
  const coils = new THREE.InstancedMesh(new THREE.BoxGeometry(1.8, 0.22, 0.6), coilMat, 36);
  for (let k = 0; k < 36; k++) { const a = (k % 12) / 12 * Math.PI * 2, row = Math.floor(k / 12); const q = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(1, 0, 0), a); m4.compose(new THREE.Vector3(45.2 + row * 2.6 + 0.5, AXIS_Y + Math.cos(a) * 2.75, Math.sin(a) * 2.75), q, new THREE.Vector3(1, 1, 1)); coils.setMatrixAt(k, m4); }
  root.add(coils);
  // 자기력선 입자: 회전자와 함께 도는 두 개의 고리(좌·우 로브) — 단면에서 N극 → 고정자 → S극
  const fm = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
  {
    const i = instanceIndex, h = (k) => hash(i.add(k));
    const lobe = h(0).greaterThan(0.5).select(float(1.0), float(-1.0));
    const slice = floor_(h(1).mul(6.0));
    const phi = fract(h(2).add(t.mul(0.28))).mul(6.2831853);
    const cy = cos(phi).mul(2.3), cz = sin(phi).mul(2.3).add(lobe.mul(1.75));
    const x = float(46.2).add(slice.mul(1.4)).add(h(3).sub(0.5).mul(0.3));
    const th = U.spin;                                                                           // 회전자와 함께 회전
    const y = cy.mul(cos(th)).sub(cz.mul(sin(th))), z = cy.mul(sin(th)).add(cz.mul(cos(th)));
    fm.positionNode = vec3(x, y.add(AXIS_Y), z);
    fm.scaleNode = float(0.13).add(h(4).mul(0.1));
    fm.colorNode = varying(mix(vec3(0.3, 0.6, 1.0), vec3(1.0, 0.45, 0.3), step_(0.5, fract(phi.div(6.2831853)))).mul(U.gen).mul(0.9), 'vField');
    fm.opacityNode = smoothstep(0.5, 0.0, length(uv().sub(0.5))).pow(1.4);
  }
  const fieldLines = new THREE.Sprite(fm); fieldLines.count = 6000; fieldLines.frustumCulled = false; fieldLines.renderOrder = 9;
  root.add(fieldLines);
  // 유도 전류: 고정자 코일 주변을 도는 노란 점
  const im = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
  {
    const i = instanceIndex, h = (k) => hash(i.add(900 + k));
    const row = floor_(h(0).mul(3.0)), a = fract(h(1).add(t.mul(0.5).mul(U.spin.mul(0.0).add(1.0)))).mul(6.2831853);
    im.positionNode = vec3(float(45.7).add(row.mul(2.6)).add(h(2).mul(0.8)), cos(a).mul(2.95).add(AXIS_Y), sin(a).mul(2.95));
    im.scaleNode = float(0.18);
    im.colorNode = varying(vec3(1.0, 0.82, 0.3).mul(U.gen).mul(1.3), 'vCurrent');
    im.opacityNode = smoothstep(0.5, 0.0, length(uv().sub(0.5))).pow(1.3);
  }
  const current = new THREE.Sprite(im); current.count = 1800; current.frustumCulled = false; current.renderOrder = 9;
  root.add(current);

  // ───────── 복수기 / 변압기 ─────────
  const cond = new THREE.Mesh(new THREE.BoxGeometry(30, 4, 13), holo(teal, { alpha: 0.05, edge: 0.5 })); cond.position.set(25, -6.2, 0); root.add(cond);
  const trans = new THREE.Mesh(new THREE.BoxGeometry(7, 6, 6), holo(amber, { alpha: 0.07, edge: 0.7 })); trans.position.set(66, -3, 0); root.add(trans);

  // ───────── 송전선 / 송전탑 / 펄스 ─────────
  const lineEnd = LINE_X0 + LINE_SPAN * (LINE_N - 1);
  const towerParts = [
    ...[[-1.6, -1.6], [1.6, -1.6], [1.6, 1.6], [-1.6, 1.6]].map(([x, z]) => new THREE.CylinderGeometry(0.1, 0.22, LINE_Y + 8, 5).translate(x, (LINE_Y + 8) / 2 - 8, z)),
    new THREE.BoxGeometry(0.35, 0.35, 11).translate(0, LINE_Y, 0), new THREE.BoxGeometry(0.3, 0.3, 8.5).translate(0, LINE_Y - 5, 0), new THREE.BoxGeometry(0.3, 0.3, 6).translate(0, LINE_Y - 10, 0),
  ];
  const towerMat = new THREE.MeshBasicNodeMaterial();
  towerMat.colorNode = Fn(() => { const y = positionWorld.y; return vec4(vec3(0.1, 0.16, 0.24).add(vec3(0.3, 0.7, 1.0).mul(smoothstep(-8.0, 20.0, positionLocal.y)).mul(0.12)), 1.0); })();
  const towers = new THREE.InstancedMesh(mergeGeometries(towerParts), towerMat, LINE_N);
  for (let k = 0; k < LINE_N; k++) { m4.makeTranslation(LINE_X0 + LINE_SPAN * k, 0, 0); towers.setMatrixAt(k, m4); }
  towers.frustumCulled = false; root.add(towers);
  // 전선 3가닥(+ 처짐 없이 직선): 얇은 선
  const wirePts = [];
  const wires = [[0, 5.2, LINE_Y], [0, 0, LINE_Y - 5], [0, -3.0, LINE_Y - 10]];
  for (const [, z, y] of wires) { wirePts.push(new THREE.Vector3(66 + 2, 2, z), new THREE.Vector3(LINE_X0, y, z)); for (let k = 0; k < LINE_N - 1; k++) wirePts.push(new THREE.Vector3(LINE_X0 + LINE_SPAN * k, y, z), new THREE.Vector3(LINE_X0 + LINE_SPAN * (k + 1), y, z)); }
  const wireGeo = new THREE.BufferGeometry().setFromPoints(wirePts);
  const wireMat = new THREE.LineBasicNodeMaterial({ transparent: true, blending: THREE.AdditiveBlending, depthWrite: false });
  wireMat.colorNode = Fn(() => vec4(vec3(0.25, 0.65, 1.0).mul(0.4), 1.0))();
  const wiresLine = new THREE.LineSegments(wireGeo, wireMat); wiresLine.frustumCulled = false; root.add(wiresLine);
  // 송전 펄스: 위치 packet(0~1) 주변의 밝은 덩어리가 선을 따라 달린다
  const pm = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
  {
    const i = instanceIndex, h = (k) => hash(i.add(3000 + k));
    const wire = floor_(h(0).mul(2.999));
    const s = fract(h(1)), x = float(66).add(s.mul(lineEnd - 66));
    const wy = wire.equal(0.0).select(float(LINE_Y), wire.equal(1.0).select(float(LINE_Y - 5), float(LINE_Y - 10))), wz = wire.equal(0.0).select(float(5.2), wire.equal(1.0).select(float(0.0), float(-3.0)));
    pm.positionNode = vec3(x, wy.add(h(2).sub(0.5).mul(0.4)), wz.add(h(3).sub(0.5).mul(0.4)));
    pm.scaleNode = float(0.45).add(h(4).mul(0.8));
    const pk = exp(pow(s.sub(U.packet).div(0.012), 2.0).negate()).mul(U.packet.greaterThan(-0.5).select(float(1.0), float(0.0)));
    pm.colorNode = varying(vec3(1.0, 0.85, 0.35).mul(pk).mul(3.4).add(vec3(0.2, 0.5, 1.0).mul(0.05)), 'vPulse');
    pm.opacityNode = smoothstep(0.5, 0.0, length(uv().sub(0.5))).pow(1.3);
  }
  const pulses = new THREE.Sprite(pm); pulses.count = 30000; pulses.frustumCulled = false; pulses.renderOrder = 9;
  root.add(pulses);

  return {
    root, U, red, teal, primary, secondary, rotorGroup, flowPrimary, flowSecondary, vessel, sg, pump, prz, lineEnd,
    /** 터빈/발전기 회전각 갱신 */
    setSpin(a) { U.spin.value = a; rotorGroup.rotation.x = a; },
    setQuality(cap) {
      const k = Math.min(1, cap / 300000);
      flowPrimary.setCount(9000 * k); flowSecondary.setCount(9000 * k); photonSprite.count = Math.floor(7000 * Math.max(0.4, k)); fieldLines.count = Math.floor(6000 * Math.max(0.4, k)); pulses.count = Math.floor(30000 * Math.max(0.3, k));
    },
  };
}

// 작은 헬퍼(TSL 에 floor/step 이 이름 충돌하지 않도록 지역 정의)
import { floor as floor_, step as step_ } from 'three/tsl';
