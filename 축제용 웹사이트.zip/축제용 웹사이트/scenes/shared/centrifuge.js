// scenes/shared/centrifuge.js — Ch.5 원심분리기(개념도) + 캐스케이드 홀
//
//  UF₆ 기체를 고속 회전 통에 넣으면 무거운 U-238 쪽 분자는 벽 쪽으로, 가벼운 U-235 쪽 분자는 중심 쪽으로 조금 더 모인다.
//   · 한 대로는 농도 차이가 아주 작다 → 수천 대 이상을 직렬·병렬로 이어 단계적으로 농축한다(캐스케이드). 이 홀이 그것을 형상화한 것.
//   · 입자 비율은 시각화를 위해 과장했다(실제 U-235 는 0.7%). 화면에도 "개념도"로 표기한다.
//  출처: UF₆ 분자 질량 — ²³⁵UF₆ ≈ 349.03, ²³⁸UF₆ ≈ 352.04 (차이 약 0.9%) [원자 질량: U-235 235.0439, U-238 238.0508, F 18.9984].
//  좌표: 대표 원심분리기(히어로)가 원점. 열(캐스케이드 단계)은 +x 로, 행(병렬 라인)은 −z 로 늘어선다.

import * as THREE from 'three/webgpu';
import {
  Fn, float, vec3, vec4, uniform, uv, instanceIndex, instanceColor, hash, normalWorld, positionWorld, positionGeometry, cameraPosition,
  normalize, length, dot, mix, smoothstep, clamp, pow, exp, sin, cos, abs, fract, atan, step, varying,
} from 'three/tsl';
import { shade } from './studio.js';

export const CENT = { R: 1.6, H: 7, COLS: 16, ROWS: 6, DX: 4.4, DZ: -6.5 };
const TAU = Math.PI * 2;

/** 단계(열)에 따른 농축 색: 청회색(0.7%) → 주황(3~5%) */
const stageColor = (f) => new THREE.Color(0.32, 0.5, 0.78).lerp(new THREE.Color(1.0, 0.5, 0.1), Math.pow(f, 0.8));

export function makeCentrifuge(ctx) {
  const group = new THREE.Group();
  const t = ctx.u.time;
  const uSep = uniform(0.0), uVis = uniform(1.0), uHall = uniform(1.0);
  const { R, H, COLS, ROWS, DX, DZ } = CENT;

  // ── 히어로: 단면(투명) 원심분리기 ──
  const hero = new THREE.Group(); group.add(hero);
  const holo = (alpha, edge, color) => {
    const m = new THREE.MeshBasicNodeMaterial({ transparent: true, depthWrite: false, side: THREE.DoubleSide });
    m.colorNode = Fn(() => {
      const n = normalize(normalWorld), V = normalize(cameraPosition.sub(positionWorld));
      const f = pow(float(1.0).sub(abs(dot(n, V))), 2.2);
      return vec4(vec3(color.r, color.g, color.b).mul(f.mul(edge).add(0.08)), f.mul(edge).add(alpha));
    })();
    return m;
  };
  const casing = new THREE.Mesh(new THREE.CylinderGeometry(R, R, H, 56, 1, true), holo(0.04, 0.8, new THREE.Color(0.35, 0.8, 1.0))); hero.add(casing);
  // 회전하는 로터(줄무늬가 돌아가며 고속 회전을 보여 준다)
  const rotorMat = new THREE.MeshBasicNodeMaterial({ transparent: true, depthWrite: false, side: THREE.DoubleSide, blending: THREE.AdditiveBlending });
  rotorMat.colorNode = Fn(() => {
    const a = atan(positionGeometry.z, positionGeometry.x).div(TAU).mul(10.0).add(t.mul(1.7)), stripe = smoothstep(0.42, 0.5, abs(fract(a).sub(0.5)));
    const band = smoothstep(0.0, 0.35, positionGeometry.y.add(H * 0.5)).mul(smoothstep(0.0, 0.35, float(H * 0.5).sub(positionGeometry.y)));
    return vec4(vec3(0.3, 0.7, 1.0).mul(stripe.mul(0.5).add(0.05)).mul(band), 1.0);
  })();
  hero.add(new THREE.Mesh(new THREE.CylinderGeometry(R * 0.94, R * 0.94, H * 0.96, 56, 1, true), rotorMat));
  const capMat = new THREE.MeshBasicNodeMaterial();
  capMat.colorNode = Fn(() => {
    const n = normalize(normalWorld), V = normalize(cameraPosition.sub(positionWorld));
    const ring = smoothstep(0.1, 0.0, abs(length(positionGeometry.xz).sub(R * 0.9))).mul(0.8);
    return vec4(shade(n, V, vec3(0.5, 0.52, 0.56), { metal: 0.9, rough: 0.3 }).add(vec3(0.2, 0.7, 1.0).mul(ring)), 1.0);
  })();
  for (const s of [-1, 1]) { const c = new THREE.Mesh(new THREE.CylinderGeometry(R * 1.06, R * 1.06, 0.35, 56), capMat); c.position.y = s * (H / 2 + 0.17); hero.add(c); }
  const axis = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, H, 10), new THREE.MeshBasicNodeMaterial({ color: 0x9fe0ff, transparent: true, opacity: 0.35, blending: THREE.AdditiveBlending, depthWrite: false }));
  hero.add(axis);

  // ── 입자: 무거운 U-238(청회색)은 벽 쪽으로, 가벼운 U-235(주황)는 중심 쪽으로 ──
  const NP = 9000, i = instanceIndex, h = (k) => hash(i.add(k * 7919));
  const pm = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
  const light = step(h(1), 0.17);                                        // 17% 가 U-235 (개념도 과장)
  const rF = mix(mix(1.0, 1.42, h(2)), mix(0.05, 0.62, h(2)), light);    // 최종 반지름
  const r = mix(h(3).mul(1.45), rF, uSep);
  const ang = h(4).mul(TAU).add(t.mul(mix(5.4, 5.4, light)));
  const y = fract(h(5).add(t.mul(mix(-0.05, 0.075, light)))).mul(H * 0.94).sub(H * 0.47);
  pm.positionNode = vec3(cos(ang).mul(r), y, sin(ang).mul(r));
  pm.scaleNode = h(6).mul(0.05).add(0.04).mul(mix(1.0, 1.35, light));
  pm.colorNode = varying(mix(vec3(0.42, 0.62, 1.0).mul(1.5), vec3(1.0, 0.5, 0.1).mul(2.0), light).mul(uVis), 'vCentCol');
  pm.opacityNode = smoothstep(0.5, 0.0, length(uv().sub(0.5))).pow(1.4);
  const particles = new THREE.Sprite(pm); particles.count = NP; particles.frustumCulled = false; particles.renderOrder = 6; hero.add(particles);

  // ── 위·아래 배출관 (주황 = 농축된 흐름이 위로, 청회색 = 감손된 흐름이 아래로) ──
  const pipe = (a, c, b, color) => {
    const curve = new THREE.QuadraticBezierCurve3(a, c, b);
    const g = new THREE.Mesh(new THREE.TubeGeometry(curve, 24, 0.13, 10, false), holo(0.08, 0.9, color)); hero.add(g);
    const fm = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
    const A = vec3(a.x, a.y, a.z), C = vec3(c.x, c.y, c.z), B = vec3(b.x, b.y, b.z), hh = hash(instanceIndex.add(31 + a.y * 3.0)), s = fract(hh.add(t.mul(0.35)));
    const om = float(1.0).sub(s);
    fm.positionNode = A.mul(om.mul(om)).add(C.mul(om.mul(s).mul(2.0))).add(B.mul(s.mul(s)));
    fm.scaleNode = hash(instanceIndex.add(5)).mul(0.07).add(0.06);
    fm.colorNode = vec3(color.r, color.g, color.b).mul(2.2).mul(uVis);
    fm.opacityNode = smoothstep(0.5, 0.0, length(uv().sub(0.5))).pow(1.3);
    const sp = new THREE.Sprite(fm); sp.count = 90; sp.frustumCulled = false; sp.renderOrder = 6; hero.add(sp);
  };
  pipe(new THREE.Vector3(0, H / 2 + 0.2, 0), new THREE.Vector3(0.4, H / 2 + 1.6, 0), new THREE.Vector3(DX * 0.5, H / 2 + 1.4, 0), new THREE.Color(1.0, 0.55, 0.15));
  pipe(new THREE.Vector3(0, -H / 2 - 0.2, 0), new THREE.Vector3(-0.4, -H / 2 - 1.2, 0), new THREE.Vector3(-DX * 0.5, -H / 2 - 1.1, 0), new THREE.Color(0.4, 0.65, 1.0));

  // ── 캐스케이드 홀: 같은 원심분리기를 줄지어 세우고, 단계가 오를수록 링 색이 청회색 → 주황 ──
  const N = COLS * ROWS - 1;
  const hallGeo = new THREE.CylinderGeometry(R, R, H, 28, 1, false);
  const hallMat = new THREE.MeshBasicNodeMaterial({ transparent: true });
  hallMat.colorNode = Fn(() => {
    const n = normalize(normalWorld), V = normalize(cameraPosition.sub(positionWorld));
    const yy = positionGeometry.y, ring = smoothstep(0.16, 0.0, abs(abs(yy).sub(H * 0.34)));
    const core = shade(n, V, vec3(0.62, 0.65, 0.7), { metal: 0.85, rough: 0.4, ambient: 0.1 }).mul(1.0).add(vec3(0.03, 0.06, 0.12));
    return vec4(core.add(instanceColor.mul(ring).mul(2.6)), uHall);
  })();
  const hall = new THREE.InstancedMesh(hallGeo, hallMat, N), m4 = new THREE.Matrix4(), col = new THREE.Color();
  const pipeGeo = new THREE.CylinderGeometry(0.09, 0.09, DX - 1.7, 8, 1, false); pipeGeo.rotateZ(Math.PI / 2);
  const pipeMat = new THREE.MeshBasicNodeMaterial({ transparent: true });
  pipeMat.colorNode = Fn(() => {
    const pulse = smoothstep(0.55, 1.0, sin(positionWorld.x.mul(1.3).sub(t.mul(3.0)).add(positionWorld.z.mul(0.7))).mul(0.5).add(0.5));
    return vec4(instanceColor.mul(pulse.mul(2.4).add(0.8)), uHall);
  })();
  const pipes = new THREE.InstancedMesh(pipeGeo, pipeMat, (COLS - 1) * ROWS);
  let k = 0, pk = 0;
  for (let j = 0; j < ROWS; j++) for (let c = 0; c < COLS; c++) {
    const f = c / (COLS - 1);
    if (!(c === 0 && j === 0)) { m4.makeTranslation(c * DX, 0, j * DZ); hall.setMatrixAt(k, m4); hall.setColorAt(k, stageColor(f)); k++; }
    if (c < COLS - 1) { m4.makeTranslation(c * DX + DX / 2, H / 2 + 0.85, j * DZ); pipes.setMatrixAt(pk, m4); pipes.setColorAt(pk, stageColor((c + 0.5) / (COLS - 1))); pk++; }
  }
  hall.frustumCulled = false; pipes.frustumCulled = false; group.add(hall, pipes);
  // 홀 바닥: 격자선
  const floorMat = new THREE.MeshBasicNodeMaterial();
  floorMat.colorNode = Fn(() => {
    const px = positionGeometry.x.add(30.0), pz = positionGeometry.y.negate().sub(16.0);          // 홀 로컬 좌표(바닥판은 x축으로 −90° 눕힌 평면)
    const gx = abs(fract(px.div(DX).add(0.5)).sub(0.5)), gz = abs(fract(pz.div(-DZ).add(0.5)).sub(0.5));
    const line = smoothstep(0.02, 0.0, min2(gx.mul(DX), gz.mul(-DZ)));
    const d = length(vec3(px.sub(30.0), 0.0, pz.add(16.0))).div(70.0);
    return vec4(vec3(0.012, 0.016, 0.024).add(vec3(0.1, 0.35, 0.6).mul(line).mul(0.25)).mul(smoothstep(1.0, 0.3, d)), 1.0);
  })();
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(200, 140), floorMat); floor.rotation.x = -Math.PI / 2; floor.position.set(30, -H / 2 - 0.35, -16); group.add(floor);
  return { group, hero, uSep, uVis, uHall, N, particles };
}
const min2 = (a, b) => a.min(b);
