// scenes/shared/nucleus.js — 레이마칭 SDF 원자핵(메타볼) + 핵분열 효과(충격파 링·감마선·섬광)
//
//  · 핵은 "액체방울" 모델: 구 두 개를 smooth-min(부드러운 합집합)으로 이어 붙인 거리장(SDF).
//      - 두 구가 겹쳐 있으면 하나의 둥근 핵(U-236), 벌어지면 가운데가 잘록해지는 아령 모양(목, neck), 더 벌어지면 smooth-min 이 끊겨 두 조각.
//      - 흡수되는 중성자도 SDF 구 하나로 합쳐 넣어, 표면에 박히며 녹아드는 모습을 낸다.
//  · 표면 질감: worley(셀) 노이즈로 "핵자(양성자=주황, 중성자=청록) 알갱이" 무늬와 알갱이 사이의 어두운 골을 만든다.
//  · 바깥의 은은한 빛무리(halo)는 광선이 표면을 "스치고 지나간 최소 거리"로 계산 — 별도 지오메트리 없이 발광한다.
//  · 경계 구(BackSide)를 그려서 그 안에서만 레이마칭한다 (카메라가 구 안에 있어도 동작).
//  좌표: 핵 중심 = u.center (월드). 분열 축 = X.
//  출처(과학): 액체방울 모형(Bohr–Wheeler 1939), U-235+n → U-236* → Ba-141 + Kr-92 + 3n (대표 분열 채널), 분열당 ≈200 MeV (IAEA).

import * as THREE from 'three/webgpu';
import {
  Fn, float, int, vec3, vec4, uniform, If, Loop, Break, cameraPosition, positionWorld, normalize, length, dot, max, min, abs, mix,
  smoothstep, clamp, pow, exp, sqrt, step, select, hash, instanceIndex, uv, varying, mx_noise_float, mx_worley_noise_float,
} from 'three/tsl';
import { sphereDir } from '../../engine/tsl.js';

const BOUND_R = 20;
const MAX_STEPS = 64;

export function makeNucleus(ctx) {
  const root = new THREE.Group();
  const t = ctx.u.time;
  const u = {
    center: uniform(new THREE.Vector3(0, 0, 0)),
    steps: uniform(64),
    c1x: uniform(0), c2x: uniform(0), r1: uniform(3.0), r2: uniform(3.0), k: uniform(1.4),
    wob: uniform(0),
    nPos: uniform(new THREE.Vector3(-60, 0, 0)), nR: uniform(0.0001), nCol: uniform(new THREE.Vector3(0.2, 0.5, 1.0)),
    energy: uniform(0), heat: uniform(0), haloGain: uniform(0.6), haloMix: uniform(0),
    gain: uniform(1.0),
  };

  // smooth-min (다항식): k 가 클수록 두 형태가 부드럽게 이어진다
  const smin = (a, b, k) => { const h = max(k.sub(abs(a.sub(b))), 0.0).div(k); return min(a, b).sub(h.mul(h).mul(k).mul(0.25)); };
  const sdf = (p) => {
    const d1 = length(p.sub(vec3(u.c1x, 0.0, 0.0))).sub(u.r1);
    const d2 = length(p.sub(vec3(u.c2x, 0.0, 0.0))).sub(u.r2);
    let d = smin(d1, d2, u.k);
    d = smin(d, length(p.sub(u.nPos)).sub(u.nR), float(0.55));
    return d.sub(mx_noise_float(p.mul(0.85).add(vec3(0.0, 0.0, t.mul(0.9)))).mul(u.wob).mul(0.34));       // 표면 출렁임
  };

  const mat = new THREE.MeshBasicNodeMaterial({ transparent: true, depthWrite: false, depthTest: false, side: THREE.BackSide });
  mat.colorNode = Fn(() => {
    const ro = cameraPosition.sub(u.center);
    const rd = normalize(positionWorld.sub(cameraPosition));
    const b = dot(ro, rd);
    const h = b.mul(b).sub(dot(ro, ro).sub(BOUND_R * BOUND_R));
    const sq = sqrt(max(h, 0.0));
    const tt = max(b.negate().sub(sq), 0.0).toVar();
    const t1 = b.negate().add(sq);
    const hit = float(0.0).toVar();
    const minD = float(100.0).toVar();
    Loop({ start: int(0), end: int(MAX_STEPS), type: 'int', condition: '<' }, ({ i }) => {
      If(float(i).greaterThanEqual(u.steps), () => { Break(); });
      const d = sdf(ro.add(rd.mul(tt)));
      minD.assign(min(minD, d));
      If(d.lessThan(0.004), () => { hit.assign(1.0); Break(); });
      tt.addAssign(max(d.mul(0.85), 0.01));
      If(tt.greaterThan(t1), () => { Break(); });
    });

    const P = ro.add(rd.mul(tt));
    // 법선: 4점 사면체 기울기
    const e = float(0.012);
    const k0 = vec3(1, -1, -1), k1 = vec3(-1, -1, 1), k2 = vec3(-1, 1, -1), k3 = vec3(1, 1, 1);
    const n = normalize(k0.mul(sdf(P.add(k0.mul(e)))).add(k1.mul(sdf(P.add(k1.mul(e))))).add(k2.mul(sdf(P.add(k2.mul(e))))).add(k3.mul(sdf(P.add(k3.mul(e))))));
    const V = rd.negate();
    const lam = clamp(dot(n, normalize(vec3(-0.45, 0.8, 0.55))), 0.0, 1.0);
    const fres = pow(float(1.0).sub(clamp(dot(n, V), 0.0, 1.0)), 3.0);

    // 핵자 알갱이: 셀 id 로 양성자/중성자 색, 셀 중심까지 거리로 알갱이 입체감
    const id = mx_worley_noise_float(P.mul(1.05), 1.0, 1);
    const dist = mx_worley_noise_float(P.mul(1.05), 1.0, 0);
    const lump = pow(smoothstep(0.7, 0.1, dist), 1.2);                           // 핵자 사이의 어두운 골이 뚜렷하게
    const idr = id.mul(7.7).add(0.31).fract();                                  // 이웃 셀과 색이 덩어리지지 않게 한 번 더 섞는다
    let base = mix(vec3(0.1, 0.85, 0.8), vec3(1.0, 0.5, 0.14), step(0.5, idr));
    // 흡수 중인 중성자 부분은 중성자 색(느린 중성자=파랑 / 분열 후 빠른 중성자=빨강)
    const dn = length(P.sub(u.nPos)).sub(u.nR);
    base = mix(base, u.nCol, smoothstep(0.35, 0.0, dn).mul(step(0.01, u.nR)));
    let col = base.mul(lam.mul(0.9).add(0.3)).mul(lump.mul(0.8).add(0.45)).add(vec3(0.35, 0.65, 1.0).mul(fres).mul(0.55));
    // 목(neck)의 에너지 발광 + 분열 직후 열기
    const mid = u.c1x.add(u.c2x).mul(0.5);
    const neck = exp(pow(P.x.sub(mid).div(1.3), 2.0).negate()).mul(u.energy);
    col = col.add(vec3(1.0, 0.82, 0.55).mul(neck.mul(1.9).add(u.heat.mul(lump.mul(0.8).add(0.3)).mul(1.1))));
    col = col.mul(u.gain);

    // 빛무리: 표면을 스친 최소 거리가 작을수록 밝다
    const halo = exp(max(minD, 0.0).mul(-1.6)).mul(u.haloGain);
    const haloCol = mix(vec3(0.3, 0.7, 1.0), vec3(1.0, 0.55, 0.2), clamp(u.haloMix.add(u.energy.mul(0.6)), 0.0, 1.0)).mul(1.2);
    const isHit = hit.greaterThan(0.5);
    return vec4(select(isHit, col, haloCol), select(isHit, float(1.0), clamp(halo.mul(0.85), 0.0, 1.0)));
  })();
  const bound = new THREE.Mesh(new THREE.SphereGeometry(BOUND_R, 40, 28), mat);
  bound.renderOrder = 5; bound.frustumCulled = false;
  root.add(bound);

  // ───────── 핵분열 효과 ─────────
  const uTau = uniform(-1.0);                         // 분열 후 월드 경과 시간(초). 0 미만 = 분열 전
  const uOrigin = uniform(new THREE.Vector3());       // 분열 위치(목의 중심)
  // ① 충격파 링 (분열 축 X 에 수직인 평면)
  const ringMat = new THREE.MeshBasicNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide });
  ringMat.colorNode = Fn(() => {
    const r = length(uv().sub(0.5)).mul(2.0);
    const tau = max(uTau, 0.0);
    const band = exp(pow(r.sub(0.82).div(0.07), 2.0).negate());
    return vec4(vec3(0.75, 0.6, 1.0).mul(band).mul(exp(tau.mul(-1.8))).mul(step(0.0, uTau)).mul(2.2), 1.0);
  })();
  const ring = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), ringMat);
  ring.rotation.y = Math.PI / 2; ring.renderOrder = 8; ring.visible = false;
  root.add(ring);
  // ② 중심 섬광 구
  const flashMat = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
  flashMat.colorNode = Fn(() => {
    const r = length(uv().sub(0.5)).mul(2.0);
    const tau = max(uTau, 0.0);
    return vec4(mix(vec3(1.0, 0.7, 0.35), vec3(1.0, 1.0, 1.0), exp(r.mul(-7.0))).mul(exp(r.mul(-3.6))).mul(smoothstep(1.0, 0.5, r)).mul(exp(tau.mul(-2.2))).mul(step(0.0, uTau)).mul(1.5), 1.0);
  })();
  const flash = new THREE.Sprite(flashMat); flash.scale.set(22, 22, 1); flash.renderOrder = 9; flash.visible = false;
  root.add(flash);
  // ③ 감마선: 중심에서 사방으로 쏘아지는 가는 빛줄기 입자
  const gMat = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
  {
    const i = instanceIndex;
    const d = sphereDir(hash(i), hash(i.add(7)));
    const sp = hash(i.add(13)).mul(70.0).add(35.0);
    const tau = max(uTau, 0.0);
    gMat.positionNode = uOrigin.add(d.mul(sp).mul(tau));
    gMat.scaleNode = float(0.5).add(hash(i.add(19)).mul(0.5));
    gMat.colorNode = varying(vec3(0.7, 0.62, 1.0).mul(exp(tau.mul(-1.3))).mul(step(0.0, uTau)).mul(hash(i.add(23)).mul(1.5).add(0.6)), 'vGamma');
    gMat.opacityNode = smoothstep(0.5, 0.0, length(uv().sub(0.5))).pow(1.3);
  }
  const gamma = new THREE.Sprite(gMat); gamma.count = 2400; gamma.frustumCulled = false; gamma.renderOrder = 9; gamma.visible = false;
  root.add(gamma);

  return {
    root, u, bound, ring, flash, gamma, uTau, uOrigin,
    /** 분열 효과 갱신: tau = 분열 이후 월드 시간(초), <0 이면 숨김. origin = 분열 위치(월드) */
    setFission(tau, origin) {
      const on = tau >= 0;
      ring.visible = flash.visible = gamma.visible = on;
      uTau.value = tau; uOrigin.value.copy(origin);
      if (on) { ring.position.copy(origin); flash.position.copy(origin); const R = 2.5 + 26 * Math.pow(tau, 0.62); ring.scale.set(R, R, R); }
    },
    setCenter(v) { u.center.value.copy(v); bound.position.copy(v); },
  };
}
