// scenes/shared/comet.js — 혜성(핵·코마·이온 꼬리·먼지 꼬리)과 행성(수성·금성)
//
//  혜성 로컬 좌표: +X = 진행 방향, 꼬리는 −X(뒤쪽)로 길게 늘어난다 (연출: 꼬리가 뒤로 휘날림).
//  꼬리 입자는 전부 셰이더 안에서 계산(상태 없음): 각 입자가 s∈[0,1) 위치를 시간에 따라 꼬리를 따라 흘러간다.
//    이온 꼬리 = 푸른색·가늘고 곧음 / 먼지 꼬리 = 노란 흰색·넓고 휘어짐 (실제 혜성의 두 꼬리 구조를 반영)

import * as THREE from 'three/webgpu';
import {
  Fn, float, vec2, vec3, vec4, uniform, uv, instanceIndex, positionLocal, normalLocal, normalWorld, positionWorld, cameraPosition,
  normalize, length, dot, mix, smoothstep, clamp, pow, exp, hash, varying, mx_noise_float, mx_worley_noise_float, max,
} from 'three/tsl';
import { fbm3 } from '../../engine/tsl.js';

// ───────────────────────── 혜성 ─────────────────────────
export function makeComet(ctx) {
  const t = ctx.u.time;
  const root = new THREE.Group();
  const uFade = uniform(1.0);            // 꼬리·코마 전체 밝기 (카메라가 혜성과 하나가 될 때 서서히 줄인다)

  // 핵: 울퉁불퉁한 어두운 바위 + 균열에서 새어 나오는 주황 열
  const nucMat = new THREE.MeshBasicNodeMaterial();
  nucMat.positionNode = positionLocal.add(normalLocal.mul(fbm3(positionLocal.mul(0.85)).mul(1.15)));
  nucMat.colorNode = Fn(() => {
    const p = positionLocal.mul(0.7);
    const nW = normalize(normalWorld);
    const lam = clamp(dot(nW, vec3(-1.0, 0.1, 0.0)), 0.0, 1.0);                   // 태양은 −X 쪽
    const rock = fbm3(p.mul(3.0)).mul(0.5).add(0.55);
    const crack = smoothstep(0.62, 0.85, fbm3(p.mul(2.2).add(4.0)).mul(0.5).add(0.5)).mul(mx_worley_noise_float(p.mul(4.0)).oneMinus().pow(3.0));
    const view = normalize(cameraPosition.sub(positionWorld));
    const rim = pow(float(1.0).sub(clamp(dot(nW, view), 0.0, 1.0)), 2.2);
    const base = vec3(0.17, 0.14, 0.12).mul(rock).mul(lam.mul(1.5).add(0.22));
    return vec4(base.add(vec3(1.0, 0.45, 0.12).mul(crack).mul(1.6)).add(vec3(0.35, 0.6, 1.0).mul(rim).mul(0.45)), 1.0);   // 푸른 코마가 비추는 림라이트
  })();
  const nucleus = new THREE.Mesh(new THREE.IcosahedronGeometry(3.0, 5), nucMat);
  nucleus.name = 'comet-nucleus';
  root.add(nucleus);

  // 코마(핵 주변의 푸른 가스 구름)
  const comaMat = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
  comaMat.colorNode = Fn(() => {
    const r = length(uv().sub(0.5)).mul(2.0);
    const g = exp(r.mul(-3.6)).mul(smoothstep(1.0, 0.7, r));
    return vec4(mix(vec3(0.55, 0.8, 1.0), vec3(1.0, 1.0, 1.0), exp(r.mul(-9.0))).mul(g).mul(0.9).mul(uFade), 1.0);
  })();
  const coma = new THREE.Sprite(comaMat);
  coma.scale.set(24, 24, 1); coma.renderOrder = 5;
  root.add(coma);

  // 꼬리 공통 생성기: 인스턴스 번호만으로 위치/색을 만든다
  const tail = ({ N, L, w0, w1, curve, speed, size, color, bright, seed }) => {
    const mat = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
    const i = instanceIndex;
    const h = (k) => hash(i.add(seed + k));
    const s = h(0).add(t.mul(h(1).mul(0.5).add(0.75).mul(speed))).fract();               // 꼬리를 따라 흐르는 위치 0~1
    const spread = h(2).add(h(3)).add(h(4)).sub(1.5).mul(1.3333);                          // 가우시안 비슷한 분포 (-2~2)
    const spread2 = h(5).add(h(6)).add(h(7)).sub(1.5).mul(1.3333);
    const width = float(w0).add(s.mul(w1));
    const turb = vec3(mx_noise_float(vec3(s.mul(7.0), t.mul(0.6), h(8).mul(3.0))), mx_noise_float(vec3(s.mul(7.0).add(9.0), t.mul(0.5), h(9).mul(3.0))), 0.0).mul(s.mul(s).mul(4.0));
    const pos = vec3(s.mul(L).negate(), spread.mul(width).add(s.mul(s).mul(curve)), spread2.mul(width)).add(turb);
    mat.positionNode = pos;
    mat.scaleNode = float(size).mul(s.mul(1.4).add(0.6)).mul(h(10).mul(0.8).add(0.6));
    const fade = pow(float(1.0).sub(s), 1.7);
    mat.colorNode = varying(mix(vec3(1.0, 1.0, 1.0), color, smoothstep(0.0, 0.18, s)).mul(fade).mul(bright).mul(uFade), `vTail${seed}`);
    mat.opacityNode = smoothstep(0.5, 0.0, length(uv().sub(0.5))).pow(1.5);
    const sp = new THREE.Sprite(mat);
    sp.count = N; sp.frustumCulled = false; sp.renderOrder = 4;
    return sp;
  };
  const ion = tail({ N: 16000, L: 300, w0: 0.5, w1: 5.5, curve: 0.0, speed: 0.34, size: 1.2, color: vec3(0.2, 0.45, 1.0), bright: 0.11, seed: 100 });
  const dust = tail({ N: 12000, L: 200, w0: 1.0, w1: 14.0, curve: 34.0, speed: 0.2, size: 2.6, color: vec3(1.0, 0.86, 0.62), bright: 0.07, seed: 500 });
  root.add(ion, dust);

  return { root, nucleus, coma, ion, dust, uFade };
}

// ───────────────────────── 행성(수성·금성) ─────────────────────────
function planetMaterial(kind, sunDirW) {
  const mat = new THREE.MeshBasicNodeMaterial();
  mat.colorNode = Fn(() => {
    const p = normalize(positionLocal);
    const nW = normalize(normalWorld);
    const lam = clamp(dot(nW, sunDirW), 0.0, 1.0);
    let albedo;
    if (kind === 'mercury') {
      const crater = mx_worley_noise_float(p.mul(9.0)).oneMinus().pow(2.5);
      const rough = fbm3(p.mul(6.0)).mul(0.5).add(0.5);
      albedo = vec3(0.42, 0.39, 0.36).mul(rough.mul(0.6).add(0.55)).mul(float(1.0).sub(crater.mul(0.45)));
    } else {
      const swirl = fbm3(p.mul(3.2).add(vec3(fbm3(p.mul(1.6)).mul(1.6), 0.0, 0.0))).mul(0.5).add(0.5);
      albedo = mix(vec3(0.72, 0.58, 0.32), vec3(0.95, 0.85, 0.6), swirl);
    }
    const view = normalize(cameraPosition.sub(positionWorld));
    const rim = pow(float(1.0).sub(clamp(dot(nW, view), 0.0, 1.0)), 3.0).mul(0.18).mul(kind === 'venus' ? 1.6 : 0.6);
    return vec4(albedo.mul(lam.mul(1.5).add(0.015)).add(vec3(1.0, 0.8, 0.5).mul(rim).mul(lam.add(0.2))), 1.0);
  })();
  return mat;
}

/** 수성·금성: 오프닝 비행 경로 옆에 놓인 두 행성 (연출용 크기/위치) */
export function makePlanets(ctx) {
  const root = new THREE.Group();
  const defs = [
    { kind: 'mercury', r: 12, pos: new THREE.Vector3(1000, -8, -58) },
    { kind: 'venus', r: 21, pos: new THREE.Vector3(1600, 6, 88) },
  ];
  const planets = {};
  for (const d of defs) {
    const sunDir = vec3(...d.pos.clone().normalize().negate().toArray());   // 행성에서 태양(원점)을 향하는 방향
    const m = new THREE.Mesh(new THREE.SphereGeometry(d.r, 96, 64), planetMaterial(d.kind, sunDir));
    m.position.copy(d.pos); m.name = d.kind;
    root.add(m); planets[d.kind] = m;
  }
  return { root, planets };
}
