// scenes/shared/flow.js — 경로를 따라 흐르는 입자 (Ch.6 냉각수·증기·송전 펄스에 공통)
//
//  makePath(points, closed) : Catmull-Rom 곡선을 호 길이 균등으로 1024점 샘플링해 DataTexture 에 담는다 (CPU 1회)
//  makeFlow(ctx, {...})     : 각 입자가 경로 위 위치 s∈[0,1) 를 시간에 따라 전진 — 상태 없음(셰이더 안에서 계산)
//     · 경로 텍스처를 정점 셰이더에서 읽어 위치/접선을 얻고, 접선에 수직인 관(튜브) 단면에 흩뿌려 배관 속을 흐르는 모습을 만든다.
//     · "커브 노이즈로 흐르는 입자" 요구 사항: 관 단면 오프셋에 시간에 따라 변하는 노이즈를 더해 난류 느낌을 낸다.
//  텍스처 샘플링은 NearestFilter(1024칸)로 — float 텍스처 선형 필터 지원 여부와 무관하게 두 백엔드에서 동작한다.

import * as THREE from 'three/webgpu';
import {
  float, vec2, vec3, uniform, uv, instanceIndex, hash, texture, normalize, length, mix, smoothstep, pow, sin, cos, fract, floor,
  varying, mx_noise_float, cross, max,
} from 'three/tsl';

const RES = 1024;

export function makePath(points, closed = false) {
  const curve = new THREE.CatmullRomCurve3(points.map((p) => (p.isVector3 ? p : new THREE.Vector3(...p))), closed, 'centripetal');
  const pts = curve.getSpacedPoints(RES - 1);
  const data = new Float32Array(RES * 4);
  pts.forEach((p, i) => { data[i * 4] = p.x; data[i * 4 + 1] = p.y; data[i * 4 + 2] = p.z; data[i * 4 + 3] = 1; });
  const tex = new THREE.DataTexture(data, RES, 1, THREE.RGBAFormat, THREE.FloatType);
  tex.minFilter = tex.magFilter = THREE.NearestFilter; tex.generateMipmaps = false; tex.needsUpdate = true;
  return { curve, tex, length: curve.getLength() };
}

/**
 * @param o.path    makePath 결과
 * @param o.count   입자 수
 * @param o.color   THREE.Color (HDR 곱은 bright 로)
 * @param o.speed   경로를 도는 속도 (경로 전체 길이 대비 초당 비율, 예: 0.08)
 * @param o.radius  관 반지름(월드 단위)
 * @param o.size    입자 크기
 * @param o.bright  밝기 배수
 * @param o.range   [s0, s1] 경로 중 일부 구간만 사용 (0~1)
 */
export function makeFlow(ctx, { path, count = 4000, color = new THREE.Color(1, 0.4, 0.15), speed = 0.08, radius = 0.4, size = 0.22, bright = 0.6, range = [0, 1], seed = 0 }) {
  const t = ctx.u.time;
  const uAlpha = uniform(1.0), uSpeed = uniform(speed), uRadius = uniform(radius);
  const m = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
  const i = instanceIndex;
  const h = (k) => hash(i.add(seed * 131 + k));
  const phase = h(0).add(t.mul(uSpeed).mul(h(1).mul(0.5).add(0.75)));
  const s = fract(phase).mul(range[1] - range[0]).add(range[0]);
  const f = s.mul(RES - 1.0);
  const i0 = floor(f);
  const at = (idx) => texture(path.tex, vec2(idx.add(0.5).div(RES), 0.5)).level(0).xyz;
  const p0 = at(i0), p1 = at(max(i0.add(3.0), 0.0).min(RES - 1.0));
  const T = normalize(p1.sub(p0).add(vec3(1e-4, 0.0, 0.0)));
  const side = normalize(cross(T, vec3(0.0, 1.0, 0.001)));
  const up2 = cross(side, T);
  const ang = h(2).mul(6.2831853), rr = pow(h(3), 0.6).mul(uRadius);
  const turb = vec3(mx_noise_float(vec3(s.mul(9.0), t.mul(0.8), h(4).mul(7.0))), mx_noise_float(vec3(s.mul(9.0).add(5.0), t.mul(0.7), h(5).mul(7.0))), 0.0).mul(uRadius).mul(0.45);
  m.positionNode = p0.add(side.mul(cos(ang).mul(rr).add(turb.x))).add(up2.mul(sin(ang).mul(rr).add(turb.y)));
  m.scaleNode = float(size).mul(h(6).mul(0.7).add(0.65));
  const flick = sin(t.mul(9.0).add(h(7).mul(30.0))).mul(0.18).add(0.82);
  m.colorNode = varying(vec3(color.r, color.g, color.b).mul(flick).mul(bright).mul(uAlpha), `vFlow${seed}`);
  m.opacityNode = smoothstep(0.5, 0.0, length(uv().sub(0.5))).pow(1.4);
  const sprite = new THREE.Sprite(m);
  sprite.count = count; sprite.frustumCulled = false; sprite.renderOrder = 7;
  return { sprite, uAlpha, uSpeed, uRadius, setCount(n) { sprite.count = Math.max(100, Math.min(count, n | 0)); } };
}
