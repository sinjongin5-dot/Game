// scenes/shared/city.js — 서울 로컬 월드: 야경 도시(점 불빛 수십만 개) + 한강 + 산 + 구름층 + 충격파
//
//  로컬 좌표: 1 유닛 = 10 m. 원점 = 시청 앞(충돌 지점), +x = 동, +z = 남, +y = 위.
//  지구 구(球)에서 이 월드로 "구름 속에서" 교체된다 (거리 스케일이 10^5 배 다르므로 구름·화염이 가려 주는 순간에 바꿈).
//  ※ 실제 지도가 아니라 "서울처럼 보이는" 연출용 모델이다: 한강 경로·주요 산·강남/여의도 부도심의 대략적 위치만 반영.
//
//  구성
//   · 도시 불빛 : CPU 에서 한 번 생성한 정적 점 버퍼(위치+무작위 값). 중심부 밀도↑, 한강·산 비움, 격자 도로 + 부도심 군집,
//                 한강 양안 강변도로·한강 다리를 따라 늘어선 불빛. 앞쪽 n개가 항상 균일한 부분집합이라 품질에 따라 count 만 줄이면 된다.
//   · 지면      : 어두운 평면 + 한강/산 마스크(캔버스) + 도시 빛 번짐 + 충격파 링
//   · 구름층    : 큰 수평 판 3장(고도별). fBm 투명도, 위에서 보면 푸른 회색 / 아래에서 보면 도시 불빛에 주황빛
//   · 충격파    : uTau(충돌 후 경과 초) 가 0 이상이면 링이 퍼지고, 링이 지나간 자리의 불빛은 꺼진다

import * as THREE from 'three/webgpu';
import {
  Fn, float, vec2, vec3, vec4, uniform, uv, instanceIndex, instancedBufferAttribute, positionWorld, cameraPosition, texture,
  normalize, length, dot, mix, smoothstep, clamp, pow, exp, sin, cos, hash, varying, max, abs, select, step, positionLocal,
  normalWorld, mx_noise_float,
} from 'three/tsl';
import { fbm3 } from '../../engine/tsl.js';
import { SEOUL } from '../../data/cities.js';

export const CITY_N = 420000;
const U_LON = 8820, U_LAT = 11120;            // 1° 가 몇 유닛(10 m)인가: 경도 88.2 km, 위도 111.2 km (서울 위도 기준)
const MAP = 4500, MAP_PX = 1024;               // 마스크 맵: 한 변 9000 유닛(90 km)

export const ll2xz = (lat, lon) => [(lon - SEOUL.lon) * U_LON, -(lat - SEOUL.lat) * U_LAT];

// 한강(동 → 서) 대략 경로 [경도, 위도]
const HAN_RAW = [[127.30, 37.565], [127.17, 37.548], [127.10, 37.527], [127.05, 37.526], [127.00, 37.516], [126.96, 37.512], [126.93, 37.525], [126.90, 37.538], [126.86, 37.562], [126.80, 37.598], [126.74, 37.63]]
  .map(([lo, la]) => ll2xz(la, lo));
// 꺾은선이 각져 보이지 않도록 Catmull-Rom 으로 부드럽게 다시 샘플링 (이후 모든 계산이 이 경로를 사용)
const HAN = new THREE.CatmullRomCurve3(HAN_RAW.map(([x, z]) => new THREE.Vector3(x, 0, z)), false, 'centripetal').getPoints(90).map((v) => [v.x, v.z]);
// 산·녹지(불빛이 거의 없는 곳): [위도, 경도, 반지름 km]
const MOUNTAINS = [[37.5512, 126.9882, 1.0], [37.5933, 126.9695, 1.3], [37.5855, 126.9575, 0.9], [37.66, 126.977, 4.2], [37.695, 127.015, 3.0],
  [37.445, 126.9635, 2.8], [37.5518, 127.1036, 1.0], [37.574, 126.939, 1.2], [37.42, 127.0, 3.0], [37.5, 127.05, 0.7]].map(([la, lo, r]) => [...ll2xz(la, lo), r * 100]);
const RIVER_HALF = 55;                         // 한강 반폭(유닛) ≈ 550 m

function rng(seed) { let a = seed >>> 0; return () => { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

/** 점 (x,z) 에서 한강 폴리라인까지 거리와 가장 가까운 선분 인덱스/위치 */
function riverDist(x, z) {
  let best = 1e9, bi = 0, bt = 0;
  for (let i = 0; i < HAN.length - 1; i++) {
    const [ax, az] = HAN[i], [bx, bz] = HAN[i + 1];
    const dx = bx - ax, dz = bz - az, L2 = dx * dx + dz * dz;
    let t = ((x - ax) * dx + (z - az) * dz) / L2; t = Math.max(0, Math.min(1, t));
    const d = Math.hypot(x - (ax + dx * t), z - (az + dz * t));
    if (d < best) { best = d; bi = i; bt = t; }
  }
  return { d: best, i: bi, t: bt };
}
const mountainFactor = (x, z) => { let m = 0; for (const [mx, mz, r] of MOUNTAINS) { const d = Math.hypot(x - mx, z - mz); m = Math.max(m, Math.exp(-((d / r) ** 3))); } return m; };

/** 도시 밀도(0~1): 중심 + 강남 + 여의도 + 외곽, 산·강은 제외 */
const SUBS = [[0, 0, 900, 1.0], ...[[37.4979, 127.0276, 450, 0.95], [37.5219, 126.9246, 330, 0.55], [37.5133, 127.1002, 330, 0.6], [37.5826, 126.8895, 300, 0.45], [37.4812, 126.8826, 380, 0.5], [37.5446, 127.0557, 320, 0.5]].map(([la, lo, s, w]) => [...ll2xz(la, lo), s, w])];
function density(x, z) {
  let d = 0.32 * Math.exp(-(x * x + z * z) / (2 * 2400 * 2400));
  for (const [cx, cz, s, w] of SUBS) d += w * Math.exp(-((x - cx) ** 2 + (z - cz) ** 2) / (2 * s * s));
  return Math.min(1, d);
}

/** 한강/산 마스크 캔버스 (R=강, G=산) */
function buildMask() {
  const c = document.createElement('canvas'); c.width = c.height = MAP_PX;
  const g = c.getContext('2d'), s = MAP_PX / (2 * MAP);
  const P = (x, z) => [(x + MAP) * s, (z + MAP) * s];
  g.fillStyle = '#000'; g.fillRect(0, 0, MAP_PX, MAP_PX);
  g.globalCompositeOperation = 'lighter';
  for (const [mx, mz, r] of MOUNTAINS) {
    const [px, py] = P(mx, mz), rr = r * s * 1.6;
    const gr = g.createRadialGradient(px, py, 0, px, py, rr); gr.addColorStop(0, 'rgba(0,255,0,0.9)'); gr.addColorStop(0.6, 'rgba(0,255,0,0.5)'); gr.addColorStop(1, 'rgba(0,255,0,0)');
    g.fillStyle = gr; g.fillRect(px - rr, py - rr, rr * 2, rr * 2);
  }
  g.strokeStyle = 'rgb(255,0,0)'; g.lineCap = 'round'; g.lineJoin = 'round'; g.lineWidth = RIVER_HALF * 2 * s;
  g.beginPath(); HAN.forEach(([x, z], i) => { const [px, py] = P(x, z); i ? g.lineTo(px, py) : g.moveTo(px, py); }); g.stroke();
  return c;
}

/** 도시 불빛 점 버퍼 생성: [x, y, z, seed] × N */
function buildLights(N) {
  const r = rng(20251001);
  const out = new Float32Array(N * 4);
  let n = 0;
  const push = (x, y, z) => { if (n < N) { out[n * 4] = x; out[n * 4 + 1] = y; out[n * 4 + 2] = z; out[n * 4 + 3] = r(); n++; } };
  const GRID = 11 + 4 * r(), ROT = 0.21;                                   // 블록 크기 ≈ 110~150 m, 도로망 회전
  const cr = Math.cos(ROT), sr = Math.sin(ROT);
  const ok = (x, z, rv) => {
    const rd = riverDist(x, z);
    if (rd.d < RIVER_HALF) return false;                                    // 한강 위
    const mf = mountainFactor(x, z);
    return rv < density(x, z) * (1 - 0.93 * mf) * (rd.d < RIVER_HALF + 18 ? 0.25 : 1);
  };
  // ① 면 불빛(건물/가로등): 도심·부도심 가우시안 혼합에서 뽑은 뒤 한강/산을 제외. 일부는 격자 도로에 정렬
  //    (균일 샘플링 + 밀도 기각 방식은 중심부가 너무 성겨서, 처음부터 중심에 몰아서 뽑는다)
  const COMP = [[0, 0, 650, 0.3], ...SUBS.slice(1).map(([cx, cz, s, w]) => [cx, cz, s * 0.9, 0.08 + 0.12 * w]), [0, 0, 2300, 0.14]];
  const wsum = COMP.reduce((a, c) => a + c[3], 0);
  const gaussR = () => Math.sqrt(-2 * Math.log(Math.max(r(), 1e-9))) * Math.cos(2 * Math.PI * r());
  let guard = 0;
  while (n < N * 0.86 && guard++ < N * 60) {
    let pick = r() * wsum, c = COMP[0];
    for (const cc of COMP) { pick -= cc[3]; if (pick <= 0) { c = cc; break; } }
    let x = c[0] + gaussR() * c[2], z = c[1] + gaussR() * c[2];
    if (Math.abs(x) > 4300 || Math.abs(z) > 4300) continue;
    const rd0 = riverDist(x, z);
    if (rd0.d < RIVER_HALF) continue;
    if (r() > (1 - 0.93 * mountainFactor(x, z)) * (rd0.d < RIVER_HALF + 18 ? 0.25 : 1)) continue;
    if (r() < 0.62) {                                                       // 도로 정렬: 회전 격자의 한 축에 붙임
      const u = x * cr + z * sr, v = -x * sr + z * cr;
      if (r() < 0.5) { const uu = Math.round(u / GRID) * GRID + (r() - 0.5) * 0.8; x = uu * cr - v * sr; z = uu * sr + v * cr; }
      else { const vv = Math.round(v / GRID) * GRID + (r() - 0.5) * 0.8; x = u * cr - vv * sr; z = u * sr + vv * cr; }
      if (riverDist(x, z).d < RIVER_HALF) continue;
    }
    const d = density(x, z);
    push(x, Math.pow(d, 1.6) * 3.2 * r(), z);                                  // 중심부일수록 고층(높이 최대 ~70 m)
  }
  // ② 한강 강변도로(양안) + 다리: 길게 이어진 밝은 선
  const edge = Math.floor(N * 0.075);
  for (let k = 0; k < edge; k++) {
    const seg = Math.floor(r() * (HAN.length - 1)), t = r();
    const [ax, az] = HAN[seg], [bx, bz] = HAN[seg + 1];
    const dx = bx - ax, dz = bz - az, L = Math.hypot(dx, dz), nx = -dz / L, nz = dx / L;
    const side = r() < 0.5 ? -1 : 1, off = RIVER_HALF + 10 + r() * 5;
    push(ax + dx * t + nx * off * side, 0.6, az + dz * t + nz * off * side);
  }
  const bridges = [0.07, 0.15, 0.22, 0.28, 0.33, 0.4, 0.46, 0.52, 0.58, 0.66, 0.74, 0.82, 0.9];
  const perBridge = Math.floor((N * 0.02) / bridges.length);
  for (const bt of bridges) {
    const f = bt * (HAN.length - 1), seg = Math.min(HAN.length - 2, Math.floor(f)), t = f - seg;
    const [ax, az] = HAN[seg], [bx, bz] = HAN[seg + 1];
    const dx = bx - ax, dz = bz - az, L = Math.hypot(dx, dz), nx = -dz / L, nz = dx / L;
    const cx = ax + dx * t, cz = az + dz * t;
    for (let k = 0; k < perBridge; k++) { const s = (r() * 2 - 1) * (RIVER_HALF + 14); push(cx + nx * s, 0.9, cz + nz * s); }
  }
  // ③ 나머지: 외곽 산재(위성 도시 느낌)
  while (n < N) { const x = (r() * 2 - 1) * 4300, z = (r() * 2 - 1) * 4300; if (r() < 0.12 * density(x, z) + 0.01) push(x, 0, z); else if (guard++ > N * 80) break; }
  // 앞쪽 n개가 항상 균일한 부분집합이 되도록 섞는다 (count 만 줄여도 전체 분포 유지)
  for (let i = n - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); for (let c = 0; c < 4; c++) { const tmp = out[i * 4 + c]; out[i * 4 + c] = out[j * 4 + c]; out[j * 4 + c] = tmp; } }
  return out;
}

export async function makeCity(ctx) {
  const root = new THREE.Group();
  const t = ctx.u.time;
  const uTau = uniform(-1.0);          // 충돌 후 경과 시간(초). 0 미만 = 충돌 전
  const uSpeed = uniform(1400.0);      // 충격파 속도(유닛/초)
  const uGlow = uniform(1.0);          // 도시 전체 밝기 배수
  const uWipe = uniform(1.0);          // 충격파 지나간 불빛을 끌지 여부(1=끈다)
  const uSlab = uniform(1.0);          // 구름층 불투명도 배수 (충돌 후 충격파가 구름을 날려 보낸다)
  const uGround = uniform(1.0);        // 지면의 도시 빛 번짐 배수
  const uPool = uniform(0.0);          // 글자 아래 지면에 번지는 청록 빛 웅덩이
  const uOn = uniform(1.0e9);          // 송전 후 "불이 켜지는" 반경(유닛). 작으면 중심부만 켜짐, 1e9 = 전체 켜짐 (Ch.6 서울 점등 연출)

  // ── 도시 불빛 ──
  const data = buildLights(CITY_N);
  const attr = new THREE.InstancedBufferAttribute(data, 4);
  const lights = new THREE.Sprite(new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending }));
  const mat = lights.material;
  const a = instancedBufferAttribute(attr);          // vec4(x, y, z, seed)
  mat.positionNode = a.xyz;
  const seed = a.w;
  // 카메라가 가까워지면 점이 풍선처럼 커지지 않도록 크기를 줄인다 (70유닛 이내에서 최대 70%까지)
  mat.scaleNode = float(1.7).add(seed.mul(2.3)).mul(clamp(length(a.xyz.sub(cameraPosition)).div(70.0), 0.3, 1.0));
  // 색: 대부분 따뜻한 전구색, 일부 흰 LED/푸른 상업지구, 드물게 붉은 간판
  const warm = vec3(1.0, 0.78, 0.42), white = vec3(0.82, 0.93, 1.0), red = vec3(1.0, 0.36, 0.22);
  const col0 = mix(mix(warm, white, step(0.78, seed.mul(7.31).fract())), red, step(0.975, seed.mul(13.7).fract()));
  const d = length(a.xz);
  const rw = uSpeed.mul(uTau.max(0.0));                                   // 충격파 반지름
  const ring = exp(pow(d.sub(rw).div(80.0), 2.0).negate()).mul(step(0.0, uTau));
  const alive = float(1.0).sub(smoothstep(rw.sub(160.0), rw.sub(20.0), d).oneMinus().mul(uWipe).mul(step(0.0, uTau)));   // 파동이 지나간 곳은 꺼짐
  const lit = float(1.0).sub(smoothstep(uOn.sub(180.0), uOn, d));                         // 켜진 영역(바깥은 어두움)
  const onRing = exp(pow(d.sub(uOn.sub(70.0)).div(90.0), 2.0).negate()).mul(step(0.0, uOn));   // 켜지는 파면의 밝은 띠
  const twinkle = sin(t.mul(seed.mul(3.0).add(0.6)).add(seed.mul(80.0))).mul(0.12).add(0.9);
  mat.colorNode = varying(col0.mul(pow(seed.mul(17.3).fract(), 2.2).mul(1.7).add(0.22)).mul(twinkle).mul(ring.mul(5.0).add(1.0)).mul(alive).mul(uGlow).mul(1.9).mul(lit.add(onRing.mul(2.2).mul(lit.mul(0.6).add(0.4)))), 'vCityCol');
  mat.opacityNode = smoothstep(0.5, 0.0, length(uv().sub(0.5))).pow(1.3);
  lights.count = CITY_N; lights.frustumCulled = false; lights.renderOrder = 6;
  root.add(lights);

  // ── 지면 ──
  const maskTex = new THREE.CanvasTexture(buildMask());
  maskTex.colorSpace = THREE.NoColorSpace; maskTex.generateMipmaps = true; maskTex.minFilter = THREE.LinearMipmapLinearFilter; maskTex.needsUpdate = true;
  const groundMat = new THREE.MeshBasicNodeMaterial();
  groundMat.colorNode = Fn(() => {
    const q = positionWorld.xz;
    const m = texture(maskTex, clamp(q.add(MAP).div(2 * MAP), 0.0, 1.0));
    const river = smoothstep(0.4, 0.75, m.r), mnt = smoothstep(0.1, 0.7, m.g);
    const dist = length(q);
    const glow = exp(dist.div(-1900.0)).mul(uGround);                                      // 도시 빛 번짐
    let col = vec3(0.004, 0.006, 0.013).add(vec3(1.0, 0.55, 0.25).mul(glow).mul(0.028)).add(vec3(0.002, 0.007, 0.003).mul(mnt));
    const rn = mx_noise_float(vec3(q.mul(0.03), t.mul(0.15))).mul(0.5).add(0.5);        // 강물 일렁임
    col = mix(col, vec3(0.012, 0.03, 0.075).add(vec3(1.0, 0.7, 0.4).mul(glow).mul(rn).mul(0.05)), river);
    // 충격파 링 (지면에 번지는 빛)
    const tau = uTau.max(0.0), rw2 = uSpeed.mul(tau);
    const ring2 = exp(pow(dist.sub(rw2).div(70.0), 2.0).negate()).mul(step(0.0, uTau)).mul(exp(tau.mul(-0.35)));
    const scorch = smoothstep(rw2, rw2.mul(0.5), dist).mul(step(0.0, uTau)).mul(0.5);
    col = col.add(vec3(1.0, 0.8, 0.5).mul(ring2).mul(3.2)).add(vec3(0.9, 0.3, 0.08).mul(scorch).mul(exp(tau.mul(-0.5))).mul(0.5));
    // 글자 아래 지면에 비치는 청록빛 웅덩이(글자 연출용)
    col = col.add(vec3(0.1, 0.55, 0.9).mul(exp(pow(dist.div(62.0), 2.0).negate())).mul(uPool).mul(0.16));
    return vec4(col, 1.0);
  })();
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(14000, 14000), groundMat);
  ground.rotation.x = -Math.PI / 2; ground.position.y = -0.3; ground.renderOrder = 0;
  root.add(ground);

  // ── 구름층 3장 ──
  const slabs = [];
  [[720, 0.0], [430, 7.3], [270, 15.1]].forEach(([y, sd], idx) => {
    const sm = new THREE.MeshBasicNodeMaterial({ transparent: true, depthWrite: false, side: THREE.DoubleSide });
    sm.colorNode = Fn(() => {
      const p = positionWorld;
      const base = p.xz.mul(0.0011).add(vec2(sd, sd * 0.7));
      const n = fbm3(vec3(base.x.add(t.mul(0.0025)), base.y, float(sd).add(t.mul(0.001)))).mul(1.2).add(fbm3(vec3(base.mul(4.0), t.mul(0.004))).mul(0.35)).add(0.08);
      const dens = smoothstep(0.1, 0.55, n);
      const dy = cameraPosition.y.sub(y);
      const nearFade = smoothstep(0.0, 90.0, abs(dy));                                   // 카메라와 너무 가까우면 투명(통과 시 갑작스러운 컷 방지)
      const glowC = exp(length(p.xz).div(-2400.0));
      const above = vec3(0.1, 0.13, 0.2).mul(0.55);                                       // 위에서 보면 푸른 회색(별빛/달빛)
      const below = vec3(1.0, 0.55, 0.22).mul(glowC).mul(0.55).add(vec3(0.02, 0.025, 0.04));   // 아래에서 보면 도시 불빛에 주황빛
      const col = mix(below, above, step(0.0, dy));
      return vec4(col, dens.mul(0.78).mul(nearFade).mul(uSlab));
    })();
    const slab = new THREE.Mesh(new THREE.PlaneGeometry(16000, 16000), sm);
    slab.rotation.x = -Math.PI / 2; slab.position.y = y; slab.renderOrder = 8 + idx;
    root.add(slab); slabs.push(slab);
  });

  // ── 충격 돔 (충돌 직후 퍼지는 구 모양 섬광) ──
  const domeMat = new THREE.MeshBasicNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide });
  const uDome = uniform(0.0);
  domeMat.colorNode = Fn(() => {
    const nW = normalize(normalWorld);
    const view = normalize(cameraPosition.sub(positionWorld));
    const fres = pow(float(1.0).sub(abs(dot(nW, view))), 2.0);
    const n = fbm3(positionLocal.mul(3.0).add(vec3(0.0, t.mul(2.0), 0.0))).mul(0.5).add(0.5);
    return vec4(vec3(1.0, 0.72, 0.4).mul(fres.add(0.15)).mul(n.mul(1.2).add(0.4)).mul(uDome).mul(2.0), 1.0);
  })();
  const dome = new THREE.Mesh(new THREE.SphereGeometry(1, 64, 40), domeMat);
  dome.visible = false; dome.renderOrder = 12;
  root.add(dome);

  // ── 외부 제어 ──
  const api = {
    root, lights, ground, slabs, dome, uTau, uSpeed, uGlow, uWipe, uDome, uSlab, uGround, uPool, uOn,
    /** 품질(파티클 상한)에 맞춰 점 개수 조절 */
    setCount(n) { lights.count = Math.max(1000, Math.min(CITY_N, n | 0)); },
    /** 충돌 후 경과 시간(초)로 충격파·돔을 갱신. tau<0 이면 충돌 전 */
    setImpact(tau) {
      uTau.value = tau;
      const on = tau >= 0;
      dome.visible = on && tau < 3.2;
      if (dome.visible) {
        const R = 40 + 900 * Math.pow(tau, 0.75);
        dome.scale.set(R, R * 0.8, R);
        uDome.value = Math.exp(-tau * 1.15);
      }
    },
    /** 도시 중심 기준 한강 경로(디버그용) */
    HAN,
  };
  return api;
}
