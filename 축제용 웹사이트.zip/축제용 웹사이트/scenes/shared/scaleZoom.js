// scenes/shared/scaleZoom.js — Ch.1 "파워스 오브 텐" 줌인: 연료 펠릿 → 결정 알갱이 → 결정 격자 → 원자(전자 확률 구름) → 원자핵(핵자)
//
//  원리: 카메라는 한 자리에 고정하고, 각 층(layer)의 "크기"만 줌 값 z 에 따라 바꾼다 (끊김 없는 원샷 줌).
//   z = log10(시야 폭[m]).  층 i 의 특징 크기 F_i(m) 가 화면의 몇 배인가 frac = F_i / 10^z  — 이 값이 적당할 때만 그 층을 보이게 한다(크로스페이드).
//   층 로컬 단위 1칸 = m_i 미터 → 월드 배율 S_i = m_i · VH / 10^z  (VH = 시야 높이(월드 단위)).
//  층 구성 (로컬 단위 / 특징 크기):
//    pellet  1 unit = 1 mm   / UO₂ 세라믹 펠릿 지름·높이 1 cm
//    grains  1 unit = 1 µm   / 소결 결정 알갱이 ≈ 10 µm (다결정, 알갱이 경계)
//    lattice 1 unit = a      / UO₂ 형석(fluorite) 격자 상수 a ≈ 0.547 nm  (U 큰 구, O 작은 구) — 레이마칭 + 도메인 반복(무한 격자)
//    atom    1 unit = 2×10⁻¹⁰ m / 원자: 전자 확률 구름(레이마칭 볼륨). 짙은 곳 = 전자가 발견될 확률이 높은 곳. 중심의 핵은 점
//    nucleus 1 unit = 2.47 fm / U 핵 반지름 ≈ 7.4 fm → 3 단위. 핵자(양성자 주황·중성자 청록) 236개 + 강한 핵력의 빛 가닥(글루온 입자)
//  ※ 모식도: 전자 구름의 껍질 반지름·모양은 이해를 돕기 위한 단순화다(실제 U 원자는 92개 전자의 복잡한 오비탈).
//  출처: UO₂ 격자 상수 5.47 Å, 핵 반지름 R≈1.2·A^(1/3) fm (A=235 → 7.4 fm), 원자 크기 ~10⁻¹⁰ m.

import * as THREE from 'three/webgpu';
import {
  Fn, float, int, vec2, vec3, vec4, uniform, uv, instanceIndex, instanceColor, instancedBufferAttribute, cameraPosition, positionWorld, positionLocal,
  normalWorld, normalize, length, dot, mix, smoothstep, clamp, pow, exp, sin, cos, abs, fract, floor, max, min, step, hash, varying, If, Loop, Break, sqrt, reflect,
  mx_noise_float, mx_worley_noise_float, mx_worley_noise_vec2,
} from 'three/tsl';
import { fbm3 } from '../../engine/tsl.js';

export const VH = 95.6;                  // 시야 높이(월드 단위) — 카메라 거리 98, FOV 52° 일 때 중심 평면의 높이
export const CAM_DIST = 98;
const M = { pellet: 1e-3, grains: 1e-6, lattice: 5.47e-10, atom: 2e-10, nucleus: 2.47e-15 };      // 로컬 1단위의 실제 길이(m)
const F = { pellet: 1e-2, grains: 1e-5, lattice: 5.47e-10, atom: 6e-10, nucleus: 1.48e-14 };       // 특징 크기(m)
const BOUND = 420;

function rng(seed) { let a = seed >>> 0; return () => { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
const band = (lf, a0, a1, b0, b1) => { const sm = (e0, e1, x) => { const t = Math.min(1, Math.max(0, (x - e0) / (e1 - e0))); return t * t * (3 - 2 * t); }; return sm(a0, a1, lf) * (1 - sm(b0, b1, lf)); };

export function makeScaleZoom(ctx, center = new THREE.Vector3()) {
  const root = new THREE.Group();
  const uCenter = uniform(center.clone());       // 레이마칭 층의 중심(월드) — 이 씬이 원자 위치로 옮겨져 있으므로 카메라 좌표에서 빼 준다
  const t = ctx.u.time;
  const L = {};                                   // 층별 uniform 모음

  // ───────────── 1) 펠릿 ─────────────
  const uPelletA = uniform(1.0), uPelletDetail = uniform(0.0);
  const pelletMat = new THREE.MeshBasicNodeMaterial({ transparent: true, depthWrite: false });
  pelletMat.colorNode = Fn(() => {
    const p = positionLocal;
    const nW = normalize(normalWorld), V = normalize(cameraPosition.sub(positionWorld));
    const lam = clamp(dot(nW, normalize(vec3(-0.35, 0.55, 0.75))), 0.0, 1.0);
    const rim = pow(float(1.0).sub(clamp(dot(nW, V), 0.0, 1.0)), 2.6);
    const g1 = mx_worley_noise_float(p.mul(26.0), 1.0, 0), g1id = mx_worley_noise_float(p.mul(26.0), 1.0, 1);
    const g2 = mx_worley_noise_float(p.mul(230.0), 1.0, 0), g2id = mx_worley_noise_float(p.mul(230.0), 1.0, 1);
    const mott = fbm3(p.mul(0.6)).mul(0.5).add(0.5);
    const gA = mix(0.55, 1.0, smoothstep(0.08, 0.5, g1)).mul(mix(0.82, 1.1, g1id));
    const gB = mix(0.55, 1.0, smoothstep(0.08, 0.5, g2)).mul(mix(0.82, 1.1, g2id));
    const grain = mix(gA, gA.mul(gB), uPelletDetail);
    const spark = step(0.985, g1id).mul(1.6);                                  // 반짝이는 결정면
    const spec = pow(max(dot(reflect(normalize(vec3(0.35, -0.55, -0.75)), nW), V), 0.0), 24.0);
    const base = vec3(0.2, 0.2, 0.225).mul(grain).mul(mott.mul(0.5).add(0.7)).mul(lam.mul(1.5).add(0.12)).add(vec3(0.9, 0.95, 1.0).mul(spec).mul(0.35));
    return vec4(base.add(vec3(0.3, 0.8, 1.0).mul(rim).mul(0.35)).add(vec3(1.0, 0.9, 0.8).mul(spark).mul(lam).mul(0.5)), uPelletA);
  })();
  const pellet = new THREE.Group();
  const pCyl = new THREE.Mesh(new THREE.CylinderGeometry(5, 5, 10, 64, 1), pelletMat);
  pCyl.position.z = -5;                                                      // 옆면의 한 점(0,0,0)이 화면 중심에 오도록
  pellet.add(pCyl); root.add(pellet);

  // ───────────── 2) 결정 알갱이 ─────────────
  const uGrainA = uniform(0.0);
  const grainMat = new THREE.MeshBasicNodeMaterial({ transparent: true, depthWrite: false });
  grainMat.colorNode = Fn(() => {
    const q = positionLocal.xy.mul(0.1);
    const w = mx_worley_noise_vec2(vec3(q, 0.0), 1.0, 1), idw = mx_worley_noise_float(vec3(q, 0.0), 1.0, 1);
    const edge = smoothstep(0.0, 0.07, w.y.sub(w.x));                                          // 알갱이 경계(F2−F1 이 작은 곳)
    const ang = idw.mul(6.2831853);
    const stripe = sin(positionLocal.x.mul(cos(ang)).add(positionLocal.y.mul(sin(ang))).mul(2.2)).mul(0.5).add(0.5);     // 결정면 줄무늬
    const tone = mix(vec3(0.16, 0.15, 0.16), vec3(0.3, 0.27, 0.26), idw);
    const body = tone.mul(stripe.mul(0.09).add(0.92)).mul(mix(0.82, 1.0, smoothstep(0.0, 0.5, w.x)));
    const pore = smoothstep(0.1, 0.05, w.x).mul(step(0.86, fract(idw.mul(31.7))));                // 기공(작은 구멍)
    const glowEdge = vec3(1.0, 0.45, 0.12).mul(float(1.0).sub(edge)).mul(0.5);
    return vec4(body.mul(edge.mul(0.7).add(0.3)).mul(float(1.0).sub(pore.mul(0.9))).add(glowEdge.mul(0.5)), uGrainA);
  })();
  const grains = new THREE.Mesh(new THREE.PlaneGeometry(900, 900), grainMat);
  grains.position.z = 0; root.add(grains);

  // ───────────── 3) 결정 격자 (레이마칭, 도메인 반복) ─────────────
  const uLatS = uniform(10.0), uLatA = uniform(0.0);
  const latMat = new THREE.MeshBasicNodeMaterial({ transparent: true, depthWrite: false, depthTest: false, side: THREE.BackSide });
  latMat.colorNode = Fn(() => {
    const ro = cameraPosition.sub(uCenter), rd = normalize(positionWorld.sub(cameraPosition));
    const S = uLatS, zl = clamp(S.mul(2.2), 1.0, 40.0);
    const sdf = (p) => {
      const pl = p.div(S);
      const q = fract(pl.add(0.5)).sub(0.5);
      const dU = length(q).sub(0.2), dO = length(abs(q).sub(0.25)).sub(0.085);
      const d = min(dU, dO).mul(S);
      return max(d, abs(p.z).sub(zl));
    };
    const tEnter = max(ro.z.sub(zl).div(rd.z.negate().max(1e-3)), 0.0);
    const tExit = ro.z.add(zl).div(rd.z.negate().max(1e-3));
    const tt = tEnter.toVar(); const hit = float(0.0).toVar();
    Loop({ start: int(0), end: int(64), type: 'int', condition: '<' }, () => {
      const d = sdf(ro.add(rd.mul(tt)));
      If(d.lessThan(S.mul(0.0025).max(0.002)), () => { hit.assign(1.0); Break(); });
      tt.addAssign(max(d.mul(0.9), S.mul(0.002)));
      If(tt.greaterThan(tExit).or(rd.z.greaterThanEqual(-1e-3)), () => { Break(); });
    });
    const P = ro.add(rd.mul(tt));
    const e = S.mul(0.01).max(0.004);
    const k0 = vec3(1, -1, -1), k1 = vec3(-1, -1, 1), k2 = vec3(-1, 1, -1), k3 = vec3(1, 1, 1);
    const n = normalize(k0.mul(sdf(P.add(k0.mul(e)))).add(k1.mul(sdf(P.add(k1.mul(e))))).add(k2.mul(sdf(P.add(k2.mul(e))))).add(k3.mul(sdf(P.add(k3.mul(e))))));
    const lam = clamp(dot(n, normalize(vec3(-0.4, 0.6, 0.7))), 0.0, 1.0);
    const rim = pow(float(1.0).sub(clamp(dot(n, rd.negate()), 0.0, 1.0)), 2.5);
    const pl = P.div(S), q = fract(pl.add(0.5)).sub(0.5);
    const isU = step(length(q).sub(0.2), length(abs(q).sub(0.25)).sub(0.085));                  // U 구가 더 가까우면 1
    const base = mix(vec3(1.0, 0.28, 0.22), vec3(0.62, 0.74, 1.0), isU);
    const fog = exp(P.z.negate().add(zl).div(zl.mul(3.5)).negate()).mul(0.55).add(0.45);
    const col = base.mul(lam.mul(0.95).add(0.12)).add(vec3(0.3, 0.8, 1.0).mul(rim).mul(0.45)).mul(fog);
    return vec4(col, hit.mul(uLatA));
  })();
  const lattice = new THREE.Mesh(new THREE.SphereGeometry(BOUND, 24, 16), latMat);
  lattice.renderOrder = 2; lattice.frustumCulled = false; root.add(lattice);

  // ───────────── 4) 원자(전자 확률 구름) ─────────────
  const uAtomS = uniform(15.0), uAtomA = uniform(0.0), uAtomCore = uniform(0.0);
  const atomMat = new THREE.MeshBasicNodeMaterial({ transparent: true, depthWrite: false, depthTest: false, blending: THREE.AdditiveBlending, side: THREE.BackSide });
  atomMat.colorNode = Fn(() => {
    const ro = cameraPosition.sub(uCenter), rd = normalize(positionWorld.sub(cameraPosition));
    const S = uAtomS, zl = clamp(S.mul(0.55), 1.5, 36.0);
    const tEnter = max(ro.z.sub(zl).div(rd.z.negate().max(1e-3)), 0.0), tExit = ro.z.add(zl).div(rd.z.negate().max(1e-3));
    const N = 36, dt = tExit.sub(tEnter).div(float(N));
    const acc = vec3(0.0, 0.0, 0.0).toVar();
    Loop({ start: int(0), end: int(N), type: 'int', condition: '<' }, ({ i }) => {
      const p = ro.add(rd.mul(tEnter.add(dt.mul(float(i).add(0.5))))).div(S);                  // 원자 단위 좌표
      const r = length(p), ct = p.z.div(max(r, 1e-4));
      const ang1 = ct.mul(ct).mul(0.8).add(0.2), ang2 = pow(ct.mul(ct).mul(3.0).sub(1.0), 2.0).mul(0.22).add(0.12);
      const sh = (rk, sk, w, a) => exp(pow(r.sub(rk).div(sk), 2.0).negate()).mul(w).mul(a);
      const rho = sh(0.13, 0.045, 1.5, float(1.0)).add(sh(0.4, 0.075, 1.1, ang1)).add(sh(0.72, 0.1, 0.9, ang2)).add(sh(1.08, 0.13, 0.7, ang1.mul(0.9).add(0.1))).add(sh(1.5, 0.17, 0.5, ang2.mul(0.8).add(0.2)));
      // 확률 구름: 알갱이처럼 반짝이는 고주파 노이즈 × 일렁임 — 짙은 곳일수록 전자가 발견될 확률이 높다
      const speck = pow(mx_noise_float(p.mul(46.0).add(vec3(0.0, 0.0, t.mul(1.7)))).mul(0.5).add(0.5), 2.2).mul(1.5).add(0.35);
      const shimmer = mx_noise_float(p.mul(7.0).add(vec3(0.0, 0.0, t.mul(0.4)))).mul(0.25).add(0.9);
      const c = mix(vec3(0.15, 0.4, 1.0), vec3(0.85, 0.95, 1.0), clamp(rho.mul(0.6), 0.0, 1.0)).mul(rho.mul(shimmer).mul(speck));
      acc.addAssign(c.mul(dt).div(zl).mul(0.2));
    });
    return vec4(acc.mul(uAtomA), 1.0);
  })();
  const atom = new THREE.Mesh(new THREE.SphereGeometry(BOUND, 24, 16), atomMat);
  atom.renderOrder = 3; atom.frustumCulled = false; root.add(atom);

  // 원자 한가운데의 작은 빛 점: 줌인 중 "질량은 여기(핵)에 모여 있다"를 암시. 핵 층이 나타나면 사라진다
  const uCoreA = uniform(0.0);
  const coreMat = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false, depthTest: false, blending: THREE.AdditiveBlending });
  coreMat.colorNode = Fn(() => { const rr = length(uv().sub(0.5)).mul(2.0); return vec4(mix(vec3(1.0, 0.6, 0.25), vec3(1.0, 1.0, 1.0), exp(rr.mul(-10.0))).mul(exp(rr.mul(-4.0))).mul(smoothstep(1.0, 0.5, rr)).mul(uCoreA).mul(2.4), 1.0); })();
  const coreSprite = new THREE.Sprite(coreMat); coreSprite.scale.set(3.4, 3.4, 1); coreSprite.renderOrder = 4; root.add(coreSprite);

  // ───────────── 5) 원자핵: 핵자 236개 + 강한 핵력 가닥 ─────────────
  const nucleus = new THREE.Group(); root.add(nucleus);
  const uNucA = uniform(0.0), uHi = uniform(0.0);
  const r = rng(235);
  const NN = 236, R_N = 3.0, rad = 0.34;
  const pts = [];
  for (let i = 0; i < NN; i++) { let v; do { v = new THREE.Vector3(r() * 2 - 1, r() * 2 - 1, r() * 2 - 1); } while (v.length() > 1); pts.push(v.multiplyScalar(R_N - rad * 0.6)); }
  for (let it = 0; it < 70; it++) {                                           // 겹치는 핵자를 밀어내며 촘촘히 채우는 간단한 이완
    for (let a = 0; a < NN; a++) for (let b = a + 1; b < NN; b++) {
      const d = pts[a].distanceTo(pts[b]);
      if (d < rad * 1.9 && d > 1e-4) { const push = (rad * 1.9 - d) * 0.5 / d; const dv = pts[a].clone().sub(pts[b]).multiplyScalar(push); pts[a].add(dv); pts[b].sub(dv); }
    }
    for (const p of pts) { const l = p.length(); if (l > R_N - rad) p.multiplyScalar((R_N - rad) / l); }
  }
  const nGeo = new THREE.SphereGeometry(rad, 14, 10);
  const nMat = new THREE.MeshBasicNodeMaterial({ transparent: true, depthWrite: true });
  nMat.positionNode = positionLocal.add(vec3(mx_noise_float(vec3(float(instanceIndex).mul(0.7), t.mul(7.0), 1.0)), mx_noise_float(vec3(float(instanceIndex).mul(0.9), t.mul(6.0), 4.0)), mx_noise_float(vec3(float(instanceIndex).mul(1.3), t.mul(8.0), 9.0))).mul(0.025));
  nMat.colorNode = Fn(() => {
    const nW = normalize(normalWorld), V = normalize(cameraPosition.sub(positionWorld));
    const lam = clamp(dot(nW, normalize(vec3(-0.4, 0.7, 0.6))), 0.0, 1.0);
    const rim = pow(float(1.0).sub(clamp(dot(nW, V), 0.0, 1.0)), 2.5);
    return vec4(instanceColor.mul(lam.mul(0.8).add(0.35)).add(vec3(0.5, 0.8, 1.0).mul(rim).mul(0.3)), uNucA);
  })();
  const nuc = new THREE.InstancedMesh(nGeo, nMat, NN);
  const m4 = new THREE.Matrix4(), col = new THREE.Color();
  pts.forEach((p, i) => { m4.makeTranslation(p.x, p.y, p.z); nuc.setMatrixAt(i, m4); col.set(i % 2 === 0 ? 0xff8c2a : 0x1fd6c8); nuc.setColorAt(i, col); });
  nuc.frustumCulled = false; nucleus.add(nuc);
  // 가닥(강한 핵력): 이웃 핵자끼리 얇은 빛 선 + 선을 따라 달리는 글루온 알갱이
  const segs = [];
  for (let a = 0; a < NN; a++) for (let b = a + 1; b < NN; b++) if (pts[a].distanceTo(pts[b]) < rad * 2.35) segs.push([pts[a], pts[b]]);
  const lineGeo = new THREE.BufferGeometry().setFromPoints(segs.flatMap(([a, b]) => [a, b]));
  const lineMat = new THREE.LineBasicNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
  lineMat.colorNode = Fn(() => vec4(vec3(0.5, 0.78, 1.0).mul(sin(positionLocal.x.add(positionLocal.y).add(positionLocal.z).mul(9.0).sub(t.mul(6.0))).mul(0.3).add(0.7)).mul(uNucA).mul(0.5), 1.0))();
  nucleus.add(new THREE.LineSegments(lineGeo, lineMat));
  const SA = new Float32Array(segs.length * 3), SB = new Float32Array(segs.length * 3);
  segs.forEach(([a, b], i) => { SA.set([a.x, a.y, a.z], i * 3); SB.set([b.x, b.y, b.z], i * 3); });
  const GL = Math.min(5200, segs.length * 8), gAttrA = new THREE.InstancedBufferAttribute(new Float32Array(GL * 3), 3), gAttrB = new THREE.InstancedBufferAttribute(new Float32Array(GL * 3), 3);
  for (let i = 0; i < GL; i++) { const k = i % segs.length; gAttrA.setXYZ(i, SA[k * 3], SA[k * 3 + 1], SA[k * 3 + 2]); gAttrB.setXYZ(i, SB[k * 3], SB[k * 3 + 1], SB[k * 3 + 2]); }
  const gm = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
  {
    const A = instancedBufferAttribute(gAttrA), B = instancedBufferAttribute(gAttrB), h = hash(instanceIndex);
    const s = fract(h.add(t.mul(h.mul(0.8).add(0.5))));
    gm.positionNode = mix(A, B, s);
    gm.scaleNode = float(0.06).add(hash(instanceIndex.add(5)).mul(0.05));
    gm.colorNode = varying(vec3(0.7, 0.9, 1.0).mul(sin(s.mul(3.14159)).mul(uNucA).mul(1.4)), 'vGluon');
    gm.opacityNode = smoothstep(0.5, 0.0, length(uv().sub(0.5))).pow(1.3);
  }
  const gluons = new THREE.Sprite(gm); gluons.count = GL; gluons.frustumCulled = false; gluons.renderOrder = 5; nucleus.add(gluons);
  // 마지막 장면의 주인공 중성자(가장자리의 청록 핵자 하나): 밝게 빛나며 Ch.2 의 "날아오는 중성자"로 이어진다
  let hiIdx = 0, best = -1;
  pts.forEach((p, i) => { if (i % 2 === 1 && p.length() > best) { best = p.length(); hiIdx = i; } });
  const hiMat = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
  hiMat.colorNode = Fn(() => { const rr = length(uv().sub(0.5)).mul(2.0); return vec4(mix(vec3(0.2, 0.5, 1.0), vec3(1.0, 1.0, 1.0), exp(rr.mul(-9.0))).mul(exp(rr.mul(-3.0))).mul(smoothstep(1.0, 0.5, rr)).mul(uHi).mul(2.2), 1.0); })();
  const hiSprite = new THREE.Sprite(hiMat); hiSprite.position.copy(pts[hiIdx]); hiSprite.scale.set(3.2, 3.2, 1); hiSprite.renderOrder = 6; nucleus.add(hiSprite);

  return {
    root, pellet, grains, lattice, atom, nucleus, hiPos: pts[hiIdx].clone(), VH,
    /** z = log10(시야 폭[m]), main = 전체 가중치(겹침 구간 페이드) */
    update(z, main = 1) {
      const lf = (key) => Math.log10(F[key] / Math.pow(10, z));
      const S = (key) => THREE.MathUtils.clamp((M[key] * VH) / Math.pow(10, z), 1e-4, 2.0e4);
      // 알파(크로스페이드)
      const aP = band(lf('pellet'), -9, -8, Math.log10(8), Math.log10(30));            // 확대되면(frac↑) 서서히 사라짐
      const aG = band(lf('grains'), -1.0, -0.52, 2.0, 2.6);
      const aL = band(lf('lattice'), -1.82, -1.3, -0.1, 0.45);          // 셀이 시야의 1~3배가 되기 전에 사라져 거대한 구 표면이 화면을 덮지 않게
      const aA = band(lf('atom'), -0.52, -0.22, 2.18, 2.7);
      const aN = band(lf('nucleus'), -1.4, -0.82, 9, 10);
      uPelletA.value = aP * main; uGrainA.value = aG * main; uLatA.value = aL * main; uAtomA.value = aA * main; uNucA.value = aN * main;
      pellet.visible = aP > 0.003; grains.visible = aG > 0.003; lattice.visible = aL > 0.003; atom.visible = aA > 0.003; nucleus.visible = aN > 0.003;
      // 배율
      pellet.scale.setScalar(S('pellet')); grains.scale.setScalar(S('grains'));
      uLatS.value = S('lattice'); uAtomS.value = S('atom');
      nucleus.scale.setScalar((F.nucleus / Math.pow(10, z) * VH) / 6.0);
      uPelletDetail.value = THREE.MathUtils.smoothstep(lf('pellet'), 0.4, 1.0);
      uAtomCore.value = 0;
      uCoreA.value = THREE.MathUtils.smoothstep(lf('nucleus'), -3.6, -2.2) * (1 - THREE.MathUtils.smoothstep(lf('nucleus'), -1.5, -0.7)) * main;
    },
    setHighlight(v) { uHi.value = v; },
    setBounds(visible) { lattice.visible = lattice.visible && visible; atom.visible = atom.visible && visible; },
  };
}
