// scenes/shared/aurora.js — 피날레 초록 오로라: 한반도 북쪽 하늘에 걸린 빛의 커튼 + 커튼을 따라 흐르는 입자
//
//  (연출) 실제 오로라는 고위도에서 생기지만, 피날레에서는 "깨끗한 에너지"의 상징으로 한반도 위 하늘에 초록 커튼을 건다.
//  구성
//   · 커튼 4장: 지구 표면 위(1.02R)를 따라 활처럼 휘어진 수직 띠. 아래쪽 가장자리가 가장 밝은 초록, 위로 갈수록 청록 → 연보라로 옅어지고,
//     세로 줄무늬(빛살)가 흔들리며 흐른다. 가산 블렌딩. (모두 셰이더 노이즈, 이미지 없음)
//   · 입자 : 커튼 면 위를 위로 떠오르는 수만 개의 작은 빛 알갱이(상태 없는 셰이더 입자, 오프닝의 "먼지" 입자와 같은 질감)
//   · orbitPose(tt) : 피날레~크레딧(30초)을 잇는 지구 궤도 카메라
//  좌표: 지구(EARTH_POS, 반지름 EARTH_R=40). 한반도가 KOR_UP 을 향하고, 지리상 북극 방향은 한반도에서의 "북쪽"으로 계산한다.

import * as THREE from 'three/webgpu';
import {
  Fn, float, vec2, vec3, vec4, uniform, uv, instanceIndex, hash, positionWorld, cameraPosition, normalize, length, dot, mix, smoothstep, clamp, pow, exp, sin, cos,
  abs, fract, floor, step, varying, mx_noise_float, normalGeometry,
} from 'three/tsl';
import { EARTH_POS, EARTH_R, KOR_UP, SEOUL_LL } from './earth.js';
import { spline, lerp } from '../../engine/ease.js';

const D2R = Math.PI / 180;
// 로컬 기저: up=KOR_UP(한반도 위), north=지리 북쪽(월드 +Y 를 한반도 접평면에 투영), east
export const BASIS = (() => {
  const up = KOR_UP.clone().normalize();
  const north = new THREE.Vector3(0, 1, 0).addScaledVector(up, -up.y).normalize();
  const east = new THREE.Vector3().crossVectors(north, up).normalize();
  const pole = north.clone().multiplyScalar(Math.cos(SEOUL_LL.lat * D2R)).addScaledVector(up, Math.sin(SEOUL_LL.lat * D2R)).normalize();   // 지리상 북극 방향(월드)
  return { up, north, east, pole };
})();

/** 극축 둘레의 위도원: 서울에서 북쪽으로 dLat° 떨어진 위도에서, 서울 경도 기준 λ(라디안) 위치의 단위 벡터 */
function ringPoint(dLat, lam, out) {
  const { pole, up, north } = BASIS;
  const lat = (SEOUL_LL.lat + dLat) * D2R;
  const u1 = up.clone().addScaledVector(pole, -up.dot(pole)).normalize();         // 서울을 지나는 자오면 방향
  const u2 = new THREE.Vector3().crossVectors(pole, u1).normalize();               // 동쪽
  return out.copy(pole).multiplyScalar(Math.sin(lat)).addScaledVector(u1, Math.cos(lat) * Math.cos(lam)).addScaledVector(u2, Math.cos(lat) * Math.sin(lam));
}

export function makeAurora(ctx) {
  const root = new THREE.Group(); root.position.copy(EARTH_POS);
  const t = ctx.u.time;
  const uAur = uniform(0.0), uCor = uniform(0.0);                                     // uCor: 해킹 연출 때 오로라가 마젠타/청록 노이즈로 오염되는 정도(0~1)
  const SEG = 120, SPAN = 70 * D2R, R0 = EARTH_R * 1.02, HT = EARTH_R * 0.3;
  const curtains = [{ dLat: 13, ph: 0.0, w: 1.0 }, { dLat: 15.5, ph: 3.1, w: 0.8 }, { dLat: 18.5, ph: 5.7, w: 0.65 }, { dLat: 11, ph: 8.3, w: 0.55 }];
  const tmp = new THREE.Vector3();
  const mats = [];
  curtains.forEach((c, ci) => {
    const pos = [], uvs = [], idx = [];
    for (let i = 0; i <= SEG; i++) {
      const u = i / SEG, lam = (u - 0.5) * SPAN;
      ringPoint(c.dLat + Math.sin(u * 7 + c.ph) * 1.2, lam, tmp);
      const h = HT * (0.7 + 0.5 * Math.sin(u * 9 + c.ph * 1.3));                     // 위쪽 끝은 물결치듯
      pos.push(tmp.x * R0, tmp.y * R0, tmp.z * R0, tmp.x * (R0 + h), tmp.y * (R0 + h), tmp.z * (R0 + h)); uvs.push(u, 0, u, 1);
      if (i < SEG) { const k = i * 2; idx.push(k, k + 1, k + 2, k + 1, k + 3, k + 2); }
    }
    const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2)); g.setIndex(idx);
    const m = new THREE.MeshBasicNodeMaterial({ transparent: true, depthWrite: false, side: THREE.DoubleSide, blending: THREE.AdditiveBlending });
    const ph = float(c.ph);
    m.colorNode = Fn(() => {
      const U = uv(), v = U.y, u = U.x;
      const ray = mx_noise_float(vec3(u.mul(70.0).add(ph), t.mul(0.35), v.mul(1.5))).mul(0.5).add(0.5);              // 세로 빛살
      const wave = sin(u.mul(9.0).add(t.mul(0.45)).add(ph)).mul(0.5).add(0.5);
      const rays = pow(ray, 2.2).mul(0.8).add(0.3).mul(wave.mul(0.6).add(0.5));
      const fall = pow(float(1.0).sub(v), 1.5).mul(smoothstep(0.0, 0.06, v));                                         // 아래가 가장 밝고 위로 옅어짐
      const edge = smoothstep(0.0, 0.12, u).mul(smoothstep(1.0, 0.88, u));
      let col = mix(mix(vec3(0.25, 1.0, 0.5), vec3(0.1, 0.85, 0.8), smoothstep(0.15, 0.55, v)), vec3(0.65, 0.35, 1.0), smoothstep(0.6, 1.0, v).mul(0.6));
      // 오염: 세로 블록 단위로 색이 마젠타/청록으로 튀고 깜빡이며 끊긴다
      const blk = hash(floor(u.mul(26.0)).add(floor(t.mul(11.0)).mul(5.0)).add(ph.mul(3.0)));
      const bad = step(0.55, blk).mul(uCor);
      col = mix(col, mix(vec3(1.0, 0.1, 0.55), vec3(0.1, 0.6, 1.0), step(0.5, hash(floor(u.mul(26.0)).add(9.0)))), bad.mul(0.85));
      const drop = float(1.0).sub(step(0.82, hash(floor(u.mul(40.0)).add(floor(t.mul(14.0)).mul(3.0)))).mul(uCor).mul(0.9));
      return vec4(col.mul(rays).mul(fall).mul(edge).mul(uAur).mul(c.w).mul(2.6).mul(drop), 1.0);
    })();
    const mesh = new THREE.Mesh(g, m); mesh.renderOrder = 5; mesh.frustumCulled = false; root.add(mesh); mats.push(m);
  });

  // 커튼 면을 따라 떠오르는 입자
  const N = 36000;
  const pm = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
  {
    const i = instanceIndex, h = (k) => hash(i.add(k * 4099));
    // 커튼 번호/좌표: 입자마다 해시로 한 커튼의 (u, v) 선택 — 같은 곡선 공식을 셰이더에서 다시 쓰기 위해 ring 을 근사(위도원)로 계산
    const pole = vec3(BASIS.pole.x, BASIS.pole.y, BASIS.pole.z), up = vec3(BASIS.up.x, BASIS.up.y, BASIS.up.z);
    const u1 = normalize(up.sub(pole.mul(dot(up, pole)))), u2 = pole.cross(u1);
    const which = h(1).mul(4.0).floor();
    const dLat = which.equal(0.0).select(13.0, which.equal(1.0).select(15.5, which.equal(2.0).select(18.5, 11.0)));
    const phv = which.equal(0.0).select(0.0, which.equal(1.0).select(3.1, which.equal(2.0).select(5.7, 8.3)));
    const u = h(2), lam = u.sub(0.5).mul(SPAN);
    const lat = float(SEOUL_LL.lat).add(dLat.add(sin(u.mul(7.0).add(phv)).mul(1.2))).mul(D2R);
    const dir = pole.mul(sin(lat)).add(u1.mul(cos(lat).mul(cos(lam)))).add(u2.mul(cos(lat).mul(sin(lam))));
    const ht = float(HT).mul(sin(u.mul(9.0).add(phv.mul(1.3))).mul(0.5).add(1.2));
    const s = fract(h(3).add(t.mul(h(4).mul(0.04).add(0.025))));                                // 0(아래) → 1(위)
    const sway = sin(t.mul(0.7).add(h(5).mul(6.28))).mul(0.12);
    pm.positionNode = dir.mul(float(R0).add(s.mul(ht))).add(u2.mul(sway));
    pm.scaleNode = h(6).mul(0.1).add(0.05);
    pm.colorNode = varying(mix(mix(vec3(0.3, 1.0, 0.55), vec3(0.15, 0.9, 0.9), s), vec3(1.0, 0.15, 0.6), uCor.mul(step(0.5, h(8)))).mul(float(1.0).sub(s).pow(0.8)).mul(h(7).mul(1.2).add(0.4)).mul(0.45).mul(uAur), 'vAurP');
    pm.opacityNode = smoothstep(0.5, 0.0, length(uv().sub(0.5))).pow(1.4);
  }
  const particles = new THREE.Sprite(pm); particles.count = N; particles.frustumCulled = false; particles.renderOrder = 6; root.add(particles);

  return { root, uAur, uCor, particles, setCount(n) { particles.count = Math.max(4000, Math.min(N, n | 0)); } };
}

// ── 피날레~크레딧 궤도 카메라 (tt: 피날레 시작부터의 초, 0~30) ──
//  지구 중심 기준 구면 좌표: (거리 d, 한반도 위로부터 남쪽으로 기운 각 el, 방위 az). 한반도 북쪽의 오로라 활이 화면에 걸리도록 남쪽 상공에서 북쪽을 본다.
const KEY_D = [[0, 3.6], [4, 3.0], [9, 2.1], [13, 1.8], [17, 2.4], [22, 2.9], [30, 3.4]];               // × EARTH_R
const KEY_EL = [[0, 14], [5, 18], [10, 24], [14, 28], [18, 22], [24, 18], [30, 14]];                          // 도(°): 한반도 천정에서 남쪽으로 벌어진 각
const KEY_AZ = [[0, 0], [6, 6], [12, -10], [18, -16], [24, -4], [30, 12]];                                    // 도(°): 동서 방향 선회
const KEY_LOOK = [[0, 0.12], [9, 0.24], [15, 0.3], [24, 0.2], [30, 0.12]];                                    // 시선 = 한반도에서 북쪽으로 얼마나 (× R)

export function orbitPose(tt, pose) {
  const d = spline(KEY_D, tt) * EARTH_R, el = spline(KEY_EL, tt) * D2R, az = spline(KEY_AZ, tt) * D2R, lk = spline(KEY_LOOK, tt);
  const { up, north, east } = BASIS;
  // 카메라 방향: 한반도 위(up)에서 남쪽(−north)으로 el 만큼 기울고 방위 az
  const dir = up.clone().multiplyScalar(Math.cos(el)).addScaledVector(north, -Math.sin(el) * Math.cos(az)).addScaledVector(east, Math.sin(el) * Math.sin(az)).normalize();
  pose.pos.copy(EARTH_POS).addScaledVector(dir, d);
  pose.look.copy(EARTH_POS).addScaledVector(up, EARTH_R * 0.95).addScaledVector(north, EARTH_R * lk);
  pose.fov = lerp(48, 50, Math.min(1, tt / 30)); pose.roll = 0;
  return pose;
}
