// scenes/shared/earthMasks.js — 해안선 벡터 + 도시 목록 → 지구 셰이더용 마스크 캔버스(코드로 그림, 외부 이미지 없음)
//
//  채널: R = 육지(0/1, 가장자리는 안티앨리어싱), G = 야간 불빛 세기, B = 사용 안 함
//   · global : 전 세계 4096×2048 (등장방형). 110m 해안선 + 동아시아 50m 덧그림 + 전 세계 도시 불빛
//   · korea  : 한반도 주변 2048×1560 (경도 122~132.5, 위도 32.2~40.2). 10m 해안선 + 한국 도시/고속도로 불빛
//  데이터: data/coast.js (Natural Earth, 퍼블릭 도메인), data/cities.js

import { COAST } from '../../data/coast.js';
import { CITIES } from '../../data/cities.js';

export const KOREA_BOX = { lon0: 122, lon1: 132.5, lat0: 32.2, lat1: 40.2 };

// 한국 주요 고속도로(대략적 경로): [위도, 경도] 목록
const ROADS = [
  [[37.57, 126.98], [37.27, 127.03], [36.99, 127.09], [36.81, 127.11], [36.35, 127.38], [35.87, 128.60], [35.54, 129.31], [35.18, 129.08]],  // 경부
  [[37.57, 126.98], [37.32, 126.83], [36.97, 126.62], [36.78, 126.45], [35.97, 126.74], [35.16, 126.85], [34.81, 126.39]],                      // 서해안
  [[37.46, 126.70], [37.34, 127.95], [37.75, 128.88]],                                                                                          // 영동
  [[37.57, 126.98], [37.88, 127.73], [37.75, 128.88]],                                                                                          // 춘천~동해
  [[36.35, 127.38], [35.82, 127.15], [35.16, 126.85]],                                                                                          // 호남
  [[35.87, 128.60], [35.16, 126.85]], [[35.18, 128.68], [35.18, 129.08]], [[36.64, 127.49], [36.12, 128.34], [35.87, 128.60]],
  [[36.02, 129.37], [35.87, 128.60]], [[35.54, 129.31], [36.02, 129.37]],
];

/** 간단한 결정적 난수 (mulberry32) — 새로고침해도 같은 야경 */
function rng(seed) { let a = seed >>> 0; return () => { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
function gauss(r) { return Math.sqrt(-2 * Math.log(Math.max(r(), 1e-9))) * Math.cos(2 * Math.PI * r()); }

function makeCanvas(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; }

function landPath(polys, q, X, Y) {
  const path = new Path2D();
  for (const rings of polys) for (const ring of rings) {
    path.moveTo(X(ring[0] / q), Y(ring[1] / q));
    for (let i = 2; i < ring.length; i += 2) path.lineTo(X(ring[i] / q), Y(ring[i + 1] / q));
    path.closePath();
  }
  return path;
}

/** 야간 불빛을 그린다: 부드러운 후광 + 점 알갱이 + (한국이면) 고속도로 */
function drawLights(ctx, X, Y, pxPerDeg, { haloDeg, haloMin, dotsPerWeight, dotSigmaDeg, onlyKorea, seed }) {
  const r = rng(seed);
  ctx.globalCompositeOperation = 'lighter';
  for (const [, lat, lon, w] of CITIES) {
    if (onlyKorea && !(lon > KOREA_BOX.lon0 - 1 && lon < KOREA_BOX.lon1 + 1 && lat > KOREA_BOX.lat0 - 1 && lat < KOREA_BOX.lat1 + 1)) continue;
    const cx = X(lon), cy = Y(lat);
    const rad = (haloMin + haloDeg * Math.sqrt(w)) * pxPerDeg;
    const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, rad);
    const a = Math.min(1, 0.25 + 0.75 * w);
    g.addColorStop(0, `rgba(0,255,0,${(a * 0.9).toFixed(3)})`);
    g.addColorStop(0.35, `rgba(0,255,0,${(a * 0.32).toFixed(3)})`);
    g.addColorStop(1, 'rgba(0,255,0,0)');
    ctx.fillStyle = g; ctx.fillRect(cx - rad, cy - rad, rad * 2, rad * 2);
    // 알갱이: 도시 주변에 가우시안으로 흩뿌린 작은 불빛
    const n = Math.floor(dotsPerWeight * w);
    const sg = (dotSigmaDeg * (0.5 + Math.sqrt(w))) * pxPerDeg;
    ctx.fillStyle = 'rgba(0,255,0,0.55)';
    for (let i = 0; i < n; i++) { const x = cx + gauss(r) * sg, y = cy + gauss(r) * sg; ctx.fillRect(x, y, 1.2, 1.2); }
  }
  if (onlyKorea) {                                    // 고속도로: 도시를 잇는 가는 선 + 선을 따라 점
    ctx.strokeStyle = 'rgba(0,150,0,0.55)'; ctx.lineWidth = 1.4;
    for (const road of ROADS) {
      ctx.beginPath(); road.forEach(([la, lo], i) => (i ? ctx.lineTo(X(lo), Y(la)) : ctx.moveTo(X(lo), Y(la)))); ctx.stroke();
    }
  }
  ctx.globalCompositeOperation = 'source-over';
}

export function buildEarthMasks() {
  const q = COAST.q;

  // ── 전 세계 ──
  const GW = 4096, GH = 2048;
  const gc = makeCanvas(GW, GH), g = gc.getContext('2d');
  const gX = (lon) => ((lon + 180) / 360) * GW, gY = (lat) => ((90 - lat) / 180) * GH;
  g.fillStyle = '#000'; g.fillRect(0, 0, GW, GH);
  g.fillStyle = 'rgb(255,0,0)';
  g.fill(landPath(COAST.world, q, gX, gY), 'evenodd');
  // 동아시아는 50m 로 덮어 그리기 (해당 사각형 안만 지운 뒤 다시 채움)
  {
    const [x0, y0, x1, y1] = COAST.boxes.asia;
    g.save(); g.beginPath(); g.rect(gX(x0), gY(y1), gX(x1) - gX(x0), gY(y0) - gY(y1)); g.clip();
    g.fillStyle = '#000'; g.fillRect(0, 0, GW, GH);
    g.fillStyle = 'rgb(255,0,0)'; g.fill(landPath(COAST.asia, q, gX, gY), 'evenodd');
    g.restore();
  }
  drawLights(g, gX, gY, GW / 360, { haloDeg: 0.26, haloMin: 0.05, dotsPerWeight: 650, dotSigmaDeg: 0.3, onlyKorea: false, seed: 7 });

  // ── 한반도 고해상도 ──
  const b = KOREA_BOX, KW = 2048, KH = Math.round((KW * (b.lat1 - b.lat0)) / (b.lon1 - b.lon0));
  const kc = makeCanvas(KW, KH), k = kc.getContext('2d');
  const kX = (lon) => ((lon - b.lon0) / (b.lon1 - b.lon0)) * KW, kY = (lat) => ((b.lat1 - lat) / (b.lat1 - b.lat0)) * KH;
  k.fillStyle = '#000'; k.fillRect(0, 0, KW, KH);
  k.fillStyle = 'rgb(255,0,0)'; k.fill(landPath(COAST.korea, q, kX, kY), 'evenodd');
  drawLights(k, kX, kY, KW / (b.lon1 - b.lon0), { haloDeg: 0.12, haloMin: 0.02, dotsPerWeight: 5200, dotSigmaDeg: 0.08, onlyKorea: true, seed: 11 });

  return { global: gc, korea: kc, koreaBox: KOREA_BOX };
}
