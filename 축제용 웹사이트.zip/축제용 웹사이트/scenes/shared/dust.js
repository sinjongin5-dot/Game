// scenes/shared/dust.js — "먼지 입자 풀": 충돌 파편 → 네온 글자 → 풍화 → 우라늄 원자로 이어지는 하나의 파티클 시스템
//
//  모든 입자의 위치는 "씬 로컬 시간 uT 의 함수"로 셰이더 안에서 계산된다(상태·CPU 갱신 없음):
//   ① 폭발      0.35s~     충돌 지점에서 사방(위쪽 치우침)으로 분출, 공기 저항으로 감속. 뜨거운 주황 → 식으며 청록
//   ② 수렴      2.7~8s     왼쪽 글자 픽셀부터 순서대로(key) 소용돌이치며 글자 목표로 빨려 들어감 → 네온 선으로 그려지는 효과
//   ③ 유지      ~11s       실제 폰트 글자 판이 크로스페이드되는 동안 입자는 희미하게 반짝임
//   ④ 풍화      11~14s     왼쪽부터 순서대로 바람(+커브 노이즈)에 흩날려 분해
//   ⑤ 원자      13~16s     먼지가 다시 모여 우라늄 원자(핵 + 전자 오비탈 5겹)가 된다 → 이후 Ch.1(원자 속으로)이 같은 입자를 이어받는다
//  색: 파편=주황 → 네온 청록(+연두 성분). 이 "청록~연두" 색조 시드는 피날레의 초록 오로라에서도 그대로 쓴다(수미상관).
//  주의: 입자 순서/시드는 CPU 에서 한 번 만든 정적 버퍼이므로 품질 변경은 count 만 줄이면 된다(앞쪽 n개 = 균일 부분집합).

import * as THREE from 'three/webgpu';
import {
  float, vec2, vec3, uniform, uv, instanceIndex, instancedBufferAttribute, length, normalize, mix, smoothstep, clamp, pow, exp, sin, cos,
  hash, varying, step, floor, max, min, mx_noise_vec3, mx_noise_float,
} from 'three/tsl';
import { sphereDir } from '../../engine/tsl.js';
import { sampleText, TITLE_Y } from './titleText.js';

export const ATOM_CENTER = new THREE.Vector3(0, TITLE_Y, 0);

/** @param N 입자 수(최대) */
export function makeDust(ctx, N, text = '친환경 에너지') {
  const root = new THREE.Group();
  const uT = uniform(0.0);                 // 씬 로컬 시간(초)
  const uBright = uniform(0.55);           // 전체 밝기
  const uImpact = uniform(new THREE.Vector3(0, 2, 0));   // 폭발 중심(충돌 지점)

  const { A, B } = sampleText(text, N);
  const attrA = new THREE.InstancedBufferAttribute(A, 4), attrB = new THREE.InstancedBufferAttribute(B, 4);
  const a = instancedBufferAttribute(attrA);   // (tx, ty, key, kind)  kind: 1=외곽선(네온), 0=면
  const b = instancedBufferAttribute(attrB);   // (r1, r2, r3, r4) 시드
  const i = instanceIndex;
  const h = (k) => hash(i.add(k));
  const T = uT;
  const key = a.z, isEdge = a.w;

  // ── ① 폭발 ──
  const dRaw = sphereDir(b.x, b.y);
  const dir = normalize(vec3(dRaw.x, dRaw.y.abs().mul(0.7).add(0.35), dRaw.z));
  const speed = pow(b.z, 1.5).mul(330.0).add(90.0);
  const drag = 1.1;
  const pExp = (te) => uImpact.add(dir.mul(speed).mul(float(1.0).sub(exp(te.mul(-drag)))).div(drag));

  // ── ② 글자로 수렴 ──
  const target = vec3(a.x, a.y.add(TITLE_Y), b.z.sub(0.5).mul(0.7).add(sin(T.mul(3.0).add(b.x.mul(40.0))).mul(0.1)));
  const tc = key.mul(2.6).add(2.7).add(b.w.mul(0.25));                       // 이 입자가 출발하는 시각
  const dur = b.z.mul(0.5).add(1.4);
  const e1 = smoothstep(0.0, 1.0, clamp(T.sub(tc).div(dur), 0.0, 1.0));
  const teC = max(min(T, tc).sub(0.35), 0.0);
  const p0 = pExp(teC);
  const sv = normalize(dir.cross(vec3(0.0, 1.0, 0.0)).add(vec3(0.001, 0.0, 0.0)));
  const swirl1 = sv.mul(sin(e1.mul(3.14159265)).mul(float(26.0).add(b.y.mul(24.0))));
  const p1 = mix(p0, target, e1).add(swirl1);

  // ── ④ 풍화(왼쪽부터) ──
  const tr = key.mul(2.0).add(11.0).add(b.x.mul(0.3));
  const tau = clamp(T.sub(tr).div(2.6), 0.0, 1.0);
  const wind = normalize(vec3(1.0, 0.2, 0.55));
  const curl = mx_noise_vec3(target.mul(0.06).add(vec3(0.0, T.mul(0.18), 7.7))).mul(38.0).mul(pow(tau, 1.1));
  const disp = wind.mul(b.y.mul(80.0).add(50.0)).mul(pow(tau, 1.35)).add(curl);
  const p2 = p1.add(disp);

  // ── ⑤ 원자 ──
  const tg = b.y.mul(1.9).add(13.0);
  const e3 = smoothstep(0.0, 1.0, clamp(T.sub(tg).div(1.7), 0.0, 1.0));
  const shell = floor(b.x.mul(4.999));                                       // 0~4 번째 전자껍질
  const Rk = shell.mul(3.4).add(8.0);
  const theta = b.z.mul(6.2831853).add(T.mul(float(0.62).sub(shell.mul(0.09))).mul(step(0.5, b.w).mul(2.0).sub(1.0)));
  const al = shell.mul(0.63).add(0.3), be = shell.mul(1.9);
  const lx = cos(theta).mul(Rk), ly = float(0.0), lz = sin(theta).mul(Rk).mul(0.82);
  const ca = cos(al), sa = sin(al), cb = cos(be), sb = sin(be);
  const rx = lx, ry = ly.mul(ca).sub(lz.mul(sa)), rz = ly.mul(sa).add(lz.mul(ca));
  const orbit = vec3(rx.mul(cb).add(rz.mul(sb)), ry, rx.mul(sb).negate().add(rz.mul(cb)));
  const cloud = vec3(h(1).add(h(2)).add(h(3)).sub(1.5), h(4).add(h(5)).add(h(6)).sub(1.5), h(7).add(h(8)).add(h(9)).sub(1.5)).mul(0.95);
  const isNuc = step(b.y, 0.07);                                             // 7% 는 핵(양성자·중성자 덩어리)
  const nuc = sphereDir(h(10), h(11)).mul(pow(h(12), 0.33)).mul(1.9);
  const atomPos = vec3(ATOM_CENTER.x, ATOM_CENTER.y, ATOM_CENTER.z).add(mix(orbit.add(cloud), nuc, isNuc));
  const sv3 = normalize(vec3(b.x.sub(0.5), 0.6, b.y.sub(0.5)).cross(vec3(0.0, 1.0, 0.2)).add(vec3(0.001, 0.0, 0.0)));
  const p3 = mix(p2, atomPos, e3).add(sv3.mul(sin(e3.mul(3.14159265)).mul(16.0)));

  // ── 보이는 정도(실제 글자 판과 크로스페이드) ──
  const textHold = smoothstep(7.2, 8.8, T).mul(float(1.0).sub(smoothstep(10.9, 11.6, T)));   // 글자 판이 보이는 동안 1
  const vis = float(1.0).sub(textHold.mul(float(0.97).sub(float(0.2).mul(isEdge)).sub(0.0))).max(0.03);
  const spark = float(1.0).add(step(0.96, h(20).add(T.mul(0.9)).fract()).mul(2.2));

  // ── 색 ──
  const te = max(T.sub(0.35), 0.0);
  const hot = exp(te.mul(-0.85)).mul(step(T, tc));                           // 폭발 중에만 뜨겁다
  const neon = mix(vec3(0.16, 0.9, 1.0), vec3(0.4, 1.0, 0.55), b.w.mul(0.55));            // 청록 ~ 연두 (피날레 오로라와 동일 색조 시드)
  const dim = mix(vec3(0.05, 0.4, 0.75), vec3(0.2, 0.7, 0.5), b.w.mul(0.5));
  const base = mix(dim.mul(0.2), neon.mul(0.85), isEdge);
  const fire = mix(vec3(1.0, 0.45, 0.1), vec3(1.0, 0.92, 0.7), hot.mul(0.6)).mul(hot.mul(2.0).add(0.6));
  const atomCol = mix(vec3(0.7, 0.88, 1.0), mix(vec3(1.0, 0.55, 0.15), vec3(0.2, 0.95, 0.85), step(0.5, h(13))), isNuc).mul(isNuc.mul(0.9).add(1.0));   // 전자=흰빛 파랑, 핵=양성자 주황/중성자 청록
  let col = mix(fire, base, smoothstep(0.0, 0.9, e1));
  col = mix(col, base.mul(0.55), smoothstep(0.0, 0.5, tau));
  col = mix(col, atomCol, e3);
  col = col.mul(vis).mul(spark).mul(uBright);

  // ── 크기 ──
  const sizeBase = h(30).mul(0.16).add(0.17);
  const burst = float(1.0).add(exp(te.mul(-1.4)).mul(step(T, tc).mul(2.2)));

  const mat = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
  mat.positionNode = p3;
  mat.scaleNode = sizeBase.mul(burst).mul(isNuc.mul(0.9).mul(e3).add(1.0));
  mat.colorNode = varying(col, 'vDust');
  mat.opacityNode = smoothstep(0.5, 0.0, length(uv().sub(0.5))).pow(1.5);
  const points = new THREE.Sprite(mat);
  points.count = N; points.frustumCulled = false; points.renderOrder = 7;
  root.add(points);

  return {
    root, points, uT, uBright, uImpact, N,
    setCount(n) { points.count = Math.max(1000, Math.min(N, n | 0)); },
  };
}
