// scenes/shared/beams.js — 중성자 "빔" 풀: 머리(밝은 구) + 뒤로 길게 늘어진 빛 꼬리
//
//  씬이 매 프레임 beams.set(i, {pos, dir, len, color, alpha}) 로 위치만 알려 주면 된다. (꼬리 입자는 셰이더에서 계산: 상태 없음)
//  색 규약: 느린 중성자=파랑, 빠른 중성자=빨강 (config.js colors.neutronSlow / neutronFast)

import * as THREE from 'three/webgpu';
import { Fn, float, vec3, vec4, uniform, uv, instanceIndex, hash, normalize, length, mix, smoothstep, pow, sin, varying, exp } from 'three/tsl';

export function makeBeams(ctx, count = 8, perBeam = 520) {
  const root = new THREE.Group();
  const t = ctx.u.time;
  const beams = [];
  for (let b = 0; b < count; b++) {
    const U = {
      head: uniform(new THREE.Vector3(0, -999, 0)), dir: uniform(new THREE.Vector3(1, 0, 0)),
      len: uniform(5.0), color: uniform(new THREE.Vector3(0.2, 0.5, 1.0)), alpha: uniform(0.0), size: uniform(0.5),
    };
    // 꼬리 입자
    const m = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
    const i = instanceIndex;
    const s = pow(hash(i.add(b * 977)), 1.6);                                       // 머리 쪽에 더 촘촘
    const jitter = vec3(hash(i.add(11 + b)), hash(i.add(23 + b)), hash(i.add(37 + b))).sub(0.5).mul(U.size.mul(0.7).mul(s.mul(1.4).add(0.3)));
    m.positionNode = U.head.sub(U.dir.mul(s).mul(U.len)).add(jitter);
    m.scaleNode = U.size.mul(0.42).mul(float(1.0).sub(s.mul(0.7)));
    const flick = sin(t.mul(24.0).add(hash(i.add(5)).mul(40.0))).mul(0.2).add(0.8);
    m.colorNode = varying(U.color.mul(float(1.0).sub(s).pow(1.5)).mul(flick).mul(U.alpha).mul(0.55), `vBeam${b}`);
    m.opacityNode = smoothstep(0.5, 0.0, length(uv().sub(0.5))).pow(1.4);
    const trail = new THREE.Sprite(m); trail.count = perBeam; trail.frustumCulled = false; trail.renderOrder = 10;
    // 머리(광구)
    const hm = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
    hm.positionNode = U.head;
    hm.scaleNode = U.size.mul(3.4);
    hm.colorNode = Fn(() => { const r = length(uv().sub(0.5)).mul(2.0); return vec4(mix(U.color, vec3(1, 1, 1), exp(r.mul(-9.0))).mul(exp(r.mul(-3.6))).mul(smoothstep(1.0, 0.55, r)).mul(U.alpha).mul(2.0), 1.0); })();   // 가장자리를 0 으로 눌러 사각형이 보이지 않게
    const head = new THREE.Sprite(hm); head.frustumCulled = false; head.renderOrder = 11;
    root.add(trail, head);
    beams.push({ U, trail, head });
  }
  return {
    root, beams,
    /** i 번 빔 설정. pos: 머리 위치, dir: 진행 방향(단위), len: 꼬리 길이, color: THREE.Color/Vector3, alpha: 0~1, size: 머리 크기 */
    set(i, { pos, dir, len = 5, color, alpha = 1, size = 0.5 }) {
      const U = beams[i].U;
      U.head.value.copy(pos); U.dir.value.copy(dir); U.len.value = len; U.alpha.value = alpha; U.size.value = size;
      if (color) U.color.value.set(color.r ?? color.x, color.g ?? color.y, color.b ?? color.z);
    },
    hide(i) { beams[i].U.alpha.value = 0; },
    hideAll() { for (const b of beams) b.U.alpha.value = 0; },
  };
}
