// scenes/shared/dotChart.js — Ch.7 점 그림 막대그래프: "1 점 = 1 gCO₂eq/kWh"
//
//  발전원별 생애주기(건설~운영~폐기) 온실가스 배출량의 중앙값만큼 점이 쏟아져 쌓인다. 숫자를 읽지 않아도 높이로 한눈에 비교된다.
//  출처: IPCC AR5 WGIII (2014) Annex III, Table A.III.2 — 생애주기 배출량 중앙값(gCO₂eq/kWh):
//         석탄 820, 천연가스(복합) 490, 태양광(대규모) 48 [지붕형 41], 원자력 12, 풍력 11(육상)·12(해상).
//  ※ 발전원·기술·지역·가정에 따라 범위가 크다(석탄 740~910, 가스 410~650, 원자력 3.7~110 등). 화면에는 "중앙값"이라고 표기한다.

import * as THREE from 'three/webgpu';
import {
  Fn, float, vec3, vec4, uniform, instanceIndex, instanceColor, instancedBufferAttribute, hash, normalWorld, positionWorld, positionLocal, cameraPosition,
  normalize, dot, mix, smoothstep, clamp, pow, exp, sin, abs, fract, varying, length, uv,
} from 'three/tsl';
import { shade } from './studio.js';
import { makeFloor } from './fuelcycle.js';

export const SOURCES = [
  { id: 'coal', v: 820, name: '석탄', color: [0.9, 0.2, 0.08], t0: 0.0 },
  { id: 'gas', v: 490, name: '천연가스', color: [1.0, 0.55, 0.14], t0: 0.7 },
  { id: 'pv', v: 48, name: '태양광', color: [1.0, 0.88, 0.3], t0: 1.3 },
  { id: 'nuke', v: 12, name: '원자력', color: [0.35, 1.0, 0.6], t0: 1.8 },
  { id: 'wind', v: 11, name: '풍력', color: [0.45, 0.85, 1.0], t0: 2.2 },
];
const COLS = 10, DEPTH = 3, P = 0.55, PER = COLS * DEPTH, GAP = 3.4, BAR_W = COLS * P;
export const barX = (i) => (i - 2) * (BAR_W + GAP);
export const barH = (v) => Math.ceil(v / PER) * P;

export function makeDotChart(ctx) {
  const group = new THREE.Group();
  const uT = uniform(0.0), uA = uniform(1.0), uFocus = uniform(3.0);          // uFocus: 강조할 막대 번호(원자력=3)
  const total = SOURCES.reduce((s, o) => s + o.v, 0);
  const meta = new Float32Array(total * 4), ctrs = new Float32Array(total * 3);   // meta = (착지 시각, 막대 번호, 행, 해시), ctrs = 점 중심
  const geo = new THREE.SphereGeometry(0.21, 14, 10);
  const mat = new THREE.MeshBasicNodeMaterial({ transparent: true });
  const mt = instancedBufferAttribute(new THREE.InstancedBufferAttribute(meta, 4));
  const vm = varying(mt, 'vDotMeta');
  const s = clamp(uT.sub(vm.x).div(0.55), 0.0, 1.0), e = float(1.0).sub(pow(float(1.0).sub(s), 3.0));
  const ctr = instancedBufferAttribute(new THREE.InstancedBufferAttribute(ctrs, 3));
  const grow = smoothstep(0.0, 0.25, s).mul(0.2).add(0.8).mul(s.greaterThan(0.001).select(1.0, 0.0));            // 착지 전에는 보이지 않음
  mat.positionNode = ctr.add(positionLocal.sub(ctr).mul(grow)).add(vec3(0.0, float(1.0).sub(e).mul(34.0), 0.0));      // 점 중심 기준으로 크기 조절 + 위에서 낙하
  mat.colorNode = Fn(() => {
    const n = normalize(normalWorld), V = normalize(cameraPosition.sub(positionWorld));
    const dl = uT.sub(vm.x).sub(0.5).max(0.0);
    const lan = exp(dl.mul(-5.0)).mul(dl.greaterThan(0.0001).select(1.0, 0.0));                              // 착지 직후 번쩍
    const hi = float(1.0).add(abs(vm.y.sub(uFocus)).lessThan(0.5).select(0.45, 0.0));
    const col = instanceColor.mul(0.9).mul(hi).add(shade(n, V, instanceColor.mul(0.5), { metal: 0.1, rough: 0.35 }).mul(0.5)).add(instanceColor.mul(lan).mul(2.2));
    return vec4(col, uA);
  })();
  const mesh = new THREE.InstancedMesh(geo, mat, total), m4 = new THREE.Matrix4(), c = new THREE.Color();
  let k = 0;
  SOURCES.forEach((src, bi) => {
    for (let j = 0; j < src.v; j++) {
      const layer = j % PER, col = layer % COLS, zi = Math.floor(layer / COLS), row = Math.floor(j / PER);
      const px = barX(bi) + (col - (COLS - 1) / 2) * P, py = row * P + 0.3, pz = (zi - 1) * P;
      m4.makeTranslation(px, py, pz); ctrs[k * 3] = px; ctrs[k * 3 + 1] = py; ctrs[k * 3 + 2] = pz;
      mesh.setMatrixAt(k, m4); c.setRGB(...src.color); mesh.setColorAt(k, c);
      const h = Math.abs(Math.sin(k * 12.9898) * 43758.5453) % 1;
      meta[k * 4] = src.t0 + row * 0.04 + h * 0.3; meta[k * 4 + 1] = bi; meta[k * 4 + 2] = row; meta[k * 4 + 3] = h;
      k++;
    }
  });
  mesh.frustumCulled = false; group.add(mesh);
  const floor = makeFloor(90, 0.0); group.add(floor);
  // 기준선(바닥 위의 가는 빛 띠)
  const baseMat = new THREE.MeshBasicNodeMaterial({ transparent: true, blending: THREE.AdditiveBlending, depthWrite: false });
  baseMat.colorNode = Fn(() => { const u = uv(); return vec4(vec3(0.3, 0.7, 1.0).mul(smoothstep(0.5, 0.0, abs(u.y.sub(0.5))).mul(0.5)).mul(smoothstep(0.5, 0.35, abs(u.x.sub(0.5)))), 1.0); })();
  const base = new THREE.Mesh(new THREE.PlaneGeometry(barX(4) - barX(0) + BAR_W + 8, 1.2), baseMat); base.rotation.x = -Math.PI / 2; base.position.y = 0.02; group.add(base);
  return { group, mesh, uT, uA, uFocus, total };
}
