// scenes/shared/space.js — 오프닝 우주 공간 자원: 별밭, 태양(표면·코로나·플레어), 행성
//
//  모든 것이 "절차적(프로시저럴)" — 외부 이미지 없이 셰이더로 만든다.
//  좌표계(오프닝 공통): 태양 = 원점(반지름 100), 지구 방향 = +X. (단위는 연출용 비율이며 실제 축척이 아니다)

import * as THREE from 'three/webgpu';
import {
  Fn, float, vec2, vec3, vec4, uniform, uv, instanceIndex, cameraPosition, positionLocal, normalView, positionViewDirection,
  normalize, length, dot, mix, smoothstep, clamp, pow, exp, sin, cos, hash, mx_worley_noise_float, max, select, varying,
} from 'three/tsl';
import { fbm3, sphereDir, hdrRamp } from '../../engine/tsl.js';

export const SUN_R = 100;

// ───────────────────────── 별밭 ─────────────────────────
// 카메라를 따라다니는 거대한 천구 위에 무한히 먼 별을 뿌린다 (카메라가 수천 유닛 날아가도 별은 시차 없이 고정).
export function makeStars(ctx) {
  const N = 7000, R = 3000;
  const root = new THREE.Group();
  const mat = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
  const i = instanceIndex;
  const h1 = hash(i), h2 = hash(i.add(101)), h3 = hash(i.add(202)), h4 = hash(i.add(303));
  mat.positionNode = cameraPosition.add(sphereDir(h1, h2).mul(R));
  mat.scaleNode = float(4.0).add(pow(h3, 4.0).mul(10.0));                         // 대부분 작고 일부만 큼
  const twinkle = sin(ctx.u.time.mul(h2.mul(3.0).add(1.2)).add(h1.mul(60.0))).mul(0.22).add(0.78);
  const tint = mix(vec3(0.62, 0.78, 1.0), vec3(1.0, 0.86, 0.62), h4);              // 청백색 ~ 주황색 별
  // instanceIndex 에서 파생된 값은 정점 단계에서 계산 → varying 으로 프래그먼트에 전달
  mat.colorNode = varying(tint.mul(pow(h3, 5.0).mul(3.2).add(0.55)).mul(twinkle), 'vStarColor');
  mat.opacityNode = smoothstep(0.5, 0.0, length(uv().sub(0.5))).pow(1.6);         // 둥근 점 + 부드러운 가장자리
  const stars = new THREE.Sprite(mat);
  stars.count = N; stars.frustumCulled = false; stars.renderOrder = -10;
  root.add(stars);
  return { root, material: mat };
}

// ───────────────────────── 태양 ─────────────────────────
//  · 표면: 대류 세포(과립, worley 노이즈) + 슈퍼과립 + 흑점 + 가장자리 어두워짐(limb darkening), HDR 밝기
//  · 코로나: 카메라를 보는 큰 판 + 각도 방향 노이즈로 만든 방사형 빛줄기
//  · 플레어/프로미넌스: 구 표면에서 솟았다 가라앉는 자기장 고리를 따라 흐르는 수만 개의 점(전부 셰이더 안에서 계산, CPU 갱신 0)
//  핸들: uBig(0~1) = 대형 플레어 세기 — sun 씬이 시간에 맞춰 올린다.
export function makeSun(ctx) {
  const R = SUN_R;
  const root = new THREE.Group();
  const uBig = uniform(0);
  const uGain = uniform(1.0);            // 표면 밝기 배수 (튜닝/연출용)
  const uCoronaGain = uniform(1.0);      // 코로나 밝기 배수
  const t = ctx.u.time;

  // ── 표면 ──
  const surfMat = new THREE.MeshBasicNodeMaterial();
  surfMat.colorNode = Fn(() => {
    const p = normalize(positionLocal);
    const gA = mx_worley_noise_float(p.mul(46.0).add(vec3(0.0, 0.0, t.mul(0.5))));     // 작은 대류 세포 (0=중심 … 1=경계)
    const gB = mx_worley_noise_float(p.mul(13.0).add(vec3(t.mul(0.07), 0.0, 0.0)));    // 큰 슈퍼과립
    const mott = fbm3(p.mul(3.3).add(vec3(0.0, t.mul(0.03), 0.0)));                    // 대규모 밝기 얼룩
    const lanes = pow(clamp(float(1.0).sub(gA.mul(1.05)), 0.0, 1.0), 1.7);                 // 세포 사이 어두운 골
    const heat0 = lanes.mul(0.7).add(float(1.0).sub(gB).mul(0.3));
    const spots = smoothstep(0.5, 0.7, fbm3(p.mul(5.2).add(11.3)));                    // 흑점
    const heat = heat0.add(mott.mul(0.38)).sub(spots.mul(0.7));
    const mu = clamp(dot(normalView, positionViewDirection), 0.04, 1.0);
    const limb = pow(mu, 0.85);                                                          // 가장자리 어두워짐
    const col = hdrRamp(clamp(heat.mul(0.62).add(0.02), 0.0, 1.0));
    return vec4(col.mul(heat.mul(0.5).add(0.38)).mul(limb).mul(uGain), 1.0);       // 표면은 1 근처의 HDR: 블룸이 과하지 않게, 오렌지색과 대류 무늬가 읽히도록
  })();
  const sphere = new THREE.Mesh(new THREE.SphereGeometry(R, 128, 96), surfMat);
  sphere.name = 'sun-surface';
  root.add(sphere);

  // ── 코로나 ──
  const coronaMat = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
  const CORONA_SPAN = 4.0;   // 판의 반폭 = 4R
  coronaMat.colorNode = Fn(() => {
    const q = uv().sub(0.5).mul(2.0 * CORONA_SPAN);                                    // 태양 반지름 단위 좌표
    const rr = length(q);
    const dir = q.div(max(rr, 0.001));
    const rays = fbm3(vec3(dir.mul(2.3), t.mul(0.04).add(rr.mul(0.4)))).mul(0.5).add(0.5);
    const inner = exp(rr.sub(1.0).mul(-3.4));
    const outer = exp(rr.sub(1.0).mul(-1.3)).mul(0.09);
    const I = inner.add(outer).mul(rays.mul(1.4).add(0.3)).mul(smoothstep(0.97, 1.05, rr)).mul(smoothstep(float(CORONA_SPAN), 2.4, rr));
    const col = mix(vec3(1.0, 0.84, 0.52), vec3(1.0, 0.32, 0.06), smoothstep(1.0, 2.6, rr));
    return vec4(col.mul(I).mul(0.9).mul(uCoronaGain), 1.0);
  })();
  const corona = new THREE.Sprite(coronaMat);
  corona.scale.set(R * CORONA_SPAN * 2, R * CORONA_SPAN * 2, 1);
  corona.renderOrder = 1;
  root.add(corona);

  // ── 플레어/프로미넌스 (자기장 고리를 따라 흐르는 점) ──
  // 노드 그래프를 JS 로 직접 조립한다 (인스턴스 번호 → 고리 번호 → 고리 모양/수명 → 입자 위치).
  const ARCS = 16, N = 26000;
  const flareMat = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
  {
    const i = instanceIndex;
    const arcU = i.mod(ARCS);
    const big = select(arcU.lessThan(2), float(1.0), float(0.0));                      // 0·1번 고리 = 대형 플레어
    const s = (k) => hash(arcU.mul(13).add(k));
    // 발 위치: 카메라(+X 쪽)에서 볼 때 가장자리(limb)에 오도록 x 성분을 작게
    const phi = s(2).mul(6.2831853);
    const d0 = normalize(vec3(s(1).sub(0.42).mul(0.8), cos(phi), sin(phi)));
    const axis = normalize(vec3(s(3).sub(0.5), s(4).sub(0.5), s(5).sub(0.5)).add(vec3(0.001, 0.0, 0.0)));
    const tdir = normalize(d0.cross(axis));
    const span = mix(float(0.2).add(s(6).mul(0.32)), float(0.55), big);                // 고리 길이(라디안)
    const H = mix(float(0.1).add(s(7).mul(0.26)), float(0.6), big).mul(R);             // 고리 최대 높이
    // 수명 주기: 솟아오름 → 정점 → 가라앉음. 대형 플레어는 uBig 이 직접 제어
    const P = float(4.0).add(s(8).mul(5.0));
    const ph = t.div(P).add(s(9)).fract();
    const lifeCycle = smoothstep(0.0, 0.3, ph).mul(smoothstep(1.0, 0.62, ph));
    const life = mix(lifeCycle, uBig, big);
    // 고리를 따라 흐르는 입자
    const u = hash(i.add(7)).add(t.mul(hash(i.add(11)).mul(0.06).add(0.04))).fract();
    const a = u.sub(0.5).mul(span);
    const dp = d0.mul(cos(a)).add(tdir.mul(sin(a)));
    const prof = pow(sin(u.mul(3.14159265)), 0.75);
    // 자기장 줄기는 3가닥이 꼬인 밧줄(나선) 모양: 고리의 진행 방향 f, 반경 방향 dp, 옆 방향 side 로 단면을 만든다
    const f = d0.mul(sin(a).negate()).add(tdir.mul(cos(a)));
    const side = normalize(dp.cross(f));
    const strand = hash(i.add(51)).mul(3.0).floor().mul(2.0943951);
    const theta = u.mul(22.0).add(strand).add(hash(i.add(52)).sub(0.5).mul(0.9));
    const rad = float(0.8).add(prof.mul(H).mul(0.075)).mul(hash(i.add(53)).mul(0.9).add(0.45));
    const twist = dp.mul(cos(theta)).add(side.mul(sin(theta))).mul(rad);
    flareMat.positionNode = dp.mul(float(R * 1.003).add(prof.mul(H).mul(life))).add(twist);
    const bright = pow(sin(u.mul(3.14159265)), 0.5).mul(life);
    flareMat.scaleNode = float(2.4).add(hash(i.add(31)).mul(3.2)).mul(life.mul(0.6).add(0.4));
    // 낮은 곳은 흰빛 노랑, 높은 곳은 주황~붉은색
    flareMat.colorNode = varying(hdrRamp(float(0.52).sub(prof.mul(0.3)).add(hash(i.add(41)).mul(0.12))).mul(bright.mul(0.3)), 'vFlareColor');
    flareMat.opacityNode = smoothstep(0.5, 0.0, length(uv().sub(0.5))).pow(1.4);
  }
  const flares = new THREE.Sprite(flareMat);
  flares.count = N; flares.frustumCulled = false; flares.renderOrder = 2;
  root.add(flares);

  return { root, uBig, uGain, uCoronaGain, sphere, corona, flares, R };
}
