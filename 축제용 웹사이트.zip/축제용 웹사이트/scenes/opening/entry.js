// scenes/opening/entry.js — Scene 3. 대기권 진입 → 서울 돌진 (16~24초)
//
//  연출  16.0~18.4  지구(한반도)로 가속하며 접근 → 대기권에 닿자 화면 가장자리에 플라즈마 불꽃 + 열기 왜곡 + 화면 흔들림
//        18.4~19.0  구름층에 진입: 구름 베일이 화면을 덮는다 → (가려진 순간) 지구 구에서 "서울 로컬 월드"로 교체
//        19.0~23.5  구름 3겹을 뚫고 야경 도시 불빛(점 수십만 개)이 급속히 다가온다. 한강·산이 어두운 틈으로 보임
//        23.5~24.0  충돌 직전 0.5초 슬로모션(timeScale 0.15)으로 긴장감 → 24.0 충돌(Scene 4)
//  자막 없음. 사운드와 영상에 집중.
//  카메라는 월드 시간(tw)으로 진행해서, 슬로모션 구간에도 "정확히 충돌 순간에 지면에 닿도록" 맞춘다.
//
//  좌표: 지구 단계 = 오프닝 공통 좌표(지구 중심 EARTH_POS), 도시 단계 = 서울 로컬 좌표(1유닛=10m, 원점=시청).

import * as THREE from 'three/webgpu';
import { SceneBase } from '../_base.js';
import { Shared } from '../_shared.js';
import { makeStars } from '../shared/space.js';
import { makeEarth, EARTH_POS, EARTH_R, KOR_UP } from '../shared/earth.js';
import { makeCity } from '../shared/city.js';
import { Track, makePose } from '../../engine/camera.js';
import { clamp, curve, smoothstep, easeInCubic, easeInOutCubic, lerp } from '../../engine/ease.js';

const SWAP = 3.0;          // 로컬 시간: 지구 → 도시 월드 교체 시각 (= 19.0초, 구름 베일이 가장 짙은 순간)
const LEN = 8.0;
const R_START = 95, R_END = EARTH_R + 0.08;     // 접근 거리(지구 중심 기준): 95 → 대기 상단 약 12 km 위

// 슬로모션 곡선(마지막 0.5초): timeScaleAt 과 월드 시간 적분(twAt)이 같은 함수를 쓴다
const scaleCurve = (t) => curve([[0, 1], [7.3, 1], [7.55, 0.15], [9, 0.15]], t);
const TW = (() => { const n = 1600, tab = new Float32Array(n + 1); let acc = 0; for (let i = 1; i <= n; i++) { acc += scaleCurve(((i - 0.5) / n) * LEN) * (LEN / n); tab[i] = acc; } return tab; })();
const twAt = (t) => { const f = clamp(t / LEN) * 1600, i = Math.floor(f); return i >= 1600 ? TW[1600] : lerp(TW[i], TW[i + 1], f - i); };

export default class EntryScene extends SceneBase {
  async warmup() {
    const ctx = this.ctx;
    this.stars = await Shared.create(ctx, 'stars', makeStars);
    this.earth = await Shared.create(ctx, 'earth', makeEarth);
    this.city = await Shared.create(ctx, 'city', makeCity);
    this.pose = makePose(); this.pose.near = 0.3; this.pose.far = 9000;

    // 도시 단계 카메라 경로 (서울 로컬 좌표): 구름 위 12 km → 시청 앞 지면. 가속 하강 + 약한 나선
    this.dive = new Track({
      pos: [[-90, 1250, 760], [-60, 760, 450], [-30, 340, 200], [-10, 120, 76], [-2.5, 30, 20], [0, 7, 6.5]],
      look: [[0, 0, 0]], fov: [80, 66], ease: easeInCubic, scale: 300, near: 0.3, far: 9000,
    });
    this.diveLen = twAt(LEN) - twAt(SWAP);
    this.tw0 = twAt(SWAP);
  }

  start() {
    const ctx = this.ctx;
    this._phase = 'earth';
    Shared.acquire(ctx, 'stars');
    Shared.acquire(ctx, 'earth');
    this.city.setImpact(-1);
    this.city.uGlow.value = 1; this.city.uSlab.value = 1; this.city.uGround.value = 1; this.city.uPool.value = 0;

    const a = this.audio;
    this.roar = this.own(a.wind({ level: 0.0001, center: 600, fadeIn: 0.1 }));
    this.rumble = this.own(a.drone({ freqs: [44, 66], level: 0.0001, cutoff: 220, fadeIn: 0.1, detune: 14 }));
    this._acc = 0;
  }

  timeScaleAt(t) { return scaleCurve(t); }

  _swapToCity() {
    Shared.release(this.ctx, 'earth');
    Shared.acquire(this.ctx, 'city');
    this._phase = 'city';
  }

  update(t, dt, dtReal) {
    const w = this.weight, post = this.post, ctx = this.ctx, pose = this.pose;
    post.blendBloom(1.5, w);

    // 월드 시간 클럭에 따라 단계 전환 (시크 후에도 같은 결과)
    if (this._phase === 'earth' && t >= SWAP) this._swapToCity();
    else if (this._phase === 'city' && t < SWAP - 0.001) { Shared.release(ctx, 'city'); Shared.acquire(ctx, 'earth'); this._phase = 'earth'; }

    // ── 카메라 ──
    if (this._phase === 'earth') {
      const u = clamp(t / SWAP);
      const e = easeInCubic(u) * 0.85 + u * 0.15;                       // 시작은 부드럽게(Scene 2 의 감속 이어받음), 갈수록 가속
      const r = lerp(R_START, R_END, e);
      const spin = 0.25 * u * u;                                         // 하강하며 살짝 선회
      pose.pos.copy(EARTH_POS).addScaledVector(KOR_UP, r);
      pose.pos.x += Math.sin(spin * 6) * r * 0.01; pose.pos.y += Math.cos(spin * 6) * r * 0.01;
      pose.look.copy(EARTH_POS).addScaledVector(KOR_UP, EARTH_R - 1);
      pose.fov = lerp(58, 82, easeInCubic(u));
      pose.roll = 0.16 * u * Math.sin(u * 5.0);
      pose.scale = Math.max(0.3, r - EARTH_R);
      pose.near = 0.02; pose.far = 9000;
      this.cam(pose);
      // 지구 구름·불빛 고주파 디테일은 가까울수록
      this.earth.uDetail.value = clamp(1 - (r - EARTH_R - 0.5) / 30);
      this.earth.uCloudSpin.value = ctx.u.time.value * 0.0006;
    } else {
      const u = clamp((twAt(t) - this.tw0) / this.diveLen);
      const p = this.dive.at(u);
      pose.pos.copy(p.pos); pose.look.copy(p.look);
      pose.fov = p.fov + 10 * Math.sin(u * Math.PI) ;                    // 중간에 FOV 가 한 번 더 확 벌어짐 (급강하 체감)
      pose.roll = 0.22 * Math.sin(u * 3.2) * (1 - u);
      pose.scale = Math.max(4, p.pos.y * 0.3);
      pose.near = 0.2; pose.far = 9000;
      this.cam(pose);
    }

    // ── 화면 FX 타임라인 (로컬 시간) ──
    post.u.fire.value = curve([[0.55, 0], [1.3, 0.75], [2.2, 1.0], [3.5, 1.0], [4.8, 0.5], [6.2, 0.14], [8.0, 0.0]], t) * w;
    post.u.heat.value = curve([[0.6, 0], [1.4, 0.8], [2.4, 1.0], [3.6, 0.8], [5.5, 0.25], [8.0, 0.0]], t) * w;
    post.u.veil.value = curve([[2.2, 0], [2.7, 0.65], [3.05, 1.0], [3.5, 0.9], [4.4, 0.28], [5.6, 0.04], [7.0, 0.0]], t) * w;
    post.u.speed.value = curve([[0, 0.0], [3.2, 0.15], [5.5, 0.55], [7.5, 0.85]], t) * w;
    post.u.anamorphic.value = ctx.config.post.anamorphic.strength * (1 + 0.8 * smoothstep((t - 5.0) / 3.0));
    // 화면 흔들림: 대기권 진입 이후 계속(에너지를 유지해 주는 방식)
    if (t > 0.9) this.camRig.shake(dt * 3.2 * (0.45 + 0.35 * smoothstep((t - 0.9) / 3.0)) * w);

    // ── 도시 단계 세부 ──
    if (this._phase === 'city') {
      const cap = this.quality.particleCap;
      this.city.setCount(cap * 0.4);
      // 구름층 사이를 지날 때 도시 불빛이 구름에 가려지도록 slab 불투명도는 셰이더가 처리
    }

    // ── 사운드 ──
    this._acc += dtReal;
    if (this._acc > 0.1) {
      this._acc = 0;
      const burn = curve([[0.4, 0], [1.6, 1], [4.5, 0.85], [7.2, 0.55], [8, 0.3]], t);
      this.roar.setLevel(0.02 + 0.34 * burn * w, 0.25);
      this.roar.setCenter(500 + 1500 * smoothstep(t / 8), 0.25);
      this.rumble.setLevel(0.12 + 0.34 * smoothstep((t - 0.8) / 3.5) * w, 0.25);
      this.rumble.setCutoff(180 + 700 * smoothstep(t / 8), 0.25);
    }
    this.once('enter', t > 1.3, () => this.audio.whoosh({ dur: 1.4, from: 400, to: 3600, level: 0.3 }));
    this.once('cloud', t > 2.85, () => this.audio.hit({ freq: 70, level: 0.3, decay: 0.8, noise: 0.9 }));
    this.once('dive', t > 3.9, () => this.audio.riser({ dur: 3.4, from: 200, to: 3000, level: 0.28 }));
    this.once('tension', t > 7.45, () => { this.own(this.audio.drone({ freqs: [36.7], level: 0.5, cutoff: 120, fadeIn: 0.25, type: 'sine', detune: 2 })); this.rumble.setCutoff(70, 0.3); this.roar.setLevel(0.04, 0.3); });
  }

  dispose() {
    const ctx = this.ctx;
    Shared.release(ctx, 'stars');
    Shared.release(ctx, this._phase === 'city' ? 'city' : 'earth');
    const u = this.post.u;
    u.fire.value = 0; u.heat.value = 0; u.veil.value = 0; u.speed.value = 0;
    u.anamorphic.value = ctx.config.post.anamorphic.strength;
  }
}
