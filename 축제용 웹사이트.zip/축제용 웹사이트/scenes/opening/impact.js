// scenes/opening/impact.js — Scene 4. 충돌 & 글자 연출 (24~40초)
//
//   0.0  화이트 플래시 → 충격파 링(지면) + 충격 돔 + 파편 폭발 + 카메라 쉐이크 + 쾅
//   0.6~2.7  도시 불빛이 파동에 지워지고, 카메라가 급히 뒤로 빠지며 올라간다. 파편이 사방으로 흩어짐
//   2.7~7.0  파편이 글자의 왼쪽부터 순서대로 화면 중앙으로 빨려 들어가며 "친환경 에너지"를 네온 선으로 그려 냄
//   7.0~9.0  입자가 정렬되며 실제 폰트 글자(금속 + 네온 외곽)로 크로스페이드, 빛이 글자를 가로질러 쓸고 가며 렌즈 플레어
//   9.0~11.0 글자 유지(≈2초)
//   11.0~14.0 글자가 왼쪽부터 먼지처럼 바람에 풍화 (입자가 같은 자리에서 다시 나타나 흩날림)
//   13.0~16.0 먼지가 하나둘 모여 우라늄 원자(핵 + 전자 오비탈)가 됨 → Ch.1 로 이어짐
//  입자 풀은 shared/dust.js — 피날레의 초록 오로라와 Ch.1 의 원자도 같은 입자 시드(색조 포함)를 사용한다.

import * as THREE from 'three/webgpu';
import { Fn, float, vec3, vec4, uniform, uv, texture, exp, pow, smoothstep, length, mix } from 'three/tsl';
import { SceneBase } from '../_base.js';
import { Shared } from '../_shared.js';
import { makeStars } from '../shared/space.js';
import { makeCity } from '../shared/city.js';
import { makeDust, ATOM_CENTER } from '../shared/dust.js';
import { buildTitleTexture, TITLE_W, TITLE_Y } from '../shared/titleText.js';
import { Track, makePose } from '../../engine/camera.js';
import { clamp, curve, smoothstep as sstep, lerp } from '../../engine/ease.js';

const TEXT = '친환경 에너지';
/** 시간(t) → 경로 매개변수(0~1): 구간별 선형 보간(키마다 멈추지 않아 속도가 연속적) */
const lin = (keys, t) => { if (t <= keys[0][0]) return keys[0][1]; for (let i = 0; i < keys.length - 1; i++) { const [t0, v0] = keys[i], [t1, v1] = keys[i + 1]; if (t <= t1) return lerp(v0, v1, (t - t0) / (t1 - t0)); } return keys[keys.length - 1][1]; };

export default class ImpactScene extends SceneBase {
  async warmup() {
    const ctx = this.ctx;
    this.stars = await Shared.create(ctx, 'stars', makeStars);
    this.city = await Shared.create(ctx, 'city', makeCity);

    // 입자 풀: 품질 상한의 30% (고: 30만 / 중: 9만 / 저: 1.5만 / WebGL2 폴백: 3만)
    const N = Math.max(15000, Math.min(300000, Math.floor(this.quality.particleCap * 0.3)));
    this.dust = makeDust(ctx, N, TEXT);
    this.root.add(this.dust.root);

    // 실제 폰트 글자 판 (금속 + 네온 질감). 빛 스윕 밴드는 셰이더에서
    const tex = buildTitleTexture(TEXT);
    this.uAlpha = uniform(0.0); this.uSweep = uniform(-1.0);
    const s = texture(tex, uv());
    const tm = new THREE.MeshBasicNodeMaterial({ transparent: true, depthWrite: false });
    const band = exp(pow(uv().x.sub(this.uSweep).mul(7.5), float(2.0)).negate());
    tm.colorNode = vec4(s.rgb.mul(1.35).add(vec3(1.0, 0.95, 0.85).mul(band).mul(s.a).mul(3.2)), 1.0);
    tm.opacityNode = s.a.mul(this.uAlpha);
    this.textMesh = new THREE.Mesh(new THREE.PlaneGeometry(TITLE_W, TITLE_W * 0.25), tm);
    this.textMesh.position.set(0, TITLE_Y, 0); this.textMesh.renderOrder = 9;
    this.root.add(this.textMesh);

    // 충돌 섬광(큰 광구)과 글자 스윕용 별빛(렌즈 플레어)
    const mkGlow = (power) => {
      const m = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
      const u = uniform(0.0);
      m.colorNode = Fn(() => { const r = length(uv().sub(0.5)).mul(2.0); return vec4(mix(vec3(1.0, 0.6, 0.25), vec3(1.0, 0.95, 0.85), exp(r.mul(-6.0))).mul(exp(r.mul(-power))).mul(u), 1.0); })();
      return { m, u };
    };
    const g1 = mkGlow(3.2); this.flashSprite = new THREE.Sprite(g1.m); this.uFlashGlow = g1.u; this.flashSprite.scale.set(900, 900, 1); this.flashSprite.position.set(0, 10, 0); this.flashSprite.renderOrder = 11;
    const g2 = mkGlow(5.5); this.flareSprite = new THREE.Sprite(g2.m); this.uFlare = g2.u; this.flareSprite.scale.set(34, 34, 1); this.flareSprite.renderOrder = 12;
    this.root.add(this.flashSprite, this.flareSprite);

    // 카메라: 충돌 직전 Scene 3 의 마지막 포즈(시청 앞 지면)에서 시작 → 위로/뒤로 빠져 글자 정면으로
    this.track = new Track({
      pos: [[0, 7, 6.5], [0, 22, 30], [0, 44, 80], [0, 54, 124], [0, 57, 112], [0, 58, 101], [0, 58, 98], [0, 58, 110], [0, 58, 128]],
      look: [[0, 0, 0], [0, 12, 0], [0, 38, 0], [0, 56, 0], [0, 58, 0]], ease: (u) => u, fov: [66, 52], scale: 60, near: 0.3, far: 9000,
    });
    this.pose = makePose();
  }

  start() {
    const ctx = this.ctx;
    Shared.acquire(ctx, 'stars');
    Shared.acquire(ctx, 'city');
    this.city.uGlow.value = 1; this.city.uWipe.value = 1; this.city.uSlab.value = 1; this.city.uGround.value = 1; this.city.uPool.value = 0;
    this.dust.uT.value = 0;
    this._acc = 0; this._pingIdx = 0;
    this.onQuality();
  }

  onQuality() {
    this.dust.setCount(Math.min(this.dust.N, this.quality.particleCap * 0.3));
    this.city.setCount(this.quality.particleCap * 0.4);
  }

  update(t, dt, dtReal) {
    const w = this.weight, post = this.post, a = this.audio, ctx = this.ctx;
    post.blendBloom(1.0, w);
    const tt = Math.max(t, 0);
    this.dust.uT.value = tt;
    this.dust.uBright.value = 0.55 * (t > 14 ? w : 1);              // 끝에서 Ch.1 의 원자 층으로 넘어갈 때 입자 원자를 서서히 비운다
    this.city.setImpact(t >= 0 ? t : -1);

    // ── 충돌 순간 ──
    this.once('impact', t >= 0, () => {
      post.flashPulse(1.0, 2.1);
      this.camRig.shake(1.5);
      a.hit({ freq: 36, level: 1.0, decay: 3.2, noise: 0.9 });
      a.hit({ freq: 84, level: 0.55, decay: 1.4, noise: 0.5 });
      this.own(a.wind({ level: 0.3, center: 260, fadeIn: 0.05 })).setLevel(0.02, 2.2);   // 충격 직후 먼지 바람이 잦아듦
    });
    this.uFlashGlow.value = t >= 0 ? Math.exp(-t * 1.7) * 2.6 * w : 0;
    if (t >= 0 && t < 2.5) this.camRig.shake(dt * 0.9 * Math.exp(-t * 0.9));

    // ── 배경 정리: 충격파가 구름을 날려 보내고, 도시 빛 번짐이 사라지며, 글자 아래에 청록 빛 웅덩이가 번진다 ──
    this.city.uSlab.value = 1 - sstep((t - 0.3) / 2.2);
    this.city.uGround.value = 1 - 0.9 * sstep((t - 0.8) / 3.0);
    this.city.uPool.value = (sstep((t - 4.0) / 3.0) * (1 - 0.6 * sstep((t - 11.0) / 2.0)) + 0.9 * sstep((t - 14.0) / 1.5)) * w;

    // ── 글자 판 / 빛 스윕 / 렌즈 플레어 ──
    const hold = sstep((t - 7.2) / 1.6) * (1 - sstep((t - 10.9) / 0.7));
    this.uAlpha.value = hold * w;
    const sw = clamp((t - 8.2) / 1.9);                                                  // 8.2~10.1 스윕
    this.uSweep.value = sw > 0 && sw < 1 ? lerp(-0.1, 1.1, sw) : -1;
    const bell = Math.sin(Math.PI * sw) * (sw > 0 && sw < 1 ? 1 : 0);
    this.flareSprite.position.set(lerp(-TITLE_W * 0.6, TITLE_W * 0.6, sw), TITLE_Y, 1.5);
    this.uFlare.value = bell * 3.0 * w;
    post.u.anamorphic.value = ctx.config.post.anamorphic.strength * (1 + 2.2 * bell);

    // ── 카메라 ──
    const u = lin([[0, 0], [1.0, 0.1], [3.0, 0.34], [6.0, 0.6], [11.0, 0.8], [16.0, 1.0]], t);
    const p = this.track.at(clamp(u));
    this.pose.pos.copy(p.pos); this.pose.look.copy(p.look);
    this.pose.pos.x += Math.sin(tt * 0.25) * 2.2 * sstep(tt / 5);                        // 정면 대기 중 약한 좌우 이동
    this.pose.fov = p.fov;
    this.pose.scale = Math.max(6, this.pose.pos.distanceTo(p.look) * 0.2);
    this.pose.near = 0.3; this.pose.far = 9000;
    this.cam(this.pose);

    // ── 사운드 ──
    if (t > 2.9 && t < 7.2) {                                                            // 글자가 그려지는 동안 상승하는 반짝임 아르페지오 (펜타토닉)
      const idx = Math.floor((t - 2.9) / 0.34);
      if (idx > this._pingIdx) { this._pingIdx = idx; const sc = [0, 2, 4, 7, 9, 12, 14, 16, 19, 21]; a.ping({ freq: 440 * Math.pow(2, sc[idx % sc.length] / 12 + Math.floor(idx / 10) * 1), level: 0.07 + 0.002 * idx, decay: 0.9 }); }
    }
    this.once('reveal', t > 7.3, () => { this.own(a.drone({ freqs: [220, 277.2, 329.6, 440], level: 0.2, cutoff: 3500, type: 'sine', fadeIn: 0.8, bus: 'music', detune: 4 })); a.hit({ freq: 70, level: 0.5, decay: 1.4, noise: 0.2 }); });
    this.once('sweep', t > 8.2, () => { a.whoosh({ dur: 1.7, from: 500, to: 6000, level: 0.25 }); a.ping({ freq: 1760, level: 0.16, decay: 1.8 }); });
    this.once('dissolve', t > 11.0, () => { this.own(a.wind({ level: 0.26, center: 700, fadeIn: 0.8 })); });
    this.once('gather', t > 12.9, () => { a.riser({ dur: 2.8, from: 200, to: 2600, level: 0.2 }); this.own(a.drone({ freqs: [55, 110, 164.8], level: 0.26, cutoff: 500, fadeIn: 2.0, detune: 7 })); });
    this.once('atom', t > 15.2, () => { for (const f of [523.3, 784.0, 1046.5]) a.ping({ freq: f, level: 0.1, decay: 2.4 }); });
  }

  dispose() {
    Shared.release(this.ctx, 'stars');
    Shared.release(this.ctx, 'city');
    this.uAlpha.value = 0; this.uFlare.value = 0; this.uFlashGlow.value = 0;
    this.city.setImpact(-1); this.city.uSlab.value = 1; this.city.uGround.value = 1; this.city.uPool.value = 0;
    this.post.u.anamorphic.value = this.ctx.config.post.anamorphic.strength;
  }
}
