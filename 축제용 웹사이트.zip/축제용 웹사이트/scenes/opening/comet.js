// scenes/opening/comet.js — Scene 2. 혜성이 되어 날아가기 (6~16초)
//
//  연출: 태양 표면에서 튕겨 나온 혜성의 시점. 처음 ~2초는 멀어지는 태양을 돌아보며(뒤로 푸른 이온 꼬리·먼지 꼬리가 길게 늘어남),
//        카메라가 핵 주위를 반 바퀴 돌아 진행 방향을 향한다. FOV 가 확 넓어지는 워프 + 화면 가장자리 속도선.
//        수성·금성을 스쳐 지나가고, 푸른 지구가 점점 커지며 다가온다. (한반도가 터미네이터에 걸린 쪽으로 접근)
//  사운드: 점점 커지는 바람 + 상승하는 저음.
//  매치컷: 태양 화이트아웃(Scene 1) → 이 씬 시작 / 이 씬 끝(지구 푸른 림) → Scene 3 대기권 불꽃.
//  좌표: 오프닝 공통(태양=원점, 지구=+X 2640). 지구 접근 종점 = 한반도 위 95 유닛.

import * as THREE from 'three/webgpu';
import { SceneBase } from '../_base.js';
import { Shared } from '../_shared.js';
import { makeStars, makeSun } from '../shared/space.js';
import { makeEarth, EARTH_POS, KOR_UP } from '../shared/earth.js';
import { makeComet, makePlanets } from '../shared/comet.js';
import { Track, makePose } from '../../engine/camera.js';
import { clamp, curve, smoothstep, smootherstep, easeInOutCubic, easeOutCubic, lerp } from '../../engine/ease.js';

const C = new THREE.Vector3(), T = new THREE.Vector3(), LOOK = new THREE.Vector3(), V = new THREE.Vector3();
const X = new THREE.Vector3(1, 0, 0);

export default class CometScene extends SceneBase {
  async warmup() {
    const ctx = this.ctx;
    this.stars = await Shared.create(ctx, 'stars', makeStars);
    this.sun = await Shared.create(ctx, 'sun', makeSun);
    this.earth = await Shared.create(ctx, 'earth', makeEarth);
    this.planets = await Shared.create(ctx, 'planets', makePlanets);
    this.cometObj = makeComet(ctx);
    this.root.add(this.cometObj.root);

    // 혜성(핵) 경로: 태양 표면 → 수성·금성 곁 → 한반도 위 95 유닛
    const end = EARTH_POS.clone().addScaledVector(KOR_UP, 95);
    this.path = new THREE.CatmullRomCurve3([
      new THREE.Vector3(130, 0, 0), new THREE.Vector3(330, 10, -8), new THREE.Vector3(680, -6, 12), new THREE.Vector3(1150, 14, -10),
      new THREE.Vector3(1750, -10, 14), new THREE.Vector3(2250, 6, 30), new THREE.Vector3(2470, 14, 58), end,
    ], false, 'centripetal');
    this.endPos = end;

    // 핵 기준 카메라 상대 위치/시선 (진행도 u=0~1). 0: 태양 쪽을 돌아봄 → 0.38: 핵을 바라보며 선회 → 0.55 이후 진행 방향
    this.offTrack = new Track({
      pos: [[-7, 5, 13], [-4, 6, 16], [6, 5.5, 12.5], [9.5, 3.5, 7.5], [6.5, 2.4, 3.4], [2.2, 0.8, 0.5], [0.4, 0.15, 0.0]],
      look: [[-95, -4, 0], [-45, -2, 0], [0, 0, 0], [70, 0, 0], [170, 0, 0], [400, 0, 0], [800, 0, 0]],
      fov: [75, 58], ease: (u) => u,
    });
    this.pose = makePose();
    this.pose.near = 0.4; this.pose.far = 9000;
  }

  start() {
    const ctx = this.ctx;
    for (const k of ['stars', 'sun', 'earth', 'planets']) Shared.acquire(ctx, k);
    this._acc = 0;
    this.cometObj.uFade.value = 1; this.cometObj.nucleus.visible = true;

    const a = this.audio;
    this.wind = this.own(a.wind({ level: 0.06, center: 380, fadeIn: 1.0 }));
    this.engine = this.own(a.drone({ freqs: [55, 110, 165], level: 0.22, cutoff: 260, fadeIn: 1.2, detune: 9 }));
    a.hit({ freq: 52, level: 0.6, decay: 1.5, noise: 0.5 });                          // 발사 쿵
    this.own(a.riser({ dur: 3.5, from: 400, to: 4200, level: 0.2 }));
  }

  /** 시간 → 경로 진행도: 발사 순간의 가속(빠른 출발)과 지구 앞에서 부드럽게 감속하는 ease-in-out 의 혼합 */
  pathEase(u) { return clamp(0.62 * easeInOutCubic(u) + 0.38 * easeOutCubic(u)); }

  update(t, dt, dtReal) {
    const w = this.weight, post = this.post, u = clamp(t / this.len);
    post.blendBloom(1.9, w);
    const e = this.pathEase(u);
    this.path.getPointAt(e, C);
    this.path.getTangentAt(e, T);

    // 혜성 오브젝트: 핵 위치 + 진행 방향으로 회전(꼬리는 −X = 뒤쪽)
    const g = this.cometObj.root;
    g.position.copy(C);
    g.quaternion.setFromUnitVectors(X, T);
    // 카메라가 핵과 하나가 되는 후반부: 꼬리·코마 페이드, 핵 축소
    const merge = smoothstep((u - 0.72) / 0.22);
    this.cometObj.uFade.value = (1 - 0.85 * merge) * w;
    this.cometObj.nucleus.scale.setScalar(Math.max(0.001, 1 - merge));

    // 카메라: 핵 + 상대 위치. 시선은 초반 상대 오프셋 → 후반엔 지구 중심으로 서서히 이동
    const tr = this.offTrack.at(u);
    const pose = this.pose;
    pose.pos.copy(C).add(tr.pos);
    LOOK.copy(C).add(tr.look);
    const toEarth = smootherstep((u - 0.5) / 0.5);
    V.copy(EARTH_POS).lerp(this.endPos, 0.0);
    LOOK.lerp(V, toEarth);
    pose.look.copy(LOOK);
    pose.fov = curve([[0, 74], [0.08, 108], [0.38, 98], [0.62, 72], [0.86, 61], [1, 58]], u);
    pose.roll = 0.09 * Math.sin(u * Math.PI * 1.6) * (1 - toEarth);
    pose.scale = 8;
    this.cam(pose);

    // 화면 FX: 속도선(가장자리) — 초반 폭발적, 중반 최대, 지구에 다가가며 잦아듦
    post.u.speed.value = curve([[0, 0.5], [0.1, 1.0], [0.5, 0.95], [0.85, 0.35], [1, 0.0]], u) * w;
    post.u.anamorphic.value = this.ctx.config.post.anamorphic.strength * (0.8 + 0.6 * (1 - u));
    post.u.godray.value = 0;

    // 지구 구름 디테일: 가까워질수록(거리 < 120) 서서히
    const dEarth = pose.pos.distanceTo(EARTH_POS);
    this.earth.uDetail.value = clamp(1 - (dEarth - 45) / 110);
    this.earth.uCloudSpin.value = this.ctx.u.time.value * 0.0006;

    // 사운드
    this._acc += dtReal;
    if (this._acc > 0.2) {
      this._acc = 0;
      this.wind.setLevel(0.06 + 0.3 * smoothstep(u), 0.4);
      this.wind.setCenter(380 + 1700 * u, 0.4);
      this.engine.setFreqs([55 * (1 + u * 0.9), 110 * (1 + u * 0.9), 165 * (1 + u * 0.9)], 0.5);
      this.engine.setCutoff(260 + 900 * u, 0.4);
    }
    this.once('merc', C.x > 940, () => this.audio.whoosh({ dur: 0.7, from: 2600, to: 500, level: 0.24 }));
    this.once('venus', C.x > 1540, () => this.audio.whoosh({ dur: 0.9, from: 2200, to: 400, level: 0.26 }));
    this.once('earthriser', t > 6.0, () => this.audio.riser({ dur: 3.8, from: 150, to: 2200, level: 0.18 }));
  }

  dispose() {
    for (const k of ['stars', 'sun', 'earth', 'planets']) Shared.release(this.ctx, k);
    this.post.u.speed.value = 0;
    this.post.u.anamorphic.value = this.ctx.config.post.anamorphic.strength;
  }
}
