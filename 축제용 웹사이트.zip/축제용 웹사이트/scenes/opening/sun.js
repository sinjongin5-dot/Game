// scenes/opening/sun.js — Scene 1. 태양 (0~6초)
//
//  연출: 검은 우주 + 별밭, 화면 가득 거대한 태양. 카메라는 +X 방향에서 아주 천천히 다가가고(ease-in-out),
//        블룸·갓레이로 눈부시다. 3~5초에 대형 플레어가 솟구치고, 끝 무렵 플레어 속으로 파고들며 화이트아웃 → 혜성(Scene 2).
//  사운드: 낮은 드론 + 서서히 커지는 배음 + 저음 럼블, 화이트아웃 직전 상승음 → 쿵.
//  자막: "모든 에너지의 시작, 태양" (config.js)
//  좌표: 태양 = 원점(반지름 100), 카메라는 +X 쪽에서 −X 방향(태양)을 본다.

import { SceneBase } from '../_base.js';
import { Shared } from '../_shared.js';
import { makeStars, makeSun } from '../shared/space.js';
import { Track } from '../../engine/camera.js';
import { curve, smoothstep, easeInOutSine } from '../../engine/ease.js';
import * as THREE from 'three/webgpu';

const _v = new THREE.Vector3();

export default class SunScene extends SceneBase {
  async warmup() {
    this.stars = await Shared.create(this.ctx, 'stars', makeStars);
    this.sun = await Shared.create(this.ctx, 'sun', makeSun);
    // 카메라 돌리: 7초짜리 경로를 6.6초까지(겹침 구간 끝) 사용 → 화이트아웃 순간에도 계속 다가가는 중
    this.track = new Track({
      pos: [[480, 44, 64], [398, 30, 46], [328, 18, 31], [262, 9, 20]],
      look: [[0, -2, 0]], fov: [46, 52], ease: easeInOutSine, scale: 260, near: 1, far: 9000,
    });
  }

  start() {
    Shared.acquire(this.ctx, 'stars');
    Shared.acquire(this.ctx, 'sun');
    this._acc = 0;

    // 사운드: 낮은 드론(E1) + 위로 갈수록 커지는 배음 + 저음 럼블
    const a = this.audio;
    this.drone = this.own(a.drone({ freqs: [41.2, 82.4, 123.5], level: 0.32, cutoff: 170, fadeIn: 2.2, detune: 6 }));
    this.overtones = this.own(a.drone({ freqs: [329.6, 494.0, 659.3], level: 0.02, cutoff: 1100, type: 'sine', fadeIn: 0.4, bus: 'music', detune: 3 }));
    this.rumble = this.own(a.wind({ level: 0.2, center: 90, fadeIn: 2.5 }));
  }

  update(t, dt, dtReal) {
    const w = this.weight, post = this.post, p = this.progress(t);
    post.blendBloom(2.6, w);
    this.cam(this.track.at(t / 7.0));

    // 대형 플레어: 1.5초부터 솟아올라 4.2초에 정점
    this.sun.uBig.value = curve([[0, 0.12], [1.5, 0.22], [4.3, 1.0], [7, 1.0]], t) * w;

    // 갓레이: 태양의 화면 위치를 광원으로. 다가갈수록 강해진다
    _v.set(0, 0, 0).project(this.ctx.camera);
    post.u.godCenter.value.set(_v.x * 0.5 + 0.5, _v.y * 0.5 + 0.5);
    post.u.godray.value = (0.1 + 0.2 * p) * w;
    post.u.anamorphic.value = this.ctx.config.post.anamorphic.strength * (0.45 + 0.4 * p);

    // 화이트: 시작 때 눈부심이 걷히며 태양이 드러나고, 끝에서 플레어 속으로 화이트아웃 (정점 ≈ 5.95초)
    const fadeIn = 1 - smoothstep(t / 1.4);
    const burst = smoothstep((t - 5.3) / 0.65) * (1 - smoothstep((t - 5.95) / 0.6));
    post.setFlash(Math.max(fadeIn, burst));

    // 사운드 변화는 0.2초에 한 번만 갱신
    this._acc += dtReal;
    if (this._acc > 0.2) {
      this._acc = 0;
      this.drone.setCutoff(170 + 700 * p * p, 0.4);
      this.overtones.setLevel(0.02 + 0.13 * p * p, 0.4);
      this.rumble.setLevel(0.18 + 0.12 * p, 0.4);
    }
    this.once('riser', t > 4.3, () => this.audio.riser({ dur: 1.6, from: 260, to: 5200, level: 0.3 }));
    this.once('thump', t > 5.9, () => this.audio.hit({ freq: 58, level: 0.55, decay: 1.3, noise: 0.3 }));
  }

  dispose() {
    Shared.release(this.ctx, 'stars');
    Shared.release(this.ctx, 'sun');
    this.post.u.godray.value = 0;
    this.post.u.anamorphic.value = this.ctx.config.post.anamorphic.strength;
  }
}
