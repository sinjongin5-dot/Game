// scenes/ch2.js — Ch.2 핵분열: 불릿타임 (65~90초)
//
//  와우 모먼트: time scale 0.04배 매트릭스식 불릿타임. 카메라(실시간)가 핵 주위를 360° 도는 동안 느린 중성자(월드 시간)는 거의 멈춘 듯 기어간다.
//   0.0~2.8   정상 속도로 느린 중성자(파랑)가 U-235 핵(주황·청록 핵자 알갱이)을 향해 날아옴 — 카메라는 중성자 뒤를 따라간다
//   2.8~4.2   시간이 늘어지며 0.04배로 (사운드도 저역 필터로 가라앉음)
//   ~5.5      중성자가 핵에 박혀 녹아든다 → U-236*(들뜬 상태) → 액체방울처럼 출렁임 → 가운데가 잘록해짐(neck)
//   14.0      핵이 둘로 끊어짐: 바륨-141 + 크립톤-92, 감마선 섬광 + 충격파 링 + 빠른 중성자(빨강) 3개 방출.
//             이때 time scale 이 정상으로 복귀하며 쿵! — HUD "약 200 MeV 방출" 카운트업
//   15~25     조각이 갈라져 날아가고, 중성자 3개가 화면 밖으로 → (매치컷) Ch.3 연쇄 반응으로
//  자막/키워드 카드: config.js (ch2)
//  시간 구조: 사건(중성자 도착·출렁임·절단)은 "월드 시간 tw"로, 카메라 공전은 "실시간 t"로 진행 → 불릿타임이 자연스럽게 만들어진다.
//  과학: U-235 + n → U-236* → Ba-141 + Kr-92 + 3n (대표 채널), 분열당 ≈200 MeV (IAEA). 실제로는 수십 종의 분열 생성물이 있다.

import * as THREE from 'three/webgpu';
import { float, vec3, instanceIndex, hash, mix, varying, mx_noise_vec3, pow, uv, length, smoothstep as tslSmooth } from 'three/tsl';
import { SceneBase } from './_base.js';
import { Shared } from './_shared.js';
import { makeNucleus } from './shared/nucleus.js';
import { makeBeams } from './shared/beams.js';
import { makeStars } from './shared/space.js';
import { makePose } from '../engine/camera.js';
import { clamp, lerp, curve, smoothstep, easeInOutCubic, easeOutCubic } from '../engine/ease.js';
import { sphereDir } from '../engine/tsl.js';
import { ATOM_CENTER } from './shared/dust.js';

// Ch.1(줌인)·S4(원자 먼지)와 같은 위치에 핵이 있어야 매치컷이 이어진다 → 이 챕터 전체를 원자 위치로 옮겨 둔다
const OFF = ATOM_CENTER;

const LEN = 25;
const R0 = 3.0;                                        // 핵 반지름(유닛)
const T_SCISSION = 14.0;                               // 절단 시각(실시간, 로컬 초)
const scaleAt = (t) => curve([[0, 1], [2.8, 1], [4.2, 0.04], [13.6, 0.055], [14.6, 0.9], [15.4, 1], [30, 1]], t);
const N_TAB = 2500;
const TW = (() => { const tab = new Float32Array(N_TAB + 1); let acc = 0; for (let i = 1; i <= N_TAB; i++) { acc += scaleAt(((i - 0.5) / N_TAB) * LEN) * (LEN / N_TAB); tab[i] = acc; } return tab; })();
const twAt = (t) => { const f = clamp(t / LEN) * N_TAB, i = Math.min(N_TAB - 1, Math.floor(f)); return lerp(TW[i], TW[i + 1], f - i); };
const TW_S = twAt(T_SCISSION);                         // 절단 순간의 월드 시간
const TW_HIT = TW_S - 0.45;                            // 중성자가 핵에 닿는 월드 시간 (절단 0.45초 전)

const C_O = new THREE.Vector3(-1.4, 0, 0);             // 카메라 공전 중심(충돌 지점 근처)
const V = new THREE.Vector3(), MID = new THREE.Vector3(), HEAD = new THREE.Vector3(), DIR = new THREE.Vector3(1, 0, 0);
const FAST = new THREE.Color(0xff3b30), SLOW = new THREE.Color(0x2f7bff);
const EMIT = [new THREE.Vector3(0.28, 0.82, -0.5).normalize(), new THREE.Vector3(-0.35, -0.7, -0.62).normalize(), new THREE.Vector3(0.2, -0.12, 1.0).normalize()];

export default class Ch2 extends SceneBase {
  async warmup() {
    const ctx = this.ctx;
    this.stars = await Shared.create(ctx, 'stars', makeStars);
    this.nuc = makeNucleus(ctx);
    this.beams = makeBeams(ctx, 6, 520);
    this.root.add(this.nuc.root, this.beams.root);
    this.root.position.copy(OFF);

    // 양자 거품: 핵 주변을 느리게 떠다니는 은은한 빛 알갱이 (불릿타임에서도 "움직임"이 읽히도록 시차 제공)
    const fm = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
    const i = instanceIndex, tm = ctx.u.time;
    const dir = sphereDir(hash(i), hash(i.add(7)));
    const rad = pow(hash(i.add(13)), 0.7).mul(26.0).add(5.5);
    const drift = mx_noise_vec3(dir.mul(rad).mul(0.12).add(vec3(0.0, tm.mul(0.12), hash(i.add(3)).mul(9.0)))).mul(3.0);
    fm.positionNode = dir.mul(rad).add(drift);
    fm.scaleNode = float(0.07).add(hash(i.add(19)).mul(0.12));
    fm.colorNode = varying(mix(vec3(0.15, 0.7, 0.9), vec3(1.0, 0.55, 0.2), hash(i.add(29)).greaterThan(0.6).select(float(1.0), float(0.0))).mul(0.6), 'vFoamC');
    fm.opacityNode = tslSmooth(0.5, 0.0, length(uv().sub(0.5))).pow(1.4);
    this.foam = new THREE.Sprite(fm); this.foam.count = 3500; this.foam.frustumCulled = false; this.foam.renderOrder = 4;
    this.root.add(this.foam);

    this.pose = makePose(); this.pose.near = 0.1; this.pose.far = 9000;
    this.frag = { ba: new THREE.Vector3(), kr: new THREE.Vector3() };
    this.nPos = new THREE.Vector3();
  }

  start() {
    Shared.acquire(this.ctx, 'stars');
    this._acc = 0; this._beat = 0; this.hit = false;
    this.nuc.u.center.value.copy(OFF); this.nuc.bound.position.set(0, 0, 0);          // 셰이더 중심은 월드 좌표, 경계 구는 root(OFF) 기준 로컬
    this.nuc.u.steps.value = this.ctx.quality.tier.marchSteps;
    this.foam.count = Math.min(3500, Math.floor(this.quality.particleCap * 0.01));

    // HUD (다이제틱): 핵 옆 라벨, 분열 후 조각 라벨, 에너지 카운트업
    const s0 = this.def.start, id = this.id;
    this.hud.add({ id: `${id}-react`, owner: id, anchor: () => V.set(0, 4.4, 0).add(OFF), text: 'U-235 + 중성자 → U-236*', sub: 'NEUTRON ABSORPTION', offset: [90, -60], from: s0 + 5.8, to: s0 + 13.2, color: '#22e6ff' });
    this.hud.add({ id: `${id}-mev`, owner: id, anchor: () => V.set(0, 6.2, 0).add(OFF), sub: 'ENERGY RELEASED', offset: [-130, -70], from: s0 + 14.3, to: s0 + 24, color: '#ffd27a',
      text: (tt) => `약 ${Math.round(200 * easeOutCubic(clamp((tt - (s0 + 14.1)) / 2.6)))} MeV 방출` });
    this.hud.add({ id: `${id}-ba`, owner: id, anchor: () => V.copy(this.frag.ba).add(OFF), text: '바륨-141', sub: 'Ba-141', offset: [70, -75], from: s0 + 15.2, to: s0 + 23.5, color: '#ff8c2a' });
    this.hud.add({ id: `${id}-kr`, owner: id, anchor: () => V.copy(this.frag.kr).add(OFF), text: '크립톤-92', sub: 'Kr-92', offset: [-70, 80], from: s0 + 15.4, to: s0 + 23.5, color: '#1fd6c8' });

    // 사운드: 낮은 긴장 드론 + 느린 심장 박동
    const a = this.audio;
    this.drone = this.own(a.drone({ freqs: [49, 73.4, 98], level: 0.2, cutoff: 360, fadeIn: 1.5, detune: 8 }));
    this.pad = this.own(a.drone({ freqs: [392, 587.3], level: 0.02, cutoff: 1800, type: 'sine', fadeIn: 1.0, bus: 'music' }));
    a.whoosh({ dur: 1.2, from: 300, to: 1800, level: 0.12 });
  }

  timeScaleAt(t) { return scaleAt(t); }

  /** 핵의 모양(SDF 매개변수)을 월드 시간으로 계산 */
  _shape(tw) {
    const u = this.nuc.u, tws = tw - TW_HIT;
    // 중성자: 접근 → 접촉 → 흡수(녹아듦)
    const approach = clamp(tw / TW_HIT);
    const nx = lerp(-46, -(R0 + 0.35), approach);
    let R = R0, nR = 0.45, q = 0, osc = 0;
    if (tws >= 0) {
      const ab = smoothstep(tws / 0.07);
      nR = 0.45 * (1 - ab);
      this.nPos.set(lerp(-(R0 + 0.35), -R0 * 0.35, ab), 0, 0);
      R = R0 + 0.07 * ab;
      const qb = Math.pow(smoothstep((tws - 0.1) / 0.36), 1.5);                  // 늘어남(목 형성)
      osc = Math.sin((Math.PI * 2 * tws) / 0.12) * 0.1 * smoothstep((tws - 0.03) / 0.1) * (1 - qb);   // 액체방울 출렁임
      q = clamp(qb * 0.98 + osc, 0, 1);
    } else this.nPos.set(nx, 0, 0);
    const r = R * (1 - 0.206 * q), s = q * 1.52 * r;
    let c1 = -s, c2 = s, r1 = r, r2 = r, k = lerp(1.5, 0.1, smoothstep((q - 0.45) / 0.55)), wob = 0.45 + 0.9 * q;
    const energy = smoothstep((q - 0.5) / 0.45) * (tw < TW_S ? 1 : 0);
    let heat = 0;
    const taus = tw - TW_S;
    if (taus >= 0) {
      const D = 2 * s + 26 * (1 - Math.exp(-1.15 * taus));                       // 두 조각 사이 거리
      const asym = smoothstep(taus / 0.35);
      c2 = lerp(s, D * 0.395, asym); c1 = lerp(-s, -D * 0.605, asym);            // 무거운 Ba 는 덜 움직임(운동량 보존)
      const relax = 1 - Math.exp(-taus * 5);
      const ring = Math.exp(-taus * 3.5) * Math.sin((Math.PI * 2 * taus) / 0.32);
      r1 = lerp(r, R * 0.73, relax) * (1 + 0.1 * ring); r2 = lerp(r, R * 0.843, relax) * (1 - 0.1 * ring);
      k = 0.1; wob = 0.55 * Math.exp(-taus * 1.4);
      heat = Math.exp(-taus * 0.8);
    }
    u.c1x.value = c1; u.c2x.value = c2; u.r1.value = r1; u.r2.value = r2; u.k.value = k; u.wob.value = wob;
    u.nPos.value.copy(this.nPos); u.nR.value = Math.max(nR, 0.0001);
    u.energy.value = energy; u.heat.value = heat;
    u.haloMix.value = clamp(energy + heat * 0.7);
    u.haloGain.value = 0.5 + 0.7 * energy + 0.5 * heat;
    this.frag.ba.set(c2, 0, 0); this.frag.kr.set(c1, 0, 0);
    return { tws, taus, q, nx, c1, c2 };
  }

  update(t, dt, dtReal) {
    const w = this.weight, post = this.post, a = this.audio;
    post.blendBloom(1.5, w);
    const tw = twAt(t);
    const st = this._shape(tw);

    // ── 중성자 빔: 느린 중성자(파랑)는 접촉 전까지, 빠른 중성자(빨강) 3개는 절단 후 ──
    if (st.tws < 0) { HEAD.set(st.nx, 0, 0); this.beams.set(0, { pos: HEAD, dir: DIR, len: 7, color: SLOW, alpha: w, size: 0.5 }); } else this.beams.hide(0);
    MID.set(0, 0, 0);
    for (let k = 0; k < 3; k++) {
      if (st.taus >= 0) {
        HEAD.copy(MID).addScaledVector(EMIT[k], 3 + 46 * st.taus);
        this.beams.set(1 + k, { pos: HEAD, dir: EMIT[k], len: 6.5, color: FAST, alpha: w * clamp(1 - (t - 20) / 4), size: 0.46 });
      } else this.beams.hide(1 + k);
    }
    this.nuc.setFission(st.taus, MID);
    this.nuc.u.gain.value = w;

    // ── 카메라: 중성자를 따라가다가 → 접촉점 주위를 360° 공전(실시간) → 절단 뒤 뒤로 빠짐 ──
    const oc = easeInOutCubic(clamp((t - 3.0) / (14.6 - 3.0)));
    const th0 = -Math.PI / 2 + 0.5;                                              // 처음엔 중성자 경로를 옆에서 바라보는 위치
    const theta = th0 + Math.PI * 2 * oc + 0.05 * Math.max(0, t - 14.6);
    let rho = t < 3.4 ? lerp(30, 12.8, easeInOutCubic(t / 3.4)) : 12.8 + 0.6 * Math.sin((t - 3.4) * 0.5);
    rho = lerp(rho, 27, easeInOutCubic(clamp((t - 14.2) / 7.5)));
    const h = 2.4 + 1.3 * Math.sin(oc * Math.PI * 2) + 0.12 * Math.max(0, t - 16);
    const p = this.pose;
    p.pos.set(C_O.x + Math.cos(theta) * rho, h, C_O.z + Math.sin(theta) * rho).add(OFF);
    if (t < 3.4) { V.set(st.nx * 0.5, 0, 0).lerp(C_O, easeInOutCubic(t / 3.4)); } else V.copy(C_O);   // 중성자와 핵의 중간점을 비추다가 접촉점으로
    V.lerp(MID, smoothstep((t - 14.0) / 2.2));
    p.look.copy(V).add(OFF);
    p.fov = curve([[0, 54], [4, 46], [14, 44], [15.5, 52], [22, 58]], t);
    p.roll = 0.04 * Math.sin(t * 0.3);
    p.scale = 6; p.near = 0.1; p.far = 9000;
    this.cam(p);

    // ── 사건 효과 ──
    this.once('hit', st.tws >= 0, () => { a.hit({ freq: 46, level: 0.5, decay: 1.6, noise: 0.15 }); a.ping({ freq: 659, level: 0.12, decay: 2.2 }); });
    this.once('scission', st.taus >= 0, () => {
      post.flashPulse(0.5, 3.6); this.camRig.shake(0.9);
      a.hit({ freq: 34, level: 1.0, decay: 3.4, noise: 0.85 }); a.hit({ freq: 110, level: 0.55, decay: 1.6, noise: 0.5 });
      a.whoosh({ dur: 1.4, from: 400, to: 5200, level: 0.3 }); a.riser({ dur: 2.0, from: 200, to: 3000, level: 0.15 });
      this.drone.setCutoff(1200, 1.2); this.pad.setLevel(0.12, 1.5);
    });
    this.once('n1', st.taus >= 0.15 && t > 14.3, () => a.whoosh({ dur: 0.8, from: 1800, to: 500, level: 0.2 }));
    this.once('n2', st.taus >= 0.15 && t > 14.5, () => a.whoosh({ dur: 0.8, from: 2200, to: 600, level: 0.2 }));
    this.once('n3', st.taus >= 0.15 && t > 14.7, () => a.whoosh({ dur: 0.8, from: 2600, to: 700, level: 0.2 }));
    post.u.anamorphic.value = this.ctx.config.post.anamorphic.strength * (1 + 1.8 * Math.exp(-Math.max(0, t - 14) * 1.2) * (t > 14 ? 1 : 0));

    // 사운드: 불릿타임 진입 시 저역 필터가 내려가고(시간이 늘어지는 소리), 천천히 뛰는 심장 박동
    this._acc += dtReal;
    if (this._acc > 0.15) {
      this._acc = 0;
      if (t < 14) this.drone.setCutoff(lerp(360, 85, smoothstep((t - 2.8) / 1.4)), 0.4);
      this.drone.setLevel(0.2 + 0.1 * smoothstep((t - 8) / 6), 0.4);
    }
    if (t > 4.4 && t < 14 && t > this._beat) { this._beat = t + 1.15; a.hit({ freq: 40, level: 0.2 + 0.01 * (t - 4), decay: 0.9, noise: 0 }); }
    this.once('slow', t > 2.8, () => a.whoosh({ dur: 1.6, from: 4200, to: 160, level: 0.28 }));
    this.once('neck', st.tws >= 0.12, () => this.own(a.riser({ dur: 5.4, from: 140, to: 1900, level: 0.16 })));
  }

  dispose() {
    Shared.release(this.ctx, 'stars');
    this.beams.hideAll();
    this.nuc.setFission(-1, MID);
    this.post.u.anamorphic.value = this.ctx.config.post.anamorphic.strength;
  }
}
