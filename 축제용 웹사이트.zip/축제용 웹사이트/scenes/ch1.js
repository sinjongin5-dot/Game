// scenes/ch1.js — Ch.1 파워스 오브 텐 줌인: 원자 속으로 (40~65초)
//
//  와우 모먼트: 끊김 없는 원샷 줌. 연료 펠릿(1 cm) → 결정 알갱이(10 µm) → 결정 격자(0.5 nm) → 원자(전자 확률 구름) → 원자핵(15 fm) → 핵자.
//   · 오른쪽 로그 눈금자(10⁻² m → 10⁻¹⁵ m)가 같이 움직이며 크기를 체감시킨다.
//   · 전자는 레이마칭 확률 구름(오비탈): 짙은 곳이 전자가 발견될 확률이 높은 곳. 대부분은 빈 공간.
//   · 핵 안에서 양성자(주황)·중성자(청록)가 강한 핵력의 빛 가닥으로 연결되어 떨린다.
//  매치컷: (이전) Scene 4 에서 먼지가 모인 우라늄 원자 → 이 챕터 0~3초에 눈금자가 역주행하며 펠릿까지 초고속으로 물러난다 → 본 줌인.
//          (이후) 마지막에 핵 속 중성자 하나가 밝게 빛나며 → Ch.2 의 "날아오는 중성자".
//  좌표: 원자 위치(ATOM_CENTER)에 모든 층이 겹쳐 있고 카메라는 정면 98 유닛에서 고정(FOV 52°, 시야 높이 VH=95.6).
//  자막/카드: config.js (ch1). 카드: U-235 = 양성자 92 + 중성자 143 / 원자핵 크기 = 원자의 약 수만분의 1.

import * as THREE from 'three/webgpu';
import { SceneBase } from './_base.js';
import { Shared } from './_shared.js';
import { makeStars } from './shared/space.js';
import { makeScaleZoom, CAM_DIST } from './shared/scaleZoom.js';
import { ATOM_CENTER } from './shared/dust.js';
import { makePose } from '../engine/camera.js';
import { clamp, lerp, spline, smoothstep, easeInOutCubic } from '../engine/ease.js';

// 줌 값 z = log10(시야 폭[m]). t<3: 원자 → 펠릿으로 역주행(빠르게), 이후: 펠릿에서 핵자까지 천천히 파고듦
const Z_KEYS = [[3, -2.0], [5, -2.9], [7.5, -4.2], [10, -6.0], [12.5, -8.2], [15, -9.8], [17.5, -11.2], [20, -12.5], [22.5, -13.35], [25, -13.6]];
const zAt = (t) => (t < 3 ? lerp(-8.9, -2.0, easeInOutCubic(t / 3)) : spline(Z_KEYS, t));
const STAGES = [[5.6, 'grain'], [10.2, 'lattice'], [13.4, 'atom'], [19.4, 'nucleus']];

export default class Ch1 extends SceneBase {
  async warmup() {
    const ctx = this.ctx;
    this.stars = await Shared.create(ctx, 'stars', makeStars);
    this.zoom = makeScaleZoom(ctx, ATOM_CENTER);
    this.root.add(this.zoom.root);
    this.root.position.copy(ATOM_CENTER);
    this.pose = makePose(); this.pose.near = 1; this.pose.far = 2000;
  }

  start() {
    Shared.acquire(this.ctx, 'stars');
    this._acc = 0; this._stage = 0;
    this.zoom.nucleus.rotation.set(0, 0, 0);
    const a = this.audio;
    this.drone = this.own(a.drone({ freqs: [110, 164.8, 220], level: 0.14, cutoff: 700, fadeIn: 1.2, detune: 7 }));
    this.pad = this.own(a.drone({ freqs: [660, 990], level: 0.0001, cutoff: 3000, type: 'sine', fadeIn: 0.2, bus: 'music' }));
    a.whoosh({ dur: 2.6, from: 5000, to: 300, level: 0.3 });                      // 되감기 쉬익
  }

  update(t, dt, dtReal) {
    const w = this.weight, post = this.post, a = this.audio, ui = this.ctx.ui;
    post.blendBloom(1.3, w);
    const z = zAt(t);
    this.zoom.update(z, w);

    // 카메라 고정(핸드헬드만) — 원자 위치 정면
    const p = this.pose;
    p.pos.set(0, 0, CAM_DIST).add(ATOM_CENTER); p.look.copy(ATOM_CENTER);
    p.fov = 52; p.roll = 0; p.scale = 40; p.near = 1; p.far = 2000;
    this.cam(p);

    // 줌 속도에 비례한 방사형 블러(고품질 단계) + 마지막에 핵이 살짝 회전
    const dz = (zAt(t + 0.05) - zAt(t - 0.05)) / 0.1;                              // dec/s (+: 멀어짐, −: 파고듦)
    post.zoomRadial = clamp(dz * 0.012, -0.035, 0.07) * w;
    this.zoom.nucleus.rotation.y = 0.55 * smoothstep((t - 19) / 6);
    this.zoom.nucleus.rotation.x = 0.18 * smoothstep((t - 19) / 6);
    this.zoom.setHighlight(smoothstep((t - 22.6) / 2.2) * w);
    post.u.anamorphic.value = this.ctx.config.post.anamorphic.strength * (0.5 + 0.5 * smoothstep((t - 18) / 5));

    // 눈금자
    ui.ruler.set({ show: t > 0.6 && t < 25.2 && w > 0.4, z });

    // 사운드: 들어갈수록 낮아지는 드론, 단계 전환마다 낮은 쿵 + 반짝임, 핵 안에서는 높은 패드
    this._acc += dtReal;
    if (this._acc > 0.12) {
      this._acc = 0;
      const depth = clamp((-2 - z) / 12);
      const f = 110 * Math.pow(2, -depth * 1.2);
      this.drone.setFreqs([f, f * 1.5, f * 2], 0.4);
      this.drone.setCutoff(900 - 500 * depth, 0.4);
      this.drone.setLevel(0.16 + 0.1 * depth, 0.4);
      this.pad.setLevel(0.1 * smoothstep((t - 18.5) / 4) * w, 0.5);
    }
    while (this._stage < STAGES.length && t > STAGES[this._stage][0]) {
      this._stage++;
      a.hit({ freq: 48 - this._stage * 4, level: 0.4, decay: 1.4, noise: 0.15 }); a.ping({ freq: 440 * (1 + this._stage * 0.5), level: 0.1, decay: 1.8 });
    }
    this.once('riser', t > 20.5, () => this.own(a.riser({ dur: 4.2, from: 250, to: 3800, level: 0.2 })));
    this.once('neutron', t > 23.4, () => { a.ping({ freq: 1320, level: 0.14, decay: 2.2 }); a.whoosh({ dur: 1.4, from: 800, to: 3200, level: 0.18 }); });
  }

  dispose() {
    Shared.release(this.ctx, 'stars');
    this.ctx.ui.ruler.set({ show: false, z: -2 });
    this.post.zoomRadial = 0;
    this.post.u.anamorphic.value = this.ctx.config.post.anamorphic.strength;
  }
}
