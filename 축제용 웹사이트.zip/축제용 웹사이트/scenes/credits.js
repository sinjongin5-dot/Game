// scenes/credits.js — 피날레 뒤 10초 (265~275초): 기본은 "해킹 → 블루스크린 → 되감기" 연출의 3D 부분
//
//  config.js 의 hack.enabled 가 true 이면 (기본):
//   · 지구 위로 웜 네트워크(shared/worm.js)가 서울에서 전 세계로 번지고, 오로라가 마젠타/청록 노이즈로 오염된다.
//   · 블루스크린(ui/hack.js, DOM) 뒤에서 3D 는 계속 진행되다가, bsodEnd 부터는 "되감기": 카메라가 궤도를 거꾸로 돌고(24→14초 지점),
//     웜 감염이 거꾸로 풀리고(uT 감소), 오로라가 원래 초록으로 돌아온다. 끝 포즈 = 브릿지 시작 포즈(orbitPose(14)).
//  false 이면 평범한 크레딧 장면(오로라가 잦아드는 지구 궤도). 제작자 이름은 config.credits.show 가 true 일 때만 DOM 이 띄운다.
//  카메라: shared/aurora.js 의 orbitPose — 피날레와 이어지는 같은 곡선.

import { SceneBase } from './_base.js';
import { Shared } from './_shared.js';
import { makeStars } from './shared/space.js';
import { makeEarth, EARTH_R, EARTH_POS } from './shared/earth.js';
import { makeAurora, orbitPose } from './shared/aurora.js';
import { makeWorm } from './shared/worm.js';
import { hackProfile } from '../ui/hack.js';
import { makePose } from '../engine/camera.js';
import { clamp, lerp, smoothstep } from '../engine/ease.js';

export const REWIND_END_TT = 14;                                        // 되감기가 끝나는 궤도 시각(= 브릿지 시작 포즈)

export default class Credits extends SceneBase {
  async warmup() {
    const ctx = this.ctx;
    this.stars = await Shared.create(ctx, 'stars', makeStars);
    this.earth = await Shared.create(ctx, 'earth', makeEarth);
    this.aurora = await Shared.create(ctx, 'aurora', makeAurora);
    this.worm = await Shared.create(ctx, 'worm', async (c) => makeWorm(c, (await Shared.create(c, 'earth', makeEarth)).quat));
    this.pose = makePose(); this.pose.near = 0.2; this.pose.far = 9000;
  }

  start() {
    const ctx = this.ctx;
    Shared.acquire(ctx, 'stars'); Shared.acquire(ctx, 'earth'); Shared.acquire(ctx, 'aurora'); Shared.acquire(ctx, 'worm');
    this._acc = 0;
    this.hack = !!ctx.config.hack?.enabled;
    this.pad = this.own(this.audio.drone({ freqs: [293.7, 440.0, 554.4], level: 0.07, cutoff: 2400, type: 'sine', fadeIn: 1.0, bus: 'music', detune: 4 }));
    if (this.hack) this.glitchDrone = this.own(this.audio.drone({ freqs: [110, 116.5, 164.8], level: 0.0001, cutoff: 900, type: 'sawtooth', fadeIn: 0.3, detune: 30 }));
  }

  update(t, dt, dtReal) {
    const w = this.weight, post = this.post, ctx = this.ctx, p = this.pose, H = ctx.config.hack;
    post.blendBloom(1.1, w);
    const Td = this.def.start + t;                                           // 디렉터 시간
    let tt = 20 + Math.max(0, t), aur, uT = 0, wormA = 0;
    if (this.hack) {
      const rew0 = H.bsodEnd - this.def.start, rewLen = this.len - rew0;
      const tt0 = 20 + 0.55 * rew0;
      if (t < rew0) { tt = 20 + 0.55 * Math.max(0, t); uT = Td - H.wormStart; wormA = 1; aur = 1; }
      else {
        const u = clamp((t - rew0) / rewLen);
        tt = lerp(tt0, REWIND_END_TT, Math.pow(u, 1.4));                      // 궤도를 거꾸로(점점 빠르게)
        uT = (H.bsodEnd - H.wormStart) * (1 - Math.pow(u, 1.2));              // 감염이 거꾸로 풀림
        wormA = 1 - smoothstep((u - 0.78) / 0.22); aur = lerp(1, 0.65, smoothstep(u));
      }
    } else aur = 1 - 0.35 * smoothstep(t / 8);
    orbitPose(tt, p);
    p.scale = 60; p.near = 0.2; p.far = 9000;
    this.cam(p);
    const alt = p.pos.distanceTo(EARTH_POS) - EARTH_R;
    this.earth.uDetail.value = clamp(1 - (alt - 0.5) / 30);
    this.earth.uCloudSpin.value = ctx.u.time.value * 0.0006;
    this.aurora.uAur.value = aur * w;
    this.aurora.uCor.value = this.hack ? hackProfile(Td, H).cor : 0;
    this.earth.uGreen.value = 1;
    this.worm.uT.value = Math.max(0, uT); this.worm.uA.value = wormA * w;
    this._acc += dtReal;
    if (this._acc > 0.1) {
      this._acc = 0;
      this.pad.setLevel(0.07 * (this.hack ? (1 - smoothstep((Td - H.wormStart) / 2.5)) : (1 - smoothstep((t - 6) / 4))), 0.5);
      if (this.hack) this.glitchDrone.setLevel(0.16 * smoothstep((Td - H.wormStart) / 2.0) * (Td < H.bsodStart ? 1 : 0), 0.15);
    }
  }

  dispose() {
    const ctx = this.ctx;
    for (const k of ['stars', 'earth', 'aurora', 'worm']) Shared.release(ctx, k);
    this.earth.uGreen.value = 0; this.aurora.uAur.value = 0; this.aurora.uCor.value = 0; this.worm.uT.value = 0; this.worm.uA.value = 0;
  }
}
