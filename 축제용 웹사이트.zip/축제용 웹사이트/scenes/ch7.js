// scenes/ch7.js — Ch.7 왜 친환경인가 (210~245초)
//
//  와우 모먼트: 같은 하늘 아래 두 발전소 — 석탄 화력의 검은 연기와 CO₂ 분자 vs 원전 냉각탑의 하얀 수증기, 그리고 "점 한 개 = 1 g CO₂" 가 쏟아져 쌓이는 막대그래프.
//  그 뒤 솔직한 숙제: 사용후핵연료는 수조 → 건식 저장 → 지하 수백 m 처분의 길을 간다. 마지막은 냉각탑의 수증기를 타고 우주로 솟아오른다.
//   0~3.4    서울 야경(Ch.6 에서 이어짐) → 빠른 팬(whip) + 섬광 컷
//   3.4~11.8 황혼의 발전소: 석탄 굴뚝의 연기·CO₂ 분자 → 냉각탑의 수증기 (수증기 ≠ 연기)
//   11.8~19.8 점 막대그래프: 생애주기 배출량 석탄 820 / 가스 490 / 태양광 48 / 원자력 12 / 풍력 11~12 gCO₂eq/kWh (IPCC AR5 중앙값)
//   19.8~30.2 사용후핵연료의 길(단면 도해) + "남은 과제"
//   30.2~35  냉각탑 수증기를 타고 상승 → 구름 → 우주 (피날레로 컷)
//  과학 주의: 원전도 건설·연료 채굴/가공·폐기 과정에서 온실가스가 나온다 → 그래서 "발전 중 직접 배출 없음"과 "생애주기 배출"을 구분해 말한다.
//   수치는 중앙값이며 범위가 넓다(shared/dotChart.js 주석). 온칼로 상태는 2026년 8월 기준 문구(시연 전 최신 확인 필요).
//  자막/카드: config.js (ch7)

import * as THREE from 'three/webgpu';
import { SceneBase } from './_base.js';
import { Shared } from './_shared.js';
import { makeStars } from './shared/space.js';
import { makeCity } from './shared/city.js';
import { makePowerplants, NUKE_X } from './shared/powerplants.js';
import { makeDotChart, SOURCES, barX, barH } from './shared/dotChart.js';
import { makeRepository, pathAt, HOLE_X0, HOLE_DX, DEPTH_Y } from './shared/repository.js';
import { makePose } from '../engine/camera.js';
import { clamp, lerp, spline, smoothstep, easeInCubic, easeOutCubic } from '../engine/ease.js';

const P_ORG = new THREE.Vector3(0, -3000, 0);          // 발전소 무대
const C_ORG = new THREE.Vector3(4000, -3000, 0);       // 점 그래프 무대
const R_ORG = new THREE.Vector3(-4000, -3000, 0);      // 처분 도해 무대
// 구간(로컬 초)
const T_PLANTS = 3.4, T_CHART = 11.8, T_REPO = 19.8, T_RISE = 30.2;
const TRANS = [T_CHART, T_REPO, T_RISE];
// 카메라 웨이포인트 [u, 위치xyz, 시선xyz, FOV] (u = 구간 진행도, 구간 원점 기준)
const WP_PLANTS = [[0, -30, 32, 380, 0, 38, 0, 44], [0.28, 10, 38, 300, -30, 45, 0, 44], [0.45, -85, 46, 150, -118, 85, 0, 50], [0.68, -20, 38, 170, 30, 70, 0, 52], [1, 70, 42, 175, 108, 85, -20, 52]];
const WP_CHART = [[0, 0, 9, 62, 0, 7, 0, 40], [0.4, 8, 8, 52, 2, 6.5, 0, 38], [0.62, 13, 2.6, 21, 13.3, 0.8, 0, 36], [0.8, 12, 3.6, 28, 10, 2.2, 0, 38], [1, 3, 8.5, 58, 0, 6.5, 0, 40]];
const WP_REPO = [[0, -128, 14, 120, -122, 6, 0, 42], [0.18, -86, 12, 118, -66, 4, 0, 44], [0.36, -18, 6, 130, -2, 0, 0, 48], [0.54, 52, -30, 140, 66, -46, 0, 50],
  [0.7, 118, -78, 100, 130, -88, 0, 46], [0.84, 142, -88, 44, 142, -94, 0, 40], [1, 142, -94, 20, 142, -96, 0, 34]];
const camAt = (wp, u, k) => spline(wp.map((w) => [w[0], w[k]]), u);
const V = new THREE.Vector3();
const nuke2 = new THREE.Vector3(NUKE_X + 78, 0, -84);          // 두 번째 냉각탑 (상승 기준점)

export default class Ch7 extends SceneBase {
  async warmup() {
    const ctx = this.ctx;
    this.stars = await Shared.create(ctx, 'stars', makeStars);
    this.city = await Shared.create(ctx, 'city', makeCity);
    this.pl = makePowerplants(ctx); this.pl.group.position.copy(P_ORG);
    this.chart = makeDotChart(ctx); this.chart.group.position.copy(C_ORG);
    this.repo = makeRepository(ctx); this.repo.group.position.copy(R_ORG);
    this.root.add(this.pl.group, this.chart.group, this.repo.group);
    this.pose = makePose(); this.pose.near = 0.3; this.pose.far = 30000;
    this._phase = null;
  }

  start() {
    const ctx = this.ctx;
    Shared.acquire(ctx, 'stars'); Shared.acquire(ctx, 'city');
    this._cityHeld = true; this._phase = null; this._acc = 0; this._tickT = 0;
    this.city.uOn.value = 1e9; this.city.uGlow.value = 0.4;
    this.onQuality();
    const s0 = this.def.start, id = this.id;
    const H = (o) => this.hud.add({ owner: id, ...o });
    const P = (x, y, z) => () => V.set(x, y, z).add(P_ORG);
    // 발전소
    H({ id: `${id}-coal`, anchor: P(-96, 150, -26), text: '석탄 화력: 태워서 열을 얻음 → CO₂ 와 그을음', sub: 'COMBUSTION', offset: [-30, -110], from: s0 + 5.0, to: s0 + 8.2, color: '#ff8a5a' });
    H({ id: `${id}-co2`, anchor: P(-40, 190, -30), text: 'CO₂ 분자 = 탄소 1 + 산소 2', sub: '', offset: [60, -50], from: s0 + 6.3, to: s0 + 8.6, color: '#ffb0a0' });
    H({ id: `${id}-vap`, anchor: P(NUKE_X + 78, 105, -84), text: '원전 냉각탑의 흰 구름 = 수증기(물)', sub: 'WATER VAPOR — 연기가 아님', offset: [-40, -100], from: s0 + 8.8, to: s0 + 11.8, color: '#bfe8ff' });
    H({ id: `${id}-nofire`, anchor: P(NUKE_X, 62, 0), text: '핵분열은 "연소"가 아니라서 발전 중 CO₂ 를 직접 내지 않음', sub: '', offset: [-120, -90], from: s0 + 9.4, to: s0 + 11.7, color: '#7be8ff' });
    // 점 그래프
    const CH = (x, y, z) => () => V.set(x, y, z).add(C_ORG);
    SOURCES.forEach((src, i) => {
      const hh = barH(src.v);
      const lab = (tt) => { const k = clamp((tt - (s0 + T_CHART + 0.6 + src.t0)) / 1.6); const n = Math.round(src.v * k); return `${src.name} ${src.id === 'wind' ? (k >= 1 ? '11~12' : n) : n}`; };
      H({ id: `${id}-bar${i}`, anchor: CH(barX(i), hh + 1.4, 0), text: lab, sub: i === 0 ? 'gCO₂eq / kWh' : '', offset: i < 3 ? [0, -56] : [(i === 3 ? -20 : 30), -54 - (i - 3) * 30], from: s0 + T_CHART + 0.9 + src.t0, to: s0 + T_REPO - 0.2, color: `rgb(${src.color.map((c) => Math.round(255 * c)).join(',')})` });
    });
    H({ id: `${id}-src`, anchor: CH(26, 0.4, 0), text: '1 점 = 1 gCO₂eq/kWh  (건설~운영~폐기 생애주기 중앙값)', sub: '출처: IPCC AR5 WGIII Annex III · 범위가 넓음', offset: [-30, 50], from: s0 + T_CHART + 0.8, to: s0 + T_REPO - 0.3, color: '#cfe3ff' });
    H({ id: `${id}-nukeNote`, anchor: CH(barX(3), 1.0, 0), text: '원자력 12 ≈ 풍력 11~12', sub: '석탄의 약 1/70', offset: [-30, -175], from: s0 + T_CHART + 5.6, to: s0 + T_REPO - 0.3, color: '#7dffb4' });
    // 처분 도해
    const R = (x, y) => () => V.set(x, y, 0).add(R_ORG);
    H({ id: `${id}-pool`, anchor: R(-118, 18), text: '① 저장수조: 물이 열과 방사선을 막으며 수년간 냉각', sub: 'SPENT FUEL POOL', offset: [20, -60], from: s0 + T_REPO + 1.0, to: s0 + T_REPO + 4.4, color: '#7be8ff' });
    H({ id: `${id}-cask`, anchor: R(-50, 14), text: '② 건식 저장: 콘크리트·강철 용기, 공기로 냉각', sub: 'DRY CASK STORAGE', offset: [0, -70], from: s0 + T_REPO + 3.4, to: s0 + T_REPO + 6.6, color: '#cfd8e6' });
    H({ id: `${id}-deep`, anchor: R(112, DEPTH_Y + 4), text: '③ 지하 약 430 m 암반 속 처분장 (개념도)', sub: '핀란드 온칼로 ≈ 400~430 m', offset: [-110, -80], from: s0 + T_REPO + 6.0, to: s0 + T_REPO + 9.2, color: '#ffd27a' });
    H({ id: `${id}-can`, anchor: R(HOLE_X0, DEPTH_Y - 12), text: '구리 용기 + 벤토나이트 점토 + 암반', sub: '겹겹의 방벽 · 수만 년 격리 목표', offset: [70, 40], from: s0 + T_REPO + 8.4, to: s0 + T_REPO + 10.4, color: '#ffc08a' });
    H({ id: `${id}-task`, anchor: R(HOLE_X0 + 30, DEPTH_Y + 8), text: '남은 과제: 장기 안전성 검증과 사회적 합의', sub: '온칼로: 2026.8 규제기관 안전성 평가 통과 · 정부 운영 허가 결정 단계', offset: [0, -80], from: s0 + T_REPO + 8.8, to: s0 + T_RISE - 0.3, color: '#ffffff' });

    const a = this.audio;
    this.wind = this.own(a.wind({ level: 0.0, center: 380, fadeIn: 2 }));
    this.pad = this.own(a.drone({ freqs: [174.6, 220, 261.6], level: 0.08, cutoff: 1400, type: 'sine', fadeIn: 1.5, bus: 'music', detune: 3 }));
    this.sub = this.own(a.drone({ freqs: [43.65, 65.4], level: 0.1, cutoff: 220, fadeIn: 1.5, detune: 6 }));
  }

  /** 사용후핵연료 캡슐의 경로 진행도(0~1) */
  _capE(t) { const u = clamp((t - (T_REPO + 0.6)) / 8.4); return u * u * (3 - 2 * u); }

  onQuality() {
    const cap = this.quality.particleCap;
    this.pl.setCount(cap < 100000 ? 0.45 : 1);
  }

  _enter(ph) {
    const ctx = this.ctx;
    if (ph === 'city') { /* 도시는 start() 에서 잡았다 */ }
    else if (this._cityHeld) { Shared.release(ctx, 'city'); this._cityHeld = false; }
    this.pl.group.visible = ph === 'plants' || ph === 'rise';
    this.chart.group.visible = ph === 'chart';
    this.repo.group.visible = ph === 'repo';
    if (ph === 'chart') this.chart.uT.value = 0;
    this._phase = ph;
  }

  update(t, dt, dtReal) {
    const w = this.weight, post = this.post, a = this.audio, ctx = this.ctx, p = this.pose;
    const ph = t < T_PLANTS ? 'city' : t < T_CHART ? 'plants' : t < T_REPO ? 'chart' : t < T_RISE ? 'repo' : 'rise';
    if (ph !== this._phase) {
      if (ph === 'city' && this._phase && this._phase !== 'city') { Shared.acquire(ctx, 'city'); this._cityHeld = true; }   // 시크로 앞 구간으로 돌아온 경우
      this._enter(ph);
    }
    post.blendBloom(ph === 'city' ? 0.8 : ph === 'rise' ? 1.2 : 0.9, w);

    // ── 카메라 ──
    p.roll = 0; p.scale = 40; p.near = 0.3; p.far = 30000;
    if (ph === 'city') {
      const u = clamp(t / T_PLANTS), whip = easeInCubic(clamp((t - 2.35) / 1.05));
      p.pos.set(lerp(-1050, -980, u), lerp(1450, 1500, u), lerp(2350, 2330, u));
      p.look.set(lerp(0, -4600, whip), lerp(0, 380, whip), lerp(0, -1800, whip)); p.fov = lerp(56, 62, whip); p.scale = 300;
    } else if (ph === 'plants') {
      const u = clamp((t - T_PLANTS) / (T_CHART - T_PLANTS));
      p.pos.set(camAt(WP_PLANTS, u, 1), camAt(WP_PLANTS, u, 2), camAt(WP_PLANTS, u, 3)).add(P_ORG);
      p.look.set(camAt(WP_PLANTS, u, 4), camAt(WP_PLANTS, u, 5), camAt(WP_PLANTS, u, 6)).add(P_ORG); p.fov = camAt(WP_PLANTS, u, 7); p.scale = 60;
    } else if (ph === 'chart') {
      const u = clamp((t - T_CHART) / (T_REPO - T_CHART));
      p.pos.set(camAt(WP_CHART, u, 1), camAt(WP_CHART, u, 2), camAt(WP_CHART, u, 3)).add(C_ORG);
      p.look.set(camAt(WP_CHART, u, 4), camAt(WP_CHART, u, 5), camAt(WP_CHART, u, 6)).add(C_ORG); p.fov = camAt(WP_CHART, u, 7); p.scale = 8;
    } else if (ph === 'repo') {
      const u = clamp((t - T_REPO) / (T_RISE - T_REPO));
      p.pos.set(camAt(WP_REPO, u, 1), camAt(WP_REPO, u, 2), camAt(WP_REPO, u, 3));
      p.look.set(camAt(WP_REPO, u, 4), camAt(WP_REPO, u, 5), camAt(WP_REPO, u, 6)); p.fov = camAt(WP_REPO, u, 7); p.scale = 30;
      // 중간 구간에서는 이동하는 캡슐을 따라간다(앞뒤는 웨이포인트)
      const f = smoothstep((u - 0.1) / 0.14) * (1 - smoothstep((u - 0.66) / 0.14));
      if (f > 0) {
        const e = this._capE(t); pathAt(e, V);
        p.look.x = lerp(p.look.x, V.x + 8, f); p.look.y = lerp(p.look.y, V.y, f);
        p.pos.x = lerp(p.pos.x, V.x - 16, f); p.pos.y = lerp(p.pos.y, V.y * 0.8 + 6, f);
      }
      p.pos.add(R_ORG); p.look.add(R_ORG);
    } else {
      const u = clamp((t - T_RISE) / 4.8), e = easeInCubic(u);
      p.pos.set(nuke2.x + lerp(34, 0, e), lerp(8, 1100, e), nuke2.z + lerp(58, 0, e)).add(P_ORG);
      p.look.set(nuke2.x, lerp(60, 1500, e), nuke2.z).add(P_ORG); p.fov = lerp(50, 80, e); p.scale = 120;
      post.u.speed.value = 0.5 * smoothstep((u - 0.4) / 0.5) * w;
      post.u.veil.value = 0.95 * smoothstep((u - 0.5) / 0.3) * (1 - smoothstep((u - 0.9) / 0.1)) * w;
      post.u.veilColor.value.set(1.25, 1.3, 1.45);
    }
    if (ph !== 'rise') { post.u.speed.value = 0; post.u.veil.value = 0; }
    this.cam(p);

    // ── 단계별 연출 ──
    this.pl.uSmoke.value = w; this.pl.uCO2.value = w; this.chart.uA.value = w;
    if (ph === 'chart') {
      this.chart.uT.value = t - T_CHART;
      post.u.anamorphic.value = ctx.config.post.anamorphic.strength * 0.6;
    } else post.u.anamorphic.value = ctx.config.post.anamorphic.strength;
    if (ph === 'repo') {
      const rp = this.repo, e = this._capE(t);
      pathAt(e, V); rp.capsule.position.copy(V); rp.capsule.position.z = 1;
      rp.trail.forEach((s, i) => { pathAt(Math.max(0, e - (i + 1) * 0.011), V); s.position.copy(V); s.position.z = 1; const k = 1 - i / rp.trail.length; s.scale.setScalar(6 * k); });
      rp.capsule.scale.setScalar(8 + 1.5 * Math.sin(t * 6));
      const arrived = clamp((t - (T_REPO + 7.2)) / 1.4);
      rp.holes.forEach((h, i) => { h.visible = i === 0 ? arrived > 0.3 : t > T_REPO + 8.2 + i * 0.22; });
      rp.uCap.value = w;
    }

    // ── 스캔 라인 전환 ──
    let scan = -1;
    for (const T of TRANS) { const u = (t - (T - 0.5)) / 1.0; if (u > 0 && u < 1) scan = lerp(1.06, -0.06, u); }
    post.u.scan.value = scan;
    this.once('cut', t > T_PLANTS - 0.06, () => { post.flashPulse(0.9, 4.5); a.whoosh({ dur: 1.0, from: 5000, to: 600, level: 0.28 }); });
    TRANS.forEach((T, i) => this.once(`tr${i}`, t > T - 0.05, () => { post.flashPulse(0.15, 7); a.whoosh({ dur: 0.8, from: 5500, to: 700, level: 0.18 }); a.ping({ freq: 1500 - i * 140, level: 0.07, decay: 1.2 }); }));

    // ── 사운드 ──
    this._acc += dtReal;
    if (this._acc > 0.12) {
      this._acc = 0;
      this.wind.setLevel(ph === 'plants' ? 0.12 : ph === 'rise' ? 0.2 * smoothstep((t - T_RISE) / 3) : 0.0001, 0.6);
      this.pad.setLevel(0.08 + 0.05 * (ph === 'repo' ? 1 : 0), 0.6);
      this.sub.setLevel(ph === 'city' ? 0.04 : 0.1 + 0.08 * (ph === 'repo' ? smoothstep((t - T_REPO) / 6) : 0), 0.6);
    }
    if (ph === 'chart' && t > this._tickT) {                                                          // 점이 쌓이는 소리: 막대마다 음높이, 낮은 막대일수록 맑은 소리
      const tt = t - T_CHART;
      for (const src of SOURCES) if (tt > src.t0 && tt < src.t0 + 0.5 + Math.min(1.6, src.v / 700) && Math.random() < 0.16) a.ping({ freq: 260 * Math.pow(2, SOURCES.indexOf(src) * 3 / 12 + 0.0) * (1 + (src.v < 100 ? 2 : 0)), level: 0.025, decay: 0.2 });
      this._tickT = t + 0.05;
    }
    this.once('nukeNote', t > T_CHART + 5.6, () => { a.ping({ freq: 1568, level: 0.12, decay: 2.0 }); a.ping({ freq: 2093, level: 0.07, decay: 1.6 }); });
    this.once('caps', t > T_REPO + 0.6, () => { a.whoosh({ dur: 7.0, from: 300, to: 1200, level: 0.1 }); });
    this.once('can', t > T_REPO + 8.4, () => { a.hit({ freq: 55, level: 0.55, decay: 1.8, noise: 0.25 }); a.ping({ freq: 523, level: 0.1, decay: 2.4 }); });
    this.once('rise', t > T_RISE + 0.1, () => this.own(a.riser({ dur: 4.3, from: 200, to: 5200, level: 0.24 })));
    this.once('endflash', t > T_RISE + 4.55, () => { post.flashPulse(1.0, 2.2); });
    if (ph === 'rise') post.setFlash(0);
  }

  dispose() {
    const ctx = this.ctx, u = this.post.u;
    Shared.release(ctx, 'stars');
    if (this._cityHeld) { Shared.release(ctx, 'city'); this._cityHeld = false; }
    u.scan.value = -1; u.speed.value = 0; u.veil.value = 0; u.anamorphic.value = ctx.config.post.anamorphic.strength;
  }
}
