// scenes/ch5.js — Ch.5 연료의 화학: 광석에서 연료집합체까지 (145~175초)
//
//  와우 모먼트: 마크로 렌즈로 훑는 "연료가 만들어지는 과정". 홀로그램 스캔 라인이 훑고 지나갈 때마다 단계가 바뀐다.
//   0~4.6    옐로케이크(우라늄 정광) 더미 마크로 — 얕은 피사계 심도, 태양의 주황빛이 이어지는 따뜻한 색
//   4.6~9.6  천연 우라늄 1000개 점: U-235(주황)는 겨우 7개 = 0.7%
//   9.6~19.4 UF₆ 기체 → 원심분리기(가벼운 U-235는 중심으로, 무거운 U-238은 벽으로) → 카메라가 빠지며 수십 대의 캐스케이드 홀
//   19.4~22.4 같은 점 격자: 주황이 7 → 약 40개 (≈4%)  (농축 3~5%)
//   22.4~25.8 세라믹 펠릿: 백열 상태로 소결 → 식어 가며 500원 동전과 크기 비교
//   25.8~30   지르코늄 합금관에 펠릿을 쌓아 연료봉(약 3.7 m) → 수백 개를 묶은 연료집합체 → 푸른 빛으로 Ch.6 의 원자로 속으로 컷
//  자막/키워드 카드: config.js (ch5)
//  출처: 천연 우라늄 U-235 = 0.7204% (IAEA), 경수로 연료 농축도 3~5%.  UF₆ 분자 질량 349.03/352.04 (차이 약 0.9%).
//   소결 약 1,700 °C(UO₂ 세라믹), 펠릿 지름 약 8.2 mm, 연료봉 길이 약 4 m(유효 길이 약 3.7 m) — shared/fuelcycle.js 의 출처 주석 참고.
//  ※ 점 격자·원심분리기 입자 비율은 이해를 돕는 개념도다 (화면에도 표기).

import * as THREE from 'three/webgpu';
import { SceneBase } from './_base.js';
import { makeYellowcake, makeDotGrid, makePellets, makeRodAssembly } from './shared/fuelcycle.js';
import { makeCentrifuge } from './shared/centrifuge.js';
import { makePose } from '../engine/camera.js';
import { clamp, lerp, spline, smoothstep } from '../engine/ease.js';

const ST = new THREE.Vector3(0, -6000, 0);                                       // 무대 (태양·Ch.4 무대와 멀리)
const ORG = {                                                                    // 샷별 로컬 원점
  A: new THREE.Vector3(0, 0, 0), G: new THREE.Vector3(300, 0, 0), B: new THREE.Vector3(0, 0, -300),
  C: new THREE.Vector3(0, 0, 300), D: new THREE.Vector3(300, 0, 300),
};
// 샷 구간(로컬 초)과 카메라 웨이포인트 [u, 위치xyz, 시선xyz, FOV] (u = 샷 진행도 0~1, 원점 기준)
const SHOTS = [
  { id: 'A', org: 'A', t0: 0, t1: 4.6, dof: [1.0, 3.2, 2.2], scale: 6, wp: [
    [0, -9.0, 3.4, 11.5, 0, 0.9, 0, 34], [0.5, -5.0, 2.6, 8.2, 0.2, 1.2, 0, 32], [1, 0.8, 2.3, 5.4, 0.8, 1.5, 0.2, 30]] },
  { id: 'G', org: 'G', t0: 4.6, t1: 9.6, scale: 40, wp: [
    [0, -6, -3, 62, -1, -0.5, 0, 42], [0.5, 2, 0.5, 54, 0, 0, 0, 42], [1, 7, 1.5, 46, 1.5, 0.5, 0, 42]] },
  { id: 'B', org: 'B', t0: 9.6, t1: 19.4, scale: 14, wp: [
    [0, 0.0, 0.8, 13.5, 0, 0.3, 0, 38], [0.16, 4.0, 2.0, 12.0, 0, 0.3, 0, 36], [0.38, 6.0, 3.2, 8.5, 0.5, 0.8, 0, 40], [0.5, 2.0, 4.5, 9.0, 3, 0.8, -3, 44],
    [0.7, -3, 7, 17, 14, 0.5, -8, 46], [1, -20, 15, 34, 28, -1, -14, 52]] },
  { id: 'G2', org: 'G', t0: 19.4, t1: 21.9, scale: 40, wp: [[0, 5, 1, 50, 0, 0, 0, 42], [1, 0, 0, 44, 0, 0, 0, 40]] },
  { id: 'C', org: 'C', t0: 21.9, t1: 24.9, dof: [1.0, 4.0, 2.0], scale: 6, wp: [
    [0, -0.4, 1.0, 4.6, -1.9, 0.6, 2.0, 26], [0.5, 2.2, 1.6, 6.2, -0.4, 0.8, 1.2, 32], [1, 6.0, 3.0, 8.2, 1.2, 0.9, 0.8, 38]] },
  { id: 'D', org: 'D', t0: 24.9, t1: 29.9, scale: 24, wp: [                    // 처음 세 개는 대표 연료봉(x=−1.26) 기준, 이후는 집합체 중심 기준
    [0, 1.9, 0.9, -6.5, -1.26, 0, -9.0, 34], [0.2, 1.6, 0.7, -14, -1.26, 0, -18, 38], [0.38, 2.0, 1.0, -60, -1.26, 0, -90, 44], [0.52, 13, 6, -30, 0, 0, -12, 46],
    [0.68, 9, 4, 10, 0, 0, -10, 48], [0.84, 2, 1, 28, 0, 0, -40, 50], [1, 0, 0, 18, 0, 0, -60, 52]] },
];
const TRANS = [4.6, 9.6, 19.4, 21.9, 24.9];                                      // 스캔 라인 전환 시각
const shotOf = (t) => { for (let i = SHOTS.length - 1; i >= 0; i--) if (t >= SHOTS[i].t0) return SHOTS[i]; return SHOTS[0]; };
const camAt = (s, t, k) => spline(s.wp.map((w) => [w[0], w[k]]), clamp((t - s.t0) / (s.t1 - s.t0)));
const V = new THREE.Vector3();

export default class Ch5 extends SceneBase {
  async warmup() {
    const ctx = this.ctx;
    this.stage = new THREE.Group(); this.stage.position.copy(ST); this.root.add(this.stage);
    this.yc = makeYellowcake(ctx); this.yc.group.position.copy(ORG.A);
    this.grid = makeDotGrid(ctx); this.grid.group.position.copy(ORG.G);
    this.cent = makeCentrifuge(ctx); this.cent.group.position.copy(ORG.B);
    this.pel = makePellets(ctx); this.pel.group.position.copy(ORG.C);
    this.rod = makeRodAssembly(ctx); this.rod.group.position.copy(ORG.D);
    this.stage.add(this.yc.group, this.grid.group, this.cent.group, this.pel.group, this.rod.group);
    this.pose = makePose(); this.pose.near = 0.05; this.pose.far = 3000;
    this._shot = null;
  }

  start() {
    this._acc = 0; this._tickT = 0; this._shot = null;
    this.grid.uK.value = 7; this.grid.uAppear.value = 0;
    this.onQuality();
    const s0 = this.def.start, id = this.id;
    const H = (o) => this.hud.add({ owner: id, ...o });
    const at = (org, x, y, z) => () => V.set(x, y, z).add(ORG[org]).add(ST);
    // A 옐로케이크
    H({ id: `${id}-yc`, anchor: at('A', 0.6, 2.0, 0), text: '옐로케이크 — 우라늄 정광(주성분 U₃O₈)', sub: 'URANIUM ORE CONCENTRATE', offset: [90, -80], from: s0 + 0.9, to: s0 + 4.4, color: '#ffc94a' });
    // G 1000개 점
    H({ id: `${id}-nat`, anchor: at('G', 0, 17.3, 0), text: () => '천연 우라늄 1000개 중 U-235는 7개 (0.7%)', sub: '개념도 — 나머지 99.3%는 쪼개지지 않는 U-238', offset: [0, -62], from: s0 + 5.4, to: s0 + 9.4, color: '#ffb36b' });
    // B 원심분리기
    H({ id: `${id}-uf6`, anchor: at('B', 1.2, 2.6, 0), text: 'UF₆ 기체를 고속 회전', sub: '분자 질량 차이 약 0.9% (349 vs 352) · 개념도', offset: [100, -70], from: s0 + 10.3, to: s0 + 14.6, color: '#7be8ff' });
    H({ id: `${id}-u235`, anchor: at('B', 0.1, -0.4, 0), text: '가벼운 U-235 → 중심 쪽', sub: '', offset: [-96, 60], from: s0 + 11.6, to: s0 + 14.4, color: '#ff9a3a' });
    H({ id: `${id}-u238`, anchor: at('B', 1.3, -1.8, 0), text: '무거운 U-238 → 벽 쪽', sub: '', offset: [110, 40], from: s0 + 12.0, to: s0 + 14.4, color: '#8fb4ff' });
    H({ id: `${id}-casc`, anchor: at('B', 32, 4.5, -16), text: '캐스케이드: 수천 대 이상을 직렬·병렬로 연결', sub: '한 대로는 차이가 아주 작아서 단계적으로 농축 · 0.7% → 3~5%', offset: [-20, -110], from: s0 + 16.4, to: s0 + 19.6, color: '#ffd27a' });
    // G2 농축 후
    H({ id: `${id}-enr`, anchor: at('G', 0, 17.3, 0), text: () => `농축 후: 1000개 중 약 ${Math.round(this.grid.uK.value)}개 (≈${(this.grid.uK.value / 10).toFixed(1)}%)`, sub: '경수로 연료 농축도 3~5% · 개념도', offset: [0, -62], from: s0 + 19.9, to: s0 + 22.0, color: '#ffb36b' });
    // C 펠릿
    H({ id: `${id}-sint`, anchor: at('C', -1.9, 1.3, 2.0), text: 'UO₂ 분말을 눌러 약 1,700 °C 에서 소결', sub: 'SINTERED CERAMIC PELLET · 지름 약 8 mm', offset: [-60, -90], from: s0 + 22.2, to: s0 + 24.5, color: '#ff9a3a' });
    H({ id: `${id}-coin`, anchor: at('C', 4.3, 0.3, 0.4), text: '500원 동전 지름 26.5 mm', sub: '', offset: [60, -70], from: s0 + 23.3, to: s0 + 24.9, color: '#d8e6ff' });
    // D 연료봉·집합체
    H({ id: `${id}-rod`, anchor: at('D', -0.6, 0.8, -9), text: '지르코늄 합금 피복관에 펠릿을 쌓은 연료봉', sub: '길이 약 4 m · 펠릿 수백 개', offset: [-40, -80], from: s0 + 25.2, to: s0 + 26.9, color: '#cfe3ff' });
    H({ id: `${id}-asm`, anchor: at('D', 0, 6, -20), text: '연료집합체 — 연료봉 수백 개를 격자로 묶음', sub: '예) 17×17 배열 = 연료봉 264개', offset: [110, -90], from: s0 + 28.2, to: s0 + 30.2, color: '#7be8ff' });

    const a = this.audio;
    this.pad = this.own(a.drone({ freqs: [196, 246.9, 293.7], level: 0.09, cutoff: 1500, type: 'sine', fadeIn: 1.8, bus: 'music', detune: 3 }));
    this.sub = this.own(a.drone({ freqs: [49, 73.4], level: 0.1, cutoff: 240, fadeIn: 1.5, detune: 6 }));
    this.whine = null;
  }

  onQuality() {
    const cap = this.quality.particleCap;
    this.yc.setCount(cap < 100000 ? 12000 : this.yc.N);
    this.cent.particles.count = Math.max(2500, Math.min(9000, Math.floor(cap * 0.04)));
  }

  update(t, dt, dtReal) {
    const w = this.weight, post = this.post, a = this.audio, ctx = this.ctx, p = this.pose;
    post.blendBloom(0.9, w);
    const sh = shotOf(t), org = ORG[sh.org];
    if (sh.id !== this._shot) { this._shot = sh.id; this._enter(sh.id); }

    // ── 샷별 시간 의존 연출 ──
    const g = this.grid, c = this.cent, pe = this.pel, rd = this.rod;
    if (sh.id === 'G') { g.uAppear.value = smoothstep((t - 4.7) / 1.5); g.uK.value = 7; }
    if (sh.id === 'G2') {
      g.uAppear.value = 1;
      g.uK.value = lerp(7, 40, smoothstep((t - 20.1) / 1.3));
    }
    c.uSep.value = smoothstep((t - 10.0) / 3.4);
    pe.uHeat.value = 0.95 * Math.pow(1 - smoothstep((t - 22.1) / 2.6), 1.3);
    rd.uLoad.value = t - 24.85;
    rd.uAsm.value = smoothstep((t - 26.8) / 1.7);
    rd.uOpaque.value = smoothstep((t - 27.8) / 0.6);
    rd.uBlue.value = smoothstep((t - 28.2) / 1.0);
    this.yc.motes.visible = pe.motes.visible = true;

    // ── 카메라 ──
    p.pos.set(camAt(sh, t, 1), camAt(sh, t, 2), camAt(sh, t, 3)).add(org).add(ST);
    p.look.set(camAt(sh, t, 4), camAt(sh, t, 5), camAt(sh, t, 6)).add(org).add(ST);
    p.fov = camAt(sh, t, 7); p.roll = 0; p.scale = sh.scale; p.near = 0.05; p.far = 3000;
    if (sh.dof) {
      const d = p.pos.distanceTo(p.look);                                       // 초점은 시선 중심, 폭은 얕게 (macro)
      post.u.focus.value = d * sh.dof[0]; post.u.focal.value = sh.dof[1]; post.u.bokeh.value = sh.dof[2];
    } else { post.u.focus.value = 1000; post.u.focal.value = 1.0e6; }
    this.cam(p);

    // ── 스캔 라인 전환 + 도입 ──
    let scan = -1;
    for (const T of TRANS) { const u = (t - (T - 0.5)) / 1.0; if (u > 0 && u < 1) scan = lerp(1.06, -0.06, u); }
    if (t > 0.1 && t < 1.2) scan = lerp(1.06, -0.06, (t - 0.1) / 1.1);
    post.u.scan.value = scan;
    this.once('cut', t > -0.1, () => post.flashPulse(0.8, 6));
    for (let i = 0; i < TRANS.length; i++) this.once(`tr${i}`, t > TRANS[i] - 0.05, () => { post.flashPulse(0.18, 7); a.whoosh({ dur: 0.9, from: 6000, to: 700, level: 0.2 }); a.ping({ freq: 1400 - i * 120, level: 0.08, decay: 1.2 }); });
    post.u.anamorphic.value = ctx.config.post.anamorphic.strength * (sh.id === 'B' || sh.id === 'D' ? 1.3 : 0.7);
    post.u.godray.value = 0;

    // ── 종료: 푸른 빛으로 번쩍 → Ch.6 원자로 속 체렌코프 ──
    post.setFlash(smoothstep((t - 29.35) / 0.6) * (1 - smoothstep((t - 30.1) / 0.6)));

    // ── 사운드 ──
    this._acc += dtReal;
    if (this._acc > 0.12) {
      this._acc = 0;
      const depth = sh.id === 'B' ? smoothstep((t - 9.6) / 5) : 0;
      this.pad.setLevel(0.09 + 0.06 * (sh.id === 'D' ? smoothstep((t - 24.9) / 3) : 0), 0.5);
      this.sub.setLevel(0.1 + 0.06 * depth, 0.5);
      if (this.whine) { this.whine.setFreqs([180 + 520 * c.uSep.value, 270 + 780 * c.uSep.value], 0.3); this.whine.setLevel(sh.id === 'B' && t < 18.6 ? 0.06 + 0.08 * c.uSep.value : 0.0001, 0.4); }
    }
    this.once('whine', t > 9.8, () => { this.whine = this.own(a.drone({ freqs: [180, 270], level: 0.06, cutoff: 3200, type: 'sine', fadeIn: 1.2, detune: 5 })); });
    this.once('grid', t > 5.3, () => { a.riser({ dur: 1.6, from: 400, to: 3200, level: 0.12 }); });
    this.once('sinter', t > 22.0, () => { a.hit({ freq: 70, level: 0.5, decay: 1.2, noise: 0.6 }); a.riser({ dur: 2.2, from: 300, to: 2600, level: 0.1 }); });
    this.once('coin', t > 23.4, () => { a.ping({ freq: 2093, level: 0.14, decay: 1.8 }); a.ping({ freq: 3136, level: 0.07, decay: 1.4 }); });
    this.once('load', t > 25.1, () => { a.hit({ freq: 110, level: 0.3, decay: 0.5, noise: 0.3 }); });
    if (t > 25.1 && t < 26.6 && t > this._tickT) { this._tickT = t + 0.13; a.ping({ freq: 1200 + 90 * ((t * 7) % 6), level: 0.05, decay: 0.25 }); }
    this.once('asm', t > 26.8, () => { a.whoosh({ dur: 1.7, from: 400, to: 5000, level: 0.24 }); this.own(a.riser({ dur: 2.2, from: 250, to: 4800, level: 0.2 })); });
    this.once('end', t > 29.5, () => { a.hit({ freq: 42, level: 0.8, decay: 2.2, noise: 0.5 }); this.camRig.shake(0.5); });
  }

  /** 샷이 바뀔 때: 해당 샷의 무대만 보이게 */
  _enter(id) {
    const on = (id === 'A') ? 'yc' : (id === 'G' || id === 'G2') ? 'grid' : id === 'B' ? 'cent' : id === 'C' ? 'pel' : 'rod';
    this.yc.group.visible = on === 'yc'; this.grid.group.visible = on === 'grid'; this.cent.group.visible = on === 'cent';
    this.pel.group.visible = on === 'pel'; this.rod.group.visible = on === 'rod';
    if (id === 'G') { this.grid.uK.value = 7; this.grid.uAppear.value = 0; }
    if (id !== 'D') { this.rod.uAsm.value = 0; }
  }

  dispose() {
    const u = this.post.u;
    u.scan.value = -1; u.focus.value = 1000; u.focal.value = 1.0e6; u.godray.value = 0; u.anamorphic.value = this.ctx.config.post.anamorphic.strength;
    this.post.setFlash(0);
  }
}
