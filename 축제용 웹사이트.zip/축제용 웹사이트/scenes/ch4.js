// scenes/ch4.js — Ch.4 E=mc²: 질량이 빛이 되는 순간 (120~145초)
//
//  와우 모먼트: 거대한 홀로그램 저울 위에서 분열 전후의 질량을 달아 보면 "아주 조금" 가벼워져 있다.
//   사라진 질량이 빛 입자로 변해 쏟아져 나와 3D 수식 "E = mc²" 를 SDF 금속 글자로 빚어낸다.
//   빛이 폭발적으로 퍼지며 카메라가 쭉 빠지면 → 오프닝의 태양이 나타난다 (수미상관).
//   "태양도 질량을 에너지로 바꿔 빛납니다 (핵융합)" — 핵분열(무거운 핵이 쪼개짐)과 핵융합(가벼운 핵이 합쳐짐)은 다른 반응임을 한 줄로 구분.
//   0~2 저울 등장(홀로그램 스캔) → 2~5 분열 전후 물질이 양쪽 접시에 → 6~9 저울이 기움 → 9~12.5 사라진 질량이 빛으로 → 12.5~17 빛이 글자를 그림
//   → 16.5~18.4 금속 SDF 글자로 → 18.4~20.3 유지 → 20.3~21.2 폭발·카메라 후퇴 → 21.2~25 태양
//  수치 출처(원자 질량, AME2020): U-235 235.0439 u + n 1.0087 u = 236.0526 u  /  Ba-141 140.9144 u + Kr-92 91.9262 u + 3n 3.0260 u = 235.8666 u
//   → 차이 0.186 u = 약 173 MeV (이 한 경로 기준. 분열 전체에서 중성자 방출 후 붕괴 등을 합쳐 "약 200 MeV"). 1 g → E=mc² = 9×10¹³ J.
//  ※ 실제 질량 차이는 0.08%라 눈으로 보이지 않는다 — 저울의 기울기는 이해를 위해 크게 과장했다(화면에 표기).

import * as THREE from 'three/webgpu';
import { Fn, float, vec3, vec4, uniform, uv, normalWorld, positionWorld, positionLocal, cameraPosition, normalize, length, dot, mix, smoothstep, clamp, pow, abs, exp, step, fract, mx_noise_float, instanceColor, instanceIndex } from 'three/tsl';
import { SceneBase } from './_base.js';
import { Shared } from './_shared.js';
import { makeStars, makeSun } from './shared/space.js';
import { makeSDFText } from './shared/sdfText.js';
import { makeForge } from './shared/forge.js';
import { makePose } from '../engine/camera.js';
import { clamp as cl, lerp, spline, smoothstep as sstep, easeInOutCubic, easeOutCubic } from '../engine/ease.js';

const ST = new THREE.Vector3(0, -4000, 0);            // 저울 무대의 월드 위치 (태양 장면과 멀리 떨어뜨려 서로 간섭하지 않게)
const SWAP = 21.2;                                     // 로컬 시간: 빛 폭발 화이트아웃 → 태양
const PIV = 2.2;                                       // 저울 지렛대 높이
const BEAM_L = 5.0;                                    // 지렛대 반길이
const WP = [                                           // 카메라 [t, px,py,pz, lx,ly,lz, fov] (무대 로컬)
  [0,    7.5, 1.2, 14,    0, 0.2, 0,   44],
  [5,   -3.0, 2.2, 12,    0, 0.5, 0,   42],
  [9,    3.0, 0.4, 9.5,   3.8, -0.1, 0, 40],
  [13,   0.0, 2.0, 13.5,  0, 1.2, 0,   46],
  [17,   0.0, 1.3, 15.5,  0, 1.0, 0,   44],
  [20.3, 0.0, 1.0, 12.8,  0, 1.0, 0,   40],
];
const cam = (t, k) => spline(WP.map((w) => [w[0], w[k]]), t);
const V = new THREE.Vector3(), HEAD = new THREE.Vector3();

function holo(color, alpha = 0.06, edge = 0.7, uA = null) {
  const m = new THREE.MeshBasicNodeMaterial({ transparent: true, depthWrite: false, side: THREE.DoubleSide });
  m.colorNode = Fn(() => {
    const nW = normalize(normalWorld), Vw = normalize(cameraPosition.sub(positionWorld));
    const f = pow(float(1.0).sub(abs(dot(nW, Vw))), 2.0);
    const k = uA ? uA : float(1.0);
    return vec4(vec3(color.r, color.g, color.b).mul(f.mul(edge).add(0.1)).mul(k), f.mul(edge).add(alpha).mul(k));
  })();
  return m;
}

export default class Ch4 extends SceneBase {
  async warmup() {
    const ctx = this.ctx;
    this.stars = await Shared.create(ctx, 'stars', makeStars);
    this.sun = await Shared.create(ctx, 'sun', makeSun);

    const stage = this.stage = new THREE.Group(); stage.position.copy(ST); this.root.add(stage);
    this.uScaleA = uniform(0.0);
    const cyan = new THREE.Color(0.25, 0.85, 1.0), amber = new THREE.Color(1.0, 0.72, 0.3);

    // 저울: 받침 + 기둥 + 지렛대 + 접시 2 + 줄
    const base = new THREE.Mesh(new THREE.CylinderGeometry(3.3, 3.6, 0.5, 48), holo(cyan, 0.08, 0.8, this.uScaleA)); base.position.y = -3.7;
    const column = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.34, 5.9, 20), holo(cyan, 0.1, 0.8, this.uScaleA)); column.position.y = -0.55;
    const hub = new THREE.Mesh(new THREE.SphereGeometry(0.42, 24, 16), holo(amber, 0.15, 0.9, this.uScaleA)); hub.position.y = PIV;
    this.beam = new THREE.Mesh(new THREE.BoxGeometry(BEAM_L * 2 + 0.6, 0.2, 0.5), holo(cyan, 0.1, 0.9, this.uScaleA)); this.beam.position.y = PIV;
    this.panL = new THREE.Mesh(new THREE.CylinderGeometry(2.1, 2.1, 0.1, 48), holo(cyan, 0.05, 0.55, this.uScaleA));
    this.panR = this.panL.clone();
    stage.add(base, column, hub, this.beam, this.panL, this.panR);
    const chainMat = new THREE.LineBasicNodeMaterial({ transparent: true, blending: THREE.AdditiveBlending, depthWrite: false });
    chainMat.colorNode = Fn(() => vec4(vec3(0.4, 0.8, 1.0).mul(this.uScaleA).mul(0.6), 1.0))();
    const mkChain = () => { const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(6 * 3), 3)); const l = new THREE.LineSegments(g, chainMat); l.frustumCulled = false; stage.add(l); return l; };
    this.chainL = mkChain(); this.chainR = mkChain();

    // 접시 위 물질: 핵자(양성자 주황·중성자 청록) 덩어리. 반지름은 질량수^(1/3) 에 비례 — U-235 : Ba-141 : Kr-92 = 1 : 0.84 : 0.73 (실제 핵 반지름 비와 같다)
    this.uBallA = uniform(0.0);
    const tt = ctx.u.time, uA = this.uBallA;
    const nMat = new THREE.MeshBasicNodeMaterial({ transparent: true, depthWrite: true });
    nMat.positionNode = positionLocal.add(vec3(mx_noise_float(vec3(float(instanceIndex).mul(0.7), tt.mul(7.0), 1.0)), mx_noise_float(vec3(float(instanceIndex).mul(0.9), tt.mul(6.0), 4.0)), mx_noise_float(vec3(float(instanceIndex).mul(1.3), tt.mul(8.0), 9.0))).mul(0.012));
    nMat.colorNode = Fn(() => {
      const nW = normalize(normalWorld), Vw = normalize(cameraPosition.sub(positionWorld));
      const lam = clamp(dot(nW, normalize(vec3(-0.4, 0.7, 0.6))), 0.0, 1.0);
      const rim = pow(float(1.0).sub(clamp(dot(nW, Vw), 0.0, 1.0)), 2.5);
      return vec4(instanceColor.mul(lam.mul(0.8).add(0.35)).add(vec3(0.5, 0.8, 1.0).mul(rim).mul(0.3)), uA);
    })();
    const nGeo = new THREE.SphereGeometry(1, 14, 10);
    let seed = 91;
    const rnd = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };
    const ORANGE = new THREE.Color(0xff8c2a), TEAL = new THREE.Color(0x1fd6c8), RED = new THREE.Color(0xff3b30), BLUE = new THREE.Color(0x3d86ff);
    const NR = 0.127;                                                  // 핵자 하나의 반지름(월드 단위, 세 덩어리 공통)
    const cluster = (N, R, protonFrac) => {
      const pts = [];
      for (let i = 0; i < N; i++) { let v; do { v = new THREE.Vector3(rnd() * 2 - 1, rnd() * 2 - 1, rnd() * 2 - 1); } while (v.length() > 1); pts.push(v.multiplyScalar(R - NR * 0.6)); }
      for (let it = 0; it < 50; it++) {                                // 겹침 이완
        for (let i = 0; i < N; i++) for (let j = i + 1; j < N; j++) {
          const d = pts[i].distanceTo(pts[j]);
          if (d < NR * 1.9 && d > 1e-4) { const dv = pts[i].clone().sub(pts[j]).multiplyScalar((NR * 1.9 - d) * 0.5 / d); pts[i].add(dv); pts[j].sub(dv); }
        }
        for (const q of pts) { const l = q.length(); if (l > R - NR) q.multiplyScalar((R - NR) / l); }
      }
      const m = new THREE.InstancedMesh(nGeo, nMat, N), m4 = new THREE.Matrix4(), c = new THREE.Color();
      pts.forEach((q, i) => { m4.makeScale(NR, NR, NR).setPosition(q); m.setMatrixAt(i, m4); c.copy(rnd() < protonFrac ? ORANGE : TEAL); m.setColorAt(i, c); });
      m.frustumCulled = false;
      const g = new THREE.Group(); g.add(m); return g;
    };
    const single = (color, r) => { const m = new THREE.InstancedMesh(nGeo, nMat, 1), m4 = new THREE.Matrix4().makeScale(r, r, r); m.setMatrixAt(0, m4); m.setColorAt(0, color); m.frustumCulled = false; const g = new THREE.Group(); g.add(m); return g; };
    this.objL = [cluster(235, 1.12, 0.39), single(BLUE, 0.2)];                                                   // U-235 + 느린 중성자
    this.objR = [cluster(141, 0.945, 0.4), cluster(92, 0.82, 0.39), single(RED, 0.2), single(RED, 0.2), single(RED, 0.2)];   // Ba-141, Kr-92, 중성자 3개
    stage.add(...this.objL, ...this.objR);
    // 사라진 질량(유령 구): 오른쪽 접시 위에서 빛으로 변한다
    this.uGhost = uniform(0.0);
    const gm = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
    gm.colorNode = Fn(() => { const r = length(uv().sub(0.5)).mul(2.0); return vec4(mix(vec3(1.0, 0.75, 0.35), vec3(1.0, 1.0, 1.0), exp(r.mul(-7.0))).mul(exp(r.mul(-3.0))).mul(smoothstep(1.0, 0.5, r)).mul(this.uGhost).mul(2.0), 1.0); })();
    this.ghost = new THREE.Sprite(gm); this.ghost.scale.set(1.6, 1.6, 1); this.ghost.renderOrder = 10; stage.add(this.ghost);

    // 빛 입자 + SDF 글자 (무대 로컬 (0,1,0) 에 중심)
    const N = Math.max(15000, Math.min(150000, Math.floor(this.quality.particleCap * 0.15)));
    this.forge = makeForge(ctx, N, 'E = mc²', 12, new THREE.Vector3(0, 1.0, 0));
    stage.add(this.forge.points);
    this.text = makeSDFText(ctx, { text: 'E = mc²', worldW: 12, depth: 0.55, center: new THREE.Vector3(0, 1.0, 0) });
    this.text.uCenter.value.copy(ST).add(new THREE.Vector3(0, 1.0, 0));
    this.text.mesh.position.set(0, 1.0, 0);
    stage.add(this.text.mesh);
    this.flare = (() => { const m = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending }); this.uFlare = uniform(0.0);
      m.colorNode = Fn(() => { const r = length(uv().sub(0.5)).mul(2.0); return vec4(mix(vec3(1.0, 0.7, 0.35), vec3(1.0, 1.0, 1.0), exp(r.mul(-7.0))).mul(exp(r.mul(-5.0))).mul(smoothstep(1.0, 0.5, r)).mul(this.uFlare).mul(2.6), 1.0); })();
      const s = new THREE.Sprite(m); s.scale.set(4.2, 4.2, 1); s.renderOrder = 12; stage.add(s); return s; })();

    this.pose = makePose(); this.pose.near = 0.1; this.pose.far = 9000;
  }

  start() {
    const ctx = this.ctx;
    Shared.acquire(ctx, 'stars');
    this._phase = 'stage'; this._acc = 0; this._tick = 0;
    this.stage.visible = true;
    this.forge.uT.value = 0; this.forge.uBurst.value = 0; this.forge.uVis.value = 1;
    this.forge.uStart.value = 11.0; this.forge.uSpan.value = 4.6;
    this.onQuality();
    const s0 = this.def.start, id = this.id;
    const H = (o) => this.hud.add({ owner: id, ...o });
    const at = (x, y, z) => () => V.set(x, y, z).add(ST);
    H({ id: `${id}-L`, anchor: at(-BEAM_L, PIV - 3.1, 0), text: '분열 전: U-235 + 중성자', sub: '236.0526 u', offset: [-70, -60], from: s0 + 3.2, to: s0 + 13, color: '#ffb36b' });
    H({ id: `${id}-R`, anchor: at(BEAM_L, PIV - 3.1 + 0.9, 0), text: '분열 후: Ba-141 + Kr-92 + 중성자 3개', sub: '235.8666 u', offset: [70, -70], from: s0 + 4.6, to: s0 + 13, color: '#7be8ff' });
    H({ id: `${id}-diff`, anchor: at(0, PIV + 0.9, 0), text: '질량 차이 약 0.186 u  (≈ 173 MeV)', sub: '실제로는 0.08% — 기울기는 이해를 위해 과장', offset: [0, -90], from: s0 + 8.6, to: s0 + 13.2, color: '#ffffff' });
    H({ id: `${id}-eq`, anchor: at(0, 3.6, 0), text: '에너지 E  =  질량 m  ×  광속 c²', sub: '1 g → 약 9×10¹³ J', offset: [0, -50], from: s0 + 17.6, to: s0 + 21, color: '#ffd27a' });
    H({ id: `${id}-fusion`, anchor: () => V.set(0, 0, 0), text: '태양 — 핵융합 (수소 → 헬륨)', sub: 'FUSION ≠ FISSION', offset: [150, -150], from: s0 + 22.2, to: s0 + 25, color: '#ffa840' });

    const a = this.audio;
    this.pad = this.own(a.drone({ freqs: [220, 277.2, 329.6], level: 0.1, cutoff: 1800, type: 'sine', fadeIn: 2.0, bus: 'music', detune: 3 }));
    this.sub = this.own(a.drone({ freqs: [55, 82.4], level: 0.12, cutoff: 260, fadeIn: 1.5, detune: 6 }));
    a.whoosh({ dur: 1.6, from: 400, to: 4000, level: 0.2 });
  }

  onQuality() { this.forge.setCount(Math.min(this.forge.N, this.quality.particleCap * 0.15)); }

  _toSun() { this.stage.visible = false; Shared.acquire(this.ctx, 'sun'); this._phase = 'sun'; }
  _toStage() { Shared.release(this.ctx, 'sun'); this.stage.visible = true; this._phase = 'stage'; }

  update(t, dt, dtReal) {
    const w = this.weight, post = this.post, a = this.audio, ctx = this.ctx, p = this.pose;
    post.blendBloom(1.2, w);
    this.once('cut', t > -0.1, () => post.flashPulse(0.8, 6));                // 이전 장면(공간이 다름)과의 컷을 섬광으로 가린다
    if (this._phase === 'stage' && t >= SWAP) this._toSun();
    else if (this._phase === 'sun' && t < SWAP - 0.001) this._toStage();

    // ── 저울 ──
    const tilt = 0.17 * sstep((t - 6.0) / 3.0) * (1 + 0.05 * Math.sin(t * 4) * (1 - sstep((t - 9.5) / 1.5)));
    this.uScaleA.value = sstep(t / 1.4) * (1 - sstep((t - 13.2) / 2.6)) * w;
    const side = (sgn) => { const ex = sgn * BEAM_L * Math.cos(tilt), ey = PIV + sgn * BEAM_L * Math.sin(tilt); return [ex, ey, ey - 3.1]; };
    const [lx, ly, lpan] = side(-1), [rx, ry, rpan] = side(1);
    this.beam.rotation.z = tilt;
    this.panL.position.set(lx, lpan, 0); this.panR.position.set(rx, rpan, 0);
    const fillChain = (line, ex, ey, py) => { const a_ = line.geometry.attributes.position, r = 1.9;
      [[-r, 0.0], [r, 0.0], [0, r]].forEach(([dx, dz], k) => { a_.setXYZ(k * 2, ex, ey, 0); a_.setXYZ(k * 2 + 1, ex + dx, py + 0.06, dz); }); a_.needsUpdate = true; };
    fillChain(this.chainL, lx, ly, lpan); fillChain(this.chainR, rx, ry, rpan);
    // 접시 위 물질: 순서대로 쏙 나타남
    this.uBallA.value = this.uScaleA.value;
    const pop = (t0, d) => easeOutCubic(cl((t - t0) / d));
    this.objL[0].position.set(lx, lpan + 1.2, 0); this.objL[0].scale.setScalar(pop(2.0, 0.9) + 1e-3);
    this.objL[1].position.set(lx + 1.55, lpan + 0.4, 0.4); this.objL[1].scale.setScalar(pop(2.5, 0.8) + 1e-3);
    const rp = (k, dx, dy, dz, t0) => { this.objR[k].position.set(rx + dx, rpan + dy, dz); this.objR[k].scale.setScalar(pop(t0, 0.8) + 1e-3); };
    rp(0, -0.55, 1.0, 0, 3.3); rp(1, 0.95, 0.85, 0.2, 3.6); rp(2, -1.5, 0.35, 0.7, 4.0); rp(3, 0.2, 0.3, -1.4, 4.2); rp(4, 1.9, 0.3, -0.7, 4.4);
    const hide = 1 - sstep((t - 13.2) / 2.2);
    for (const o of [...this.objL, ...this.objR]) if (hide < 0.999) o.scale.multiplyScalar(Math.max(hide, 0.0001));

    // 사라진 질량(빛 덩어리): 오른쪽 접시 위에 떠올라 → 빛 입자로
    const gl = sstep((t - 9.0) / 1.2) * (1 - sstep((t - 11.6) / 0.8));
    this.uGhost.value = gl * (0.8 + 0.2 * Math.sin(t * 9)) * w;
    this.ghost.position.set(rx, rpan + 1.8 + 0.5 * sstep((t - 9) / 2), 0);
    this.forge.uSource.value.copy(this.ghost.position);

    // ── 글자 ──
    this.forge.uT.value = t;
    this.forge.uVis.value = (1 - 0.82 * sstep((t - 16.4) / 1.2)) * w;
    this.text.uA.value = sstep((t - 16.2) / 2.0) * w;
    const sw = cl((t - 17.9) / 1.9);
    this.text.uSweep.value = sw > 0 && sw < 1 ? lerp(-0.1, 1.1, sw) : -1;
    const bell = Math.sin(Math.PI * sw) * (sw > 0 && sw < 1 ? 1 : 0);
    this.flare.position.set(lerp(-7, 7, sw), 1.0, 1.2); this.uFlare.value = bell * w;
    post.u.anamorphic.value = ctx.config.post.anamorphic.strength * (1 + 2.0 * bell);
    const burst = cl((t - 20.3) / 1.0);
    this.forge.uBurst.value = burst * burst * 1.1;
    this.text.uGain.value = 1 + 2.4 * burst;

    // ── 스캔 라인: 시작 때 홀로그램이 위에서 아래로 훑으며 나타남 ──
    post.u.scan.value = t > 0.15 && t < 1.9 ? lerp(-0.05, 1.1, (t - 0.15) / 1.7) : -1;

    // ── 카메라 ──
    if (this._phase === 'stage') {
      const tt = Math.min(t, 20.3);
      p.pos.set(cam(tt, 1), cam(tt, 2), cam(tt, 3)); p.look.set(cam(tt, 4), cam(tt, 5), cam(tt, 6)); p.fov = cam(tt, 7);
      if (t > 20.3) { const u = cl((t - 20.3) / 0.9); p.pos.z += 50 * u * u; p.pos.y += 3 * u; p.fov += 18 * u; }
      p.pos.add(ST); p.look.add(ST);
      p.roll = 0; p.scale = 6; p.near = 0.1; p.far = 9000;
      post.u.speed.value = (t > 20.3 ? 0.8 * cl((t - 20.3) / 0.8) : 0) * w;
      this.cam(p);
    } else {
      const u = cl((t - SWAP) / (this.len - SWAP));
      p.pos.set(lerp(470, 560, easeInOutCubic(u)), lerp(40, 54, u), lerp(60, 78, u)); p.look.set(0, -2, 0); p.fov = 51; p.roll = 0; p.scale = 260; p.near = 1; p.far = 9000;
      this.cam(p);
      this.sun.uBig.value = 0.75 * w;
      post.u.speed.value = 0;
      const v = new THREE.Vector3(0, 0, 0).project(ctx.camera); post.u.godCenter.value.set(v.x * 0.5 + 0.5, v.y * 0.5 + 0.5); post.u.godray.value = 0.22 * w;
    }
    // 화이트: 폭발 정점(21.0~21.4) 후 걷힘
    post.setFlash(Math.max(sstep((t - 20.55) / 0.55) * (1 - sstep((t - 21.15) / 1.3)), 0));

    // ── 사운드 ──
    this._acc += dtReal;
    if (this._acc > 0.12) { this._acc = 0; this.pad.setLevel(0.1 + 0.08 * sstep((t - 12) / 5), 0.4); this.sub.setLevel(0.12 + 0.1 * sstep((t - 8) / 6) * (this._phase === 'stage' ? 1 : 0), 0.4); }
    if (t > 6 && t < 9.2 && t > this._tick) { this._tick = t + 0.45; a.ping({ freq: 880 + 120 * (t - 6), level: 0.05, decay: 0.3 }); }
    if (t > 12.6 && t < 17.4 && t > this._tick) { this._tick = t + 0.3; a.ping({ freq: 660 * Math.pow(2, [0, 3, 7, 10, 12, 15][Math.floor((t - 12.6) / 0.3) % 6] / 12), level: 0.06, decay: 0.8 }); }
    this.once('ghost', t > 9.2, () => { this.own(a.riser({ dur: 3.2, from: 300, to: 4200, level: 0.18 })); });
    this.once('reveal', t > 16.4, () => { this.own(a.drone({ freqs: [330, 415.3, 493.9, 659.3], level: 0.18, cutoff: 3500, type: 'sine', fadeIn: 0.7, bus: 'music', detune: 4 })); a.hit({ freq: 62, level: 0.5, decay: 1.5, noise: 0.2 }); });
    this.once('sweep', t > 17.9, () => a.whoosh({ dur: 1.9, from: 500, to: 6500, level: 0.22 }));
    this.once('burst', t > 20.3, () => this.own(a.riser({ dur: 1.0, from: 400, to: 7000, level: 0.3 })));
    this.once('flash', t > 20.95, () => { a.hit({ freq: 44, level: 0.9, decay: 2.8, noise: 0.7 }); a.hit({ freq: 100, level: 0.4, decay: 1.4, noise: 0.5 }); this.camRig.shake(0.5); });
    this.once('sun', t > SWAP, () => { this.own(a.drone({ freqs: [41.2, 82.4, 123.5], level: 0.3, cutoff: 600, fadeIn: 1.4, detune: 6 })); this.own(a.drone({ freqs: [329.6, 494], level: 0.07, cutoff: 1100, type: 'sine', fadeIn: 1.4, bus: 'music' })); });
  }

  dispose() {
    const ctx = this.ctx;
    Shared.release(ctx, 'stars');
    if (this._phase === 'sun') Shared.release(ctx, 'sun');
    this.sun.uBig.value = 0;
    const u = this.post.u; u.scan.value = -1; u.speed.value = 0; u.godray.value = 0; u.anamorphic.value = ctx.config.post.anamorphic.strength;
  }
}
