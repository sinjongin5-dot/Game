// ════════════════════════════════════════════════════════════════════
//  config.js — 이 사이트의 모든 "조절 손잡이"가 모여 있는 파일
//  동아리원이 수정할 곳: ① 크레딧(credits) ② 자막/키워드 카드 문구 ③ 타이밍 ④ 사운드 음량 ⑤ 품질
//  수정 후 브라우저 새로고침(Ctrl+F5)만 하면 반영됩니다. (빌드 과정 없음)
// ════════════════════════════════════════════════════════════════════

export const CONFIG = {

  // ── 기본 정보 ──────────────────────────────────────────────────────
  title: '친환경 에너지, 원자력',
  subtitle: '태양에서 원자핵까지',

  // ── 크레딧 (이름 표시) ─────────────────────────────────────────────
  //  show: false 이면 제작자 이름을 화면에 전혀 띄우지 않는다("누가 만들었는지 밝히지 않음"). true 로 바꾸고 아래를 채우면 크레딧 문구가 나온다.
  credits: {
    show:    false,
    school:  '○○고등학교',      // ← 학교 이름
    club:    '○○ 동아리',       // ← 동아리 이름
    makers:  '제작자 이름',      // ← 제작자 (여러 명이면 '가, 나, 다')
    teacher: '지도교사 이름',    // ← 지도교사
  },

  // ── 피날레 "해킹 → 블루스크린 → 되감기" 연출 (ui/hack.js · scenes/credits.js · scenes/shared/worm.js) ──
  //  순수한 시각·음향 연출이다: 가짜 터미널 글자, 가짜 오류 화면일 뿐이며 실제 네트워크 통신·시스템 접근은 전혀 없다.
  //  시각은 디렉터 시간(초). 순서: 이상 징후 → 웜 확산 → 혼돈 → 블루스크린 → 되감기(→ 태양으로 돌아가 루프)
  hack: {
    enabled:     true,           // false 로 두면 이 연출 전체를 끄고 평범한 크레딧 장면으로 돌아간다
    aiName:      'OPUS-5.5',     // 화면에 나오는 "침입자" 이름 (가상)
    t0:          317,            // 첫 글리치(이상 징후)
    wormStart:   322,            // 웜 확산 시작 (= 크레딧 장면 시작)
    chaos:       325.5,          // 화면 붕괴 시작
    bsodStart:   326.4,          // 블루스크린 시작
    bsodEnd:     329.7,          // 블루스크린 끝 → 되감기 시작
    rewindEnd:   336.8,          // 되감기 끝(순백) → 루프
    fakeDuration: 337,           // 되감기 타임코드가 거슬러 올라가는 "원래 길이"(초)
  },

  // ── 색상 팔레트 ────────────────────────────────────────────────────
  // 원자 규약색: 양성자=주황, 중성자=청록, 전자=흰빛 파랑, 빠른 중성자=빨강, 느린 중성자=파랑
  colors: {
    bgDeep:       0x02040c,   // 딥 네이비/블랙 배경
    sun:          0xff8a1f,   // 태양 오렌지
    cyan:         0x22e6ff,   // 청록(시안)
    green:        0x7dff6a,   // 연두(친환경 포인트)
    proton:       0xff8c2a,   // 양성자
    neutron:      0x1fd6c8,   // 중성자
    electron:     0xbfe2ff,   // 전자
    neutronFast:  0xff3b30,   // 빠른 중성자
    neutronSlow:  0x2f7bff,   // 느린 중성자
    primaryLoop:  0xff6a2a,   // 1차 계통(고압 냉각수) 빨강-주황
    secondaryLoop:0x1fd6c8,   // 2차 계통(깨끗한 물/증기) 청록
  },

  // ── 전체 타임라인 ──────────────────────────────────────────────────
  // start/end: 초 단위(디렉터 시간). 앞 씬의 end = 다음 씬의 start 로 이어져야 합니다.
  // overlap : 이 씬과 "다음 씬"이 겹쳐서 매치컷을 만드는 구간의 총 길이(초).
  //           경계 시각 ± overlap/2 동안 두 씬이 동시에 그려지고 카메라가 부드럽게 섞입니다.
  // skip    : true 면 →/← 키로 건너뛰는 "챕터 시작점".
  // module  : 씬 구현 파일 (scenes/ 폴더)
  loopLength: 337,   // 한 바퀴 총 길이(초) = 5분 37초. 마지막 씬의 end 와 같아야 함.

  scenes: [
    // ── 오프닝 (0~40s) ─────────────────────────────────────────────
    { id: 'sun',    label: 'Scene 1 · 태양',          start:   0, end:   6, overlap: 1.2, skip: true,  module: './scenes/opening/sun.js',
      subtitles: [ { at: 1.0, dur: 4.6, text: '모든 에너지의 시작, 태양' } ] },
    { id: 'comet',  label: 'Scene 2 · 혜성 비행',     start:   6, end:  16, overlap: 1.5, module: './scenes/opening/comet.js' },
    { id: 'entry',  label: 'Scene 3 · 대기권·서울',   start:  16, end:  24, overlap: 0.6, module: './scenes/opening/entry.js' },   // 23.5~24.0 슬로모션
    { id: 'impact', label: 'Scene 4 · 충돌·글자',     start:  24, end:  40, overlap: 1.5, module: './scenes/opening/impact.js' },

    // ── 본편 (40~245s) ─────────────────────────────────────────────
    { id: 'ch1', label: 'Ch.1 · 원자 속으로',        start:  40, end:  65, overlap: 1.5, skip: true, module: './scenes/ch1.js',
      subtitles: [ { at: 2.0, dur: 9.0,  text: '연료 한 알 속에는 수많은 원자가 있습니다' },
                   { at: 12.5, dur: 10.0, text: '원자의 대부분은 빈 공간, 질량은 가운데 핵에 모여 있죠' } ],
      cards: [ { at: 1.0, items: [
        { k: 'U-235',    v: '양성자 92 + 중성자 143' },
        // [수정 반영] 원래 문구 "약 10만분의 1"은 수소 기준. 우라늄은 핵 지름≈15fm, 원자 지름≈3.5×10⁻¹⁰m → 약 2만분의 1.
        { k: '원자핵 크기', v: '원자의 약 수만분의 1' },
      ] } ] },

    { id: 'ch2', label: 'Ch.2 · 핵분열',            start:  65, end:  90, overlap: 1.5, skip: true, module: './scenes/ch2.js',
      subtitles: [ { at: 2.0, dur: 9.0,  text: '느린 중성자 하나가 우라늄 핵에 부딪히면…' },
                   { at: 13.0, dur: 10.0, text: '핵이 둘로 쪼개지며 엄청난 에너지가 나옵니다' } ],
      cards: [ { at: 1.0, items: [
        { k: '핵분열',  v: '무거운 핵이 둘로 쪼개지는 반응' },
        { k: '중성자',  v: '핵분열을 일으키는 입자' },
        // 8.2×10¹³ J/kg(U-235) ÷ 2.4×10⁷ J/kg(석탄) ≈ 3.4×10⁶ → "수백만 배"
        { k: '1회 분열당', v: '약 200 MeV (석탄 연소의 약 300만 배/kg)' },
      ] } ] },

    { id: 'ch3', label: 'Ch.3 · 연쇄 반응·제어',     start:  90, end: 120, overlap: 1.5, skip: true, module: './scenes/ch3.js',
      subtitles: [ { at: 2.0, dur: 12.0, text: '쪼개질 때 나온 중성자가 또 다른 핵을 쪼갭니다 — 연쇄 반응' },
                   { at: 15.0, dur: 13.0, text: '제어봉이 중성자를 흡수해 반응 속도를 일정하게 지킵니다' } ],
      cards: [ { at: 1.0, items: [
        { k: '연쇄 반응', v: '나온 중성자가 다음 분열을 일으킴' },
        { k: '제어봉',   v: '붕소·카드뮴이 중성자를 흡수' },
        { k: '감속재',   v: '물이 중성자 속도를 늦춤' },
      ] } ] },

    { id: 'ch4', label: 'Ch.4 · E=mc²',             start: 120, end: 145, overlap: 1.5, cutIn: 'hard', skip: true, module: './scenes/ch4.js',
      subtitles: [ { at: 2.0, dur: 10.0, text: '분열 뒤 남은 조각들은 처음보다 아주 조금 가볍습니다' },
                   { at: 12.5, dur: 8.0, text: '사라진 질량은 어디로 갔을까요? 에너지로 바뀌었습니다' },
                   { at: 21.4, dur: 3.4, text: '태양도 질량을 에너지로 바꿔 빛납니다 — 단, 핵융합이라는 다른 반응이죠' } ],
      cards: [ { at: 1.0, items: [
        // 이 분열 경로(U-235+n → Ba-141+Kr-92+3n)의 원자 질량(AME2020): 236.0526 u → 235.8666 u, 차이 0.186 u = 0.079% (≈173 MeV)
        { k: '질량 결손', v: '분열 뒤 질량이 약 0.08% 줄어듦' },
        { k: 'E = mc²',  v: '1 g이 전부 에너지가 되면 약 9×10¹³ J' },
      ] } ] },

    { id: 'ch5', label: 'Ch.5 · 연료의 화학',        start: 145, end: 175, overlap: 1.5, cutIn: 'hard', skip: true, module: './scenes/ch5.js',
      subtitles: [ { at: 1.6, dur: 8.2,  text: '천연 우라늄에는 쪼개지는 U-235가 약 0.7%뿐' },
                   { at: 10.4, dur: 11.4, text: '원심분리기를 수없이 이어 U-235를 3~5%로 높입니다' },
                   { at: 22.2, dur: 7.0, text: '세라믹 펠릿으로 구워 금속관에 쌓아 연료봉, 그리고 집합체로' } ],
      cards: [ { at: 1.0, items: [
        { k: '농축',      v: 'U-235 비율을 3~5%로 높이는 과정' },
        { k: 'UO₂ 세라믹', v: '우라늄 산화물을 구운 연료 알갱이' },
        // 45 GWd/tU 가정 계산: 펠릿(UO₂ ≈ 8 g, U ≈ 7 g)=2.7×10¹⁰ J ≈ 석탄 1.1 t. (NEI 등이 인용하는 "석탄 약 1톤")
        { k: '펠릿 1개',  v: '석탄 약 1톤 분량의 에너지' },
      ] } ] },

    // ── 핵심 기계 해부 (175~232s): 원자로 용기 → 냉각재펌프 → 가압기 → 증기발생기 → 터빈 → 발전기 (기계공학 단면·분해 모델) ──
    { id: 'mech', label: 'Ch.6a · 핵심 기계 해부',    start: 175, end: 232, overlap: 1.5, cutIn: 'hard', skip: true, module: './scenes/mech.js',
      // 수치 출처(대표 가압경수로·APR1400 일반 자료): 열출력 3,983 MWt/전기 1,400 MWe, 노심 241 집합체, 운전압력 15.5 MPa(155 bar), 입구/출구 약 291/324 °C,
      //  155 bar 포화온도 약 345 °C(증기표), 2차 증기 약 6.9 MPa(≈ 70 bar, 포화 약 285 °C), 터빈 1,800 rpm(60 Hz·4극), RCP 약 1,200 rpm. 자세한 건 scenes/shared/mech/*.js 주석.
      subtitles: [ { at: 0.8,  dur: 10.0, text: '원자로 용기 — 155기압을 견디는 두께 약 25 cm의 강철 그릇' },
                   { at: 11.2, dur: 8.2,  text: '냉각재펌프 — 임펠러가 물을 밀어 1차 계통을 순환시킵니다' },
                   { at: 19.7, dur: 8.2,  text: '가압기 — 전열기와 스프레이로 압력을 155기압에 고정합니다' },
                   { at: 28.3, dur: 9.6,  text: '증기발생기 — 1차수와 2차수는 섞이지 않고 열만 주고받습니다' },
                   { at: 38.3, dur: 10.0, text: '터빈 — 증기가 팽창하며 날개를 밀어 초당 30바퀴 돕니다' },
                   { at: 48.7, dur: 8.2,  text: '발전기 — 회전하는 전자석이 코일에 전류를 만듭니다' } ],
      cards: [ { at: 1.0,  items: [ { k: '원자로 용기', v: '저합금강 벽 약 25 cm · 155기압' }, { k: '연료집합체', v: '241개 (APR1400)' }, { k: '제어봉', v: '비상시 중력으로 낙하 — SCRAM' } ] },
               { at: 11.6, items: [ { k: '냉각재펌프', v: '약 1,200 rpm · 노형당 2~4대' }, { k: '축 밀봉', v: '3단으로 155기압 차단' }, { k: '플라이휠', v: '정전 뒤에도 관성으로 유량 유지' } ] },
               { at: 20.0, items: [ { k: '가압기', v: '155기압 · 포화온도 약 345 °C' }, { k: '전열기', v: '증기를 만들어 압력 ↑' }, { k: '스프레이', v: '증기를 응축시켜 압력 ↓' } ] },
               { at: 28.6, items: [ { k: '증기발생기', v: '1차 324→291 °C · 2차 약 70 bar 증기' }, { k: 'U자관', v: '수천~1만여 개의 가는 관' }, { k: '습분분리기', v: '건조 증기만 터빈으로' } ] },
               { at: 38.6, items: [ { k: '터빈', v: '1,800 rpm · 4극 발전기와 직결' }, { k: '단(stage)', v: '고정 노즐 + 회전 버킷' }, { k: '저압터빈', v: '마지막 단 날개 길이 1.5 m급' } ] },
               { at: 49.0, items: [ { k: '발전기', v: '4극 회전자 · 60 Hz · 약 1,400 MWe' }, { k: '냉각', v: '수소(회전자) + 순수 냉각수(코일)' }, { k: '승압', v: '약 20 kV → 345·765 kV 송전' } ] } ] },

    { id: 'ch6', label: 'Ch.6 · 원자로에서 전기까지', start: 232, end: 267, overlap: 1.5, cutIn: 'hard', skip: true, module: './scenes/ch6.js',
      subtitles: [ { at: 2.0, dur: 14.0, text: '핵분열의 열이 물을 데우고, 그 증기가 터빈을 돌립니다' },
                   { at: 18.0, dur: 14.0, text: '결국 원리는 물 끓여 터빈 돌리기. 열원만 다릅니다' } ],
      cards: [ { at: 1.0, items: [
        { k: '가압경수로', v: '한국 원전의 주력 방식(PWR)' },
        { k: '증기발생기', v: '1차 계통의 열을 2차 계통에 전달' },
        { k: '패러데이 전자기 유도', v: '자석이 돌며 전류를 만듦' },
      ] } ] },

    { id: 'ch7', label: 'Ch.7 · 왜 친환경인가',      start: 267, end: 302, overlap: 1.5, skip: true, module: './scenes/ch7.js',
      subtitles: [ { at: 3.8,  dur: 7.8, text: '발전 중에는 이산화탄소를 직접 내놓지 않습니다' },
                   { at: 12.2, dur: 7.2, text: '건설부터 폐기까지 따져도 배출량은 풍력과 비슷한 수준' },
                   { at: 20.4, dur: 9.4, text: '다만 사용후핵연료 관리라는 숙제도 함께 풀어가야 합니다' } ],
      cards: [ { at: 4.4,  items: [ { k: '수증기 ≠ 연기', v: '냉각탑에서 나오는 흰 구름은 물' } ] },
               // IPCC AR5 WGIII Annex III Table A.III.2 중앙값 (gCO₂eq/kWh): 석탄 820, 가스 490, 태양광(대규모) 48, 원자력 12, 풍력 11~12
               { at: 12.6, items: [ { k: '생애주기 배출량', v: '건설~운영~폐기 전체의 탄소 배출 (중앙값)' } ] },
               { at: 20.8, items: [ { k: '사용후핵연료 관리', v: '아직 풀어가야 할 숙제' } ] } ] },

    // ── 피날레·크레딧·루프 브릿지 (302~337s) ───────────────────────
    { id: 'finale', label: 'Finale · 초록 오로라',   start: 302, end: 322, overlap: 1.0, cutIn: 'hard', skip: true, module: './scenes/finale.js',
      subtitles: [ { at: 7.0, dur: 11.0, text: '과학으로 만드는 깨끗한 에너지' } ] },
    { id: 'credits', label: 'Intrusion · 해킹 연출',    start: 322, end: 332, overlap: 1.0, module: './scenes/credits.js' },
    { id: 'bridge',  label: '루프 브릿지 → 태양',     start: 332, end: 337, overlap: 0.0, module: './scenes/bridge.js' },
  ],

  // ── 카메라 ─────────────────────────────────────────────────────────
  camera: {
    fov: 50, near: 0.05, far: 4000,
    handheld: {             // 미세 핸드헬드 흔들림 (회전 위주라 씬 크기와 무관하게 동작)
      rotDeg: 0.10,         // 회전 흔들림 크기(도). 0이면 끔
      posAmp: 0.0025,       // 위치 흔들림(씬 스케일 대비 비율)
    },
    shake: { maxDeg: 2.2, decay: 3.2, freq: 17 },   // 충돌·폭발용 쉐이크
  },

  // ── 후처리(포스트 프로세싱) ────────────────────────────────────────
  post: {
    exposure: 1.0,
    bloom: { strength: 0.2, radius: 0.32, threshold: 1.0 },    // ※ r186 블룸은 강도가 세다: 0.5 이상이면 화면 전체가 안개처럼 뿌옇게 번짐. 씬별 보정은 post.blendBloom()
    audioBloomBoost: 0.45,     // 저음 에너지에 따라 블룸이 추가로 커지는 정도 (0 = 오디오 리액티브 끔)
    anamorphic: { strength: 0.55, threshold: 1.1, sigma: 38, tint: [0.35, 0.62, 1.0] },
    godray: { strength: 0.0 },                       // 씬이 필요할 때 ctx.fx.godray 로 켬
    chromaticAberration: 0.22,
    vignette: { strength: 0.62, softness: 0.55 },
    grain: 0.22,
    motionBlur: { strength: 1.0, samples: 12 },      // 카메라 이동 기반 블러
  },

  // ── 품질 3단계 + 자동 조절 ─────────────────────────────────────────
  quality: {
    start: 'high',
    webglParticleCap: 100000,   // WebGPU 가 없어 WebGL2 로 폴백되면 단계와 무관하게 이 값으로 제한
    tiers: {
      high: { label: '고', particleCap: 1000000, renderScale: 1.00, maxPixelRatio: 1.5,
              dof: true,  motionBlur: true,  bloom: true, anamorphic: true,  godray: true,  ca: true,  grain: true, vignette: true, marchSteps: 96 },
      mid:  { label: '중', particleCap:  300000, renderScale: 0.85, maxPixelRatio: 1.0,
              dof: false, motionBlur: false, bloom: true, anamorphic: true,  godray: true,  ca: true,  grain: true, vignette: true, marchSteps: 64 },
      low:  { label: '저', particleCap:   50000, renderScale: 0.70, maxPixelRatio: 1.0,
              dof: false, motionBlur: false, bloom: true, anamorphic: false, godray: false, ca: false, grain: false, vignette: true, marchSteps: 40 },
    },
    auto: {
      enabled: true,
      fpsThreshold: 45,    // 평균 FPS 가 이 값 미만이
      seconds: 5,          // 이 시간(초) 이상 지속되면
      cooldown: 12,        // 한 단계 내리고, 다음 판정까지 대기(초)
    },
  },

  // ── 사운드 (0~1 선형 음량) ─────────────────────────────────────────
  audio: {
    master: 0.8,
    music: 0.75,
    sfx: 0.9,
    drone: 0.55,
    reverbSend: 0.28,
    limiter: { threshold: -6, ratio: 20, attack: 0.003, release: 0.12 },   // 갑작스러운 큰 소리 방지용 마스터 리미터
  },

  // ── 화면/자막/UI ───────────────────────────────────────────────────
  ui: {
    letterbox: false,           // 위아래 검은 띠(시네마스코프) 켜기/끄기. 런타임에서는 L 키
    subtitleHeightVh: 4.6,      // 자막 글자 크기 = 화면 높이의 % (요구 사항: 4% 이상)
    subtitleFade: 0.6,          // 자막 페이드 인/아웃 시간(초)
    cardSlide: 0.7,             // 키워드 카드 슬라이드 시간(초)
    cardDuration: 8.0,          // 키워드 카드 표시 시간(초) — 8초 뒤 슬라이드 아웃
    cursorHideMs: 3000,         // 마우스가 멈추면 커서를 숨기는 시간
    fullscreenOnStart: false,   // true 면 시작 버튼을 누를 때 자동 전체화면 (F 키로도 가능)
    showHelpOnStart: false,
  },

  // ── 안정성 ─────────────────────────────────────────────────────────
  safety: {
    maxDeltaTime: 0.05,         // 탭 복귀·프레임 드랍 시 시간이 튀지 않게 하는 프레임당 최대 dt(초)
    sceneErrorLimit: 3,         // 한 씬에서 이 횟수 이상 오류가 나면 그 씬의 연출만 끄고 다음 씬으로 진행
    renderErrorLimit: 20,       // 연속 렌더 오류가 이 횟수를 넘으면 한 단계 낮은 품질로 전환
  },
};

// 타임라인 정합성 검사 (개발 중 실수 방지)
(function validate() {
  const s = CONFIG.scenes;
  for (let i = 0; i < s.length; i++) {
    if (!(s[i].end > s[i].start)) console.warn('[CONFIG] end <= start:', s[i].id);
    if (i > 0 && s[i].start !== s[i - 1].end) console.warn('[CONFIG] 씬이 이어지지 않음:', s[i - 1].id, '→', s[i].id);
  }
  if (s[s.length - 1].end !== CONFIG.loopLength) console.warn('[CONFIG] loopLength 와 마지막 씬 end 가 다름');
})();
