// audio.js — Web Audio 실시간 합성 엔진 (외부 음원 파일 없음)
//
//  구조:  [드론/음악/효과음 버스] → (리버브 센드) → master → 리미터 → 소프트 클리퍼 → 스피커
//                                 ↘ AnalyserNode  → bass/mid/level  (오디오 리액티브: 블룸·파티클 펄스에 사용)
//  · 모든 소리는 voice 핸들을 반환하고 live 목록에 등록된다 → stopAll() 로 챕터 건너뛰기/일시정지 때 한 번에 정리.
//  · 공간음향: opts.pos 를 주면 PannerNode 로 3D 위치를 부여한다 (프로젝터 스피커는 스테레오라 equalpower 사용).
//  · 브라우저 오디오 정책: start() 는 "시작" 버튼 클릭(사용자 제스처) 안에서 호출해야 한다.

export class AudioEngine {
  constructor(cfg) {
    this.cfg = cfg;
    this.ctx = null;
    this.ready = false;
    this.muted = false;
    this.bass = 0; this.mid = 0; this.level = 0;   // 0~1 (부드럽게 평균낸 분석값)
    this.peak = 0;                                  // 최근 샘플 최대 진폭 (QA 용: 클리핑 여부 확인)
    this.live = new Set();
  }

  // ───────────────────────── 초기화 ─────────────────────────
  async start() {
    if (this.ctx) { try { await this.ctx.resume(); } catch (_) { /* 무시 */ } return this.ready; }
    try {
      const AC = window.AudioContext || window.webkitAudioContext;
      const ctx = (this.ctx = new AC({ latencyHint: 'interactive' }));
      const c = this.cfg;

      // 버스
      this.pre = ctx.createGain();
      this.master = ctx.createGain(); this.master.gain.value = c.master;
      this.limiter = ctx.createDynamicsCompressor();
      const L = c.limiter;
      this.limiter.threshold.value = L.threshold; this.limiter.ratio.value = L.ratio;
      this.limiter.attack.value = L.attack; this.limiter.release.value = L.release; this.limiter.knee.value = 0;
      this.clip = ctx.createWaveShaper(); this.clip.curve = softClipCurve(); this.clip.oversample = '2x';
      this.pre.connect(this.master); this.master.connect(this.limiter); this.limiter.connect(this.clip); this.clip.connect(ctx.destination);

      this.buses = {};
      for (const name of ['music', 'sfx', 'drone']) {
        const g = ctx.createGain(); g.gain.value = c[name]; g.connect(this.pre);
        const send = ctx.createGain(); send.gain.value = c.reverbSend; g.connect(send);
        this.buses[name] = { in: g, send };
      }

      // 리버브: 합성 임펄스 응답(3.2초)
      this.reverb = ctx.createConvolver(); this.reverb.buffer = makeImpulse(ctx, 3.2, 2.6);
      const rvOut = ctx.createGain(); rvOut.gain.value = 0.9;
      for (const b of Object.values(this.buses)) b.send.connect(this.reverb);
      this.reverb.connect(rvOut); rvOut.connect(this.pre);

      // 분석기
      this.analyser = ctx.createAnalyser(); this.analyser.fftSize = 1024; this.analyser.smoothingTimeConstant = 0.55;
      this.analyser.minDecibels = -85; this.analyser.maxDecibels = -12;   // 기본(-100~-30)보다 넓혀서 드론만 있을 때 bass 가 1 로 포화되지 않게
      this.pre.connect(this.analyser);
      this._fd = new Uint8Array(this.analyser.frequencyBinCount);
      this._td = new Float32Array(this.analyser.fftSize);

      // 공용 노이즈 버퍼 (2초, 루프)
      this.noiseBuf = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
      const d = this.noiseBuf.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;

      await ctx.resume();
      this.ready = true;
    } catch (e) {
      console.warn('[audio] 초기화 실패 — 소리 없이 계속합니다', e);
      this.ready = false;
    }
    return this.ready;
  }

  setMuted(m) {
    this.muted = m;
    if (!this.ready) return;
    const t = this.ctx.currentTime;
    this.master.gain.cancelScheduledValues(t);
    this.master.gain.setTargetAtTime(m ? 0 : this.cfg.master, t, 0.05);
  }
  toggleMute() { this.setMuted(!this.muted); return this.muted; }

  /** config 의 음량을 다시 적용 (콘솔에서 CONFIG.audio.music = 0.5 처럼 바꾼 뒤 호출 가능) */
  applyLevels() {
    if (!this.ready) return;
    const t = this.ctx.currentTime;
    if (!this.muted) this.master.gain.setTargetAtTime(this.cfg.master, t, 0.05);
    for (const n of ['music', 'sfx', 'drone']) {
      this.buses[n].in.gain.setTargetAtTime(this.cfg[n], t, 0.05);
      this.buses[n].send.gain.setTargetAtTime(this.cfg.reverbSend, t, 0.05);
    }
  }

  suspend() { if (this.ready) this.ctx.suspend().catch(() => {}); }
  resume() { if (this.ready) this.ctx.resume().catch(() => {}); }

  /** 3D 소리의 청취자 = 카메라 */
  setListener(cam) {
    if (!this.ready) return;
    const l = this.ctx.listener, e = cam.matrixWorld.elements;
    const p = cam.position;
    if (l.positionX) {
      l.positionX.value = p.x; l.positionY.value = p.y; l.positionZ.value = p.z;
      l.forwardX.value = -e[8]; l.forwardY.value = -e[9]; l.forwardZ.value = -e[10];
      l.upX.value = e[4]; l.upY.value = e[5]; l.upZ.value = e[6];
    }
  }

  /** 매 프레임: 저음/중음/전체 에너지 갱신 */
  update() {
    if (!this.ready || this.ctx.state !== 'running') { this.bass *= 0.9; this.mid *= 0.9; this.level *= 0.9; return; }
    this.analyser.getByteFrequencyData(this._fd);
    const f = this._fd, binHz = this.ctx.sampleRate / this.analyser.fftSize;
    const avg = (hz0, hz1) => {
      const a = Math.max(1, Math.floor(hz0 / binHz)), b = Math.max(a + 1, Math.ceil(hz1 / binHz));
      let s = 0; for (let i = a; i < b; i++) s += f[i]; return s / (b - a) / 255;
    };
    const bassT = avg(30, 140), midT = avg(140, 2000);
    this.bass += (bassT - this.bass) * (bassT > this.bass ? 0.55 : 0.12);   // 어택은 빠르게, 릴리즈는 느리게
    this.mid += (midT - this.mid) * (midT > this.mid ? 0.4 : 0.1);
    this.analyser.getFloatTimeDomainData(this._td);
    let pk = 0, sum = 0; for (let i = 0; i < this._td.length; i++) { const v = Math.abs(this._td[i]); if (v > pk) pk = v; sum += v * v; }
    this.peak = Math.max(pk, this.peak * 0.995);
    this.level += (Math.sqrt(sum / this._td.length) * 3 - this.level) * 0.2;
  }

  // ───────────────────────── 내부 도우미 ─────────────────────────
  _out(bus, pos) {
    // 노드 체인의 출구. pos 가 있으면 PannerNode 를 거친다.
    const dest = this.buses[bus || 'sfx'].in;
    if (!pos) return { node: dest, panner: null };
    const p = this.ctx.createPanner();
    p.panningModel = 'equalpower'; p.distanceModel = 'inverse';
    p.refDistance = pos.ref ?? 5; p.rolloffFactor = pos.rolloff ?? 0.6; p.maxDistance = 1e6;
    this._setPannerPos(p, pos);
    p.connect(dest);
    return { node: p, panner: p };
  }
  _setPannerPos(p, v) {
    const t = this.ctx.currentTime;
    if (p.positionX) { p.positionX.setValueAtTime(v.x, t); p.positionY.setValueAtTime(v.y, t); p.positionZ.setValueAtTime(v.z, t); }
  }
  _register(h) { this.live.add(h); return h; }

  /** 노드들을 fade 초 동안 줄이며 정리하는 stop 함수 생성 */
  _stopper(gain, sources, extra, h, outNode) {
    return (fade = 0.4) => {
      if (h._stopped) return; h._stopped = true;
      const t = this.ctx.currentTime;
      try {
        gain.gain.cancelScheduledValues(t);
        gain.gain.setValueAtTime(gain.gain.value, t);
        gain.gain.linearRampToValueAtTime(0.0001, t + fade);
        for (const s of sources) s.stop(t + fade + 0.05);
      } catch (_) { /* 이미 끝난 소스 */ }
      setTimeout(() => {
        for (const n of [gain, ...sources, ...extra, outNode]) { try { n && n.disconnect(); } catch (_) { /* 무시 */ } }
        this.live.delete(h);
      }, (fade + 0.2) * 1000);
    };
  }

  /** 모든 소리를 부드럽게 정리 (챕터 건너뛰기·재시작·일시정지 시) */
  stopAll(fade = 0.3) { for (const h of [...this.live]) h.stop(fade); }

  // ───────────────────────── 소리 만들기 ─────────────────────────

  /**
   * 드론/패드: 약간 어긋난(detune) 톱니파 여러 개 + 로우패스.
   * opts: {freqs:[Hz...], level, cutoff, type, detune(cent), bus, fadeIn, pos}
   * 반환: {setFreqs(freqs, glide), setCutoff(hz, glide), setLevel(v, glide), stop(fade)}
   */
  drone({ freqs = [55], level = 0.25, cutoff = 600, type = 'sawtooth', detune = 8, bus = 'drone', fadeIn = 2, pos = null } = {}) {
    if (!this.ready) return NOOP;
    const ctx = this.ctx, t = ctx.currentTime;
    const out = this._out(bus, pos);
    const gain = ctx.createGain(); gain.gain.setValueAtTime(0.0001, t); gain.gain.linearRampToValueAtTime(level, t + fadeIn);
    const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = cutoff; lp.Q.value = 0.7;
    lp.connect(gain); gain.connect(out.node);
    const oscs = [];
    freqs.forEach((f, i) => {
      for (const d of [-detune, detune]) {
        const o = ctx.createOscillator(); o.type = type; o.frequency.value = f; o.detune.value = d + i * 1.7;
        const g = ctx.createGain(); g.gain.value = 1 / (freqs.length * 2);
        o.connect(g); g.connect(lp); o.start(t); oscs.push({ o, g });
      }
    });
    const h = { _stopped: false, panner: out.panner };
    h.setFreqs = (fs, glide = 1.5) => { const now = ctx.currentTime; oscs.forEach(({ o }, i) => o.frequency.setTargetAtTime(fs[Math.floor(i / 2)] ?? fs[fs.length - 1], now, glide / 3)); };
    h.setCutoff = (hz, glide = 1) => lp.frequency.setTargetAtTime(hz, ctx.currentTime, glide / 3);
    h.setLevel = (v, glide = 1) => gain.gain.setTargetAtTime(v, ctx.currentTime, glide / 3);
    h.setPos = (v) => out.panner && this._setPannerPos(out.panner, v);
    h.stop = this._stopper(gain, oscs.map((x) => x.o), [lp, ...oscs.map((x) => x.g)], h, out.panner);
    return this._register(h);
  }

  /** 쿵! 임팩트: 사인파 피치 하강 + 노이즈 버스트. opts:{freq,level,decay,noise,bus,pos} */
  hit({ freq = 48, level = 0.9, decay = 1.6, noise = 0.55, bus = 'sfx', pos = null } = {}) {
    if (!this.ready) return NOOP;
    const ctx = this.ctx, t = ctx.currentTime;
    const out = this._out(bus, pos);
    const g = ctx.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(level, t + 0.006); g.gain.exponentialRampToValueAtTime(0.0001, t + decay);
    const o = ctx.createOscillator(); o.type = 'sine';
    o.frequency.setValueAtTime(freq * 3.2, t); o.frequency.exponentialRampToValueAtTime(freq, t + 0.12);
    o.connect(g); g.connect(out.node); o.start(t); o.stop(t + decay + 0.1);
    // 노이즈 꼬리
    const n = ctx.createBufferSource(); n.buffer = this.noiseBuf; n.loop = true;
    const nf = ctx.createBiquadFilter(); nf.type = 'lowpass'; nf.frequency.setValueAtTime(5000, t); nf.frequency.exponentialRampToValueAtTime(120, t + decay * 0.7);
    const ng = ctx.createGain(); ng.gain.setValueAtTime(level * noise, t); ng.gain.exponentialRampToValueAtTime(0.0001, t + decay * 0.8);
    n.connect(nf); nf.connect(ng); ng.connect(out.node); n.start(t); n.stop(t + decay);
    const h = { _stopped: false, stop: () => {} };
    setTimeout(() => { for (const x of [g, o, n, nf, ng, out.panner]) { try { x && x.disconnect(); } catch (_) { /* 무시 */ } } this.live.delete(h); }, (decay + 0.3) * 1000);
    return this._register(h);
  }

  /** 상승음(라이저): 밴드패스 노이즈가 from→to Hz 로 쓸려 올라가며 커짐 */
  riser({ dur = 4, from = 200, to = 5000, level = 0.35, bus = 'sfx', pos = null } = {}) {
    if (!this.ready) return NOOP;
    const ctx = this.ctx, t = ctx.currentTime;
    const out = this._out(bus, pos);
    const n = ctx.createBufferSource(); n.buffer = this.noiseBuf; n.loop = true;
    const bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.Q.value = 1.4;
    bp.frequency.setValueAtTime(from, t); bp.frequency.exponentialRampToValueAtTime(to, t + dur);
    const g = ctx.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(level, t + dur * 0.95); g.gain.linearRampToValueAtTime(0.0001, t + dur + 0.08);
    n.connect(bp); bp.connect(g); g.connect(out.node); n.start(t); n.stop(t + dur + 0.2);
    const h = { _stopped: false };
    h.stop = this._stopper(g, [n], [bp], h, out.panner);
    return this._register(h);
  }

  /** 바람/공기 소리: 느리게 흔들리는 밴드패스 노이즈. 반환: {setLevel, setCenter, stop} */
  wind({ level = 0.2, center = 500, bus = 'sfx', fadeIn = 1.5, pos = null } = {}) {
    if (!this.ready) return NOOP;
    const ctx = this.ctx, t = ctx.currentTime;
    const out = this._out(bus, pos);
    const n = ctx.createBufferSource(); n.buffer = this.noiseBuf; n.loop = true; n.playbackRate.value = 0.7;
    const bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = center; bp.Q.value = 0.8;
    const lfo = ctx.createOscillator(); lfo.frequency.value = 0.17;
    const lfoG = ctx.createGain(); lfoG.gain.value = center * 0.35; lfo.connect(lfoG); lfoG.connect(bp.frequency);
    const g = ctx.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(level, t + fadeIn);
    n.connect(bp); bp.connect(g); g.connect(out.node); n.start(t); lfo.start(t);
    const h = { _stopped: false };
    h.setLevel = (v, glide = 1) => g.gain.setTargetAtTime(v, ctx.currentTime, glide / 3);
    h.setCenter = (hz, glide = 1) => bp.frequency.setTargetAtTime(hz, ctx.currentTime, glide / 3);
    h.stop = this._stopper(g, [n, lfo], [bp, lfoG], h, out.panner);
    return this._register(h);
  }

  /** 맑은 종소리/핑 (FM): 키워드 카드 등장, 중성자 포획 같은 작은 효과음 */
  ping({ freq = 880, level = 0.25, decay = 1.2, bus = 'sfx', pos = null } = {}) {
    if (!this.ready) return NOOP;
    const ctx = this.ctx, t = ctx.currentTime;
    const out = this._out(bus, pos);
    const car = ctx.createOscillator(); car.frequency.value = freq;
    const mod = ctx.createOscillator(); mod.frequency.value = freq * 2.01;
    const mg = ctx.createGain(); mg.gain.setValueAtTime(freq * 1.5, t); mg.gain.exponentialRampToValueAtTime(1, t + decay);
    mod.connect(mg); mg.connect(car.frequency);
    const g = ctx.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(level, t + 0.005); g.gain.exponentialRampToValueAtTime(0.0001, t + decay);
    car.connect(g); g.connect(out.node); car.start(t); mod.start(t); car.stop(t + decay + 0.1); mod.stop(t + decay + 0.1);
    const h = { _stopped: false, stop: () => {} };
    setTimeout(() => { for (const x of [car, mod, mg, g, out.panner]) { try { x && x.disconnect(); } catch (_) { /* 무시 */ } } this.live.delete(h); }, (decay + 0.3) * 1000);
    return this._register(h);
  }

  /** 휘익 — 노이즈 스윕(워프·와이프 효과) */
  whoosh({ dur = 1.2, from = 300, to = 3000, level = 0.3, bus = 'sfx', pos = null } = {}) {
    return this.riser({ dur, from, to, level, bus, pos });
  }
}

const NOOP = { stop() {}, setLevel() {}, setFreqs() {}, setCutoff() {}, setCenter() {}, setPos() {} };

// ── 유틸 ──
function makeImpulse(ctx, seconds, power) {
  const len = Math.floor(ctx.sampleRate * seconds);
  const buf = ctx.createBuffer(2, len, ctx.sampleRate);
  for (let ch = 0; ch < 2; ch++) {
    const d = buf.getChannelData(ch); let lp = 0;
    for (let i = 0; i < len; i++) {
      const t = i / len;
      const a = 0.35 + 0.65 * (1 - t);                 // 시간이 갈수록 고음을 더 많이 깎음(어두운 잔향)
      lp += ((Math.random() * 2 - 1) - lp) * a;
      d[i] = lp * Math.pow(1 - t, power);
    }
  }
  return buf;
}

function softClipCurve() {
  const n = 2048, c = new Float32Array(n);
  for (let i = 0; i < n; i++) { const x = (i / (n - 1)) * 2 - 1; c[i] = Math.tanh(x * 1.2) / Math.tanh(1.2); }   // 리미터가 놓친 순간 피크를 둥글게
  return c;
}
