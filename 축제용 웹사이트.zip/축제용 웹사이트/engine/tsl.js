// engine/tsl.js — 여러 씬이 함께 쓰는 TSL(셰이더 그래프) 도우미 함수 모음
//  · fbm3      : 3D fBm 노이즈 (구름·태양 표면·코로나)
//  · hash3     : 정수 시드 → 0~1 난수 3개
//  · sphereDir : 시드 두 개 → 구 위의 균일한 방향
//  · hdrRamp   : 0~1 값 → (어두운 주황 → 노랑 → 흰색) 불꽃/태양 색 램프

import {
  Fn, float, vec3, mx_noise_float, hash, mix, sqrt, cos, sin, PI, smoothstep, clamp,
} from 'three/tsl';

const TAU = Math.PI * 2;

/** 3D fBm (4옥타브, 대략 -0.9~0.9). p: vec3 */
export const fbm3 = Fn(([p]) => {
  const a = mx_noise_float(p).mul(0.5);
  const b = mx_noise_float(p.mul(2.03).add(vec3(7.1, 3.7, 1.3))).mul(0.25);
  const c = mx_noise_float(p.mul(4.11).add(vec3(2.9, 8.3, 5.1))).mul(0.125);
  const d = mx_noise_float(p.mul(8.27).add(vec3(5.3, 1.9, 9.7))).mul(0.0625);
  return a.add(b).add(c).add(d);
});

/** 시드(float) 하나에서 서로 다른 난수 3개 */
export const hash3 = (seed) => vec3(hash(seed), hash(seed.add(17.0)), hash(seed.add(41.0)));

/** 시드 두 개(0~1) → 단위 구 위의 방향 */
export const sphereDir = (h1, h2) => {
  const cosT = h1.mul(2).sub(1);
  const sinT = sqrt(float(1).sub(cosT.mul(cosT)));
  const phi = h2.mul(TAU);
  return vec3(sinT.mul(cos(phi)), cosT, sinT.mul(sin(phi)));
};

/** 불꽃·태양 색 램프. x: 0~1 → 진한 주황 → 노랑 → 흰색 (HDR 로 쓰려면 바깥에서 곱한다) */
export const hdrRamp = (x) => {
  const t = clamp(x, 0, 1);
  const c0 = vec3(0.55, 0.08, 0.01), c1 = vec3(1.0, 0.42, 0.06), c2 = vec3(1.0, 0.82, 0.38), c3 = vec3(1.0, 0.97, 0.88);
  const a = mix(c0, c1, smoothstep(0.0, 0.35, t));
  const b = mix(a, c2, smoothstep(0.3, 0.7, t));
  return mix(b, c3, smoothstep(0.65, 1.0, t));
};

export { PI };
