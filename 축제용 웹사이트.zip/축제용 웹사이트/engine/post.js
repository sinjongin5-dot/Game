// engine/post.js — 후처리 파이프라인 (TSL)
//
//  장면(pass) ─ DOF ─ 카메라 모션블러 ─ [화면 FX: 열 왜곡·속도선·불꽃] ─ 블룸 ─ 아나모픽 줄무늬 ─ 갓레이
//            ─ 노출·톤매핑 ─ 색수차 ─ 비네트 ─ 필름 그레인 ─ 구름 베일 ─ 화이트 플래시
//
//  · scenePass 는 3개 품질 단계가 "공유"한다 → 씬 머티리얼이 한 번만 컴파일된다(로딩 시간·메모리 절약).
//    단계별로 다른 것은 scenePass 뒤의 후처리 체인뿐이며, 3개 체인을 미리 만들어 두므로 품질 전환 시 셰이더 컴파일 끊김이 없다.
//  · 모션블러는 속도 버퍼 대신 "카메라 이동량"(CameraRig.motion)으로 만든다 — 컴퓨트 파티클에도 똑같이 적용되고 MRT 가 필요 없다.
//  · 화면 FX(속도선·불꽃·열 왜곡·베일)는 전부 uniform 한 줄로 켜고 끈다. 씬이 ctx.post.u.speed.value = 0.8 처럼 제어한다.

import * as THREE from 'three/webgpu';
import {
  pass, uniform, vec2, vec3, vec4, float, int, Fn, screenUV, screenSize, smoothstep, mix, max, rand, fract, floor, abs,
  sin, exp, pow, step, length, normalize, atan, hash, mx_noise_float, renderOutput, Loop, convertToTexture, rtt,
} from 'three/tsl';
import { bloom } from 'three/addons/tsl/display/BloomNode.js';
import { dof } from 'three/addons/tsl/display/DepthOfFieldNode.js';
import { chromaticAberration } from 'three/addons/tsl/display/ChromaticAberrationNode.js';
import { gaussianBlur } from 'three/addons/tsl/display/GaussianBlurNode.js';
import { radialBlur } from 'three/addons/tsl/display/radialBlur.js';
import { hdrRamp } from './tsl.js';

export class PostStack {
  /**
   * @param renderer  THREE.WebGPURenderer
   * @param scene     THREE.Scene
   * @param camera    THREE.PerspectiveCamera
   * @param cfg       CONFIG.post
   * @param tiers     CONFIG.quality.tiers
   * @param timeU     공용 시간 uniform (ctx.u.time) — 화면 FX 의 노이즈 애니메이션에 사용
   */
  constructor(renderer, scene, camera, cfg, tiers, timeU) {
    this.renderer = renderer;
    this.cfg = cfg;
    this.tiers = tiers;

    // ── 런타임에서 값을 바꿀 수 있는 uniform 들 (씬/UI 가 ctx.post.u.xxx.value 로 접근) ──
    this.u = {
      time: timeU,
      exposure: uniform(cfg.exposure),
      flash: uniform(0),
      ca: uniform(cfg.chromaticAberration),
      vignette: uniform(cfg.vignette.strength),
      vignetteSoft: uniform(cfg.vignette.softness),
      grain: uniform(cfg.grain),
      anamorphic: uniform(cfg.anamorphic.strength),
      motion: uniform(new THREE.Vector3(0, 0, 0)),        // (dx, dy, radial) — CameraRig.motion 이 채움
      motionStrength: uniform(cfg.motionBlur.strength),
      // 피사계 심도: 초점 거리(월드 단위)·초점 폭·보케 크기 — 씬이 매 프레임 조절해 랙 포커스를 만든다
      // 기본값 = 사실상 꺼짐(초점 거리 매우 멀고 초점 폭 매우 큼). DOF 가 필요한 씬(Ch.5 매크로 등)만 값을 줄여서 쓴다.
      focus: uniform(1000), focal: uniform(1.0e6), bokeh: uniform(2.0),
      // 화면 FX (모두 0 = 꺼짐)
      heat: uniform(0),                                   // 열기 왜곡 세기 (대기권 진입)
      speed: uniform(0),                                  // 화면 가장자리 속도선 (혜성 비행)
      fire: uniform(0),                                   // 화면 가장자리 불꽃/플라즈마 (대기권 진입)
      veil: uniform(0),                                   // 구름 속 안개 베일 (0~1)
      veilColor: uniform(new THREE.Vector3(0.62, 0.66, 0.74)),
      godray: uniform(0),                                 // 갓레이 세기
      godCenter: uniform(new THREE.Vector2(0.5, 0.5)),    // 갓레이 광원의 화면 UV (씬이 태양 위치를 투영해 넣음)
      glitch: uniform(0), pixel: uniform(0), vhs: uniform(0),   // 디지털 글리치(찢김·RGB 분리·블록)·모자이크·VHS 되감기 — 피날레 해킹 연출(ui/hack.js)이 제어
      scan: uniform(-1.0),                                // 홀로그램 스캔 라인의 화면 세로 위치(0~1, <0 이면 꺼짐) — 챕터 5 단계 전환용
    };

    this.bloomScale = 1;      // 현재 블룸 배수 (씬이 blendBloom 으로 가중 평균을 넣는다. 아무도 안 넣으면 1)
    this._bAcc = 0; this._bW = 0;
    this.zoomRadial = 0;      // 씬이 "줌" 연출(카메라는 가만히, 장면 크기만 변화)을 할 때 방사형 블러를 직접 지정 (모션블러 높음 단계에서 적용)
    this.flashLevel = 0;      // 감쇠하는 플래시(펄스)
    this.flashHold = 0;       // 씬이 직접 유지하는 플래시(예: 루프 경계 화이트)

    // ── 공유 scenePass ──
    this.scenePass = pass(scene, camera);
    this.color = this.scenePass.getTextureNode('output');
    this.viewZ = this.scenePass.getViewZNode();

    // ── 단계별 체인 미리 생성 ──
    this.pipelines = {};
    this.bloomNodes = {};
    for (const name of Object.keys(tiers)) this._build(name);
    this.tierName = null;
    this.current = null;
  }

  _build(name) {
    const t = this.tiers[name], c = this.cfg, u = this.u;
    let n = this.color;

    if (t.dof) n = dof(n, this.viewZ, u.focus, u.focal, u.bokeh);
    if (t.motionBlur) n = this._motionBlur(n, c.motionBlur.samples);
    n = this._screenFx(n);

    // HDR 합성: 원본 + 블룸 + 아나모픽 줄무늬 + 갓레이
    const src = convertToTexture(n);
    let hdr = src;
    if (t.bloom) {
      const b = bloom(src, c.bloom.strength, c.bloom.radius, c.bloom.threshold);
      this.bloomNodes[name] = b;
      hdr = hdr.add(b);
    }
    if (t.anamorphic) {
      // 밝은 부분만 뽑아 가로로 길게 번지게 → 영화 렌즈의 푸른 줄무늬
      const a = c.anamorphic;
      const bright = convertToTexture(vec4(max(src.rgb.sub(a.threshold), 0), 1));
      const streak = gaussianBlur(bright, vec2(1, 0), a.sigma, { resolutionScale: 0.25 });
      hdr = hdr.add(streak.rgb.mul(vec3(...a.tint)).mul(u.anamorphic).mul(2.0));
    }
    if (t.godray) {
      // 광원(태양)에서 방사형으로 번지는 빛줄기: 밝은 부분만 1/4 해상도로 뽑아 방사형 블러
      const bright = rtt(vec4(max(src.rgb.sub(1.6), 0), 1), null, null, { resolutionScale: 0.25 });
      const rays = radialBlur(bright, { center: u.godCenter, count: int(24), weight: float(0.9), decay: float(0.935), exposure: float(1.0) });
      // radialBlur 결과 = 0.5*블러 + 원본 → 원본(bright)을 빼서 "빛줄기 성분"만 더한다
      hdr = hdr.add(rays.rgb.sub(bright.rgb).mul(u.godray));
    }

    // 노출 → 톤매핑(ACES) → sRGB. (post 쪽에서 직접 하므로 pipeline.outputColorTransform = false)
    let ldr = renderOutput(vec4(hdr.rgb.mul(u.exposure), 1), THREE.ACESFilmicToneMapping, THREE.SRGBColorSpace);

    // 중심점을 명시해야 한다 (r186 에서 center=null 이면 TSL 빌드 오류가 난다)
    if (t.ca) ldr = chromaticAberration(ldr, u.ca, vec2(0.5, 0.5));

    // 비네트 + 필름 그레인 + 구름 베일 + 화이트 플래시 (디스플레이 공간에서)
    const finish = Fn(() => {
      let rgb = ldr.rgb;
      if (t.vignette) {
        const d = screenUV.sub(0.5).length().mul(1.4142);
        const v = smoothstep(float(1).sub(u.vignetteSoft), float(1.0), d);
        rgb = rgb.mul(float(1).sub(v.mul(u.vignette)));
      }
      if (t.grain) {
        const g = rand(fract(screenUV.add(fract(u.time.mul(0.713))))).sub(0.5);
        rgb = rgb.add(g.mul(u.grain).mul(0.11));          // 평균 0 인 미세 노이즈(밝기 변화 없음)
      }
      // 구름 베일: 구름 속을 통과할 때 흐르는 안개처럼 화면을 덮는다
      const vn = mx_noise_float(vec3(screenUV.mul(vec2(3.0, 2.0)), u.time.mul(0.35))).mul(0.5).add(0.5);
      rgb = mix(rgb, u.veilColor, u.veil.mul(vn.mul(0.35).add(0.65)).clamp(0, 1));
      rgb = mix(rgb, vec3(1, 1, 1), u.flash);
      return vec4(rgb, 1);
    });

    const pipeline = new THREE.RenderPipeline(this.renderer, finish());
    pipeline.outputColorTransform = false;
    this.pipelines[name] = pipeline;
  }

  /** 카메라 이동 기반 모션블러: 화면 평행 이동(dx,dy) + 방사형(radial) 을 한 노드로 */
  _motionBlur(input, samples) {
    const tex = convertToTexture(input);
    const mo = this.u.motion, k = this.u.motionStrength;
    const N = samples;
    return Fn(() => {
      const acc = vec4(0).toVar();
      Loop({ start: int(0), end: int(N), type: 'int', condition: '<' }, ({ i }) => {
        const s = float(i).div(N - 1).sub(0.5);                         // -0.5 ~ +0.5 (셔터 180° 근사)
        const off = vec2(mo.x, mo.y).mul(s).add(screenUV.sub(0.5).mul(mo.z).mul(s)).mul(k);
        acc.addAssign(tex.sample(screenUV.add(off)));
      });
      return acc.div(N);
    })();
  }

  /**
   * 화면 FX 한 덩어리: 열기 왜곡(heat) → 속도선(speed) → 불꽃(fire).
   * 모두 "화면 가장자리 중심"으로 동작해서 화면 가운데 피사체는 가리지 않는다. 값이 0 이면 결과는 입력과 동일.
   */
  _screenFx(input) {
    const u = this.u;
    const tex = convertToTexture(input);
    const asp = screenSize.x.div(screenSize.y);
    return Fn(() => {
      const p = screenUV.sub(0.5).mul(vec2(asp, 1.0));         // 화면 중심 기준, 종횡비 보정(세로 -0.5~0.5)
      const r = length(p);
      const dir = p.div(max(r, 0.001));                        // 방향(각도 이음매가 없도록 노이즈 좌표로 사용)

      // ① 열기 왜곡: 가장자리일수록 강하게 출렁이는 굴절
      const nx = mx_noise_float(vec3(p.mul(7.0), u.time.mul(1.7)));
      const ny = mx_noise_float(vec3(p.mul(7.0).add(5.2), u.time.mul(1.5).add(3.1)));
      const edge = smoothstep(0.1, 0.8, r).mul(0.8).add(0.2);
      const duv = screenUV.add(vec2(nx, ny).mul(u.heat).mul(edge).mul(0.035));
      const base = tex.sample(duv);

      // ② 속도선: 각도를 90개 칸으로 나눠 칸마다 길이·굵기·깜빡임이 다른 방사형 선
      const a = atan(p.y, p.x).mul(150.0 / (2.0 * Math.PI));
      const id = floor(a), f = fract(a);
      const h1 = hash(id), h2 = hash(id.add(31.0));
      const core = smoothstep(float(0.03).add(h2.mul(0.06)), 0.0, abs(f.sub(0.5)));
      const rad = smoothstep(float(0.34).add(h1.mul(0.24)), 0.85, r);
      const flick = sin(u.time.mul(h1.mul(10.0).add(16.0)).add(h1.mul(40.0))).mul(0.5).add(0.5);
      const lines = vec3(0.78, 0.9, 1.0).mul(core.mul(rad).mul(flick).mul(u.speed).mul(1.1));

      // ③ 불꽃/플라즈마: 가장자리에서 화면 중심 쪽으로 번져 오는 화염
      const q1 = vec3(dir.mul(2.4), r.mul(3.6).sub(u.time.mul(4.2)));
      const q2 = vec3(dir.mul(5.5).add(3.3), r.mul(7.5).sub(u.time.mul(7.5)));
      // 중심(r<0.3)은 비워 두고 가장자리에서만 타오른다
      const dens = r.sub(0.3).mul(2.0).add(mx_noise_float(q1).mul(0.34)).add(mx_noise_float(q2).mul(0.15));
      const fm = smoothstep(0.02, 0.95, dens).mul(u.fire);
      const fireCol = hdrRamp(fm.mul(0.42).add(0.06)).mul(fm.mul(2.4));      // 주황~붉은 불꽃(블룸이 중심부를 노랗게 달군다)

      // ④ 홀로그램 스캔 라인: 가로 띠가 위에서 아래로 쓸고 지나가며 청록 가는 줄무늬를 남긴다
      const sy = screenUV.y.sub(u.scan);
      const band = exp(pow(sy.div(0.035), 2.0).negate()).mul(step(0.0, u.scan));
      const fine = sin(screenUV.y.mul(520.0).add(u.time.mul(8.0))).mul(0.5).add(0.5);
      const scanCol = vec3(0.25, 0.9, 1.0).mul(band.mul(1.4).add(exp(pow(sy.div(0.16), 2.0).negate()).mul(fine).mul(0.22)).mul(step(0.0, u.scan)));

      // ⑤ 글리치/VHS: 가로 띠 찢김 + RGB 분리 + 모자이크 + 랜덤 블록 반전 + VHS 트래킹 띠·잡음 (모두 0 이면 ①~④ 결과와 동일)
      const tN = floor(u.time.mul(14.0));
      const gband = floor(screenUV.y.mul(30.0));
      const tearOn = step(float(1.0).sub(u.glitch.mul(0.6)), hash(gband.add(tN.mul(7.13))));
      const tear = hash(gband.add(tN.mul(3.7)).add(11.0)).sub(0.5).mul(0.2).mul(tearOn).mul(step(0.001, u.glitch));
      const vb = fract(u.time.mul(0.31)), vband = smoothstep(0.1, 0.0, abs(screenUV.y.sub(vb))).mul(u.vhs);
      const vtear = sin(screenUV.y.mul(120.0).add(u.time.mul(40.0))).mul(0.018).add(mx_noise_float(vec3(screenUV.y.mul(40.0), u.time.mul(9.0), 1.0)).mul(0.03)).mul(vband);
      const jit = hash(tN.add(3.0)).sub(0.5).mul(0.004).mul(u.vhs);
      const cells = mix(float(2400.0), float(34.0), u.pixel);
      const uvm = mix(duv, floor(duv.mul(cells)).add(0.5).div(cells), step(0.01, u.pixel));
      const off = vec2(u.glitch.mul(0.013).add(u.vhs.mul(0.006)).add(vband.mul(0.012)), 0.0);
      const uvg = uvm.add(vec2(tear.add(vtear).add(jit), 0.0));
      const gr = tex.sample(uvg.add(off)).r, gg = tex.sample(uvg).g, gb = tex.sample(uvg.sub(off)).b;
      let col = vec3(gr, gg, gb);
      const blk = step(float(0.992).sub(u.glitch.mul(0.05)), rand(floor(screenUV.mul(vec2(16.0, 9.0))).add(vec2(tN.mul(5.3), 77.0)).div(40.0))).mul(step(0.001, u.glitch));
      col = mix(col, vec3(col.b, col.r, col.g).mul(1.6).add(vec3(0.0, 0.25, 0.4)), blk.mul(0.9));          // 블록 단위 색 뒤틀림
      const snow = rand(screenUV.mul(vec2(1.0, 1.0)).add(vec2(u.time.mul(0.173), u.time.mul(0.291)))).sub(0.5).mul(u.vhs).mul(0.22);
      col = col.add(vec3(snow, snow, snow)).add(vec3(1.0, 1.0, 1.0).mul(vband).mul(0.08));
      col = mix(col, vec3(col.r, col.g, col.b).mul(vec3(0.9, 1.05, 1.15)), u.vhs.mul(0.5));
      const useG = step(0.001, u.glitch.add(u.pixel).add(u.vhs));
      const baseRgb = mix(base.rgb, col, useG);

      return vec4(baseRgb.add(lines).add(fireCol).add(scanCol), 1.0);
    })();
  }

  /** 품질 단계 전환 (체인은 이미 준비돼 있어 끊김 없음) */
  setTier(name) {
    this.tierName = name;
    this.current = this.pipelines[name];
    this.scenePass.setResolutionScale(this.tiers[name].renderScale);
  }

  /** 로딩 중 호출: 모든 단계의 체인을 한 번씩 그려 셰이더를 미리 컴파일 */
  async warm() {
    const keep = this.tierName;
    for (const name of Object.keys(this.pipelines)) {
      try { this.setTier(name); this.pipelines[name].render(); } catch (e) { console.warn('[post] warm 실패', name, e); }
      await new Promise((r) => setTimeout(r, 0));
    }
    if (keep) this.setTier(keep);
  }

  /** 씬별 블룸 배수를 겹침 구간의 가중치로 섞어서 쓴다. 씬 update() 에서 매 프레임 호출: this.post.blendBloom(2.4, this.weight) */
  blendBloom(v, w) { this._bAcc += v * w; this._bW += w; }

  /** 하얀 섬광: peak(0~1)에서 시작해 초당 decay 비율로 사라짐 */
  flashPulse(peak = 1, decay = 3.0) { this.flashLevel = Math.max(this.flashLevel, peak); this._flashDecay = decay; }
  /** 하얀 화면을 직접 유지(0~1) — 예: 루프 경계, 와이프 */
  setFlash(v) { this.flashHold = v; }

  /** 모든 화면 FX 를 끈다 (챕터 건너뛰기·루프 시 이전 씬의 효과가 남지 않게) */
  resetFx() {
    const u = this.u;
    u.heat.value = 0; u.speed.value = 0; u.fire.value = 0; u.veil.value = 0; u.godray.value = 0; u.scan.value = -1; u.glitch.value = 0; u.pixel.value = 0; u.vhs.value = 0; this.zoomRadial = 0;
    u.anamorphic.value = this.cfg.anamorphic.strength; u.exposure.value = this.cfg.exposure;
    this.flashLevel = 0; this.flashHold = 0; this.bloomScale = 1;
  }

  /** 매 프레임: 플래시 감쇠, 모션블러 입력, 오디오 리액티브 블룸 */
  update(dtReal, camRig, audio) {
    this.flashLevel = Math.max(0, this.flashLevel - this.flashLevel * (this._flashDecay || 3) * dtReal - 0.002);
    this.u.flash.value = Math.min(1, Math.max(this.flashLevel, this.flashHold));

    this.bloomScale = this._bW > 0 ? this._bAcc / this._bW : 1;
    this._bAcc = 0; this._bW = 0;

    const m = camRig.motion;
    this.u.motion.value.set(m.dx, m.dy, m.radial + this.zoomRadial);

    const b = this.bloomNodes[this.tierName];
    if (b) {
      const boost = audio ? audio.bass * this.cfg.audioBloomBoost : 0;
      b.strength.value = this.cfg.bloom.strength * this.bloomScale * (1 + boost);
    }
  }

  render() { this.current.render(); }

  dispose() { for (const p of Object.values(this.pipelines)) p.dispose(); }
}
