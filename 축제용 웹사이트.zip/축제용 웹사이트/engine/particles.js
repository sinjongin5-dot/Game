// engine/particles.js — GPU 컴퓨트 파티클 필드 (WebGPU 컴퓨트 / WebGL2 폴백 겸용 한 벌의 코드)
//
//  · 위치·속도는 GPU 버퍼(instancedArray)에만 존재하고 CPU 로 읽어오지 않는다.
//  · 갱신은 TSL 컴퓨트 노드 하나. WebGPU 에서는 진짜 컴퓨트 셰이더, WebGL2 폴백에서는 Three.js 가 transform feedback 으로 자동 변환한다.
//    → 단, WebGL2 폴백에서도 돌아가도록 "각 파티클이 자기 상태 + 해석적 힘장(커브 노이즈·인력)만 참조" 하게 설계해야 한다.
//      (이웃 파티클 참조, atomics, workgroup 공유 메모리는 사용 금지)
//  · 개수는 setCount() 로 런타임에 줄일 수 있다 (품질 자동 하향 대응). 렌더 개수와 컴퓨트 개수를 같이 줄인다.
//  · 렌더링: SpriteNodeMaterial + 가산 블렌딩. 파티클 수보다 "겹침(overdraw)"이 병목이므로 size 를 작게 유지할 것.

import * as THREE from 'three/webgpu';
import {
  Fn, instancedArray, instanceIndex, vec3, float, uniform, hash, mx_noise_vec3, mix, length, smoothstep,
  exp, sqrt, cos, sin, pow, color,
} from 'three/tsl';

const TAU = Math.PI * 2;

export class ParticleField {
  /**
   * @param {object} o
   * @param {THREE.WebGPURenderer} o.renderer
   * @param {number} o.count      최대 개수 (버퍼 크기). 보통 quality.particleCap 의 일부
   * @param {number} [o.radius]   분포·구속 반경(월드 단위)
   * @param {number} [o.size]     스프라이트 크기(월드 단위)
   * @param {number} [o.colorA]   느린 입자 색
   * @param {number} [o.colorB]   빠른 입자 색
   * @param {number} [o.flow]     커브 노이즈 흐름 세기
   * @param {number} [o.bright]   HDR 밝기 배수 (블룸에 걸리려면 1 초과)
   */
  constructor({ renderer, count, radius = 8, size = 0.04, colorA = 0x22e6ff, colorB = 0xff8a1f, flow = 0.8, bright = 1.6 }) {
    this.renderer = renderer;
    this.maxCount = count;
    this.count = count;

    this.pos = instancedArray(count, 'vec3');
    this.vel = instancedArray(count, 'vec3');
    this.u = {
      dt: uniform(0.016), time: uniform(0), radius: uniform(radius), flow: uniform(flow),
      freq: uniform(0.32), size: uniform(size), bright: uniform(bright), bass: uniform(0),
    };

    // ── 초기화: 구 내부에 균일 분포 ──
    this.initNode = Fn(() => {
      const p = this.pos.element(instanceIndex);
      const v = this.vel.element(instanceIndex);
      const h1 = hash(instanceIndex), h2 = hash(instanceIndex.add(7919)), h3 = hash(instanceIndex.add(104729));
      const cosT = h1.mul(2).sub(1);
      const sinT = sqrt(float(1).sub(cosT.mul(cosT)));
      const phi = h2.mul(TAU);
      const r = pow(h3, 1 / 3).mul(this.u.radius);
      p.assign(vec3(sinT.mul(cos(phi)), cosT, sinT.mul(sin(phi))).mul(r));
      v.assign(vec3(0, 0, 0));
    })().compute(count);

    // ── 갱신: 커브 노이즈 흐름(발산 0 → 입자가 뭉치지 않고 소용돌이침) + 경계 구속 ──
    this.updateNode = Fn(() => {
      const p = this.pos.element(instanceIndex);
      const v = this.vel.element(instanceIndex);
      const q = p.mul(this.u.freq).add(vec3(0, this.u.time.mul(0.15), this.u.time.mul(0.11)));
      const e = float(0.15);
      const a0 = mx_noise_vec3(q);
      const ax = mx_noise_vec3(q.add(vec3(e, 0, 0)));
      const ay = mx_noise_vec3(q.add(vec3(0, e, 0)));
      const az = mx_noise_vec3(q.add(vec3(0, 0, e)));
      // curl A = (∂Az/∂y − ∂Ay/∂z, ∂Ax/∂z − ∂Az/∂x, ∂Ay/∂x − ∂Ax/∂y)
      const curl = vec3(
        ay.z.sub(a0.z).sub(az.y.sub(a0.y)),
        az.x.sub(a0.x).sub(ax.z.sub(a0.z)),
        ax.y.sub(a0.y).sub(ay.x.sub(a0.x)),
      ).div(e);
      const target = curl.mul(this.u.flow.mul(float(1).add(this.u.bass.mul(1.2))));
      v.assign(mix(v, target, float(1).sub(exp(this.u.dt.mul(-2.5)))));
      // 반경 밖으로 나가면 안쪽으로 되돌리는 부드러운 힘
      const d = length(p);
      const pull = p.mul(smoothstep(this.u.radius.mul(0.78), this.u.radius, d).mul(-1.6));
      v.addAssign(pull.mul(this.u.dt));
      p.addAssign(v.mul(this.u.dt));
    })().compute(count);

    // ── 렌더링 ──
    const speed = length(this.vel.toAttribute());
    this.material = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
    this.material.positionNode = this.pos.toAttribute();
    this.material.scaleNode = this.u.size;
    this.material.colorNode = mix(color(colorA), color(colorB), smoothstep(0.0, 1.4, speed)).mul(this.u.bright);
    this.material.opacityNode = float(0.55);

    this.mesh = new THREE.Sprite(this.material);
    this.mesh.count = count;
    this.mesh.frustumCulled = false;       // 위치가 GPU 에서 계속 바뀌므로 바운딩 박스 컬링 금지
    this._inited = false;
  }

  /** 버퍼 초기화 (warmup 때 1회, 또는 다시 처음 상태로 되돌릴 때) */
  reset() {
    this.renderer.compute(this.initNode);
    this._inited = true;
  }

  /** 렌더·컴퓨트 개수를 함께 변경 (품질 단계 변경 대응) */
  setCount(n) {
    n = Math.max(1, Math.min(n | 0, this.maxCount));
    this.count = n;
    this.mesh.count = n;
    this.updateNode.count = n;
  }

  /** 매 프레임 (dt: 월드 dt) */
  update(dt, time, bass = 0) {
    if (!this._inited) this.reset();
    this.u.dt.value = Math.min(dt, 0.05);
    this.u.time.value = time;
    this.u.bass.value = bass;
    this.renderer.compute(this.updateNode);
  }

  dispose() {
    this.material.dispose();
    // 버퍼(StorageInstancedBufferAttribute)는 GC 와 renderer 의 리소스 정리로 해제된다
    this.mesh.removeFromParent();
  }
}
