// engine/renderer.js — WebGPU 렌더러 생성 + WebGL2 자동 폴백 + 장치 소실(device lost) 감지
//
//  순서: ① WebGPU 시도 → ② 실패하면 새 canvas 로 WebGL2 백엔드 재시도 → ③ 둘 다 실패하면 예외(main.js 가 안전 화면 처리)
//  ※ WebGPU 초기화에 실패한 canvas 는 WebGL 컨텍스트를 못 얻으므로, 재시도 때는 반드시 새 canvas 를 만든다.

import * as THREE from 'three/webgpu';

function makeCanvas(container) {
  const c = document.createElement('canvas');
  c.id = 'gl';
  container.appendChild(c);
  return c;
}

/**
 * @returns {{renderer, canvas, backend:'webgpu'|'webgl2', adapterInfo:object|null}}
 */
export async function createRenderer({ container, forceWebGL = false, gpuTime = false, onLost = () => {} }) {
  const attempts = forceWebGL ? [true] : [false, true];
  let lastErr = null;

  for (const fw of attempts) {
    const canvas = makeCanvas(container);
    let renderer = null;
    try {
      renderer = new THREE.WebGPURenderer({
        canvas,
        antialias: false,                // 안티앨리어싱은 후처리/렌더 스케일로 대체 (성능)
        alpha: false,
        powerPreference: 'high-performance',   // 듀얼 GPU 노트북에서 외장 GPU 우선
        forceWebGL: fw,
        trackTimestamp: gpuTime && !fw,   // ?gputime=1 : GPU 실제 소요 시간 측정(WebGPU 전용, 디버그용)
      });
      await renderer.init();

      const isGPU = renderer.backend.isWebGPUBackend === true;
      renderer.toneMapping = THREE.NoToneMapping;   // 톤매핑은 post.js 파이프라인에서 직접 적용
      renderer.setClearColor(0x000000, 1);

      // ── 장치 소실 감지 ──
      // WebGPU: three 가 device.lost 를 받아 renderer.onDeviceLost 를 호출 → 우리 콜백으로 교체
      renderer.onDeviceLost = (info) => {
        renderer._isDeviceLost = true;               // compute()/render() 가 더 이상 GPU 를 건드리지 않게
        onLost({ api: isGPU ? 'WebGPU' : 'WebGL2', info });
      };
      // WebGL2: 컨텍스트 소실 이벤트
      canvas.addEventListener('webglcontextlost', (e) => { e.preventDefault(); onLost({ api: 'WebGL2', info: { message: 'webglcontextlost' } }); });

      let adapterInfo = null;
      try { adapterInfo = renderer.backend.adapter?.info ? { ...renderer.backend.adapter.info } : null; } catch (_) { /* 무시 */ }

      return { renderer, canvas, backend: isGPU ? 'webgpu' : 'webgl2', adapterInfo };
    } catch (e) {
      lastErr = e;
      console.warn(`[renderer] ${fw ? 'WebGL2' : 'WebGPU'} 초기화 실패 →`, e);
      try { renderer?.dispose(); } catch (_) { /* 무시 */ }
      canvas.remove();
    }
  }
  throw lastErr || new Error('렌더러를 만들 수 없습니다');
}

/** 창 크기/DPR 변경 대응 */
export function resizeRenderer(renderer, camera, maxPixelRatio) {
  const w = Math.max(2, window.innerWidth);
  const h = Math.max(2, window.innerHeight);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, maxPixelRatio));
  renderer.setSize(w, h, false);          // 캔버스 CSS 크기는 style.css 가 100% 로 관리
  camera.aspect = w / h;
  camera.updateProjectionMatrix();
}
