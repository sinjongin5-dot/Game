// engine/ease.js — 이징·보간 유틸. 모든 카메라 이동은 ease-in-out 을 쓴다.

export const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
export const lerp = (a, b, t) => a + (b - a) * t;
export const invLerp = (a, b, v) => (b === a ? 0 : clamp((v - a) / (b - a)));

export const smoothstep = (t) => { t = clamp(t); return t * t * (3 - 2 * t); };
export const smootherstep = (t) => { t = clamp(t); return t * t * t * (t * (t * 6 - 15) + 10); };

export const easeInOutCubic = (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
export const easeInOutSine = (t) => -(Math.cos(Math.PI * t) - 1) / 2;
export const easeInOutQuart = (t) => (t < 0.5 ? 8 * t * t * t * t : 1 - Math.pow(-2 * t + 2, 4) / 2);
export const easeOutCubic = (t) => 1 - Math.pow(1 - t, 3);
export const easeInCubic = (t) => t * t * t;
export const easeOutExpo = (t) => (t >= 1 ? 1 : 1 - Math.pow(2, -10 * t));
export const linear = (t) => t;

/**
 * 키프레임 곡선: keys = [[시간, 값], ...] (시간 오름차순). 구간 사이는 smoothstep 보간.
 * 예) 불릿타임 곡선: curve([[0,1],[8,1],[9.5,0.02],[13,0.02],[15,1]], t)
 */
export function curve(keys, t, ease = smoothstep) {
  if (t <= keys[0][0]) return keys[0][1];
  const last = keys[keys.length - 1];
  if (t >= last[0]) return last[1];
  for (let i = 0; i < keys.length - 1; i++) {
    const [t0, v0] = keys[i], [t1, v1] = keys[i + 1];
    if (t >= t0 && t <= t1) return lerp(v0, v1, ease((t - t0) / (t1 - t0)));
  }
  return last[1];
}

/** 겹침(오버랩) 구간 가중치용 부드러운 램프. d=0 이면 계단 함수. */
export function ramp(t, center, d) {
  if (d <= 0) return t >= center ? 1 : 0;
  return smootherstep((t - (center - d / 2)) / d);
}

/** 결정적 값 노이즈(시간의 함수) — 핸드헬드/쉐이크용. 같은 t 면 항상 같은 값. */
export function wobble(t, seed = 0) {
  return (
    Math.sin(t * 1.00 * 6.2832 + seed * 12.9898) * 0.55 +
    Math.sin(t * 2.31 * 6.2832 + seed * 78.233 + 1.7) * 0.30 +
    Math.sin(t * 5.17 * 6.2832 + seed * 37.719 + 4.2) * 0.15
  );
}

/**
 * 키프레임 값 사이를 C¹ 연속(속도가 끊기지 않는) 곡선으로 잇는다 — Catmull-Rom 형태(비균일 시간 간격 지원).
 * curve() 는 키마다 속도가 0 이 되어 "멈췄다 출발"하는 느낌이 나지만, spline() 은 카메라 거리·높이처럼 계속 흐르는 값에 적합하다.
 * keys = [[시간, 값], ...] (시간 오름차순)
 */
export function spline(keys, t) {
  const n = keys.length;
  if (t <= keys[0][0]) return keys[0][1];
  if (t >= keys[n - 1][0]) return keys[n - 1][1];
  let i = 0; while (i < n - 2 && t > keys[i + 1][0]) i++;
  const [t0, v0] = keys[i], [t1, v1] = keys[i + 1];
  const slope = (a, b) => (b[1] - a[1]) / (b[0] - a[0]);
  const m0 = i > 0 ? 0.5 * (slope(keys[i - 1], keys[i]) + slope(keys[i], keys[i + 1])) : slope(keys[i], keys[i + 1]);
  const m1 = i < n - 2 ? 0.5 * (slope(keys[i], keys[i + 1]) + slope(keys[i + 1], keys[i + 2])) : slope(keys[i], keys[i + 1]);
  const h = t1 - t0, u = (t - t0) / h, u2 = u * u, u3 = u2 * u;
  return (2 * u3 - 3 * u2 + 1) * v0 + (u3 - 2 * u2 + u) * h * m0 + (-2 * u3 + 3 * u2) * v1 + (u3 - u2) * h * m1;
}
