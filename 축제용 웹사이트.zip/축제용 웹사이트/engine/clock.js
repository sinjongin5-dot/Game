// engine/clock.js — 프레임 시계. dt 상한(maxDt)으로 탭 복귀·끊김 때 타임라인이 튀는 것을 막는다.

export class Clock {
  constructor(maxDt = 0.05) {
    this.maxDt = maxDt;
    this._last = null;
    this.rawDt = 0;      // 상한 적용 전 실제 경과 시간(디버그/FPS 계산용)
  }

  /** 다음 프레임 때 dt 를 0 으로 취급하고 싶을 때(탭 복귀, 일시정지 해제 등) */
  reset() { this._last = null; }

  /** rAF 타임스탬프(ms) → 상한이 적용된 dt(초) */
  tick(nowMs) {
    if (this._last === null) { this._last = nowMs; this.rawDt = 0; return 0; }
    const raw = Math.max(0, (nowMs - this._last) / 1000);
    this._last = nowMs;
    this.rawDt = raw;
    return Math.min(raw, this.maxDt);
  }
}
