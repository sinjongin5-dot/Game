// engine/quality.js — 품질 3단계(고/중/저) + FPS 기반 자동 하향
//
//  · 평균 FPS 가 threshold(45) 미만인 상태가 seconds(5초) 이어지면 한 단계 낮춘다.
//  · 자동으로 "올리지는" 않는다(왔다갔다 방지). 올릴 때는 Q 키(수동 순환).
//  · 일시정지/탭 비활성/로딩 직후 등 측정이 왜곡되는 구간은 pause() 로 건너뛴다.

export const ORDER = ['high', 'mid', 'low'];

export class QualityManager {
  constructor(cfg, { backend, onChange }) {
    this.cfg = cfg;
    this.backend = backend;            // 'webgpu' | 'webgl2'
    this.onChange = onChange;
    this.name = cfg.start;
    this.fps = 60;                     // 부드럽게 평균낸 FPS (디버그 표시용)
    this._acc = 0; this._frames = 0;   // 1초 버킷
    this._lowSeconds = 0;
    this._cooldown = 0;
    this._paused = false;
    this.history = [];                 // 하향 기록 (디버그/README 용)
  }

  get tier() { return this.cfg.tiers[this.name]; }

  /** 현재 단계 + 백엔드 제약을 반영한 파티클 상한. 씬은 반드시 이 값으로 파티클 수를 정한다. */
  get particleCap() {
    const cap = this.tier.particleCap;
    return this.backend === 'webgpu' ? cap : Math.min(cap, this.cfg.webglParticleCap);
  }

  set(name, reason = 'manual') {
    if (!this.cfg.tiers[name] || name === this.name) return;
    const from = this.name;
    this.name = name;
    this._lowSeconds = 0; this._cooldown = this.cfg.auto.cooldown;
    this.history.push({ from, to: name, reason, at: performance.now() });
    this.onChange(name, reason);
  }

  /** Q 키: 고 → 중 → 저 → 고 */
  cycle() { this.set(ORDER[(ORDER.indexOf(this.name) + 1) % ORDER.length], 'manual'); }

  lower(reason = 'auto') {
    const i = ORDER.indexOf(this.name);
    if (i < ORDER.length - 1) this.set(ORDER[i + 1], reason);
  }

  /** 측정 일시정지(일시정지·탭 비활성·씬 대량 로딩 등) */
  pause(v) { this._paused = v; if (v) { this._acc = 0; this._frames = 0; this._lowSeconds = 0; } }

  /** 매 프레임 호출 (dtReal: 상한 적용 전의 실제 프레임 시간) */
  sample(dtReal) {
    if (this._paused || dtReal <= 0) return;
    // 0.5초 넘는 정지(탭 전환·디버거·셰이더 컴파일 끊김 등)는 "지속적인 저FPS"가 아니므로 측정에서 제외
    if (dtReal > 0.5) { this._acc = 0; this._frames = 0; return; }
    this.fps += (1 / Math.max(dtReal, 1e-4) - this.fps) * Math.min(1, dtReal * 2);   // 지수 이동 평균

    this._acc += dtReal; this._frames++;
    if (this._acc < 1) return;
    const avg = this._frames / this._acc;       // 최근 1초 평균 FPS
    this._acc = 0; this._frames = 0;

    const a = this.cfg.auto;
    if (!a.enabled) return;
    if (this._cooldown > 0) { this._cooldown -= 1; return; }
    this._lowSeconds = avg < a.fpsThreshold ? this._lowSeconds + 1 : 0;
    if (this._lowSeconds >= a.seconds) { console.warn(`[quality] ${a.seconds}초 연속 ${avg.toFixed(0)}fps → 한 단계 하향`); this.lower('auto'); }
  }
}
