// engine/camera.js — 시네마틱 카메라 리그
//  · 씬은 매 프레임 "포즈(위치·시선·FOV·롤)"를 제출(submit)하기만 한다.
//  · 리그가 겹침 구간의 두 씬 포즈를 가중치로 섞고(→ 컷 없는 매치컷), 핸드헬드·쉐이크를 얹어 실제 카메라에 적용한다.
//  · Track: 스플라인 돌리 경로(Catmull-Rom) + ease-in-out 으로 포즈를 만들어 주는 도우미.

import * as THREE from 'three/webgpu';
import { clamp, easeInOutCubic, wobble } from './ease.js';

const _m = new THREE.Matrix4();
const _up = new THREE.Vector3(0, 1, 0);
const _qa = new THREE.Quaternion();
const _qb = new THREE.Quaternion();
const _qr = new THREE.Quaternion();
const _e = new THREE.Euler();
const _v = new THREE.Vector3();
const _fwd = new THREE.Vector3();
const _right = new THREE.Vector3();
const _upv = new THREE.Vector3();
const _d = new THREE.Vector3();

export function makePose() {
  return { pos: new THREE.Vector3(0, 0, 5), look: new THREE.Vector3(), fov: 50, roll: 0, scale: 1, near: 0.05, far: 4000 };
}

/** 포즈 → 쿼터니언 (lookAt + roll) */
function poseQuat(p, out) {
  _m.lookAt(p.pos, p.look, _up);
  out.setFromRotationMatrix(_m);
  if (p.roll) { _qr.setFromAxisAngle(_fwd.set(0, 0, -1), p.roll); out.multiply(_qr); }
  return out;
}

export class CameraRig {
  constructor(camera, cfg) {
    this.camera = camera;
    this.cfg = cfg;
    this.subs = [];
    this.pose = makePose();            // 마지막으로 해석된 기본 포즈
    this.quat = new THREE.Quaternion();
    this.shakeE = 0;                   // 쉐이크 에너지 (0~2)
    this.noiseT = 0;                   // 월드 시간 기준 노이즈 시계 (슬로모션에서는 흔들림도 느려짐)
    this.motion = { dx: 0, dy: 0, radial: 0 };   // 카메라 이동 기반 모션블러용 (화면 UV 단위)
    this._prev = { quat: new THREE.Quaternion(), pos: new THREE.Vector3(), fov: 50, valid: false };
  }

  /** 프레임 시작 시 호출 — 이전 제출 포즈 비우기 */
  begin() { this.subs.length = 0; }

  /** 씬이 카메라 포즈 제출. weight 는 Director 가 겹침 구간에서 자동으로 곱해 준다. */
  submit(pose, weight = 1) { if (weight > 1e-4) this.subs.push({ pose, weight }); }

  /** 충격 쉐이크 (amount 0~1). 충돌·폭발 때 호출 */
  shake(amount = 1) { this.shakeE = Math.min(2, this.shakeE + amount); }

  /** 제출된 포즈를 합성해서 실제 카메라에 적용. dtWorld: 월드(슬로모션 적용) 시간 */
  resolve(dtWorld, dtReal) {
    const cam = this.camera;
    const hh = this.cfg.handheld, sk = this.cfg.shake;
    this.noiseT += dtWorld;

    // 1) 가중 합성
    let wsum = 0;
    for (const s of this.subs) wsum += s.weight;
    const base = this.pose;
    if (wsum > 0) {
      base.pos.set(0, 0, 0); base.look.set(0, 0, 0);
      let fov = 0, roll = 0, scale = 0, near = 0, far = 0, acc = 0;
      for (let i = 0; i < this.subs.length; i++) {
        const { pose: p, weight: w0 } = this.subs[i];
        const w = w0 / wsum;
        base.pos.addScaledVector(p.pos, w);
        base.look.addScaledVector(p.look, w);
        fov += p.fov * w; scale += (p.scale ?? 1) * w;
        near += (p.near ?? this.cfg.near) * w; far += (p.far ?? this.cfg.far) * w;
        // 방향은 쿼터니언 slerp 로 섞는다 (시선 점을 단순 평균하면 겹침 구간에서 방향이 뒤틀릴 수 있음)
        poseQuat(p, _qb);
        if (i === 0) { _qa.copy(_qb); acc = w; }
        else { acc += w; _qa.slerp(_qb, w / acc); }
      }
      base.fov = fov; base.scale = scale; base.near = near; base.far = far; base.roll = roll;
      this.quat.copy(_qa);
    }
    // wsum === 0 이면(제출 없음) 직전 포즈 유지

    // 2) 핸드헬드 + 쉐이크 (회전 위주)
    const t = this.noiseT;
    const hRot = (hh.rotDeg * Math.PI) / 180;
    this.shakeE *= Math.exp(-dtWorld * sk.decay);
    const sAmp = (sk.maxDeg * Math.PI) / 180 * this.shakeE * this.shakeE;
    const sT = t * sk.freq;
    _e.set(
      wobble(t * 0.8, 1) * hRot + wobble(sT, 11) * sAmp,
      wobble(t * 0.7, 2) * hRot + wobble(sT * 1.13, 12) * sAmp,
      wobble(t * 0.5, 3) * hRot * 0.6 + wobble(sT * 0.87, 13) * sAmp * 0.8,
    );
    _qr.setFromEuler(_e);
    cam.quaternion.copy(this.quat).multiply(_qr);

    const pAmp = hh.posAmp * base.scale + 0.0025 * sk.maxDeg * this.shakeE * this.shakeE * base.scale;
    cam.position.copy(base.pos);
    cam.position.x += wobble(t * 0.6, 21) * pAmp;
    cam.position.y += wobble(t * 0.5, 22) * pAmp;
    cam.position.z += wobble(t * 0.4, 23) * pAmp;

    if (cam.fov !== base.fov || cam.near !== base.near || cam.far !== base.far) {
      cam.fov = base.fov; cam.near = base.near; cam.far = base.far;
      cam.updateProjectionMatrix();
    }
    cam.updateMatrixWorld();

    // 3) 모션블러 입력 계산: 직전 프레임 대비 회전(→평행 이동)·전진/FOV 변화(→방사형)
    const mo = this.motion;
    if (this._prev.valid && dtReal > 1e-4) {
      // 화면 UV 단위의 이동량 ≈ 각도 변화 / FOV
      _fwd.set(0, 0, -1).applyQuaternion(this._prev.quat);
      _v.set(0, 0, -1).applyQuaternion(cam.quaternion);
      _right.set(1, 0, 0).applyQuaternion(cam.quaternion);
      _upv.set(0, 1, 0).applyQuaternion(cam.quaternion);
      _d.copy(_v).sub(_fwd);                                  // 시선 벡터의 프레임 간 변화
      const vfov = (cam.fov * Math.PI) / 180;
      const hfov = 2 * Math.atan(Math.tan(vfov / 2) * cam.aspect);
      const dx = _d.dot(_right) / (2 * Math.tan(hfov / 2));   // 화면 UV 단위 이동량
      const dy = _d.dot(_upv) / (2 * Math.tan(vfov / 2));
      const fovRate = (cam.fov - this._prev.fov) / Math.max(cam.fov, 1);
      // 카메라가 시선 방향으로 빠르게 전진할수록 방사형 블러 (씬 스케일 대비 이동량)
      _d.copy(cam.position).sub(this._prev.pos);
      const fwdMove = _v.dot(_d) / Math.max(base.scale, 1e-3);
      // 값은 "한 프레임 동안의 이동량" — 슬로모션(dtWorld≈0)에서는 이동도 작아져 자연히 블러가 줄어든다
      mo.dx = clamp(-dx, -0.05, 0.05);
      mo.dy = clamp(-dy, -0.05, 0.05);
      mo.radial = clamp(-fovRate + fwdMove * 0.15, -0.12, 0.12);
    } else { mo.dx = mo.dy = mo.radial = 0; }
    this._prev.quat.copy(cam.quaternion); this._prev.pos.copy(cam.position); this._prev.fov = cam.fov; this._prev.valid = true;
  }

  /** 씬 전환·시크 직후 모션블러가 튀지 않게 */
  resetMotion() { this._prev.valid = false; this.motion.dx = this.motion.dy = this.motion.radial = 0; }
}

/**
 * Track — 스플라인 돌리 경로.
 *   pos : [[x,y,z], ...] 카메라 위치 제어점 (Catmull-Rom 곡선)
 *   look: [[x,y,z], ...] 바라보는 점 제어점 (1개면 고정)
 *   fov : [시작, 끝] 또는 [[u,fov], ...]
 *   ease: u(0~1) 에 적용할 이징 (기본 ease-in-out cubic)
 * 사용: const track = new Track({...});  pose = track.at(진행도 0~1)
 */
export class Track {
  constructor({ pos, look = [[0, 0, 0]], fov = [50, 50], roll = [0, 0], ease = easeInOutCubic, scale = 1, near, far }) {
    const mk = (pts) => (pts.length === 1 ? null : new THREE.CatmullRomCurve3(pts.map((p) => new THREE.Vector3(...p)), false, 'centripetal'));
    this.posCurve = mk(pos); this.posFixed = new THREE.Vector3(...pos[0]);
    this.lookCurve = mk(look); this.lookFixed = new THREE.Vector3(...look[0]);
    this.fov = fov; this.roll = roll; this.ease = ease; this.scale = scale; this.near = near; this.far = far;
    this.out = makePose();
  }

  at(u) {
    u = clamp(u);
    const e = this.ease(u);
    const o = this.out;
    if (this.posCurve) this.posCurve.getPoint(e, o.pos); else o.pos.copy(this.posFixed);
    if (this.lookCurve) this.lookCurve.getPoint(e, o.look); else o.look.copy(this.lookFixed);
    o.fov = Array.isArray(this.fov[0]) ? sampleKeys(this.fov, e) : this.fov[0] + (this.fov[1] - this.fov[0]) * e;
    o.roll = this.roll[0] + (this.roll[1] - this.roll[0]) * e;
    o.scale = this.scale;
    if (this.near !== undefined) o.near = this.near;
    if (this.far !== undefined) o.far = this.far;
    return o;
  }
}

function sampleKeys(keys, u) {
  if (u <= keys[0][0]) return keys[0][1];
  for (let i = 0; i < keys.length - 1; i++) {
    const [u0, v0] = keys[i], [u1, v1] = keys[i + 1];
    if (u <= u1) { const t = (u - u0) / (u1 - u0); const s = t * t * (3 - 2 * t); return v0 + (v1 - v0) * s; }
  }
  return keys[keys.length - 1][1];
}
