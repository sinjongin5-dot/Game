// main.js — 부팅·메인 루프·키보드·안전장치
//
//  흐름: 렌더러(WebGPU→WebGL2 폴백) → 폰트 → 후처리/카메라/품질 → 씬 로드+웜업(셰이더 미리 컴파일) → 시작 버튼 → 자동 투어(무한 반복)
//
//  URL 파라미터(점검·시연 준비용):
//    ?autostart=1   시작 버튼 없이 바로 재생(소리는 첫 키/클릭 후)   ?t=95      95초 지점부터   ?pause=1  멈춘 채로 시작
//    ?q=high|mid|low 시작 품질   ?webgl=1  WebGL2 강제   ?nosound=1  소리 끄기   ?spike  컴퓨트 파티클 스파이크   ?debug=1  디버그 패널 표시

import * as THREE from 'three/webgpu';
import { uniform } from 'three/tsl';
import { CONFIG } from './config.js';
import { createRenderer, resizeRenderer } from './engine/renderer.js';
import { PostStack } from './engine/post.js';
import { CameraRig } from './engine/camera.js';
import { QualityManager, ORDER } from './engine/quality.js';
import { Clock } from './engine/clock.js';
import { AudioEngine } from './audio.js';
import { Director } from './timeline.js';
import { SceneBase } from './scenes/_base.js';
import { Shared } from './scenes/_shared.js';
import { Subtitles } from './ui/subtitle.js';
import { KeywordCards } from './ui/keywordCard.js';
import { Hud } from './ui/hud.js';
import { Loader } from './ui/loader.js';
import { Credits, Toast, Help, DebugPanel, setLetterbox } from './ui/overlays.js';
import { HackSequence } from './ui/hack.js';
import { Gauge } from './ui/gauge.js';
import { Ruler } from './ui/ruler.js';

const params = new URLSearchParams(location.search);
const $ = (id) => document.getElementById(id);

// ───────────────────────── 로그 / 전역 오류 ─────────────────────────
const logBuf = [];
function log(level, ...args) {
  (console[level] || console.log)(...args);
  const msg = args.map((a) => (a && a.message) || (typeof a === 'string' ? a : JSON.stringify(a))).join(' ');
  logBuf.push(`${level === 'error' ? '✖' : level === 'warn' ? '▲' : '·'} ${msg}`.slice(0, 160));
  if (logBuf.length > 40) logBuf.shift();
}
window.addEventListener('error', (e) => log('error', '[window]', e.message));
window.addEventListener('unhandledrejection', (e) => log('error', '[promise]', e.reason));

// ───────────────────────── 복구 상태(장치 소실 후 자동 재시작) ─────────────────────────
let recover = null;
try { recover = JSON.parse(sessionStorage.getItem('tour-recover') || 'null'); sessionStorage.removeItem('tour-recover'); } catch (_) { /* 무시 */ }

if (params.has('spike')) {   // 컴퓨트 파티클 스파이크 모드: 씬 하나만 사용
  CONFIG.scenes = [{ id: 'spike', label: 'Compute Spike', start: 0, end: CONFIG.loopLength, overlap: 0, skip: true, module: './scenes/_spike.js' }];
}

const state = { userPaused: false, started: false, noRender: false, renderErrors: 0, recoverTried: recover?.n || 0, gpuTick: 0, gpuMs: null };
let ctx = null, director = null, post = null, renderer = null, camera = null, quality = null, audio = null;
let ui = null;

// ───────────────────────── 부팅 ─────────────────────────
async function boot() {
  const loader = new Loader();
  loader.progress(0.02, '그래픽 장치 확인 중…');

  // 1) 렌더러 (WebGPU → 실패 시 WebGL2)
  let R = null;
  try {
    R = await createRenderer({ container: $('stage'), forceWebGL: params.get('webgl') === '1' || recover?.forceWebGL, gpuTime: params.get('gputime') === '1', onLost: onDeviceLost });
    renderer = R.renderer;
  } catch (e) {
    log('error', '렌더러 생성 실패 — 안전 모드(3D 없이 자막/소리만)로 진행', e);
    state.noRender = true;
  }
  const backend = R ? R.backend : 'none';
  const gpuName = R?.adapterInfo ? [R.adapterInfo.vendor, R.adapterInfo.architecture, R.adapterInfo.description].filter(Boolean).join(' ') : '';
  loader.setInfo(`${backend.toUpperCase()}${gpuName ? ' · ' + gpuName : ''}${backend === 'webgl2' ? ' (WebGPU 미지원 → 폴백)' : ''}`);
  loader.progress(0.08, '폰트 불러오는 중…');

  // 2) 폰트: 캔버스에서 글자를 샘플링하는 연출이 있으므로 로딩이 끝난 뒤에 진행
  try {
    await Promise.race([
      Promise.all([
        document.fonts.load('700 40px Pretendard', '가나다 원자력 0123456789'),
        document.fonts.load('400 40px "Black Han Sans"', `${CONFIG.title}친환경 에너지과학으로 만드는 깨끗한 에너지 E=mc²`),
      ]),
      new Promise((r) => setTimeout(r, 4000)),
    ]);
  } catch (e) { log('warn', '폰트 로딩 실패(대체 폰트 사용)', e); }

  // 3) 핵심 시스템
  const scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(CONFIG.camera.fov, innerWidth / innerHeight, CONFIG.camera.near, CONFIG.camera.far);
  const rig = new CameraRig(camera, CONFIG.camera);
  audio = new AudioEngine(CONFIG.audio);
  const clock = new Clock(CONFIG.safety.maxDeltaTime);

  const startTier = ORDER.includes(params.get('q')) ? params.get('q') : (recover?.q || CONFIG.quality.start);
  quality = new QualityManager({ ...CONFIG.quality, start: startTier }, {
    backend,
    onChange: (name, reason) => applyQuality(name, reason),
  });

  ui = {
    hud: new Hud($('hud')),
    subtitles: new Subtitles($('subtitle'), CONFIG.scenes, CONFIG.ui),
    cards: new KeywordCards($('cards'), CONFIG.scenes, CONFIG.ui),
    credits: CONFIG.scenes.some((s) => s.id === 'credits') ? new Credits($('credits'), CONFIG) : { update() {} },
    hack: { update() {} },                                   // 후처리(post)가 만들어진 뒤 아래에서 실제 HackSequence 로 교체
    gauge: new Gauge($('gauge')),
    ruler: new Ruler($('ruler')),
    toast: new Toast($('toast')),
    help: new Help($('help')),
    debug: new DebugPanel($('debug')),
    loader,
  };
  ui.cards._onShow = () => audio.ping({ freq: 1320, level: 0.1, decay: 0.9 });   // 카드 등장음
  if (params.get('debug') === '1') ui.debug.toggle();
  setLetterbox(CONFIG.ui.letterbox);

  // ctx.u: 모든 씬/셰이더가 공유하는 uniform. time = 월드 시간(초, 불릿타임 때 느려짐) — 태양 표면 일렁임·별 반짝임 등 "절차적 애니메이션"의 시계
  ctx = { config: CONFIG, renderer, scene, camera, cam: rig, audio, quality, backend, ui, log, params, THREE, noRender: state.noRender, u: { time: uniform(0) } };

  if (!state.noRender) {
    post = new PostStack(renderer, scene, camera, CONFIG.post, CONFIG.quality.tiers, ctx.u.time);
    post.setTier(quality.name);
    resizeRenderer(renderer, camera, quality.tier.maxPixelRatio);
    ctx.post = post;
  } else {
    // 안전 모드용 더미 (Director/씬이 post 를 호출해도 죽지 않도록)
    ctx.post = { setFlash() {}, flashPulse() {}, resetFx() {}, u: {}, update() {}, render() {} };
    post = ctx.post;
  }
  try { ui.hack = new HackSequence($('hack'), CONFIG, post, audio, rig); } catch (e) { log('error', '[hack] 연출 초기화 실패 — 건너뜁니다', e); }
  loader.progress(0.15, '씬 불러오는 중…');

  // 4) 씬 로드 + 웜업 (오류가 나도 해당 씬만 비활성화하고 계속)
  const objs = {};
  const defs = CONFIG.scenes;
  for (let i = 0; i < defs.length; i++) {
    const def = defs[i];
    try {
      const mod = await import(def.module);
      objs[def.id] = new mod.default(ctx, def);
    } catch (e) {
      log('error', `[${def.id}] 로드 실패 — 빈 씬으로 대체`, e);
      objs[def.id] = new SceneBase(ctx, def); objs[def.id].failed = true;
    }
    if (!state.noRender && !objs[def.id].failed) {
      try {
        await objs[def.id].warmup();
        await warmRender(objs[def.id], scene);          // 이 씬의 머티리얼/파이프라인을 실제로 한 번 그려서 컴파일
      } catch (e) { log('error', `[${def.id}] 웜업 실패 — 이 씬은 건너뜁니다`, e); objs[def.id].failed = true; }
    }
    loader.progress(0.15 + 0.7 * ((i + 1) / defs.length), `연출 준비 중… (${i + 1}/${defs.length}) ${def.label}`);
    await new Promise((r) => setTimeout(r, 0));        // UI 갱신 여유
  }

  if (!state.noRender) {
    loader.progress(0.86, '공용 자원 셰이더 컴파일 중…');
    await warmShared(scene);
    loader.progress(0.88, '후처리 셰이더 컴파일 중…');
    await post.warm();
  }

  director = new Director(ctx, defs, objs, CONFIG.loopLength);
  if (!director.skipPoints.length) director.skipPoints.push(0);
  for (const s of director.scenes) if (s.obj.failed) s.failed = true;
  ctx.director = director;
  director.onLoop = (n) => log('info', `루프 ${n} 시작`);
  quality.pause(true);

  window.tour = { ctx, director, post, quality, audio, ui, objs, params, state, step };   // 콘솔/자동 점검용
  bindInput();
  window.addEventListener('resize', onResize);

  // 5) 시작 대기
  if (recover) loader.progress(1, '복구 중…');
  const startAt = recover ? recover.t : Number(params.get('t')) || 0;   // 복구 중이면 복구 지점(챕터 시작)이 우선
  const auto = params.get('autostart') === '1' || !!recover;
  if (!auto) await loader.ready(state.noRender ? '준비 완료 (안전 모드: 3D 없이 진행)' : '준비 완료');
  loader.progress(1);

  if (!params.has('nosound')) {
    if (auto) {
      // 자동 시작은 사용자 제스처가 없어 오디오가 막힐 수 있음 → 첫 키/클릭에서 켠다
      const unlock = async () => { window.removeEventListener('keydown', unlock); window.removeEventListener('pointerdown', unlock); if (await audio.start()) ui.toast.show('소리 켜짐'); };
      window.addEventListener('keydown', unlock); window.addEventListener('pointerdown', unlock);
      if (recover) ui.toast.show('화면 복구됨 — 소리를 켜려면 아무 키나 누르세요', 4000);
    } else await audio.start();
  }

  loader.hide();
  if (CONFIG.ui.fullscreenOnStart && !auto) document.documentElement.requestFullscreen?.().catch(() => {});
  if (startAt) director.seek(startAt);
  state.started = true;
  state.userPaused = params.get('pause') === '1' && !recover;
  if (!state.userPaused) director.play();
  quality.pause(false);
  clock.reset();

  // 6) 메인 루프
  let last = 0;
  function frame(now) {
    requestAnimationFrame(frame);
    const dt = clock.tick(now);
    last = now;
    step(dt, clock.rawDt, now);
  }
  requestAnimationFrame(frame);
  state.clock = clock;
}

/** 한 프레임 진행(점검 스크립트에서 직접 호출 가능) */
function step(dt, rawDt = dt, now = performance.now()) {
  // 1) 로직 — 오류는 Director 가 씬 단위로 격리한다. 여기서는 최후의 방어선만 둔다.
  try {
    director.update(dt);
    audio.setListener(camera);
    audio.update();
    post.update(dt, ctx.cam, audio);
    const t = director.t;
    ui.subtitles.update(t); ui.cards.update(t); ui.credits.update(t); ui.hack.update(t, rawDt); ui.hud.update(t, camera); ui.gauge.update(); ui.ruler.update();
  } catch (e) { log('error', '[frame] 로직 오류', e); }

  // 2) 렌더 — 연속 실패하면 한 단계 낮추고, 그래도 안 되면 3D 를 끄고 자막/소리만 계속
  if (!state.noRender) {
    try { post.render(); state.renderErrors = 0; }
    catch (e) {
      state.renderErrors++;
      if (state.renderErrors === 1) log('error', '[render] 오류', e);
      if (state.renderErrors >= CONFIG.safety.renderErrorLimit) {
        state.renderErrors = 0;
        if (quality.name !== 'low') quality.lower('render-error');
        else { state.noRender = true; log('error', '[render] 저품질에서도 실패 — 3D 렌더 중단(자막/소리는 계속)'); }
      }
    }
  }

  quality.sample(rawDt);
  ui.debug.update(now, debugLines);

  // ?gputime=1 : 20프레임마다 GPU 실제 소요 시간(ms)을 읽어 디버그 패널에 표시 (WebGPU 전용)
  if (params.get('gputime') === '1' && !state.noRender && ++state.gpuTick % 20 === 0) {
    Promise.all([renderer.resolveTimestampsAsync('render'), renderer.resolveTimestampsAsync('compute')])
      .then(([r, c]) => { state.gpuMs = { render: r, compute: c }; }).catch(() => {});
  }
}

/** 씬 root 를 잠시 붙여 한 번 렌더 → 머티리얼/파이프라인 컴파일 (컬링 때문에 빠지지 않도록 frustumCulled 해제) */
async function warmRender(obj, scene) {
  const saved = [];
  obj.root.traverse((o) => { saved.push([o, o.frustumCulled]); o.frustumCulled = false; });
  scene.add(obj.root);
  // 주의: rAF 대신 setTimeout 사용 — 로딩 중 탭이 백그라운드로 가도(rAF 정지) 로딩이 멈추지 않게 한다.
  try { post.render(); await new Promise((r) => setTimeout(r, 16)); post.render(); }
  finally { scene.remove(obj.root); for (const [o, f] of saved) o.frustumCulled = f; }
}

/** 공유 자원(별·태양·지구·도시·오로라 …)은 씬이 start() 에서 붙일 때야 장면에 들어가므로, 로딩 중에 한꺼번에 붙여 한 번 그려 컴파일해 둔다
 *  (안 하면 처음 그 장면이 나올 때 셰이더 컴파일로 수 초 멈출 수 있다) */
async function warmShared(scene) {
  const keys = Shared.keys(), saved = [];
  for (const k of keys) {
    try { const o = Shared.acquire(ctx, k); o.root.traverse((n) => { saved.push([n, n.frustumCulled]); n.frustumCulled = false; }); } catch (e) { log('warn', `공유 자원 웜업 실패: ${k}`, e); }
  }
  try { post.render(); await new Promise((r) => setTimeout(r, 16)); post.render(); }
  catch (e) { log('warn', '공유 자원 웜업 렌더 실패', e); }
  finally { for (const k of keys) Shared.release(ctx, k); for (const [n, f] of saved) n.frustumCulled = f; }
}

// ───────────────────────── 품질 / 리사이즈 ─────────────────────────
function applyQuality(name, reason) {
  if (!post || state.noRender) return;
  post.setTier(name);
  resizeRenderer(renderer, camera, quality.tier.maxPixelRatio);
  if (director) for (const s of director.scenes) { try { s.obj.onQuality?.(name); } catch (e) { log('error', 'onQuality', e); } }
  ui?.toast.show(`품질: ${quality.tier.label}${reason === 'auto' ? ' (자동 조절)' : reason === 'render-error' ? ' (오류 대응)' : ''}`);
  log('info', `품질 → ${name} (${reason})`);
}

let resizeTimer = 0;
function onResize() {
  // 전체화면 전환·창 크기 조절 중 이벤트가 연달아 오므로 80ms 디바운스 (rAF 가 아닌 setTimeout — 백그라운드에서도 동작)
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(() => { if (renderer) resizeRenderer(renderer, camera, quality.tier.maxPixelRatio); }, 80);
}

// ───────────────────────── 장치 소실 복구 ─────────────────────────
// GPU 장치/컨텍스트를 잃으면 페이지를 새로 불러오되, 현재 챕터 시작 시각·한 단계 낮은 품질로 자동 재시작한다.
// (소리는 브라우저 정책상 첫 키/클릭 후 다시 켜진다)
let lostHandled = false;
function onDeviceLost({ api, info }) {
  if (lostHandled) return;          // WebGPU/WebGL 이벤트가 겹쳐 두 번 들어와도 한 번만 처리
  lostHandled = true;
  log('error', `GPU 장치 소실(${api}) — 자동 복구 시도`, info?.message || '');
  const n = state.recoverTried + 1;
  if (n > 3) { ui?.toast.show('그래픽 오류가 반복됩니다. 브라우저를 재시작해 주세요', 8000); return; }
  const t = director ? director.skipPoints[director.chapterIndex] : 0;
  const q = quality ? ORDER[Math.min(ORDER.indexOf(quality.name) + 1, ORDER.length - 1)] : 'mid';
  try { sessionStorage.setItem('tour-recover', JSON.stringify({ t, q, n, forceWebGL: n >= 2 })); } catch (_) { /* 무시 */ }
  setTimeout(() => location.reload(), 800);
}

// ───────────────────────── 입력 ─────────────────────────
function bindInput() {
  let cursorT = 0;
  const showCursor = () => { document.body.classList.remove('hide-cursor'); clearTimeout(cursorT); cursorT = setTimeout(() => document.body.classList.add('hide-cursor'), CONFIG.ui.cursorHideMs); };
  window.addEventListener('mousemove', showCursor); showCursor();

  document.addEventListener('visibilitychange', () => {
    if (!director) return;
    if (document.hidden) { director.pause(); audio.suspend(); quality.pause(true); }
    else { state.clock?.reset(); if (!state.userPaused && state.started) { director.play(); audio.resume(); } quality.pause(false); }
  });

  window.addEventListener('keydown', (e) => {
    if (!state.started || e.ctrlKey || e.metaKey || e.altKey) return;
    const chapterName = () => { const s = director.scenes.find((x) => x.def.start === director.skipPoints[director.chapterIndex]); return s ? s.def.label : ''; };
    switch (e.code) {
      case 'Space': e.preventDefault(); state.userPaused = !state.userPaused;
        if (state.userPaused) { director.pause(); audio.suspend(); } else { director.play(); audio.resume(); state.clock?.reset(); }
        ui.toast.show(state.userPaused ? '일시정지' : '재생'); break;
      case 'ArrowRight': e.preventDefault(); director.nextChapter(); ui.toast.show(`▶ ${chapterName()}`); break;
      case 'ArrowLeft': e.preventDefault(); director.prevChapter(); ui.toast.show(`◀ ${chapterName()}`); break;
      case 'KeyF': if (document.fullscreenElement) document.exitFullscreen(); else document.documentElement.requestFullscreen?.().catch(() => {}); break;
      case 'KeyM': ui.toast.show(audio.toggleMute() ? '음소거' : '소리 켜짐'); break;
      case 'KeyR': director.restart(); ui.toast.show('처음부터'); break;
      case 'KeyQ': quality.cycle(); break;
      case 'KeyL': { const on = !document.body.classList.contains('has-letterbox'); setLetterbox(on); ui.toast.show(`레터박스 ${on ? '켜짐' : '꺼짐'}`); break; }
      case 'KeyH': ui.help.toggle(); break;
      case 'KeyD': ui.debug.toggle(); break;
      default: break;
    }
  });
}

function debugLines() {
  const info = renderer?.info;
  const d = director;
  return [
    `FPS ${quality.fps.toFixed(1)}  tier ${quality.name}  backend ${ctx.backend}  render ${state.noRender ? 'OFF' : 'on'}${state.userPaused ? '  [PAUSED]' : ''}`,
    `t ${d.t.toFixed(2)} / ${d.total}   loop ${d.loopCount}   timeScale ×${d.timeScale.toFixed(3)}   chapter ${d.chapterIndex}`,
    `active: ${d.activeInfo}`,
    `particleCap ${quality.particleCap.toLocaleString()}   pixelRatio ${renderer?.getPixelRatio?.().toFixed(2) ?? '-'}   renderScale ${quality.tier.renderScale}`,
    info ? `geometries ${info.memory.geometries}  textures ${info.memory.textures}  calls ${info.render.calls}  computeCalls ${info.compute?.calls ?? '-'}` : '',
    state.gpuMs ? `GPU time  render ${Number(state.gpuMs.render).toFixed(2)} ms   compute ${Number(state.gpuMs.compute).toFixed(2)} ms` : '',
    `audio ${audio.ready ? audio.ctx.state : 'off'}${audio.muted ? ' (muted)' : ''}  bass ${audio.bass.toFixed(2)}  level ${audio.level.toFixed(2)}  peak ${audio.peak.toFixed(2)}  voices ${audio.live.size}`,
    `failed scenes: ${d.scenes.filter((s) => s.failed).map((s) => s.def.id).join(', ') || '-'}`,
    ...logBuf.slice(-6),
  ].filter(Boolean);
}

boot().catch((e) => {
  log('error', '부팅 실패', e);
  const l = $('loadlabel'); if (l) l.textContent = '오류가 발생했습니다. 콘솔(F12)을 확인하세요: ' + (e && e.message);
});
