# 친환경 에너지, 원자력 — 태양에서 원자핵까지

학교 축제 시연용 자동 투어 웹사이트 (Three.js r186 WebGPU/TSL, WebGL2 자동 폴백).
> 현재 **2단계(공통 엔진)** 까지 구현되어 있고, 각 씬은 자리표시자(빈 씬)입니다. 정식 README 는 7단계에서 완성합니다.

## 실행

```bash
node serve.js
```

그다음 크롬에서 `http://localhost:8123` 을 엽니다. (Windows 는 `start.bat` 더블클릭)
`index.html` 을 직접 더블클릭(file://)하면 ES 모듈이 막혀 동작하지 않습니다.

## 키보드

| 키 | 동작 | 키 | 동작 |
|---|---|---|---|
| Space | 일시정지/재생 | Q | 품질 고→중→저 순환 |
| ← → | 이전/다음 챕터 | L | 레터박스 |
| F | 전체화면 | H | 도움말 |
| M | 음소거 | D | 디버그(FPS·파티클·GPU 메모리) |
| R | 처음부터 | | |

## 점검용 URL 파라미터

| 파라미터 | 의미 |
|---|---|
| `?autostart=1` | 시작 버튼 없이 바로 재생(소리는 첫 키/클릭 후 켜짐) |
| `?t=95` | 95초 지점부터 시작 · `&pause=1` 멈춘 채로 시작 |
| `?q=high\|mid\|low` | 시작 품질 · `?webgl=1` WebGL2 강제 · `?nosound=1` 소리 끄기 |
| `?debug=1` | 디버그 패널 표시 · `&gputime=1` GPU 시간 측정(WebGPU) |
| `?spike` | 컴퓨트 파티클 성능 스파이크 (`&n=500000` 개수 지정) |

## 파일 구조

```
config.js     모든 타이밍·색·크레딧·사운드·품질 설정 (여기만 고치면 됨)
main.js       부팅, 메인 루프, 키보드, 안전장치
timeline.js   디렉터: 마스터 시계, 씬 생명주기, 겹침(매치컷), 불릿타임
audio.js      Web Audio 실시간 합성 + 리미터 + 오디오 분석
engine/       renderer(폴백) · post(후처리) · camera(돌리/핸드헬드/쉐이크) · quality · clock · particles(GPU 컴퓨트) · ease
scenes/       _base.js(씬 기반 클래스) · _stub.js(빈 씬) · opening/ · ch1~ch7 · finale · credits · bridge
ui/           subtitle · keywordCard · hud · loader · overlays · style.css
vendor/three/ Three.js r186 (0.186.1, 오프라인 번들)     assets/fonts/ Black Han Sans + Pretendard (OFL)
```
