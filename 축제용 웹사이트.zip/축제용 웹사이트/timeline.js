// timeline.js — 디렉터(Director): 전체 타임라인을 지휘하는 마스터 시계
//
//  · 디렉터 시간 t(초): 자막·카드·플래시·챕터 길이를 정하는 "실시간". 0 ~ loopLength 를 반복한다.
//  · 월드 시간: 디렉터 dt 에 timeScale(불릿타임 곡선)을 곱한 값. 시뮬레이션·애니메이션 씬은 이 dt 를 쓴다.
//  · 씬 생명주기: warmup(로딩 때 1회) → start()(구간 진입) → update(t,dt)(매 프레임) → dispose()(구간 이탈)
//  · 겹침(overlap): 경계 시각 ± overlap/2 동안 이웃한 두 씬이 동시에 활성화 → 카메라가 섞이는 매치컷.
//  · 오류 격리: 어떤 씬이 예외를 던져도 그 씬만 꺼 두고(failed) 나머지 투어는 계속 진행한다.

import { ramp } from './engine/ease.js';

export class Director {
  /**
   * @param ctx      공용 컨텍스트 {scene, cam, post, audio, ui, quality, config, log ...}
   * @param defs     CONFIG.scenes
   * @param sceneObjs { id: SceneBase 인스턴스 }
   */
  constructor(ctx, defs, sceneObjs, loopLength) {
    this.ctx = ctx;
    this.defs = defs;
    this.scenes = defs.map((d) => ({ def: d, obj: sceneObjs[d.id], active: false, errors: 0, failed: false, weight: 0 }));
    this.total = loopLength;
    this.t = 0;
    this.playing = false;
    this.timeScale = 1;
    this.loopCount = 0;
    this.skipPoints = defs.filter((d) => d.skip).map((d) => d.start);
    this._justSeeked = true;
    this.onLoop = () => {};
    this.onSeek = () => {};
  }

  // ── 재생 제어 ──────────────────────────────────────────────
  play() { this.playing = true; }
  pause() { this.playing = false; }
  toggle() { this.playing = !this.playing; return this.playing; }

  /** 현재 시각이 속한 챕터(skip 지점) 인덱스 */
  get chapterIndex() {
    let idx = 0;
    for (let i = 0; i < this.skipPoints.length; i++) if (this.t >= this.skipPoints[i] - 1e-6) idx = i;
    return idx;
  }

  /** 지정 시각으로 이동. 활성 씬을 모두 정리하고 해당 시각의 "주 씬"만 새로 시작한다. */
  seek(t) {
    this._deactivateAll();
    this.t = Math.max(0, Math.min(t, this.total - 1e-3));
    this._justSeeked = true;
    this.ctx.cam.resetMotion();
    this.ctx.audio.stopAll(0.25);
    this.ctx.post.resetFx();
    this.onSeek(this.t);
  }
  restart() { this.seek(0); }
  nextChapter() {
    const i = this.chapterIndex;
    this.seek(this.skipPoints[(i + 1) % this.skipPoints.length]);
  }
  prevChapter() {
    const i = this.chapterIndex;
    const cur = this.skipPoints[i];
    // 챕터 시작 후 2초 넘게 지났으면 "그 챕터의 처음", 아니면 이전 챕터로
    this.seek(this.t - cur > 2 ? cur : this.skipPoints[(i - 1 + this.skipPoints.length) % this.skipPoints.length]);
  }

  // ── 가중치/시간 배율 ───────────────────────────────────────
  _weight(s, t) {
    const i = this.scenes.indexOf(s);
    const prev = this.scenes[i - 1], next = this.scenes[i + 1];
    // 이웃 씬이 실제로 활성일 때만 크로스페이드한다. (챕터 건너뛰기 직후·이웃 씬 오류 시에도 100% 비중으로 보이도록)
    // cutIn:'hard' = 공간이 전혀 다른 두 장면 사이의 "컷": 카메라를 섞으면 허공이 보이므로 0.1초 안에 끝나는 짧은 램프(사실상 컷)로 바꾼다(씬이 섬광·스캔 등으로 컷을 가려 준다)
    const dIn = prev ? (s.def.cutIn === 'hard' ? Math.min(prev.def.overlap, 0.1) : prev.def.overlap) : 0;
    const dOut = next ? (next.def.cutIn === 'hard' ? Math.min(s.def.overlap, 0.1) : s.def.overlap) : 0;
    const wIn = prev && prev.active ? ramp(t, s.def.start, dIn) : 1;
    const wOut = next && next.active ? 1 - ramp(t, s.def.end, dOut) : 1;
    return wIn * wOut;
  }

  /** 활성 씬들의 timeScaleAt 을 가중 평균 → 불릿타임 */
  _timeScale(t) {
    let sum = 0, w = 0;
    for (const s of this.scenes) {
      if (!s.active) continue;
      const sc = s.obj.timeScaleAt ? s.obj.timeScaleAt(t - s.def.start) : 1;
      sum += sc * s.weight; w += s.weight;
    }
    return w > 0 ? sum / w : 1;
  }

  // ── 활성 구간 판정 ─────────────────────────────────────────
  _shouldBeActive(s, t) {
    const i = this.scenes.indexOf(s);
    const prev = this.scenes[i - 1];
    const lead = prev ? prev.def.overlap / 2 : 0;       // 시작 전 미리 켜지는 시간
    const tail = s.def.overlap / 2;                      // 끝난 뒤 남아 있는 시간
    if (s.active) return t >= s.def.start - lead - 1e-6 && t < s.def.end + tail;
    // 새로 켜는 조건: 꼬리 구간으로는 "신규 활성화" 불가 (시크 직후 이전 씬이 되살아나는 것 방지)
    return t >= s.def.start - lead && t < s.def.end;
  }

  _activate(s) {
    if (s.failed) return;
    try {
      s.obj._begin();
      this.ctx.scene.add(s.obj.root);
      s.active = true;
    } catch (e) { this._fail(s, 'start', e); }
  }

  _deactivate(s) {
    if (!s.active && !s.obj.root.parent) return;
    try { s.obj._end(); } catch (e) { this.ctx.log('error', `[${s.def.id}] dispose 오류`, e); }
    this.ctx.scene.remove(s.obj.root);
    this.ctx.ui.hud.removeOwner(s.def.id);
    s.active = false; s.weight = 0;
  }
  _deactivateAll() { for (const s of this.scenes) this._deactivate(s); }

  _fail(s, where, e) {
    s.errors++;
    this.ctx.log('error', `[${s.def.id}] ${where} 오류 (${s.errors}/${this.ctx.config.safety.sceneErrorLimit})`, e);
    if (s.errors >= this.ctx.config.safety.sceneErrorLimit || where === 'start') {
      s.failed = true;                    // 이 씬의 연출만 생략하고 투어는 계속
      this._deactivate(s);
      this.ctx.log('warn', `[${s.def.id}] 씬 비활성화 — 다음 씬으로 진행합니다`);
    }
  }

  // ── 매 프레임 ──────────────────────────────────────────────
  /** @param dt 상한이 적용된 실제 경과 시간(초) */
  update(dt) {
    const { cam, audio } = this.ctx;
    const dReal = this.playing ? dt : 0;

    // 1) 시간 진행 (+ 루프)
    this.timeScale = this._timeScale(this.t);
    this.t += dReal;
    if (this.t >= this.total) {
      this._deactivateAll();
      this.t -= this.total; this.loopCount++;
      this._justSeeked = true;
      cam.resetMotion(); audio.stopAll(0.2);
      this.onLoop(this.loopCount);   // (루프 경계의 화이트 플래시는 bridge/sun 씬이 이어서 처리하므로 resetFx 하지 않는다)
    }
    const t = this.t;
    const dWorld = dReal * this.timeScale;
    this.ctx.u.time.value += dWorld;            // 공용 월드 시계 (절차적 애니메이션용)

    // 2) 활성/비활성 전환
    for (const s of this.scenes) {
      if (s.failed) continue;
      const want = this._shouldBeActive(s, t);
      if (want && !s.active) this._activate(s);
      else if (!want && s.active) this._deactivate(s);
    }

    // 3) 가중치 계산 후 씬 업데이트 (카메라 포즈 제출 포함)
    cam.begin();
    for (const s of this.scenes) {
      if (!s.active) continue;
      s.weight = this._weight(s, t);
      s.obj.weight = s.weight;
      try {
        s.obj.update(t - s.def.start, dWorld, dReal);
      } catch (e) { this._fail(s, 'update', e); }
    }
    cam.resolve(dWorld, dReal);
    this._justSeeked = false;
  }

  /** 디버그: 활성 씬 요약 */
  get activeInfo() { return this.scenes.filter((s) => s.active).map((s) => `${s.def.id}(${s.weight.toFixed(2)})`).join(' + ') || '-'; }
}
