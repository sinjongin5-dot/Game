@echo off
rem ──────────────────────────────────────────────────────────────
rem  start.bat — 더블클릭하면 로컬 서버를 켜고 크롬(기본 브라우저)으로 사이트를 엽니다.
rem  Node.js 가 있으면 serve.js, 없으면 Python 의 http.server 를 사용합니다.
rem  종료: 이 검은 창을 닫으면 서버가 꺼집니다.
rem ──────────────────────────────────────────────────────────────
chcp 65001 >nul
cd /d "%~dp0"
set PORT=8123

where node >nul 2>nul
if %errorlevel%==0 (
  start "" cmd /c "timeout /t 2 >nul & start http://localhost:%PORT%/"
  node serve.js %PORT%
  goto :eof
)

where python >nul 2>nul
if %errorlevel%==0 (
  start "" cmd /c "timeout /t 2 >nul & start http://localhost:%PORT%/"
  python -m http.server %PORT% --bind 127.0.0.1
  goto :eof
)

echo [오류] Node.js 또는 Python 이 설치되어 있지 않습니다.
echo        https://nodejs.org 에서 Node.js(LTS)를 설치한 뒤 다시 실행해 주세요.
pause
