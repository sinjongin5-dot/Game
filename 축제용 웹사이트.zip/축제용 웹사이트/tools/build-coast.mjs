// tools/build-coast.mjs — 해안선 벡터 데이터(data/coast.js) 생성 스크립트 (개발자용, 사이트 실행에는 불필요)
//
//  데이터 출처: Natural Earth (퍼블릭 도메인) — npm 패키지 world-atlas 의 land-110m / land-50m / land-10m (TopoJSON)
//  다시 만들려면 (임시 폴더에서):
//      npm i world-atlas topojson-client
//      node build-coast.mjs <이 프로젝트 경로>/data/coast.js
//
//  결과: 세 해상도의 육지 폴리곤을 0.005° 격자로 양자화해서 JS 배열로 저장한다.
//      world : 전 세계 110m (지구 전체 모습용)
//      asia  : 동아시아(경도 118~148, 위도 24~46) 50m  (S2~S3 접근 구간용)
//      korea : 한반도 주변(경도 122~132.5, 위도 32.2~40.2) 10m (급강하 구간용, 서해안 리아스식 해안까지)
//  지구 셰이더는 이 폴리곤을 캔버스에 그려 육지 마스크 텍스처를 "코드로" 만든다 → 외부 이미지 파일 불필요.

import fs from 'node:fs';
import { feature } from 'topojson-client';

const Q = 200;                                  // 1도 = 200 단위 (0.005°)
const outPath = process.argv[2] || './coast.js';
const load = (f) => JSON.parse(fs.readFileSync(new URL(`./node_modules/world-atlas/${f}`, import.meta.url)));

/** Sutherland–Hodgman: 폴리곤 링을 사각형으로 자른다 */
function clipRing(ring, [x0, y0, x1, y1]) {
  const edges = [
    { inside: (p) => p[0] >= x0, hit: (a, b) => [x0, a[1] + ((b[1] - a[1]) * (x0 - a[0])) / (b[0] - a[0])] },
    { inside: (p) => p[0] <= x1, hit: (a, b) => [x1, a[1] + ((b[1] - a[1]) * (x1 - a[0])) / (b[0] - a[0])] },
    { inside: (p) => p[1] >= y0, hit: (a, b) => [a[0] + ((b[0] - a[0]) * (y0 - a[1])) / (b[1] - a[1]), y0] },
    { inside: (p) => p[1] <= y1, hit: (a, b) => [a[0] + ((b[0] - a[0]) * (y1 - a[1])) / (b[1] - a[1]), y1] },
  ];
  let out = ring;
  for (const e of edges) {
    const inp = out; out = [];
    for (let i = 0; i < inp.length; i++) {
      const a = inp[i], b = inp[(i + 1) % inp.length];
      const ai = e.inside(a), bi = e.inside(b);
      if (ai && bi) out.push(b);
      else if (ai && !bi) out.push(e.hit(a, b));
      else if (!ai && bi) { out.push(e.hit(a, b)); out.push(b); }
    }
    if (!out.length) return [];
  }
  return out;
}

function encode(polys, box) {
  const res = [];
  for (const poly of polys) {
    const rings = [];
    for (let ring of poly) {
      if (box) ring = clipRing(ring.slice(0, -1), box);
      if (ring.length < 3) continue;
      const flat = []; let lx = null, ly = null;
      for (const [lon, lat] of ring) {
        const x = Math.round(lon * Q), y = Math.round(lat * Q);
        if (x === lx && y === ly) continue;                    // 연속 중복점 제거
        flat.push(x, y); lx = x; ly = y;
      }
      if (flat.length >= 6) rings.push(flat);
    }
    if (rings.length) res.push(rings);
  }
  return res;
}

function polysOf(file) {
  const topo = load(file);
  const f = feature(topo, topo.objects.land);
  const geoms = f.type === 'FeatureCollection' ? f.features.map((x) => x.geometry) : [f.geometry];
  const polys = [];
  for (const g of geoms) {
    if (g.type === 'Polygon') polys.push(g.coordinates);
    else if (g.type === 'MultiPolygon') polys.push(...g.coordinates);
  }
  return polys;
}

const data = {
  q: Q,
  boxes: { asia: [118, 24, 148, 46], korea: [122, 32.2, 132.5, 40.2] },
  world: encode(polysOf('land-110m.json'), null),
  asia: encode(polysOf('land-50m.json'), [118, 24, 148, 46]),
  korea: encode(polysOf('land-10m.json'), [122, 32.2, 132.5, 40.2]),
};

const body = JSON.stringify(data);
fs.writeFileSync(outPath,
`// data/coast.js — 자동 생성 파일 (tools/build-coast.mjs). 직접 수정하지 마세요.
// 출처: Natural Earth (퍼블릭 도메인), world-atlas 패키지의 land-110m / land-50m / land-10m.
// 좌표는 1도=${Q}단위(0.005°)로 양자화한 [lon0,lat0,lon1,lat1,...] 링 배열. 폴리곤 = 링 목록(첫 링=외곽, 나머지=구멍).
export const COAST = ${body};
`);
const count = (a) => a.reduce((s, p) => s + p.reduce((t, r) => t + r.length / 2, 0), 0);
console.log(`world ${count(data.world)} pts / asia ${count(data.asia)} pts / korea ${count(data.korea)} pts → ${(body.length / 1024).toFixed(0)} KB`);
