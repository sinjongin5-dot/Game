// ui/subtitle.js — 하단 중앙 자막. 디렉터 시간 t 의 "순수 함수"라서 일시정지·챕터 건너뛰기·루프에서도 상태가 꼬이지 않는다.

import { clamp } from '../engine/ease.js';

export class Subtitles {
  constructor(el, sceneDefs, cfg) {
    this.el = el;
    this.span = el.querySelector('span');
    this.fade = cfg.subtitleFade;
    el.parentElement.style.setProperty('--sub-size', `${cfg.subtitleHeightVh}vh`);
    // 모든 자막을 절대 시간(초)으로 펼쳐 둔다
    this.cues = [];
    for (const d of sceneDefs) for (const s of d.subtitles || []) this.cues.push({ start: d.start + s.at, end: d.start + s.at + s.dur, text: s.text });
    this._text = null;
  }

  update(t) {
    let cue = null;
    for (const c of this.cues) if (t >= c.start && t < c.end) { cue = c; break; }
    if (!cue) { if (this.el.style.opacity !== '0') this.el.style.opacity = '0'; return; }
    if (cue.text !== this._text) { this.span.textContent = cue.text; this._text = cue.text; }
    const a = Math.min(clamp((t - cue.start) / this.fade), clamp((cue.end - t) / this.fade));
    this.el.style.opacity = (a * a * (3 - 2 * a)).toFixed(3);
  }
}
