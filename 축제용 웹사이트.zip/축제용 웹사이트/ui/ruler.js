// ui/ruler.js — 우측 로그 스케일 눈금자 (Ch.1 파워스 오브 텐 줌인)
//  · 10⁻² m(연료 펠릿) → 10⁻¹⁵ m(핵자) 를 세로 눈금으로 보여 주고, 현재 시야 폭의 위치를 화살표로 표시한다.
//  · 씬이 매 프레임 ruler.set({ show, z }) 를 부르면 된다. z = log10(시야 폭[m]).  예) z=-2 → 1 cm, z=-10 → 0.1 nm
//  출처(크기): UO₂ 펠릿 지름·높이 ≈ 1 cm, UO₂ 결정 격자 상수 ≈ 0.547 nm, 원자 지름 ≈ 10⁻¹⁰ m, U-235 핵 지름 ≈ 15 fm (r≈1.2·A^(1/3) fm), 핵자 ≈ 1.7 fm.

import { clamp, smoothstep } from '../engine/ease.js';

const Z_TOP = -1.6, Z_BOT = -15.4;
const MARKS = [
  [-2, '연료 펠릿', '1 cm'], [-5, '결정 알갱이', '10 µm'], [-9.26, '결정 격자', '0.5 nm'], [-10, '원자', '0.1 nm'], [-13.8, '원자핵', '10 fm'], [-15, '핵자', '1 fm'],
];
const SUP = { '-': '⁻', 0: '⁰', 1: '¹', 2: '²', 3: '³', 4: '⁴', 5: '⁵', 6: '⁶', 7: '⁷', 8: '⁸', 9: '⁹' };
const sup = (n) => String(n).split('').map((c) => SUP[c] ?? c).join('');

export function formatMeters(m) {
  if (m >= 1e-2) return `${(m * 100).toFixed(1)} cm`;
  if (m >= 1e-3) return `${(m * 1e3).toFixed(1)} mm`;
  if (m >= 1e-6) return `${(m * 1e6).toFixed(1)} µm`;
  if (m >= 1e-9) return `${(m * 1e9).toFixed(1)} nm`;
  if (m >= 1e-12) return `${(m * 1e12).toFixed(1)} pm`;
  return `${(m * 1e15).toFixed(1)} fm`;
}

export class Ruler {
  constructor(el) {
    this.el = el;
    const y = (z) => ((Z_TOP - z) / (Z_TOP - Z_BOT)) * 100;                    // 0~100 (%)
    let html = '<div class="r-title">크기 눈금 (로그)</div><div class="r-bar">';
    for (let e = -2; e >= -15; e--) html += `<div class="r-tick" style="top:${y(e).toFixed(2)}%"><i></i><span>10${sup(e)} m</span></div>`;
    for (const [z, name, size] of MARKS) html += `<div class="r-mark" style="top:${y(z).toFixed(2)}%"><b>${name}</b><em>${size}</em></div>`;
    html += '<div class="r-now"><div class="r-arrow"></div><div class="r-label"></div></div></div>';
    el.innerHTML = html;
    this.now = el.querySelector('.r-now'); this.label = el.querySelector('.r-label');
    this.y = y; this.shown = 0; this._target = 0; this.z = -2;
  }

  set({ show, z }) { this._target = show ? 1 : 0; this.z = z; this._render(); }
  update() { this._render(); }

  _render() {
    this.shown += (this._target - this.shown) * 0.1;
    if (Math.abs(this.shown - this._target) < 0.003) this.shown = this._target;
    const s = smoothstep(this.shown);
    this.el.style.opacity = s.toFixed(3);
    this.el.style.transform = `translate(${((1 - s) * 130).toFixed(1)}%, -50%)`;
    if (s <= 0.001) return;
    const z = clamp(this.z, Z_BOT, Z_TOP);
    this.now.style.top = `${this.y(z).toFixed(2)}%`;
    this.label.textContent = `시야 폭 ≈ ${formatMeters(Math.pow(10, this.z))}`;
  }
}
