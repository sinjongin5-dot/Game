// ui/loader.js — 로딩 화면(진행률)과 시작 버튼

export class Loader {
  constructor() {
    this.root = document.getElementById('intro');
    this.fill = document.getElementById('loadfill');
    this.label = document.getElementById('loadlabel');
    this.btn = document.getElementById('startBtn');
    this.info = document.getElementById('sysinfo');
  }

  progress(p, text) {
    this.fill.style.width = `${Math.round(Math.min(1, Math.max(0, p)) * 100)}%`;
    if (text) this.label.textContent = text;
  }

  setInfo(text) { this.info.textContent = text; }

  /** 로딩 완료 → 시작 버튼 활성화. Promise 는 사용자가 시작을 눌렀을 때 resolve (오디오 정책: 클릭 제스처 필요) */
  ready(text = '준비 완료') {
    this.progress(1, text);
    this.btn.disabled = false;
    this.btn.focus();
    return new Promise((resolve) => {
      const go = () => { this.btn.removeEventListener('click', go); window.removeEventListener('keydown', onKey); resolve(); };
      const onKey = (e) => { if (e.code === 'Enter' || e.code === 'Space') { e.preventDefault(); go(); } };
      this.btn.addEventListener('click', go);
      window.addEventListener('keydown', onKey);
    });
  }

  hide() { this.root.classList.add('gone'); setTimeout(() => (this.root.style.display = 'none'), 1000); }
  show() { this.root.style.display = ''; this.root.classList.remove('gone'); }
}
