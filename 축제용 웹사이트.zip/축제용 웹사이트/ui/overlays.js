// ui/overlays.js — 크레딧, 토스트(짧은 안내), 디버그 패널, 도움말, 레터박스

import { clamp } from '../engine/ease.js';

/** 크레딧: credits 씬 구간(start~end) 동안 페이드 인/아웃. 문구는 CONFIG.credits */
export class Credits {
  constructor(el, config) {
    this.el = el;
    const d = config.scenes.find((s) => s.id === 'credits');
    this.start = d.start; this.end = d.end;
    const c = config.credits;
    this.hidden = c.show === false;                                  // 제작자를 밝히지 않는 설정이면 아무것도 그리지 않는다
    if (this.hidden) { el.innerHTML = ''; return; }
    el.innerHTML =
      `<div class="c-title">${config.title}</div>` +
      `<div class="c-school">${c.school} · ${c.club}</div>` +
      `<div class="c-row"><b>제작</b>${c.makers}</div>` +
      `<div class="c-row"><b>지도교사</b>${c.teacher}</div>`;
  }
  update(t) {
    if (this.hidden) return;
    const a = Math.min(clamp((t - this.start - 0.6) / 1.2), clamp((this.end - 0.6 - t) / 1.2));
    this.el.style.opacity = (a * a * (3 - 2 * a)).toFixed(3);
  }
}

export class Toast {
  constructor(el) { this.el = el; this._t = 0; }
  show(text, ms = 1400) {
    this.el.textContent = text; this.el.classList.add('show');
    clearTimeout(this._t); this._t = setTimeout(() => this.el.classList.remove('show'), ms);
  }
}

export class Help {
  constructor(el) {
    this.el = el;
    el.innerHTML = [
      ['Space', '일시정지 / 재생'], ['← →', '이전 / 다음 챕터'], ['F', '전체화면'], ['M', '음소거'],
      ['R', '처음부터'], ['Q', '품질 고/중/저 전환'], ['L', '레터박스'], ['H', '이 도움말'], ['D', '디버그(FPS·파티클)'],
    ].map(([k, v]) => `<div><kbd>${k}</kbd>${v}</div>`).join('');
  }
  toggle() { this.el.classList.toggle('hidden'); }
}

export class DebugPanel {
  constructor(el) { this.el = el; this.on = false; this._last = 0; }
  toggle() { this.on = !this.on; this.el.classList.toggle('show', this.on); return this.on; }
  /** lines: () => string[]  — 4Hz 로만 갱신해서 DOM 비용을 줄인다 */
  update(now, lines) {
    if (!this.on || now - this._last < 250) return;
    this._last = now; this.el.textContent = lines().join('\n');
  }
}

export function setLetterbox(on) { document.body.classList.toggle('has-letterbox', !!on); }
