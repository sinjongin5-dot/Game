// ui/hud.js — 다이제틱 HUD: 3D 오브젝트에 붙어 따라다니는 얇은 선 SF 스타일 홀로그램 라벨/수치
//
//  사용(씬 안에서):
//    this.hud.add({
//      id: 'mev', owner: this.id,                 // owner 를 씬 id 로 주면 씬이 끝날 때 자동 제거됨
//      anchor: someObject3D 또는 THREE.Vector3 또는 () => Vector3,
//      text: '약 200 MeV 방출' 또는 (t) => `${Math.round(200*p)} MeV`,    // 함수면 매 프레임 갱신(카운트업 가능)
//      sub: 'ENERGY RELEASED',                    // (선택) 작은 영문 보조 문구
//      offset: [90, -70],                         // 앵커에서 라벨까지의 픽셀 이동 (선을 그려 줌)
//      from: 70, to: 85,                          // (선택) 표시 구간(디렉터 시간). 앞뒤 0.4초 페이드
//      color: '#22e6ff',
//    });
//  DOM + CSS transform 만 쓰므로 글자가 선명하고 한글 폰트도 그대로 쓸 수 있다.

import * as THREE from 'three/webgpu';
import { clamp } from '../engine/ease.js';

const _v = new THREE.Vector3();

export class Hud {
  constructor(layer) { this.layer = layer; this.items = new Map(); }

  add(o) {
    this.remove(o.id);
    const off = o.offset || [80, -60];
    const el = document.createElement('div');
    el.className = 'hud-item';
    if (o.color) el.style.setProperty('--hud', o.color);
    el.innerHTML =
      `<svg width="1" height="1"><line x1="0" y1="0" x2="${off[0]}" y2="${off[1]}"></line></svg>` +
      `<div class="dot"></div><div class="txt" style="left:${off[0]}px;top:${off[1]}px;transform:translate(${off[0] < 0 ? '-100%' : '0'}, -100%)"><span class="main"></span>${o.sub ? `<small>${o.sub}</small>` : ''}</div>`;
    this.layer.appendChild(el);
    const it = { ...o, el, main: el.querySelector('.main'), _text: null };
    this.items.set(o.id, it);
    return it;
  }

  remove(id) { const it = this.items.get(id); if (it) { it.el.remove(); this.items.delete(id); } }
  removeOwner(owner) { for (const [id, it] of [...this.items]) if (it.owner === owner) this.remove(id); }
  clear() { for (const id of [...this.items.keys()]) this.remove(id); }

  /** 매 프레임 (t=디렉터 시간) */
  update(t, camera) {
    if (!this.items.size) return;
    const W = window.innerWidth, H = window.innerHeight;
    for (const it of this.items.values()) {
      const from = it.from ?? -Infinity, to = it.to ?? Infinity;
      let a = Math.min(clamp((t - from) / 0.4), clamp((to - t) / 0.4));

      // 앵커 월드 좌표
      const an = it.anchor;
      if (an && an.isObject3D) an.getWorldPosition(_v);
      else if (typeof an === 'function') _v.copy(an());
      else if (an) _v.copy(an);
      _v.project(camera);
      if (_v.z > 1 || _v.z < -1) a = 0;                      // 카메라 뒤쪽이면 숨김
      if (a <= 0.001) { if (it.el.style.opacity !== '0') it.el.style.opacity = '0'; continue; }

      const x = (_v.x * 0.5 + 0.5) * W, y = (-_v.y * 0.5 + 0.5) * H;
      it.el.style.transform = `translate(${x.toFixed(1)}px, ${y.toFixed(1)}px)`;
      it.el.style.opacity = a.toFixed(3);

      const text = typeof it.text === 'function' ? it.text(t) : it.text;
      if (text !== it._text) { it.main.textContent = text; it._text = text; }
    }
  }
}
