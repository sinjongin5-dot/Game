// ui/gauge.js — 우측 계기판: 증식계수 k (Ch.3)
//  · 반원 게이지(0.8 ~ 1.5): 왼쪽 파랑(미임계 k<1) → 가운데 연두(임계 k≈1) → 오른쪽 빨강(초임계 k>1)
//  · 씬이 매 프레임 gauge.set({ show: true, value: k }) 만 호출하면 슬라이드 인/아웃·바늘·색·문구를 알아서 처리한다.
//  출처(개념): 증식계수 k = 한 세대 중성자 수 대비 다음 세대 중성자 수의 비. k=1 임계(일정), k>1 초임계(증가), k<1 미임계(감소).

import { clamp, smoothstep } from '../engine/ease.js';

const K_MIN = 0.8, K_MAX = 1.5;
const CX = 100, CY = 100, R = 78;

function arcPath(a0, a1, r = R) {                       // 각도(도): 180 = 왼쪽 끝, 0 = 오른쪽 끝, 위쪽 반원
  const p = (a) => [CX + r * Math.cos((a * Math.PI) / 180), CY - r * Math.sin((a * Math.PI) / 180)];
  const [x0, y0] = p(a0), [x1, y1] = p(a1);
  return `M ${x0.toFixed(2)} ${y0.toFixed(2)} A ${r} ${r} 0 0 1 ${x1.toFixed(2)} ${y1.toFixed(2)}`;
}
const kToAngle = (k) => 180 - 180 * clamp((k - K_MIN) / (K_MAX - K_MIN));

export class Gauge {
  constructor(el) {
    this.el = el;
    const aOne = kToAngle(1.0);
    el.innerHTML =
      `<div class="g-title">증식계수 k</div>` +
      `<svg viewBox="0 0 200 118">` +
      `<path d="${arcPath(180, aOne + 1)}" stroke="#2f7bff" stroke-width="13" fill="none" opacity="0.85"/>` +
      `<path d="${arcPath(aOne + 1, aOne - 1)}" stroke="#7dff6a" stroke-width="15" fill="none"/>` +
      `<path d="${arcPath(aOne - 1, 0)}" stroke="#ff3b30" stroke-width="13" fill="none" opacity="0.85"/>` +
      `<g id="g-needle"><line x1="${CX}" y1="${CY}" x2="${CX - R + 6}" y2="${CY}" stroke="#fff" stroke-width="3.2" stroke-linecap="round"/><circle cx="${CX}" cy="${CY}" r="6" fill="#fff"/></g>` +
      `<text x="22" y="116" fill="#9fb8d8" font-size="10" text-anchor="middle">0.8</text><text x="100" y="22" fill="#9fb8d8" font-size="10" text-anchor="middle">1.0</text><text x="178" y="116" fill="#9fb8d8" font-size="10" text-anchor="middle">1.5</text>` +
      `</svg><div class="g-val"></div><div class="g-state"></div>`;
    this.needle = el.querySelector('#g-needle');
    this.val = el.querySelector('.g-val'); this.state = el.querySelector('.g-state');
    this.shown = 0; this.k = 1.0; this._target = 0;
  }

  /** @param show 표시 여부, value 현재 k */
  set({ show, value }) { this._target = show ? 1 : 0; this.k = value; this._render(); }

  /** 매 프레임(main 루프): 씬이 set() 을 더 이상 부르지 않아도 슬라이드 아웃이 끝까지 진행되도록 */
  update() { this._render(); }

  _render() {
    // 슬라이드 인/아웃: 목표값으로 부드럽게 접근(프레임 간격 무관한 근사)
    this.shown += (this._target - this.shown) * 0.12;
    if (Math.abs(this.shown - this._target) < 0.003) this.shown = this._target;
    const s = smoothstep(this.shown);
    this.el.style.opacity = s.toFixed(3);
    this.el.style.transform = `translate(${((1 - s) * 130).toFixed(1)}%, -50%)`;
    if (s <= 0.001) return;
    const k = clamp(this.k, K_MIN, K_MAX);
    this.needle.setAttribute('transform', `rotate(${(180 - kToAngle(k)).toFixed(2)} ${CX} ${CY})`);
    const near = Math.abs(this.k - 1.0) < 0.012;
    const col = near ? '#7dff6a' : this.k > 1 ? '#ff5a4a' : '#5aa0ff';
    this.val.textContent = `k = ${this.k.toFixed(2)}`; this.val.style.color = col;
    this.state.textContent = near ? '임계 · 안정' : this.k > 1 ? '초임계 · 반응 증가' : '미임계 · 반응 감소'; this.state.style.color = col;
  }
}
