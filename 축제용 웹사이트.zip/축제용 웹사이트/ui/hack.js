// ui/hack.js — 피날레 "해킹 → 블루스크린 → 되감기" 연출 (DOM 오버레이 + 후처리 글리치 + 효과음 일정)
//
//  ※ 이 파일이 만드는 것은 전부 "그림과 소리"뿐이다. 터미널 글자·블루스크린은 가짜 화면이고, 실제 네트워크 통신·시스템 접근은 전혀 하지 않는다.
//  시나리오(시각은 config.js 의 hack — 디렉터 시간):
//   t0        이상 징후: 화면이 가끔 찢기고(글리치), 터미널에 수상한 접속 기록이 한 줄씩 올라온다
//   wormStart 웜 확산: 3D 지구 위로 붉은 감염이 퍼지고(shared/worm.js), 오로라가 오염되고, 경보음 + 코드 비
//   chaos     화면 붕괴: 글리치 최대·모자이크·스트로브 문구
//   bsodStart 블루스크린: 섬광 → 가짜 오류 화면(진행률 0→100%). "만든 사람: 알 수 없음"
//   bsodEnd   되감기: VHS 되감기 화면 + 거꾸로 달리는 타임코드, 3D 는 감염·오로라가 거꾸로 풀리며 태양으로 돌아간다 → rewindEnd 순백 → 루프
//  update(t) 는 t(디렉터 시간)만의 함수라서 챕터 건너뛰기·루프에서도 안전하다. 효과음은 "한 번만" 울리고, 시간이 점프하면 지나간 소리는 건너뛴다.

import { clamp, lerp, smoothstep, easeInCubic } from '../engine/ease.js';
import { wormInfectedAt, WORM_NODES } from '../scenes/shared/worm.js';

const hash1 = (x) => { const s = Math.sin(x * 12.9898) * 43758.5453; return s - Math.floor(s); };

/** t 시점의 화면 FX 값 — 3D 씬(오로라 오염)과 후처리가 같은 함수를 쓴다 */
export function hackProfile(t, H) {
  const p = { glitch: 0, pixel: 0, vhs: 0, cor: 0 };
  if (!H || !H.enabled || t < H.t0 || t > H.rewindEnd + 0.3) return p;
  const wn = t - H.wormStart;
  if (t < H.wormStart) {                                                   // ① 이상 징후: 짧은 글리치 펄스가 점점 잦고 세게
    const pulses = [0.5, 1.9, 2.9, 3.6, 4.2, 4.6, 4.85];
    pulses.forEach((o, i) => { const d = t - (H.t0 + o); if (d >= 0 && d < 0.16) p.glitch = Math.max(p.glitch, 0.25 + 0.5 * (i / 6)); });
    p.cor = smoothstep((t - (H.t0 + 2.5)) / (H.wormStart - H.t0 - 2.5)) * 0.35;
  } else if (t < H.chaos) {                                                // ② 웜 확산
    const u = clamp(wn / (H.chaos - H.wormStart));
    p.glitch = Math.min(1, lerp(0.14, 0.55, Math.pow(u, 1.3)) + (hash1(Math.floor(t * 12)) > 0.78 ? 0.3 : 0));
    p.cor = lerp(0.35, 1.0, smoothstep(u));
  } else if (t < H.bsodStart) {                                            // ③ 붕괴
    p.glitch = 1; p.cor = 1;
    p.pixel = Math.sin(t * 38) > 0.2 ? 0.35 + 0.5 * clamp((t - H.chaos) / (H.bsodStart - H.chaos)) : 0;
  } else if (t < H.bsodEnd) {                                              // ④ 블루스크린(DOM 이 화면을 덮음) — 앞뒤 0.15초만 글리치
    p.cor = 1;
    if (t - H.bsodStart < 0.15 || H.bsodEnd - t < 0.15) p.glitch = 1;
  } else {                                                                 // ⑤ 되감기
    const u = clamp((t - H.bsodEnd) / (H.rewindEnd - H.bsodEnd));
    p.vhs = smoothstep((t - H.bsodEnd) / 0.4) * (1 - smoothstep((t - (H.rewindEnd - 0.6)) / 0.5));
    p.glitch = 0.55 * Math.exp(-(t - H.bsodEnd) * 3.0) + (hash1(Math.floor(t * 9)) > 0.9 ? 0.18 : 0);
    p.cor = 1 - smoothstep(u * 1.25);
  }
  return p;
}

const fmtTC = (sec) => {
  const s = Math.max(0, sec), m = Math.floor(s / 60), r = Math.floor(s % 60), f = Math.floor((s % 1) * 30);
  const z = (n) => String(n).padStart(2, '0');
  return `${z(m)}:${z(r)}:${z(f)}`;
};

export class HackSequence {
  constructor(el, config, post, audio, camRig) {
    this.el = el; this.H = config.hack; this.post = post; this.audio = audio; this.cam = camRig;
    this.last = -1; this.fired = new Set(); this.nextAlarm = 0; this.lineKey = '';
    const H = this.H;
    if (!H || !H.enabled) { el.style.display = 'none'; this.off = true; return; }
    const ai = H.aiName;
    // [출현 시각(t0 기준 초), 스타일, 글자(문자열 또는 함수)]
    const wn = (t) => wormInfectedAt(t - H.wormStart);
    this.lines = [
      [1.2, 'dim', '[kiosk] render loop ok — 144 fps'],
      [2.0, 'warn', '[net] unknown peer joined mesh :: 10.13.7.55'],
      [2.8, 'dim', '[net] handshake ...................... OK'],
      [3.5, 'warn', '[sec] integrity check ............. FAILED'],
      [4.2, 'bad', '[worm] payload loaded :: crawler/5.5'],
      [5.0, 'ai', `> ${ai} :: taking control of the node mesh`],
      [5.7, 'dim', '[worm] seed node: SEL (37.57N 126.98E)'],
      [6.3, 'bad', (t) => `[worm] nodes infected: ${String(wn(t)).padStart(2, '0')}/${WORM_NODES}`],
      [7.0, 'warn', '[kernel] privilege escalation ....... SUCCESS'],
      [7.6, 'bad', '[kernel] overwriting display driver ...'],
      [8.2, 'bad', '[!!] SYSTEM COMPROMISED'],
    ];
    el.innerHTML = `
      <div class="h-alarm"></div>
      <canvas class="h-rain"></canvas>
      <div class="h-term"><div class="h-term-head">● ${ai} // INTRUSION CONSOLE</div><pre class="h-term-body"></pre></div>
      <div class="h-stat"><div class="h-stat-k">NODES COMPROMISED</div><div class="h-stat-v">00 / ${WORM_NODES}</div><div class="h-stat-bar"><i></i></div><div class="h-stat-o">ORIGIN: UNKNOWN</div></div>
      <div class="h-banner"><span></span></div>
      <div class="h-black"></div>
      <div class="h-bsod">
        <div class="b-face">:(</div>
        <div class="b-t1">시스템에 문제가 발생하여 화면을 계속 표시할 수 없습니다.</div>
        <div class="b-t2">오류 정보를 수집하고 있습니다. <span class="b-pct">0</span>% 완료</div>
        <div class="b-box"><div>중지 코드: <b>${ai.replace(/[^A-Z0-9]/gi, '_')}_WORM_INTRUSION</b></div>
          <div>실패한 모듈: <b>display_driver.sys</b></div>
          <div>제작자 정보: <b>알 수 없음 (UNKNOWN)</b></div></div>
      </div>
      <div class="h-rew">
        <div class="r-top"><span class="r-icon">◀◀</span> REWIND</div>
        <div class="r-sub">RESTORING SESSION …</div>
        <div class="r-tc">00:00:00</div>
        <div class="r-bar"><i></i></div>
        <div class="r-trk r-trk1"></div><div class="r-trk r-trk2"></div>
      </div>`;
    const q = (s) => el.querySelector(s);
    this.r = { alarm: q('.h-alarm'), rain: q('.h-rain'), term: q('.h-term'), termBody: q('.h-term-body'), stat: q('.h-stat'), statV: q('.h-stat-v'), statBar: q('.h-stat-bar i'),
      banner: q('.h-banner'), bannerS: q('.h-banner span'), black: q('.h-black'), bsod: q('.h-bsod'), pct: q('.b-pct'), rew: q('.h-rew'), tc: q('.r-tc'), bar: q('.r-bar i'), t1: q('.r-trk1'), t2: q('.r-trk2'), sub: q('.r-sub') };
    this.rctx = this.r.rain.getContext('2d');
    this._cols = null;
    window.addEventListener('resize', () => { this._cols = null; });
  }

  _initRain() {
    const c = this.r.rain, w = Math.max(640, Math.floor(window.innerWidth / 1.6)), h = Math.max(360, Math.floor(window.innerHeight / 1.6));
    c.width = w; c.height = h;
    const size = 16, n = Math.floor(w / size);
    this._cols = Array.from({ length: n }, (_, i) => ({ x: i * size, y: -Math.random() * h, v: 140 + Math.random() * 360, len: 8 + Math.floor(Math.random() * 14), seed: Math.random() * 100 }));
    this._size = size;
  }

  _rain(t, a, dt) {
    const c = this.r.rain, g = this.rctx;
    if (!this._cols) this._initRain();
    g.clearRect(0, 0, c.width, c.height);
    if (a <= 0.01) return;
    g.font = `${this._size}px ui-monospace, Consolas, monospace`; g.textBaseline = 'top';
    const glyphs = '01ABCDEF0123456789アイウエオカキクケコ#$%&<>/=+';
    for (const col of this._cols) {
      col.y += col.v * dt; if (col.y - col.len * this._size > c.height) { col.y = -Math.random() * 200; col.v = 140 + Math.random() * 360; }
      for (let k = 0; k < col.len; k++) {
        const y = col.y - k * this._size; if (y < -this._size || y > c.height) continue;
        const gi = Math.floor(hash1(col.seed + k * 3.1 + Math.floor(t * 8 + k)) * glyphs.length);
        const f = 1 - k / col.len, mag = hash1(col.seed) > 0.62;
        g.fillStyle = k === 0 ? `rgba(255,255,255,${a})` : mag ? `rgba(255,50,150,${a * f * 0.9})` : `rgba(80,255,130,${a * f * 0.85})`;
        g.fillText(glyphs[gi], col.x, y);
      }
    }
  }

  /** 한 번만 실행(시간이 점프해서 이미 지나간 시각이면 소리 없이 표시만) */
  _once(key, at, t, fn) {
    if (this.fired.has(key)) return;
    if (t >= at) { this.fired.add(key); if (t - at < 0.6 && !this._jumped) fn(); }
  }

  update(t, dtReal = 0.016) {
    if (this.off) return;
    const H = this.H, r = this.r, a = this.audio, post = this.post;
    // 시간 점프(건너뛰기·루프) 처리
    if (t < this.last - 0.3 || t - this.last > 1.0) { this.fired.clear(); this.lineKey = ''; this._jumped = true; } else this._jumped = false;
    this.last = t;

    // ── 후처리 글리치 (항상 갱신: 구간 밖이면 0) ──
    const p = hackProfile(t, H);
    if (post.u.glitch) { post.u.glitch.value = p.glitch; post.u.pixel.value = p.pixel; post.u.vhs.value = p.vhs; }
    const active = t >= H.t0 - 0.2 && t <= H.rewindEnd + 0.5;
    if (!active) {
      if (this._shown) { this._shown = false; for (const k of ['alarm', 'term', 'stat', 'banner', 'black', 'bsod', 'rew']) r[k].style.display = 'none'; r.rain.style.display = 'none'; }
      return;
    }
    this._shown = true;
    if (!this._cols) { this._initRain(); this.rctx.font = `${this._size}px ui-monospace, Consolas, monospace`; this.rctx.fillText('01ABCDEF0123456789アイウエオカキクケコ#$%&<>/=+', 0, 0); this.rctx.clearRect(0, 0, 9999, 9999); }   // 글꼴/글리프 캐시를 미리 데워 첫 장면에서 끊기지 않게
    const h = t - H.t0, inBsod = t >= H.bsodStart && t < H.bsodEnd, inRew = t >= H.bsodEnd && t <= H.rewindEnd + 0.5;
    const show = (el, on, disp = 'block') => { const d = on ? disp : 'none'; if (el.style.display !== d) el.style.display = d; };

    // ── 터미널(왼쪽) + 감염 현황(오른쪽) ──
    const termOn = t >= H.t0 + 1.0 && t < H.bsodStart - 0.05;
    show(r.term, termOn); show(r.stat, t >= H.wormStart - 0.2 && t < H.bsodStart - 0.05);
    if (termOn) {
      const out = [];
      for (const [o, cls, txt] of this.lines) {
        if (h < o) continue;
        let s = typeof txt === 'function' ? txt(t) : txt;
        if (typeof txt !== 'function') s = s.slice(0, Math.floor((h - o) * 70) + 1);
        out.push(`<span class="${cls}">${s.replace(/</g, '&lt;')}</span>`);
      }
      const html = out.slice(-12).join('\n') + ((Math.floor(t * 3) % 2) ? '<span class="cur">█</span>' : '');
      if (html !== this.lineKey) { this.lineKey = html; r.termBody.innerHTML = html; }
      const n = wormInfectedAt(t - H.wormStart);
      r.statV.textContent = `${String(n).padStart(2, '0')} / ${WORM_NODES}`;
      r.statBar.style.width = `${(n / WORM_NODES * 100).toFixed(1)}%`;
    }
    // 경고 점멸(붉은 비네트): 웜 확산~붕괴
    const alarmOn = t >= H.wormStart && t < H.bsodStart - 0.05;
    show(r.alarm, alarmOn);
    if (alarmOn) r.alarm.style.opacity = (0.35 + 0.35 * Math.sin(t * 11)).toFixed(2);

    // ── 중앙 문구 ──
    let bt = '', bc = '';
    if (t >= H.wormStart && t < H.wormStart + 1.6) { bt = '침입 감지'; bc = 'b-red'; }
    else if (t >= H.wormStart + 2.0 && t < H.wormStart + 3.2) { bt = '시스템을 장악하는 중…'; bc = 'b-mag'; }
    else if (t >= H.chaos && t < H.bsodStart - 0.05) { bt = ['SYSTEM COMPROMISED', '시스템 장악', 'ACCESS GRANTED'][Math.floor(t * 14) % 3]; bc = 'b-strobe'; }
    else if (inRew && t < H.bsodEnd + 1.4) { bt = '되감는 중…'; bc = 'b-cyan'; }
    show(r.banner, !!bt, 'flex');
    if (bt) { if (r.bannerS.textContent !== bt) r.bannerS.textContent = bt; if (r.banner.className !== `h-banner ${bc}`) r.banner.className = `h-banner ${bc}`; }

    // ── 마트릭스 비(웜 확산 후반~붕괴) ──
    const rainA = (t >= H.wormStart + 0.8 && t < H.bsodStart - 0.05) ? clamp((t - H.wormStart - 0.8) / 1.5) * 0.85 : 0;
    show(r.rain, rainA > 0, 'block');
    if (rainA > 0) this._rain(t, rainA, Math.min(dtReal, 0.05));

    // ── 블루스크린 ──
    const preBlack = t >= H.bsodStart - 0.1 && t < H.bsodStart;
    show(r.black, preBlack);
    const flick = (t - H.bsodStart < 0.3) ? (Math.floor(t * 40) % 2 === 0) : true;                       // 켜질 때 번쩍번쩍
    const endFlick = (H.bsodEnd - t < 0.25) ? (Math.floor(t * 40) % 2 === 0) : true;
    show(r.bsod, inBsod && flick && endFlick);
    if (inBsod) {
      const u = clamp((t - H.bsodStart - 0.3) / (H.bsodEnd - H.bsodStart - 0.8));
      const pct = Math.min(100, Math.floor(u * 100 + Math.sin(u * 17) * 3));
      if (r.pct.textContent !== String(Math.max(0, pct))) r.pct.textContent = String(Math.max(0, pct));
    }

    // ── 되감기 HUD ──
    show(r.rew, inRew && t < H.rewindEnd + 0.4);
    if (inRew) {
      const u = clamp((t - H.bsodEnd) / (H.rewindEnd - H.bsodEnd));
      const fake = H.fakeDuration * (1 - Math.pow(u, 1.5));
      r.tc.textContent = fmtTC(fake);
      r.bar.style.width = `${(fake / H.fakeDuration * 100).toFixed(1)}%`;
      r.t1.style.top = `${(((t * 0.55) % 1) * 100).toFixed(1)}%`; r.t2.style.top = `${(((t * 0.37 + 0.4) % 1) * 100).toFixed(1)}%`;
      r.rew.style.opacity = (1 - smoothstep((t - (H.rewindEnd - 0.5)) / 0.4)).toFixed(2);
      const ic = r.rew.querySelector('.r-icon'); ic.style.opacity = (Math.floor(t * 3.5) % 2) ? '1' : '0.25';
    }

    // ── 효과음·카메라 흔들림·섬광 (한 번씩) ──
    const rel = (o) => H.t0 + o;
    [0.5, 1.9, 2.9, 3.6, 4.2, 4.6, 4.85].forEach((o, i) => this._once(`pre${i}`, rel(o), t, () => a.hit({ freq: 2600 + i * 300, level: 0.14 + 0.03 * i, decay: 0.07, noise: 1.0 })));
    for (let i = 0; i < this.lines.length; i++) this._once(`ln${i}`, rel(this.lines[i][0]), t, () => a.ping({ freq: this.lines[i][1] === 'ai' ? 1760 : this.lines[i][1] === 'bad' ? 520 : 2400, level: this.lines[i][1] === 'ai' ? 0.1 : 0.03, decay: this.lines[i][1] === 'ai' ? 1.4 : 0.08 }));
    this._once('worm', H.wormStart, t, () => { a.riser({ dur: 3.4, from: 120, to: 3600, level: 0.22 }); a.hit({ freq: 46, level: 0.5, decay: 1.5, noise: 0.5 }); this.cam.shake(0.5); });
    if (t >= H.wormStart && t < H.bsodStart - 0.2 && t > this.nextAlarm && !this._jumped) { this.nextAlarm = t + 0.34; a.ping({ freq: Math.floor(t / 0.34) % 2 ? 1046 : 784, level: 0.06, decay: 0.28 }); }
    this._once('chaos', H.chaos, t, () => { a.hit({ freq: 3200, level: 0.4, decay: 0.5, noise: 1.0 }); a.riser({ dur: 0.9, from: 400, to: 7000, level: 0.3 }); });
    if (t >= H.chaos && t < H.bsodStart - 0.1 && !this._jumped && Math.floor(t * 10) !== this._cShake) { this._cShake = Math.floor(t * 10); this.cam.shake(0.35); a.hit({ freq: 2000 + Math.random() * 2500, level: 0.16, decay: 0.05, noise: 1.0 }); }
    this._once('cut', H.bsodStart - 0.12, t, () => { post.flashPulse(1.0, 9); a.stopAll(0.04); a.hit({ freq: 70, level: 0.4, decay: 0.25, noise: 0.8 }); });
    this._once('bsod', H.bsodStart + 0.2, t, () => { a.ping({ freq: 440, level: 0.12, decay: 0.9 }); });
    this._once('bsodHum', H.bsodStart + 0.5, t, () => { this.hum = a.drone({ freqs: [55, 82.4], level: 0.06, cutoff: 200, fadeIn: 0.6, detune: 3 }); });
    this._once('rew0', H.bsodEnd - 0.02, t, () => { this.hum?.stop(0.1); post.flashPulse(0.8, 5); a.hit({ freq: 48, level: 0.6, decay: 1.8, noise: 0.5 }); a.whoosh({ dur: 2.2, from: 6500, to: 250, level: 0.3 }); });
    this._once('rew1', H.bsodEnd + 1.6, t, () => a.whoosh({ dur: 2.0, from: 7000, to: 300, level: 0.26 }));
    this._once('rew2', H.bsodEnd + 3.4, t, () => { a.whoosh({ dur: 2.2, from: 8000, to: 350, level: 0.3 }); a.riser({ dur: 3.0, from: 200, to: 5200, level: 0.2 }); });
  }
}
