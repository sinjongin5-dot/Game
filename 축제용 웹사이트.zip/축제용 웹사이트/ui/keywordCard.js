// ui/keywordCard.js — 좌측 하단 키워드 카드. 챕터 시작 시 슬라이드 인 → 8초 유지 → 슬라이드 아웃.
// 자막과 마찬가지로 디렉터 시간 t 의 순수 함수.

import { clamp, easeOutCubic, easeInOutCubic } from '../engine/ease.js';

export class KeywordCards {
  constructor(host, sceneDefs, cfg) {
    this.host = host;
    this.slide = cfg.cardSlide;
    this.dur = cfg.cardDuration;
    this.cards = [];
    for (const d of sceneDefs) for (const c of d.cards || []) this.cards.push({ start: d.start + c.at, items: c.items });
    this.el = document.createElement('div');
    this.el.className = 'card';
    host.appendChild(this.el);
    this._cur = null;
    this._onShow = null;         // (card) → 효과음 등을 연결할 수 있는 콜백
  }

  update(t) {
    let card = null;
    for (const c of this.cards) if (t >= c.start && t < c.start + this.dur + this.slide) { card = c; break; }
    if (!card) { if (this._cur) { this._cur = null; this.el.style.opacity = '0'; this.el.style.transform = 'translateX(-120%)'; } return; }

    if (card !== this._cur) {
      this._cur = card;
      this.el.innerHTML = `<div class="tag">KEYWORD</div>` +
        card.items.map((i) => `<div class="row"><div class="k">${i.k}</div><div class="v">${i.v}</div></div>`).join('');
      this._onShow?.(card);
    }
    const p = t - card.start;
    let x;                                              // 0 = 완전히 보임, 1 = 완전히 화면 밖
    if (p < this.slide) x = 1 - easeOutCubic(clamp(p / this.slide));
    else if (p > this.dur) x = easeInOutCubic(clamp((p - this.dur) / this.slide));
    else x = 0;
    this.el.style.transform = `translateX(${(-x * 120).toFixed(2)}%)`;
    this.el.style.opacity = (1 - x * 0.6).toFixed(3);
  }
}
